/**
 * Hook for managing backend health status
 */

import { useState, useEffect, useCallback } from 'react';
import { HealthResponse, ServiceHealth, ServiceStatus, ApiError } from '../types/api';
import api from '../services/api';

interface UseHealthReturn {
  health: ServiceHealth | null;
  loading: boolean;
  error: ApiError | null;
  lastChecked: Date | null;
  refresh: () => Promise<void>;
}

export const useHealth = (autoRefreshInterval?: number): UseHealthReturn => {
  const [health, setHealth] = useState<ServiceHealth | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<ApiError | null>(null);
  const [lastChecked, setLastChecked] = useState<Date | null>(null);

  const mapServiceStatus = (status: string): ServiceStatus => {
    switch (status.toLowerCase()) {
      case 'healthy':
        return 'healthy';
      case 'configured':
        return 'configured';
      case 'connected':
        return 'connected';
      case 'disconnected':
        return 'disconnected';
      case 'not_configured':
        return 'not_configured';
      case 'unavailable':
        return 'unavailable';
      case 'offline':
        return 'offline';
      default:
        return 'unknown';
    }
  };

  const checkHealth = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await api.get<HealthResponse>('/health');
      const data = response.data;
      
      const mappedHealth: ServiceHealth = {
        backend: mapServiceStatus(data.services.backend),
        groq: mapServiceStatus(data.services.groq),
        neo4j: mapServiceStatus(data.services.neo4j),
      };

      setHealth(mappedHealth);
      setLastChecked(new Date());
    } catch (err: any) {
      console.error('Health check failed:', err);
      
      const errorMessage =
        err?.response?.data?.detail ||
        err?.response?.data?.message ||
        (err?.request && !err?.response ? 'Unable to connect to the backend service' : null) ||
        err?.message ||
        'Health check failed';
      
      const apiError: ApiError = {
        message: errorMessage,
        status: err?.response?.status || 0,
        details: err?.response?.data || err,
      };
      setError(apiError);
      
      // Set all services as offline when health check fails
      setHealth({
        backend: 'offline',
        groq: 'unknown',
        neo4j: 'unknown',
      });
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial health check
  useEffect(() => {
    checkHealth();
  }, [checkHealth]);

  // Auto-refresh interval
  useEffect(() => {
    if (!autoRefreshInterval) return;

    const interval = setInterval(() => {
      checkHealth();
    }, autoRefreshInterval);

    return () => clearInterval(interval);
  }, [checkHealth, autoRefreshInterval]);

  return {
    health,
    loading,
    error,
    lastChecked,
    refresh: checkHealth,
  };
};

export default useHealth;