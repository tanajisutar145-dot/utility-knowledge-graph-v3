/**
 * Centralized API client for backend integration
 */

import axios, { AxiosInstance } from 'axios';
import {
  HealthResponse,
  GraphRAGRequest,
  GraphRAGResponse,
  SimpleGraphRAGResponse,
  RetrievalRequest,
  RetrievalResult,
} from '../types/api';
import { DashboardSummaryResponse } from '../types/dashboard';
import {
  GraphOverviewResponse,
  GraphExploreResponse,
  GraphNodeDetailResponse,
  GraphNeighborsResponse,
  GraphFilters,
} from '../types/graph';
import {
  DocumentOverviewResponse,
  DocumentListResponse,
  DocumentDetailResponse,
  DocumentUploadResult,
  DocumentFilters,
} from '../types/documents';
import {
  AssetOverviewResponse,
  AssetListResponse,
  AssetDetailResponse,
  AssetFilters,
} from '../types/assets';

// Centralized Axios client taking advantage of CRA proxy
const api: AxiosInstance = axios.create({
  baseURL: '',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Health endpoint - hits GET /health through CRA proxy
export const getHealth = async (): Promise<HealthResponse> => {
  const response = await api.get<HealthResponse>('/health');
  return response.data;
};

// Dashboard summary endpoint - hits GET /api/dashboard/summary
export const getDashboardSummary = async (): Promise<DashboardSummaryResponse> => {
  const response = await api.get<DashboardSummaryResponse>('/api/dashboard/summary');
  return response.data;
};

// Knowledge Graph Explorer endpoints
export const getGraphOverview = async (): Promise<GraphOverviewResponse> => {
  const response = await api.get<GraphOverviewResponse>('/api/graph/overview');
  return response.data;
};

export const exploreGraph = async (filters?: GraphFilters): Promise<GraphExploreResponse> => {
  const params: Record<string, any> = {};
  if (filters?.node_label) params.node_label = filters.node_label;
  if (filters?.rel_type) params.rel_type = filters.rel_type;
  if (filters?.query) params.query = filters.query;
  if (filters?.limit) params.limit = filters.limit;

  const response = await api.get<GraphExploreResponse>('/api/graph/explore', { params });
  return response.data;
};

export const getGraphNodeDetail = async (nodeId: string): Promise<GraphNodeDetailResponse> => {
  const response = await api.get<GraphNodeDetailResponse>(`/api/graph/node/${encodeURIComponent(nodeId)}`);
  return response.data;
};

export const getGraphNodeNeighbors = async (
  nodeId: string,
  limit: number = 50,
  relType?: string
): Promise<GraphNeighborsResponse> => {
  const params: Record<string, any> = { limit };
  if (relType) params.rel_type = relType;

  const response = await api.get<GraphNeighborsResponse>(
    `/api/graph/node/${encodeURIComponent(nodeId)}/neighbors`,
    { params }
  );
  return response.data;
};

// GraphRAG endpoints
export const askGraphRAG = async (request: GraphRAGRequest): Promise<GraphRAGResponse> => {
  const response = await api.post<GraphRAGResponse>('/api/intelligence/ask', request);
  return response.data;
};

export const askGraphRAGSimple = async (request: GraphRAGRequest): Promise<SimpleGraphRAGResponse> => {
  const response = await api.post<SimpleGraphRAGResponse>('/api/intelligence/ask/simple', request);
  return response.data;
};

// Semantic retrieval endpoint
export const retrieveSemanticResults = async (request: RetrievalRequest): Promise<RetrievalResult> => {
  const response = await api.post<RetrievalResult>('/api/search/retrieve', request);
  return response.data;
};

// Document Management endpoints
export const getDocumentsOverview = async (): Promise<DocumentOverviewResponse> => {
  const response = await api.get<DocumentOverviewResponse>('/api/documents/overview');
  return response.data;
};

export const listDocuments = async (params?: DocumentFilters & { skip?: number; limit?: number }): Promise<DocumentListResponse> => {
  const queryParams: Record<string, any> = {};
  if (params?.search) queryParams.search = params.search;
  if (params?.document_type) queryParams.document_type = params.document_type;
  if (params?.skip !== undefined) queryParams.skip = params.skip;
  if (params?.limit !== undefined) queryParams.limit = params.limit;

  const response = await api.get<DocumentListResponse>('/api/documents/', { params: queryParams });
  return response.data;
};

export const getDocumentDetail = async (documentId: string): Promise<DocumentDetailResponse> => {
  const response = await api.get<DocumentDetailResponse>(`/api/documents/${encodeURIComponent(documentId)}`);
  return response.data;
};

export const uploadDocument = async (file: File): Promise<DocumentUploadResult> => {
  const formData = new FormData();
  formData.append('file', file);
  const response = await api.post<DocumentUploadResult>('/api/documents/upload', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });
  return response.data;
};

export const deleteDocument = async (documentId: string): Promise<{ message: string; document_id: string }> => {
  const response = await api.delete<{ message: string; document_id: string }>(`/api/documents/${encodeURIComponent(documentId)}`);
  return response.data;
};

// Asset Management endpoints
export const getAssetsOverview = async (): Promise<AssetOverviewResponse> => {
  const response = await api.get<AssetOverviewResponse>('/api/assets/overview');
  return response.data;
};

export const listAssets = async (params?: AssetFilters & { skip?: number; limit?: number }): Promise<AssetListResponse> => {
  const queryParams: Record<string, any> = {};
  if (params?.search) queryParams.search = params.search;
  if (params?.asset_class) queryParams.asset_class = params.asset_class;
  if (params?.criticality) queryParams.criticality = params.criticality;
  if (params?.operational_status) queryParams.operational_status = params.operational_status;
  if (params?.unit_id) queryParams.unit_id = params.unit_id;
  if (params?.skip !== undefined) queryParams.skip = params.skip;
  if (params?.limit !== undefined) queryParams.limit = params.limit;

  const response = await api.get<AssetListResponse>('/api/assets/', { params: queryParams });
  return response.data;
};

export const getAssetDetail = async (assetId: string): Promise<AssetDetailResponse> => {
  const response = await api.get<AssetDetailResponse>(`/api/assets/${encodeURIComponent(assetId)}`);
  return response.data;
};

// Check if backend is reachable
export const isBackendReachable = async (): Promise<boolean> => {
  try {
    await getHealth();
    return true;
  } catch {
    return false;
  }
};

// Backward-compatible apiClient object
export const apiClient = {
  get: <T>(url: string) => api.get<T>(url).then(r => r.data),
  post: <T>(url: string, data?: any) => api.post<T>(url, data).then(r => r.data),
  getHealth,
  getDashboardSummary,
  getGraphOverview,
  exploreGraph,
  getGraphNodeDetail,
  getGraphNodeNeighbors,
  askGraphRAG,
  askGraphRAGSimple,
  retrieveSemanticResults,
  getDocumentsOverview,
  listDocuments,
  getDocumentDetail,
  uploadDocument,
  deleteDocument,
  getAssetsOverview,
  listAssets,
  getAssetDetail,
  isBackendReachable,
};

export { api };
export default api;