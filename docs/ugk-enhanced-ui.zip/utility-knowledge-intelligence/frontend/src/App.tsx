import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

import Layout from './components/layout/Layout';
import Dashboard from './pages/dashboard/Dashboard';
import GraphView from './pages/graph/GraphView';
import SearchPage from './pages/search/SearchPage';
import IntelligencePage from './pages/intelligence/IntelligencePage';
import DocumentsPage from './pages/documents/DocumentsPage';
import AssetsPage from './pages/assets/AssetsPage';
import HealthPage from './pages/health/HealthPage';

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
    background: {
      default: '#f5f5f5',
    },
  },
  typography: {
    h4: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 500,
    },
  },
  components: {
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        },
      },
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/graph" element={<GraphView />} />
            <Route path="/search" element={<SearchPage />} />
            <Route path="/intelligence" element={<IntelligencePage />} />
            <Route path="/documents" element={<DocumentsPage />} />
            <Route path="/assets" element={<AssetsPage />} />
            <Route path="/health" element={<HealthPage />} />
          </Routes>
        </Layout>
      </Router>
    </ThemeProvider>
  );
}

export default App;