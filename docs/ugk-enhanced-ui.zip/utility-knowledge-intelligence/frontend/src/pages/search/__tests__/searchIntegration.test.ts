import { retrieveSemanticResults, api } from '../../../services/api';
import { RetrievalRequest, RetrievalResult } from '../../../types/api';

describe('Semantic Search API and Logic Integration', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  const mockSuccessfulResponse: RetrievalResult = {
    query: 'Which inspections recorded abnormal vibration?',
    semantic_results: [
      {
        chunk_id: 'DOC-001_chunk_000',
        document_id: 'DOC-001',
        document_title: 'Routine GT Inspection - Unit 1 GT Gas Turbine',
        text: 'Routine inspection performed on Unit 1 GT Gas Turbine (AST-001) revealed concerning vibration signatures.',
        score: 0.8852847218513489,
        source: 'Field Inspector',
        metadata: {
          created_date: '2026-08-08T08:12:57.413643000+00:00',
          source_reference: 'INS-001',
          document_type: 'inspection_report',
        },
      },
      {
        chunk_id: 'DOC-007_chunk_000',
        document_id: 'DOC-007',
        document_title: 'Preventive Maintenance Completion - Generator Inspection',
        text: 'Completed quarterly preventive maintenance inspection on Unit 1 ST Generator per maintenance plan MP-015.',
        score: 0.8535959720611572,
        source: 'Senior Technician',
        metadata: {
          created_date: '2026-09-10T14:20:00.000000000+00:00',
          source_reference: 'MP-015',
          document_type: 'maintenance_report',
        },
      },
    ],
    graph_evidence: {
      entities: [
        {
          entity_id: 'AST-001',
          entity_type: 'Asset',
          properties: {
            name: 'Unit 1 GT Gas Turbine',
            model: 'M501F',
            operational_status: 'operational',
          },
        },
        {
          entity_id: 'AST-002',
          entity_type: 'Asset',
          properties: {
            name: 'Unit 1 ST Generator',
            model: 'LM6000',
            operational_status: 'operational',
          },
        },
      ],
      relationships: [
        {
          source_id: 'DOC-001',
          target_id: 'AST-001',
          relationship_type: 'ABOUT_ASSET',
          source_type: 'Document',
          target_type: 'Asset',
          properties: {},
        },
      ],
    },
    metadata: {
      execution_time: 0.145,
      top_k: 5,
      graph_depth: 1,
      min_similarity: 0.0,
      retrieval_method: 'vector+graph',
      semantic_results_count: 2,
      graph_entities_count: 2,
      graph_relationships_count: 1,
    },
  };

  it('sends correct request payload to POST /api/search/retrieve', async () => {
    const postSpy = jest.spyOn(api, 'post').mockResolvedValueOnce({ data: mockSuccessfulResponse });

    const request: RetrievalRequest = {
      query: 'Which inspections recorded abnormal vibration?',
      top_k: 5,
      graph_depth: 1,
      min_similarity: 0.0,
      include_metadata: true,
    };

    const result = await retrieveSemanticResults(request);

    expect(postSpy).toHaveBeenCalledWith('/api/search/retrieve', request);
    expect(result).toBeDefined();
    expect(result.query).toBe('Which inspections recorded abnormal vibration?');
    expect(result.semantic_results).toHaveLength(2);
    expect(result.semantic_results[0].chunk_id).toBe('DOC-001_chunk_000');
    expect(result.semantic_results[0].score).toBeCloseTo(0.8853);
    expect(result.graph_evidence.entities).toHaveLength(2);
  });

  it('handles backend 500 error without converting to empty results', async () => {
    jest.spyOn(api, 'post').mockRejectedValueOnce(new Error('Vector index search failed'));

    await expect(
      retrieveSemanticResults({
        query: 'test query',
        top_k: 5,
      })
    ).rejects.toThrow('Vector index search failed');
  });

  it('parses empty results when no chunks match similarity threshold', async () => {
    const emptyResponse: RetrievalResult = {
      query: 'obscure condition',
      semantic_results: [],
      graph_evidence: { entities: [], relationships: [] },
      metadata: {
        execution_time: 0.02,
        top_k: 5,
        graph_depth: 1,
        min_similarity: 0.95,
        semantic_results_count: 0,
        graph_entities_count: 0,
        graph_relationships_count: 0,
      },
    };

    jest.spyOn(api, 'post').mockResolvedValueOnce({ data: emptyResponse });

    const result = await retrieveSemanticResults({
      query: 'obscure condition',
      min_similarity: 0.95,
    });

    expect(result.semantic_results).toHaveLength(0);
    expect(result.graph_evidence.entities).toHaveLength(0);
    expect(result.metadata.semantic_results_count).toBe(0);
  });

  it('validates stale response prevention pattern', async () => {
    let activeRequestId = 0;

    // Simulate query 1 (slow)
    const reqId1 = ++activeRequestId;
    // Simulate query 2 (fast)
    const reqId2 = ++activeRequestId;

    let appliedResult: string | null = null;

    // Fast request finishes first
    if (reqId2 === activeRequestId) {
      appliedResult = 'Result from query 2';
    }

    // Slow request finishes later
    if (reqId1 === activeRequestId) {
      appliedResult = 'Result from query 1';
    }

    // Active result must be from Query 2, never overwritten by Query 1
    expect(appliedResult).toBe('Result from query 2');
  });
});
