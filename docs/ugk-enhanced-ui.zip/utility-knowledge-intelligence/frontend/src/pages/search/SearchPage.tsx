import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Box,
  Grid,
  Card,
  Typography,
  Button,
  CircularProgress,
  Alert,
  AlertTitle,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  FilterAltOff as ResetFilterIcon,
  FindInPage as EmptySearchIcon,
  HelpOutline as HelpIcon,
} from '@mui/icons-material';

import { useLocation } from 'react-router-dom';

import { RetrievalRequest, RetrievalResult } from '../../types/api';
import { retrieveSemanticResults, isBackendReachable } from '../../services/api';
import { SearchHeader } from './components/SearchHeader';
import { SearchControls } from './components/SearchControls';
import { SearchSummary } from './components/SearchSummary';
import { SearchResultList } from './components/SearchResultList';
import { SearchEvidencePanel } from './components/SearchEvidencePanel';

const SearchPage: React.FC = () => {
  const location = useLocation();

  // Query and configuration state
  const [query, setQuery] = useState<string>('');
  const [executedQuery, setExecutedQuery] = useState<string>('');
  const [config, setConfig] = useState<Required<Omit<RetrievalRequest, 'query' | 'include_metadata'>>>({
    top_k: 5,
    graph_depth: 1,
    min_similarity: 0.0,
  });

  // Retrieval state
  const [retrievalResult, setRetrievalResult] = useState<RetrievalResult | null>(null);
  const [selectedChunkId, setSelectedChunkId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  // Backend connectivity status
  const [isBackendHealthy, setIsBackendHealthy] = useState<boolean | null>(null);

  // In-flight request ID tracker to prevent stale responses
  const activeRequestIdRef = useRef<number>(0);

  // Check backend health on initial mount
  useEffect(() => {
    let isMounted = true;
    const checkHealth = async () => {
      try {
        const reachable = await isBackendReachable();
        if (isMounted) {
          setIsBackendHealthy(reachable);
        }
      } catch {
        if (isMounted) {
          setIsBackendHealthy(false);
        }
      }
    };
    checkHealth();
    return () => {
      isMounted = false;
    };
  }, []);

  // Execute semantic retrieval
  const handleSearch = useCallback(
    async (queryOverride?: string) => {
      const targetQuery = (queryOverride !== undefined ? queryOverride : query).trim();
      if (!targetQuery) return;

      const currentRequestId = ++activeRequestIdRef.current;
      setIsLoading(true);
      setSearchError(null);

      const requestPayload: RetrievalRequest = {
        query: targetQuery,
        top_k: config.top_k,
        graph_depth: config.graph_depth,
        min_similarity: config.min_similarity,
        include_metadata: true,
      };

      try {
        const result = await retrieveSemanticResults(requestPayload);

        // Ensure this response is for the most recent in-flight request
        if (currentRequestId === activeRequestIdRef.current) {
          setRetrievalResult(result);
          setExecutedQuery(targetQuery);
          setSearchError(null);

          // Auto-select the highest ranked result if available
          if (result.semantic_results && result.semantic_results.length > 0) {
            setSelectedChunkId(result.semantic_results[0].chunk_id);
          } else {
            setSelectedChunkId(null);
          }
        }
      } catch (err: any) {
        if (currentRequestId === activeRequestIdRef.current) {
          console.error('Semantic search error:', err);
          const errorMsg =
            err?.response?.data?.detail ||
            err?.message ||
            'Failed to retrieve semantic search results. Please check backend connection and retry.';
          setSearchError(errorMsg);
          setRetrievalResult(null);
          setSelectedChunkId(null);
        }
      } finally {
        if (currentRequestId === activeRequestIdRef.current) {
          setIsLoading(false);
        }
      }
    },
    [query, config]
  );

  // Auto-populate and trigger search if URL search param is present (e.g. from Dashboard or Asset page)
  const lastParamRef = useRef<string | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const qParam = params.get('q') || params.get('query');
    if (qParam && qParam.trim() && qParam.trim() !== lastParamRef.current) {
      lastParamRef.current = qParam.trim();
      setQuery(qParam.trim());
      handleSearch(qParam.trim());
    }
  }, [location.search, handleSearch]);

  // Determine currently selected result item
  const selectedResult =
    retrievalResult?.semantic_results?.find((r) => r.chunk_id === selectedChunkId) || null;

  return (
    <Box
      sx={{
        width: '100%',
        maxWidth: 1600,
        mx: 'auto',
        p: { xs: 2, sm: 3 },
      }}
    >
      {/* 1. Header */}
      <SearchHeader isBackendHealthy={isBackendHealthy} />

      {/* 2. Search Input & Controls */}
      <SearchControls
        query={query}
        onQueryChange={setQuery}
        config={config}
        onConfigChange={setConfig}
        onSearch={handleSearch}
        isLoading={isLoading}
      />

      {/* 3. Error State */}
      {searchError && (
        <Alert
          severity="error"
          sx={{ mb: 3, borderRadius: 2 }}
          action={
            <Button
              color="inherit"
              size="small"
              startIcon={<RefreshIcon />}
              onClick={() => handleSearch()}
            >
              Retry
            </Button>
          }
        >
          <AlertTitle sx={{ fontWeight: 700 }}>Search Retrieval Failed</AlertTitle>
          {searchError}
        </Alert>
      )}

      {/* 4. Loading State */}
      {isLoading && (
        <Card
          elevation={0}
          sx={{
            p: 6,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 2,
            bgcolor: '#ffffff',
            border: '1px solid #e2e8f0',
            borderRadius: 2,
            minHeight: 280,
          }}
        >
          <CircularProgress size={36} sx={{ color: '#0f766e' }} />
          <Typography variant="subtitle1" sx={{ fontWeight: 600, color: '#334155' }}>
            Embedding Query & Searching Vector Index...
          </Typography>
          <Typography variant="body2" sx={{ color: '#64748b', maxWidth: 460, textAlign: 'center' }}>
            Transforming query to 384-dimensional vector with BAAI/bge-small-en-v1.5 and traversing
            Neo4j chunk vector index with depth {config.graph_depth} graph expansion.
          </Typography>
        </Card>
      )}

      {/* 5. Results & Evidence Layout */}
      {!isLoading && retrievalResult && (
        <>
          {/* Summary Bar */}
          <SearchSummary result={retrievalResult} />

          {/* Results check */}
          {retrievalResult.semantic_results && retrievalResult.semantic_results.length > 0 ? (
            <Grid container spacing={3}>
              {/* Left Column: Ranked Results List */}
              <Grid item xs={12} md={7} lg={7}>
                <SearchResultList
                  results={retrievalResult.semantic_results}
                  selectedChunkId={selectedChunkId}
                  onSelectResult={setSelectedChunkId}
                  graphEvidence={retrievalResult.graph_evidence}
                  activeQuery={executedQuery}
                />
              </Grid>

              {/* Right Column: Evidence & Graph Context */}
              <Grid item xs={12} md={5} lg={5}>
                <SearchEvidencePanel
                  selectedResult={selectedResult}
                  graphEvidence={retrievalResult.graph_evidence}
                  activeQuery={executedQuery}
                />
              </Grid>
            </Grid>
          ) : (
            /* No Results Found State */
            <Card
              elevation={0}
              sx={{
                p: 5,
                bgcolor: '#ffffff',
                border: '1px solid #e2e8f0',
                borderRadius: 2,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                textAlign: 'center',
                gap: 2,
              }}
            >
              <EmptySearchIcon sx={{ fontSize: 52, color: '#94a3b8' }} />
              <Typography variant="h6" sx={{ fontWeight: 700, color: '#334155' }}>
                No Matching Semantic Evidence Found
              </Typography>
              <Typography variant="body2" sx={{ color: '#64748b', maxWidth: 520, lineHeight: 1.6 }}>
                No document chunks satisfied the current search criteria for "{executedQuery}".
                {config.min_similarity > 0 &&
                  ` The minimum similarity threshold is currently set to ${(
                    config.min_similarity * 100
                  ).toFixed(0)}%.`}
              </Typography>
              {config.min_similarity > 0 && (
                <Button
                  variant="outlined"
                  startIcon={<ResetFilterIcon />}
                  onClick={() => {
                    const newConfig = { ...config, min_similarity: 0.0 };
                    setConfig(newConfig);
                    // Re-run search with 0.0 threshold
                    const currentReq = ++activeRequestIdRef.current;
                    setIsLoading(true);
                    retrieveSemanticResults({
                      query: executedQuery,
                      top_k: newConfig.top_k,
                      graph_depth: newConfig.graph_depth,
                      min_similarity: 0.0,
                      include_metadata: true,
                    })
                      .then((res) => {
                        if (currentReq === activeRequestIdRef.current) {
                          setRetrievalResult(res);
                          if (res.semantic_results?.length > 0) {
                            setSelectedChunkId(res.semantic_results[0].chunk_id);
                          }
                        }
                      })
                      .catch((err) => {
                        if (currentReq === activeRequestIdRef.current) {
                          setSearchError(err?.message || 'Failed to retry search');
                        }
                      })
                      .finally(() => {
                        if (currentReq === activeRequestIdRef.current) {
                          setIsLoading(false);
                        }
                      });
                  }}
                  sx={{
                    color: '#0f766e',
                    borderColor: '#0f766e',
                    textTransform: 'none',
                    fontWeight: 600,
                  }}
                >
                  Reset Threshold to 0% and Retry
                </Button>
              )}
            </Card>
          )}
        </>
      )}

      {/* 6. Initial Welcome State (Before any search performed) */}
      {!isLoading && !retrievalResult && !searchError && (
        <Card
          elevation={0}
          sx={{
            p: 4,
            bgcolor: '#ffffff',
            border: '1px solid #e2e8f0',
            borderRadius: 2,
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2 }}>
            <HelpIcon sx={{ color: '#0f766e', fontSize: 24 }} />
            <Typography variant="h6" sx={{ fontWeight: 700, color: '#0f172a' }}>
              How Semantic Search Works
            </Typography>
          </Box>
          <Typography variant="body2" sx={{ color: '#475569', lineHeight: 1.7, mb: 3 }}>
            Unlike standard keyword matching, semantic search translates your query into a dense mathematical
            vector representation using the <code>BAAI/bge-small-en-v1.5</code> embedding model. It then performs
            approximate nearest-neighbor cosine similarity search over ingested utility document chunks inside
            Neo4j, followed by relational knowledge graph expansion to surface linked assets, components,
            failure events, inspections, and work orders.
          </Typography>

          <Grid container spacing={2}>
            <Grid item xs={12} sm={4}>
              <Box
                sx={{
                  p: 2,
                  bgcolor: '#f8fafc',
                  border: '1px solid #e2e8f0',
                  borderRadius: 1.5,
                  height: '100%',
                }}
              >
                <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#0f766e', mb: 0.5 }}>
                  1. Natural Phrasing
                </Typography>
                <Typography variant="caption" sx={{ color: '#64748b', lineHeight: 1.5, display: 'block' }}>
                  Ask questions in plain English such as "Which inspections recorded abnormal vibration?" or
                  "What evidence exists for compressor blade failure?"
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={12} sm={4}>
              <Box
                sx={{
                  p: 2,
                  bgcolor: '#f8fafc',
                  border: '1px solid #e2e8f0',
                  borderRadius: 1.5,
                  height: '100%',
                }}
              >
                <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#0f766e', mb: 0.5 }}>
                  2. Vector Similarity
                </Typography>
                <Typography variant="caption" sx={{ color: '#64748b', lineHeight: 1.5, display: 'block' }}>
                  Chunks are ranked by cosine similarity score. Higher percentages represent closer semantic
                  alignment with your inquiry.
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={12} sm={4}>
              <Box
                sx={{
                  p: 2,
                  bgcolor: '#f8fafc',
                  border: '1px solid #e2e8f0',
                  borderRadius: 1.5,
                  height: '100%',
                }}
              >
                <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#0f766e', mb: 0.5 }}>
                  3. Connected Evidence
                </Typography>
                <Typography variant="caption" sx={{ color: '#64748b', lineHeight: 1.5, display: 'block' }}>
                  Select any result to inspect full source text and see corresponding graph entities (assets,
                  work orders, failures) connected in Neo4j.
                </Typography>
              </Box>
            </Grid>
          </Grid>
        </Card>
      )}
    </Box>
  );
};

export default SearchPage;