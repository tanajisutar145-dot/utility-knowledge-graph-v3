import React, { useState } from 'react';
import {
  Box,
  Card,
  TextField,
  Button,
  IconButton,
  Chip,
  Typography,
  Collapse,
  Grid,
  Slider,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  CircularProgress,
} from '@mui/material';
import {
  Search as SearchIcon,
  Tune as TuneIcon,
  Clear as ClearIcon,
  RestartAlt as ResetIcon,
  LightbulbOutlined as IdeaIcon,
} from '@mui/icons-material';
import { RetrievalRequest } from '../../../types/api';

const EXAMPLE_QUERIES = [
  'Which inspections recorded abnormal vibration?',
  'What evidence exists for compressor blade failure?',
  'Which documents describe mechanical seal failures?',
  'What historical observations show heat-rate degradation?',
  'Which maintenance records are associated with failed assets?',
];

interface SearchControlsProps {
  query: string;
  onQueryChange: (q: string) => void;
  config: Required<Omit<RetrievalRequest, 'query' | 'include_metadata'>>;
  onConfigChange: (newConfig: Required<Omit<RetrievalRequest, 'query' | 'include_metadata'>>) => void;
  onSearch: (customQuery?: string) => void;
  isLoading: boolean;
}

export const SearchControls: React.FC<SearchControlsProps> = ({
  query,
  onQueryChange,
  config,
  onConfigChange,
  onSearch,
  isLoading,
}) => {
  const [showConfig, setShowConfig] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleSubmit = (overrideQuery?: string) => {
    const targetQuery = (overrideQuery !== undefined ? overrideQuery : query).trim();
    if (!targetQuery) {
      setValidationError('Please enter a search query before submitting.');
      return;
    }
    setValidationError(null);
    onSearch(overrideQuery);
  };

  const handleResetDefaults = () => {
    onConfigChange({
      top_k: 5,
      graph_depth: 1,
      min_similarity: 0.0,
    });
  };

  const isConfigModified =
    config.top_k !== 5 || config.graph_depth !== 1 || config.min_similarity !== 0.0;

  return (
    <Card
      elevation={0}
      sx={{
        p: 2.5,
        mb: 2.5,
        bgcolor: '#ffffff',
        border: '1px solid #e2e8f0',
        borderRadius: 2,
      }}
    >
      {/* Search Input Box */}
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
        <TextField
          id="semantic-search-input"
          label="Natural Language Query"
          placeholder="e.g., Which inspections recorded abnormal vibration?"
          multiline
          minRows={2}
          maxRows={4}
          value={query}
          onChange={(e) => {
            onQueryChange(e.target.value);
            if (validationError && e.target.value.trim()) {
              setValidationError(null);
            }
          }}
          onKeyDown={handleKeyDown}
          error={!!validationError}
          helperText={
            validationError ||
            'Tip: Use natural language phrasing. Press Ctrl+Enter to search quickly.'
          }
          fullWidth
          disabled={isLoading}
          InputProps={{
            endAdornment: query ? (
              <IconButton
                size="small"
                onClick={() => {
                  onQueryChange('');
                  setValidationError(null);
                }}
                disabled={isLoading}
                sx={{ alignSelf: 'flex-start', mt: 0.5, color: '#94a3b8' }}
              >
                <ClearIcon fontSize="small" />
              </IconButton>
            ) : undefined,
            sx: {
              fontSize: '0.9375rem',
              lineHeight: 1.5,
              '& .MuiOutlinedInput-notchedOutline': {
                borderColor: '#cbd5e1',
              },
              '&:hover .MuiOutlinedInput-notchedOutline': {
                borderColor: '#0f766e',
              },
              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                borderColor: '#0f766e',
              },
            },
          }}
        />

        {/* Action Buttons */}
        <Box
          sx={{
            display: 'flex',
            flexDirection: { xs: 'column', sm: 'row' },
            justifyContent: 'space-between',
            alignItems: { xs: 'stretch', sm: 'center' },
            gap: 1.5,
          }}
        >
          {/* Config Toggle */}
          <Button
            size="small"
            startIcon={<TuneIcon sx={{ fontSize: 18 }} />}
            onClick={() => setShowConfig((prev) => !prev)}
            sx={{
              color: isConfigModified ? '#0f766e' : '#64748b',
              fontWeight: 600,
              textTransform: 'none',
              bgcolor: isConfigModified ? 'rgba(15, 118, 110, 0.08)' : 'transparent',
              alignSelf: { xs: 'flex-start', sm: 'center' },
              '&:hover': {
                bgcolor: 'rgba(15, 118, 110, 0.12)',
              },
            }}
          >
            {showConfig ? 'Hide Search Controls' : 'Search Parameters'}
            {isConfigModified && (
              <Chip
                label="Custom"
                size="small"
                sx={{
                  ml: 1,
                  height: 18,
                  fontSize: '0.6875rem',
                  bgcolor: '#0f766e',
                  color: '#ffffff',
                }}
              />
            )}
          </Button>

          {/* Search Button */}
          <Button
            id="semantic-search-submit"
            variant="contained"
            disabled={isLoading || !query.trim()}
            onClick={() => handleSubmit()}
            startIcon={
              isLoading ? (
                <CircularProgress size={18} color="inherit" />
              ) : (
                <SearchIcon sx={{ fontSize: 20 }} />
              )
            }
            sx={{
              bgcolor: '#0f766e',
              color: '#ffffff',
              fontWeight: 600,
              textTransform: 'none',
              px: 3,
              py: 1,
              borderRadius: 1.5,
              boxShadow: '0 1px 3px rgba(15, 118, 110, 0.3)',
              '&:hover': {
                bgcolor: '#115e59',
              },
              '&.Mui-disabled': {
                bgcolor: '#e2e8f0',
                color: '#94a3b8',
              },
            }}
          >
            {isLoading ? 'Searching...' : 'Search'}
          </Button>
        </Box>

        {/* Backend Supported Controls Panel */}
        <Collapse in={showConfig}>
          <Box
            sx={{
              mt: 1.5,
              p: 2,
              bgcolor: '#f8fafc',
              border: '1px solid #e2e8f0',
              borderRadius: 1.5,
            }}
          >
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 600, color: '#334155' }}>
                Backend Retrieval Parameters
              </Typography>
              {isConfigModified && (
                <Button
                  size="small"
                  startIcon={<ResetIcon sx={{ fontSize: 16 }} />}
                  onClick={handleResetDefaults}
                  sx={{ color: '#64748b', textTransform: 'none', fontSize: '0.75rem' }}
                >
                  Reset Defaults
                </Button>
              )}
            </Box>

            <Grid container spacing={3}>
              {/* Top K */}
              <Grid item xs={12} sm={4}>
                <Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                    <Typography variant="caption" sx={{ color: '#475569', fontWeight: 600 }}>
                      Result Limit (top_k)
                    </Typography>
                    <Typography variant="caption" sx={{ color: '#0f766e', fontWeight: 700 }}>
                      {config.top_k} results
                    </Typography>
                  </Box>
                  <Slider
                    value={config.top_k}
                    min={1}
                    max={20}
                    step={1}
                    valueLabelDisplay="auto"
                    onChange={(_, val) =>
                      onConfigChange({ ...config, top_k: val as number })
                    }
                    sx={{
                      color: '#0f766e',
                      '& .MuiSlider-thumb': { bgcolor: '#0f766e' },
                    }}
                  />
                  <Typography variant="caption" sx={{ color: '#94a3b8', fontSize: '0.7rem' }}>
                    Supported range: 1 to 20 (backend limit)
                  </Typography>
                </Box>
              </Grid>

              {/* Min Similarity */}
              <Grid item xs={12} sm={4}>
                <Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                    <Typography variant="caption" sx={{ color: '#475569', fontWeight: 600 }}>
                      Min Similarity Threshold
                    </Typography>
                    <Typography variant="caption" sx={{ color: '#0f766e', fontWeight: 700 }}>
                      {(config.min_similarity * 100).toFixed(0)}%
                    </Typography>
                  </Box>
                  <Slider
                    value={config.min_similarity}
                    min={0.0}
                    max={1.0}
                    step={0.05}
                    valueLabelDisplay="auto"
                    valueLabelFormat={(val) => `${(val * 100).toFixed(0)}%`}
                    onChange={(_, val) =>
                      onConfigChange({ ...config, min_similarity: val as number })
                    }
                    sx={{
                      color: '#0f766e',
                      '& .MuiSlider-thumb': { bgcolor: '#0f766e' },
                    }}
                  />
                  <Typography variant="caption" sx={{ color: '#94a3b8', fontSize: '0.7rem' }}>
                    0.0 returns all ranked results; higher values filter noise
                  </Typography>
                </Box>
              </Grid>

              {/* Graph Expansion Depth */}
              <Grid item xs={12} sm={4}>
                <FormControl fullWidth size="small">
                  <InputLabel id="graph-depth-label" sx={{ fontSize: '0.8125rem' }}>
                    Graph Expansion Depth
                  </InputLabel>
                  <Select
                    labelId="graph-depth-label"
                    value={config.graph_depth}
                    label="Graph Expansion Depth"
                    onChange={(e) =>
                      onConfigChange({ ...config, graph_depth: Number(e.target.value) })
                    }
                    sx={{ fontSize: '0.875rem' }}
                  >
                    <MenuItem value={0}>0 — Chunks Only (No Graph)</MenuItem>
                    <MenuItem value={1}>1 — Direct Entities (Default)</MenuItem>
                    <MenuItem value={2}>2 — 2-Hop Traversal</MenuItem>
                    <MenuItem value={3}>3 — 3-Hop Deep Traversal</MenuItem>
                  </Select>
                </FormControl>
                <Typography variant="caption" sx={{ color: '#94a3b8', fontSize: '0.7rem', mt: 0.5, display: 'block' }}>
                  Depth of entity relationships expanded from documents
                </Typography>
              </Grid>
            </Grid>
          </Box>
        </Collapse>

        {/* Suggested Example Queries */}
        <Box sx={{ mt: 1 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, mb: 1 }}>
            <IdeaIcon sx={{ fontSize: 16, color: '#f59e0b' }} />
            <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 600 }}>
              Suggested query examples:
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
            {EXAMPLE_QUERIES.map((example) => (
              <Chip
                key={example}
                label={example}
                size="small"
                onClick={() => {
                  onQueryChange(example);
                  setValidationError(null);
                }}
                disabled={isLoading}
                sx={{
                  bgcolor: query === example ? 'rgba(15, 118, 110, 0.12)' : '#f1f5f9',
                  color: query === example ? '#0f766e' : '#475569',
                  fontWeight: query === example ? 600 : 400,
                  fontSize: '0.75rem',
                  border: query === example ? '1px solid #0f766e' : '1px solid #e2e8f0',
                  cursor: 'pointer',
                  '&:hover': {
                    bgcolor: 'rgba(15, 118, 110, 0.08)',
                    color: '#0f766e',
                    borderColor: '#0f766e',
                  },
                }}
              />
            ))}
          </Box>
        </Box>
      </Box>
    </Card>
  );
};
