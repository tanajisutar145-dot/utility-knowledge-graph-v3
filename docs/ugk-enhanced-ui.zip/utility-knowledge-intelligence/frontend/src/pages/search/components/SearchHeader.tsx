import React from 'react';
import { Box, Typography, Chip, Tooltip } from '@mui/material';
import {
  TravelExplore as SearchIcon,
  CheckCircleOutline as ReadyIcon,
  CloudOff as OfflineIcon,
} from '@mui/icons-material';

interface SearchHeaderProps {
  isBackendHealthy: boolean | null;
}

export const SearchHeader: React.FC<SearchHeaderProps> = ({ isBackendHealthy }) => {
  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: { xs: 'column', sm: 'row' },
        justifyContent: 'space-between',
        alignItems: { xs: 'flex-start', sm: 'center' },
        mb: 2.5,
        gap: 1.5,
      }}
    >
      <Box>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: 38,
              height: 38,
              borderRadius: 1.5,
              bgcolor: 'rgba(15, 118, 110, 0.1)',
              color: '#0f766e',
            }}
          >
            <SearchIcon sx={{ fontSize: 24 }} />
          </Box>
          <Typography
            variant="h4"
            sx={{
              fontSize: { xs: '1.5rem', sm: '1.75rem' },
              fontWeight: 700,
              color: '#0f172a',
              letterSpacing: '-0.02em',
            }}
          >
            Semantic Search
          </Typography>
        </Box>
        <Typography
          variant="body2"
          sx={{
            color: '#64748b',
            mt: 0.5,
            maxWidth: 720,
            fontSize: '0.875rem',
            lineHeight: 1.5,
          }}
        >
          Query utility engineering records, inspections, and operational reports using natural-language
          vector embeddings (BAAI/bge-small-en-v1.5) with connected Neo4j graph evidence expansion.
        </Typography>
      </Box>

      {/* Backend & Vector Index Status */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        {isBackendHealthy === null ? (
          <Chip
            size="small"
            label="Checking Index..."
            variant="outlined"
            sx={{ borderColor: '#cbd5e1', color: '#64748b' }}
          />
        ) : isBackendHealthy ? (
          <Tooltip title="Neo4j chunk vector index 'chunk_embedding_index' and retrieval service are active">
            <Chip
              size="small"
              icon={<ReadyIcon sx={{ fontSize: '15px !important', color: '#0f766e !important' }} />}
              label="Vector Index Active"
              sx={{
                bgcolor: 'rgba(15, 118, 110, 0.08)',
                color: '#0f766e',
                fontWeight: 600,
                fontSize: '0.75rem',
                border: '1px solid rgba(15, 118, 110, 0.25)',
              }}
            />
          </Tooltip>
        ) : (
          <Tooltip title="Backend API is currently unreachable. Check backend connection.">
            <Chip
              size="small"
              icon={<OfflineIcon sx={{ fontSize: '15px !important', color: '#dc2626 !important' }} />}
              label="Backend Unavailable"
              sx={{
                bgcolor: 'rgba(239, 68, 68, 0.08)',
                color: '#dc2626',
                fontWeight: 600,
                fontSize: '0.75rem',
                border: '1px solid rgba(239, 68, 68, 0.25)',
              }}
            />
          </Tooltip>
        )}
      </Box>
    </Box>
  );
};
