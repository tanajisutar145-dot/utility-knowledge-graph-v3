import React from 'react';
import { GraphEvidence, GraphEntity, GraphRelationship } from '../../../types/api';

/**
 * Format a similarity score (0.0 to 1.0) as a clean percentage string.
 */
export const formatSimilarityScore = (score: number | undefined | null): string => {
  if (score === undefined || score === null || isNaN(score)) {
    return '0.0%';
  }
  const clamped = Math.max(0, Math.min(1, score));
  return `${(clamped * 100).toFixed(1)}%`;
};

/**
 * Format retrieval execution time in milliseconds or seconds.
 */
export const formatExecutionTime = (seconds: number | undefined | null): string => {
  if (seconds === undefined || seconds === null || isNaN(seconds)) {
    return '0 ms';
  }
  if (seconds < 1) {
    return `${Math.round(seconds * 1000)} ms`;
  }
  return `${seconds.toFixed(2)} s`;
};

/**
 * Format ISO date string into readable local format.
 */
export const formatDate = (dateString?: string): string => {
  if (!dateString) return 'N/A';
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return d.toLocaleString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateString;
  }
};

/**
 * Highlight query terms in snippet as a visual aid.
 * Does not imply lexical matching is equivalent to semantic ranking.
 */
export const highlightQueryTerms = (text: string, query: string): React.ReactNode => {
  if (!text || !query) return text;

  // Extract non-stopword tokens of length >= 3
  const stopWords = new Set([
    'what', 'which', 'where', 'when', 'who', 'how', 'why',
    'the', 'and', 'for', 'are', 'is', 'was', 'were', 'that',
    'this', 'with', 'from', 'have', 'has', 'had', 'does', 'did',
  ]);

  const tokens = query
    .toLowerCase()
    .split(/[\s,?.!;:()"]+/)
    .filter((token) => token.length >= 3 && !stopWords.has(token));

  if (tokens.length === 0) return text;

  // Build regex pattern safely escaping characters
  const escapedTokens = tokens.map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  const regex = new RegExp(`(${escapedTokens.join('|')})`, 'gi');

  const parts = text.split(regex);
  return (
    <>
      {parts.map((part, i) => {
        const isMatch = tokens.some((t) => t.toLowerCase() === part.toLowerCase());
        if (isMatch) {
          return (
            <mark
              key={i}
              style={{
                backgroundColor: 'rgba(254, 240, 138, 0.65)',
                color: '#713f12',
                borderRadius: '3px',
                padding: '0 2px',
                fontWeight: 600,
              }}
            >
              {part}
            </mark>
          );
        }
        return part;
      })}
    </>
  );
};

/**
 * Extract entities directly or indirectly linked to a specific document.
 */
export const extractLinkedEntities = (
  documentId: string,
  graphEvidence?: GraphEvidence
): GraphEntity[] => {
  if (!graphEvidence || !graphEvidence.relationships || !graphEvidence.entities) {
    return [];
  }

  const linkedIds = new Set<string>();
  graphEvidence.relationships.forEach((rel) => {
    if (rel.source_id === documentId) {
      linkedIds.add(rel.target_id);
    } else if (rel.target_id === documentId) {
      linkedIds.add(rel.source_id);
    }
  });

  return graphEvidence.entities.filter((entity) => linkedIds.has(entity.entity_id));
};

/**
 * Extract relationships linked to a specific document.
 */
export const extractLinkedRelationships = (
  documentId: string,
  graphEvidence?: GraphEvidence
): GraphRelationship[] => {
  if (!graphEvidence || !graphEvidence.relationships) {
    return [];
  }

  return graphEvidence.relationships.filter(
    (rel) => rel.source_id === documentId || rel.target_id === documentId
  );
};
