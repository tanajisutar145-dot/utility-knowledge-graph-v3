import {
  formatSimilarityScore,
  formatExecutionTime,
  formatDate,
  extractLinkedEntities,
  extractLinkedRelationships,
} from '../searchUtils';
import { GraphEvidence } from '../../../../types/api';

describe('searchUtils', () => {
  describe('formatSimilarityScore', () => {
    it('formats valid similarity scores as percentages', () => {
      expect(formatSimilarityScore(0.88528)).toBe('88.5%');
      expect(formatSimilarityScore(0.5)).toBe('50.0%');
      expect(formatSimilarityScore(1.0)).toBe('100.0%');
      expect(formatSimilarityScore(0.0)).toBe('0.0%');
    });

    it('clamps out-of-bounds scores', () => {
      expect(formatSimilarityScore(1.25)).toBe('100.0%');
      expect(formatSimilarityScore(-0.1)).toBe('0.0%');
    });

    it('handles null, undefined, and NaN gracefully', () => {
      expect(formatSimilarityScore(undefined)).toBe('0.0%');
      expect(formatSimilarityScore(null)).toBe('0.0%');
      expect(formatSimilarityScore(NaN)).toBe('0.0%');
    });
  });

  describe('formatExecutionTime', () => {
    it('formats millisecond durations under 1 second', () => {
      expect(formatExecutionTime(0.045)).toBe('45 ms');
      expect(formatExecutionTime(0.825)).toBe('825 ms');
    });

    it('formats second durations 1 second or greater', () => {
      expect(formatExecutionTime(1.456)).toBe('1.46 s');
      expect(formatExecutionTime(8.262)).toBe('8.26 s');
    });

    it('handles null or undefined gracefully', () => {
      expect(formatExecutionTime(undefined)).toBe('0 ms');
      expect(formatExecutionTime(null)).toBe('0 ms');
    });
  });

  describe('formatDate', () => {
    it('formats ISO dates or falls back gracefully', () => {
      const formatted = formatDate('2026-08-08T08:12:57.413643000+00:00');
      expect(formatted).not.toBe('N/A');
      expect(formatDate(undefined)).toBe('N/A');
    });
  });

  describe('extractLinkedEntities and extractLinkedRelationships', () => {
    const mockEvidence: GraphEvidence = {
      entities: [
        {
          entity_id: 'AST-001',
          entity_type: 'Asset',
          properties: { name: 'Unit 1 GT Gas Turbine' },
        },
        {
          entity_id: 'INS-001',
          entity_type: 'Inspection',
          properties: { severity: 'medium' },
        },
        {
          entity_id: 'AST-002',
          entity_type: 'Asset',
          properties: { name: 'Unit 1 ST Generator' },
        },
      ],
      relationships: [
        {
          source_id: 'DOC-001',
          target_id: 'AST-001',
          relationship_type: 'ABOUT_ASSET',
          source_type: 'Document',
          target_type: 'Asset',
          properties: {},
        },
        {
          source_id: 'DOC-001',
          target_id: 'INS-001',
          relationship_type: 'ABOUT_INSPECTION',
          source_type: 'Document',
          target_type: 'Inspection',
          properties: {},
        },
        {
          source_id: 'DOC-007',
          target_id: 'AST-002',
          relationship_type: 'ABOUT_ASSET',
          source_type: 'Document',
          target_type: 'Asset',
          properties: {},
        },
      ],
    };

    it('extracts only entities linked to the target document', () => {
      const linked = extractLinkedEntities('DOC-001', mockEvidence);
      expect(linked).toHaveLength(2);
      expect(linked.map((e) => e.entity_id)).toEqual(['AST-001', 'INS-001']);
    });

    it('returns empty array if document has no linked entities', () => {
      const linked = extractLinkedEntities('DOC-999', mockEvidence);
      expect(linked).toHaveLength(0);
    });

    it('extracts relationships linked to the target document', () => {
      const rels = extractLinkedRelationships('DOC-001', mockEvidence);
      expect(rels).toHaveLength(2);
      expect(rels.map((r) => r.relationship_type)).toEqual(['ABOUT_ASSET', 'ABOUT_INSPECTION']);
    });
  });
});
