import React from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
} from '@mui/material';
import { MonitorHeart as HealthIcon } from '@mui/icons-material';
import { HealthPanel } from '../../components/common/HealthPanel';
import { useHealth } from '../../hooks/useHealth';

const HealthPage: React.FC = () => {
  const { error, lastChecked } = useHealth();

  return (
    <Box>
      <Box display="flex" alignItems="center" gap={2} mb={3}>
        <HealthIcon />
        <Typography variant="h4">
          System Health
        </Typography>
      </Box>
      
      <Typography variant="subtitle1" color="textSecondary" paragraph>
        Monitor the status of all backend services and system components.
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <HealthPanel 
            title="Service Status"
            showRefresh={true}
            autoRefresh={true}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Health Details
              </Typography>
              
              {lastChecked && (
                <Typography variant="body2" color="textSecondary" paragraph>
                  Last checked: {lastChecked.toLocaleString()}
                </Typography>
              )}

              <Box mb={2}>
                <Typography variant="subtitle2" gutterBottom>
                  Backend API
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  Core FastAPI service providing REST endpoints for all system functionality.
                </Typography>
              </Box>

              <Box mb={2}>
                <Typography variant="subtitle2" gutterBottom>
                  Groq LLM
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  AI language model service for GraphRAG question answering and text generation.
                </Typography>
              </Box>

              <Box mb={2}>
                <Typography variant="subtitle2" gutterBottom>
                  Neo4j Database
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  Graph database storing knowledge graph, entities, relationships, and embeddings.
                </Typography>
              </Box>

              {error && (
                <Box mt={2}>
                  <Typography variant="subtitle2" color="error" gutterBottom>
                    Connection Issue
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    {error.message}
                  </Typography>
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default HealthPage;