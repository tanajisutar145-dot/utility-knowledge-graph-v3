import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Box,
  Typography,
  IconButton,
  Button,
  Tooltip,
  CircularProgress,
  Alert,
  Chip,
} from '@mui/material';
import {
  CenterFocusStrong as CenterIcon,
  ZoomOutMap as FitIcon,
  Hub as HubIcon,
  Add as ExpandIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import cytoscape, { Core } from 'cytoscape';
import { GraphNode, GraphRelationship } from '../../../types/graph';
import { getNodeColor } from '../utils/graphStyles';
import { formatRelationshipLabel } from '../utils/relationshipUtils';

interface NodeRelationshipMapProps {
  centerNode: GraphNode;
  neighbors: GraphNode[];
  relationships: GraphRelationship[];
  isLoading: boolean;
  error?: string | null;
  onSelectNeighbor: (nodeId: string) => void;
  onExpandNeighbors?: () => void;
  isExpanding?: boolean;
  totalNeighborsCount?: number;
}

const MINI_CYTOSCAPE_STYLESHEET: any = [
  {
    selector: 'node',
    style: {
      'background-color': 'data(color)',
      'label': 'data(shortLabel)',
      'color': '#0f172a',
      'font-size': '10px',
      'font-weight': 600,
      'text-valign': 'bottom',
      'text-margin-y': 6,
      'text-background-color': '#ffffff',
      'text-background-opacity': 0.95,
      'text-background-padding': '3px',
      'text-background-shape': 'roundrectangle',
      'width': 34,
      'height': 34,
      'border-width': 2,
      'border-color': 'data(borderColor)',
      'cursor': 'pointer',
    },
  },
  {
    selector: 'node[?isCenter]',
    style: {
      'background-color': '#0f766e',
      'border-width': 4,
      'border-color': '#115e59',
      'width': 46,
      'height': 46,
      'font-size': '11px',
      'font-weight': 700,
      'color': '#0f766e',
      'text-background-color': '#f0fdfa',
      'text-background-opacity': 1,
      'z-index': 100,
    },
  },
  {
    selector: 'node:hover',
    style: {
      'border-width': 4,
      'border-color': '#0f766e',
    },
  },
  {
    selector: 'edge',
    style: {
      'width': 1.8,
      'line-color': '#94a3b8',
      'target-arrow-color': '#94a3b8',
      'target-arrow-shape': 'triangle',
      'arrow-scale': 1.0,
      'curve-style': 'bezier',
      'opacity': 0.85,
    },
  },
  {
    selector: 'edge:hover',
    style: {
      'line-color': '#0f766e',
      'target-arrow-color': '#0f766e',
      'width': 2.5,
      'opacity': 1,
      'z-index': 90,
    },
  },
];

export const NodeRelationshipMap: React.FC<NodeRelationshipMapProps> = ({
  centerNode,
  neighbors,
  relationships,
  isLoading,
  error,
  onSelectNeighbor,
  onExpandNeighbors,
  isExpanding = false,
  totalNeighborsCount,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const cyRef = useRef<Core | null>(null);
  const [activeLayout, setActiveLayout] = useState<'concentric' | 'cose'>('concentric');

  // Center on main node
  const handleCenter = useCallback(() => {
    if (!cyRef.current || cyRef.current.destroyed()) return;
    const center = cyRef.current.getElementById(centerNode.id);
    if (center.length > 0) {
      cyRef.current.center(center);
      cyRef.current.zoom({ level: 1.15, position: center.position() });
    }
  }, [centerNode.id]);

  // Fit all elements into view
  const handleFit = useCallback(() => {
    if (!cyRef.current || cyRef.current.destroyed()) return;
    cyRef.current.fit(undefined, 30);
  }, []);

  // Initialize Cytoscape
  useEffect(() => {
    if (!containerRef.current) return;

    const cy = cytoscape({
      container: containerRef.current,
      elements: [],
      boxSelectionEnabled: false,
      wheelSensitivity: 0.25,
      style: MINI_CYTOSCAPE_STYLESHEET,
    });

    cy.on('tap', 'node', (evt) => {
      const targetId = evt.target.id();
      if (targetId !== centerNode.id) {
        onSelectNeighbor(targetId);
      } else {
        handleCenter();
      }
    });

    cyRef.current = cy;

    const resizeObserver = new ResizeObserver(() => {
      if (cy && !cy.destroyed()) {
        cy.resize();
      }
    });
    resizeObserver.observe(containerRef.current);

    return () => {
      resizeObserver.disconnect();
      if (cy && !cy.destroyed()) {
        cy.destroy();
      }
      cyRef.current = null;
    };
  }, [centerNode.id, onSelectNeighbor, handleCenter]);

  // Update Elements & Run concentric layout
  useEffect(() => {
    const cy = cyRef.current;
    if (!cy || cy.destroyed()) return;

    cy.batch(() => {
      if (cy.destroyed()) return;
      cy.elements().remove();

      // Add center node
      const centerShort =
        centerNode.name.length > 20
          ? centerNode.name.slice(0, 18) + '...'
          : centerNode.name;

      cy.add({
        group: 'nodes',
        data: {
          id: centerNode.id,
          fullName: centerNode.name,
          shortLabel: centerShort,
          label: centerNode.label,
          entityId: centerNode.entity_id,
          isCenter: true,
          color: '#0f766e',
          borderColor: '#115e59',
        },
      });

      // Add neighbor nodes
      neighbors.forEach((n) => {
        if (n.id === centerNode.id) return;
        const col = getNodeColor(n.label);
        const short = n.name.length > 20 ? n.name.slice(0, 18) + '...' : n.name;
        cy.add({
          group: 'nodes',
          data: {
            id: n.id,
            fullName: n.name,
            shortLabel: short,
            label: n.label,
            entityId: n.entity_id,
            isCenter: false,
            color: col.bg,
            borderColor: col.border,
          },
        });
      });

      // Add edges with directionally correct friendly labels
      const existingNodeIds = new Set([
        centerNode.id,
        ...neighbors.map((n) => n.id),
      ]);

      relationships.forEach((r) => {
        if (!existingNodeIds.has(r.source) || !existingNodeIds.has(r.target)) {
          return;
        }

        const isOutbound = r.source === centerNode.id;
        const friendly = formatRelationshipLabel(r.type, isOutbound);

        cy.add({
          group: 'edges',
          data: {
            id: r.id,
            source: r.source,
            target: r.target,
            type: r.type,
            friendlyLabel: friendly,
          },
        });
      });
    });

    if (cy.destroyed()) return;

    if (neighbors.length > 0) {
      const layoutOptions =
        activeLayout === 'concentric'
          ? {
              name: 'concentric',
              concentric: (node: any) => (node.data('isCenter') ? 2 : 1),
              levelWidth: () => 1,
              padding: 30,
              minNodeSpacing: 55,
              animate: true,
              animationDuration: 350,
              fit: true,
            }
          : {
              name: 'cose',
              padding: 30,
              nodeRepulsion: 300000,
              idealEdgeLength: 60,
              animate: true,
              animationDuration: 400,
              fit: true,
            };

      const layout = cy.layout(layoutOptions);
      layout.run();
    } else {
      cy.fit(undefined, 30);
    }
  }, [centerNode, neighbors, relationships, activeLayout]);

  const hasMoreNeighbors =
    totalNeighborsCount !== undefined && totalNeighborsCount > neighbors.length;

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        bgcolor: '#ffffff',
        border: '1px solid #e2e8f0',
        borderRadius: 2,
        overflow: 'hidden',
        boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
      }}
    >
      {/* Section Header */}
      <Box
        sx={{
          px: 2,
          py: 1.25,
          bgcolor: '#f8fafc',
          borderBottom: '1px solid #e2e8f0',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexShrink: 0,
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <HubIcon sx={{ fontSize: 18, color: '#0f766e' }} />
          <Typography
            variant="subtitle2"
            sx={{
              fontWeight: 700,
              color: '#0f172a',
              letterSpacing: '0.02em',
              textTransform: 'uppercase',
              fontSize: '0.78rem',
            }}
          >
            Relationship Map
          </Typography>
          <Chip
            label={`${neighbors.length} immediate ${neighbors.length === 1 ? 'neighbor' : 'neighbors'}`}
            size="small"
            sx={{
              height: 20,
              fontSize: '0.68rem',
              fontWeight: 600,
              bgcolor: '#f0fdfa',
              color: '#0f766e',
              border: '1px solid #99f6e4',
            }}
          />
        </Box>

        {/* Map Controls */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
          {onExpandNeighbors && (
            <Button
              variant="outlined"
              size="small"
              onClick={onExpandNeighbors}
              disabled={isExpanding || !hasMoreNeighbors}
              startIcon={
                isExpanding ? (
                  <CircularProgress size={12} color="inherit" />
                ) : (
                  <ExpandIcon sx={{ fontSize: 14 }} />
                )
              }
              sx={{
                textTransform: 'none',
                fontSize: '0.7rem',
                py: 0.25,
                px: 1,
                borderColor: '#cbd5e1',
                color: '#334155',
                borderRadius: 1.5,
                '&:hover': { bgcolor: '#f0fdfa', borderColor: '#0f766e' },
              }}
            >
              {isExpanding
                ? 'Expanding...'
                : hasMoreNeighbors
                ? `Expand (${totalNeighborsCount})`
                : 'All Expanded'}
            </Button>
          )}

          <Tooltip title="Toggle Layout (Concentric / Force)">
            <IconButton
              size="small"
              onClick={() =>
                setActiveLayout((l) => (l === 'concentric' ? 'cose' : 'concentric'))
              }
              sx={{ color: '#64748b', p: 0.5 }}
            >
              <RefreshIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </Tooltip>

          <Tooltip title="Center Selected Node">
            <IconButton
              size="small"
              onClick={handleCenter}
              sx={{ color: '#64748b', p: 0.5 }}
            >
              <CenterIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </Tooltip>

          <Tooltip title="Fit Neighborhood">
            <IconButton
              size="small"
              onClick={handleFit}
              sx={{ color: '#64748b', p: 0.5 }}
            >
              <FitIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </Tooltip>
        </Box>
      </Box>

      {/* Map Content Body */}
      <Box sx={{ position: 'relative', flexGrow: 1, minHeight: 320 }}>
        {/* Loading Overlay */}
        {isLoading && (
          <Box
            sx={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              bgcolor: 'rgba(255, 255, 255, 0.8)',
              backdropFilter: 'blur(2px)',
              zIndex: 10,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 1,
            }}
          >
            <CircularProgress size={28} sx={{ color: '#0f766e' }} />
            <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 600 }}>
              Loading relationship neighborhood...
            </Typography>
          </Box>
        )}

        {/* Error Alert */}
        {error && (
          <Box sx={{ p: 2 }}>
            <Alert severity="error" sx={{ borderRadius: 1.5 }}>
              {error}
            </Alert>
          </Box>
        )}

        {/* Empty State */}
        {!isLoading && !error && neighbors.length === 0 ? (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              height: '100%',
              p: 3,
              textAlign: 'center',
              bgcolor: '#fafafa',
            }}
          >
            <HubIcon sx={{ fontSize: 40, color: '#cbd5e1', mb: 1 }} />
            <Typography variant="subtitle2" sx={{ color: '#334155', fontWeight: 600 }}>
              No Connected Neighbors Found
            </Typography>
            <Typography
              variant="caption"
              sx={{ color: '#64748b', maxWidth: 280, mt: 0.5 }}
            >
              This entity does not currently have direct relationships in the knowledge graph.
            </Typography>
          </Box>
        ) : (
          <Box
            ref={containerRef}
            sx={{
              width: '100%',
              height: '100%',
              bgcolor: '#fafafa',
              '&:focus': { outline: 'none' },
            }}
          />
        )}
      </Box>
    </Box>
  );
};
