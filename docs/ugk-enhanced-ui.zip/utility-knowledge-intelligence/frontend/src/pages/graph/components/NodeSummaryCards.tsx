import React from 'react';
import { Box, Card, Typography, Tooltip } from '@mui/material';
import {
  Factory as PlantIcon,
  ElectricBolt as UnitIcon,
  PrecisionManufacturing as AssetIcon,
  Build as ComponentIcon,
  Search as InspectionIcon,
  ReportProblem as FailureIcon,
  Assignment as WorkOrderIcon,
  CalendarMonth as ScheduleIcon,
  Warning as OutageIcon,
  Speed as HeatRateIcon,
  Description as DocumentIcon,
  ViewModule as ChunkIcon,
  Business as UtilityIcon,
  AttachMoney as CostIcon,
  Timer as TimerIcon,
  Shield as CriticalityIcon,
  InfoOutlined as InfoIcon,
} from '@mui/icons-material';
import { GraphNode, GraphRelationship } from '../../../types/graph';
import {
  formatPropertyValue,
  ParentEntityInfo,
} from '../utils/relationshipUtils';

interface SummaryCardItem {
  id: string;
  label: string;
  value: string;
  icon: React.ReactNode;
  hint?: string;
  highlight?: boolean;
}

interface NodeSummaryCardsProps {
  node: GraphNode;
  parentEntity?: ParentEntityInfo | null;
  neighbors?: GraphNode[];
  relationships?: GraphRelationship[];
  connectedByType?: Record<string, number>;
}

export const NodeSummaryCards: React.FC<NodeSummaryCardsProps> = ({
  node,
  parentEntity,
  neighbors = [],
  relationships = [],
  connectedByType = {},
}) => {
  const props = node.properties || {};

  // Count helper
  const countRels = (relType: string, labelTarget?: string): number => {
    if (connectedByType[relType] !== undefined) {
      return connectedByType[relType];
    }
    const relCount = relationships.filter((r) => r.type === relType).length;
    if (relCount > 0) return relCount;
    if (labelTarget) {
      return neighbors.filter((n) => n.label === labelTarget).length;
    }
    return 0;
  };

  const cards: SummaryCardItem[] = [];

  switch (node.label) {
    case 'GeneratingUnit': {
      if (parentEntity?.name || props.plant_id) {
        cards.push({
          id: 'parent_plant',
          label: 'Parent Plant',
          value: parentEntity?.name || String(props.plant_id),
          icon: <PlantIcon sx={{ fontSize: 18, color: '#0284c7' }} />,
        });
      }
      if (props.capacity_mw) {
        cards.push({
          id: 'capacity',
          label: 'Rated Capacity',
          value: formatPropertyValue('capacity_mw', props.capacity_mw),
          icon: <UnitIcon sx={{ fontSize: 18, color: '#2563eb' }} />,
        });
      }
      if (props.unit_type) {
        cards.push({
          id: 'unit_type',
          label: 'Unit Type',
          value: String(props.unit_type),
          icon: <InfoIcon sx={{ fontSize: 18, color: '#475569' }} />,
        });
      }
      cards.push({
        id: 'connected_assets',
        label: 'Connected Assets',
        value: String(countRels('HAS_ASSET', 'Asset')),
        icon: <AssetIcon sx={{ fontSize: 18, color: '#7c3aed' }} />,
      });
      const outages = countRels('HAS_OUTAGE', 'OutageEvent');
      if (outages > 0) {
        cards.push({
          id: 'recorded_outages',
          label: 'Recorded Outages',
          value: String(outages),
          icon: <OutageIcon sx={{ fontSize: 18, color: '#d97706' }} />,
        });
      }
      break;
    }

    case 'Asset': {
      if (props.asset_class) {
        cards.push({
          id: 'asset_class',
          label: 'Asset Class',
          value: String(props.asset_class),
          icon: <AssetIcon sx={{ fontSize: 18, color: '#7c3aed' }} />,
        });
      }
      if (parentEntity?.name) {
        cards.push({
          id: 'parent_unit',
          label: 'Generating Unit',
          value: parentEntity.name,
          icon: <UnitIcon sx={{ fontSize: 18, color: '#2563eb' }} />,
        });
      }
      if (props.criticality) {
        cards.push({
          id: 'criticality',
          label: 'Criticality',
          value: String(props.criticality),
          icon: <CriticalityIcon sx={{ fontSize: 18, color: '#e11d48' }} />,
          highlight: String(props.criticality).toLowerCase() === 'high',
        });
      }
      cards.push({
        id: 'components_count',
        label: 'Components',
        value: String(countRels('HAS_COMPONENT', 'Component')),
        icon: <ComponentIcon sx={{ fontSize: 18, color: '#4f46e5' }} />,
      });
      cards.push({
        id: 'inspections_count',
        label: 'Inspections',
        value: String(countRels('HAS_INSPECTION', 'Inspection')),
        icon: <InspectionIcon sx={{ fontSize: 18, color: '#16a34a' }} />,
      });
      cards.push({
        id: 'work_orders_count',
        label: 'Work Orders',
        value: String(countRels('HAS_WORK_ORDER', 'WorkOrder')),
        icon: <WorkOrderIcon sx={{ fontSize: 18, color: '#ea580c' }} />,
      });
      break;
    }

    case 'Component': {
      if (parentEntity?.name) {
        cards.push({
          id: 'parent_asset',
          label: 'Parent Asset',
          value: parentEntity.name,
          icon: <AssetIcon sx={{ fontSize: 18, color: '#7c3aed' }} />,
        });
      }
      if (props.component_type) {
        cards.push({
          id: 'component_type',
          label: 'Component Type',
          value: String(props.component_type),
          icon: <ComponentIcon sx={{ fontSize: 18, color: '#4f46e5' }} />,
        });
      }
      if (props.manufacturer || props.model) {
        cards.push({
          id: 'make_model',
          label: 'Make / Model',
          value: [props.manufacturer, props.model].filter(Boolean).join(' '),
          icon: <InfoIcon sx={{ fontSize: 18, color: '#64748b' }} />,
        });
      }
      if (props.criticality) {
        cards.push({
          id: 'criticality',
          label: 'Criticality',
          value: String(props.criticality),
          icon: <CriticalityIcon sx={{ fontSize: 18, color: '#e11d48' }} />,
        });
      }
      break;
    }

    case 'Inspection': {
      if (props.inspection_date) {
        cards.push({
          id: 'insp_date',
          label: 'Inspection Date',
          value: formatPropertyValue('inspection_date', props.inspection_date),
          icon: <ScheduleIcon sx={{ fontSize: 18, color: '#16a34a' }} />,
        });
      }
      if (parentEntity?.name) {
        cards.push({
          id: 'inspected_asset',
          label: 'Inspected Asset',
          value: parentEntity.name,
          icon: <AssetIcon sx={{ fontSize: 18, color: '#7c3aed' }} />,
        });
      }
      if (props.severity) {
        cards.push({
          id: 'severity',
          label: 'Severity',
          value: String(props.severity),
          icon: <CriticalityIcon sx={{ fontSize: 18, color: '#e11d48' }} />,
          highlight: String(props.severity).toLowerCase() === 'high',
        });
      }
      if (props.condition) {
        cards.push({
          id: 'condition',
          label: 'Condition',
          value: String(props.condition),
          icon: <InspectionIcon sx={{ fontSize: 18, color: '#0f766e' }} />,
        });
      }
      break;
    }

    case 'FailureEvent': {
      if (props.failure_date) {
        cards.push({
          id: 'failure_date',
          label: 'Failure Date',
          value: formatPropertyValue('failure_date', props.failure_date),
          icon: <ScheduleIcon sx={{ fontSize: 18, color: '#e11d48' }} />,
        });
      }
      if (parentEntity?.name) {
        cards.push({
          id: 'affected_asset',
          label: 'Affected Asset',
          value: parentEntity.name,
          icon: <AssetIcon sx={{ fontSize: 18, color: '#7c3aed' }} />,
        });
      }
      if (props.failure_mode) {
        cards.push({
          id: 'failure_mode',
          label: 'Failure Mode',
          value: String(props.failure_mode),
          icon: <FailureIcon sx={{ fontSize: 18, color: '#e11d48' }} />,
          highlight: true,
        });
      }
      if (props.downtime_hours !== undefined) {
        cards.push({
          id: 'downtime',
          label: 'Downtime',
          value: formatPropertyValue('downtime_hours', props.downtime_hours),
          icon: <TimerIcon sx={{ fontSize: 18, color: '#d97706' }} />,
        });
      }
      if (props.actual_cost || props.estimated_cost) {
        cards.push({
          id: 'repair_cost',
          label: props.actual_cost ? 'Actual Cost' : 'Estimated Cost',
          value: formatPropertyValue('actual_cost', props.actual_cost || props.estimated_cost),
          icon: <CostIcon sx={{ fontSize: 18, color: '#16a34a' }} />,
        });
      }
      break;
    }

    case 'WorkOrder': {
      if (props.work_type) {
        cards.push({
          id: 'work_type',
          label: 'Work Type',
          value: String(props.work_type),
          icon: <WorkOrderIcon sx={{ fontSize: 18, color: '#ea580c' }} />,
        });
      }
      if (parentEntity?.name) {
        cards.push({
          id: 'target_asset',
          label: 'Related Entity',
          value: parentEntity.name,
          icon: <AssetIcon sx={{ fontSize: 18, color: '#7c3aed' }} />,
        });
      }
      if (props.priority) {
        cards.push({
          id: 'priority',
          label: 'Priority',
          value: String(props.priority),
          icon: <CriticalityIcon sx={{ fontSize: 18, color: '#e11d48' }} />,
          highlight: String(props.priority).toLowerCase() === 'high',
        });
      }
      if (props.total_cost || props.material_cost) {
        cards.push({
          id: 'cost',
          label: 'Total Cost',
          value: formatPropertyValue('total_cost', props.total_cost || props.material_cost),
          icon: <CostIcon sx={{ fontSize: 18, color: '#16a34a' }} />,
        });
      }
      if (props.scheduled_date || props.completion_date) {
        const dKey = props.completion_date ? 'completion_date' : 'scheduled_date';
        cards.push({
          id: 'wo_date',
          label: props.completion_date ? 'Completed' : 'Scheduled',
          value: formatPropertyValue(dKey, props[dKey]),
          icon: <ScheduleIcon sx={{ fontSize: 18, color: '#64748b' }} />,
        });
      }
      break;
    }

    case 'PowerPlant': {
      if (props.plant_type) {
        cards.push({
          id: 'plant_type',
          label: 'Plant Type',
          value: String(props.plant_type),
          icon: <PlantIcon sx={{ fontSize: 18, color: '#0284c7' }} />,
        });
      }
      if (props.capacity_mw) {
        cards.push({
          id: 'plant_capacity',
          label: 'Total Capacity',
          value: formatPropertyValue('capacity_mw', props.capacity_mw),
          icon: <UnitIcon sx={{ fontSize: 18, color: '#2563eb' }} />,
        });
      }
      if (props.location) {
        cards.push({
          id: 'location',
          label: 'Location',
          value: String(props.location),
          icon: <InfoIcon sx={{ fontSize: 18, color: '#64748b' }} />,
        });
      }
      cards.push({
        id: 'units_count',
        label: 'Generating Units',
        value: String(countRels('HAS_UNIT', 'GeneratingUnit')),
        icon: <UnitIcon sx={{ fontSize: 18, color: '#2563eb' }} />,
      });
      break;
    }

    case 'MaintenancePlan': {
      if (props.maintenance_type) {
        cards.push({
          id: 'maint_type',
          label: 'Maintenance Type',
          value: String(props.maintenance_type),
          icon: <ScheduleIcon sx={{ fontSize: 18, color: '#0891b2' }} />,
        });
      }
      if (parentEntity?.name) {
        cards.push({
          id: 'associated_asset',
          label: 'Associated Asset',
          value: parentEntity.name,
          icon: <AssetIcon sx={{ fontSize: 18, color: '#7c3aed' }} />,
        });
      }
      if (props.frequency) {
        cards.push({
          id: 'frequency',
          label: 'Frequency',
          value: String(props.frequency),
          icon: <TimerIcon sx={{ fontSize: 18, color: '#475569' }} />,
        });
      }
      if (props.next_due_date) {
        cards.push({
          id: 'next_due',
          label: 'Next Due Date',
          value: formatPropertyValue('next_due_date', props.next_due_date),
          icon: <ScheduleIcon sx={{ fontSize: 18, color: '#16a34a' }} />,
        });
      }
      break;
    }

    case 'OutageEvent': {
      if (parentEntity?.name) {
        cards.push({
          id: 'affected_unit',
          label: 'Affected Unit',
          value: parentEntity.name,
          icon: <UnitIcon sx={{ fontSize: 18, color: '#2563eb' }} />,
        });
      }
      if (props.outage_type) {
        cards.push({
          id: 'outage_type',
          label: 'Outage Type',
          value: String(props.outage_type),
          icon: <OutageIcon sx={{ fontSize: 18, color: '#d97706' }} />,
        });
      }
      if (props.duration_hours !== undefined) {
        cards.push({
          id: 'duration',
          label: 'Duration',
          value: formatPropertyValue('duration_hours', props.duration_hours),
          icon: <TimerIcon sx={{ fontSize: 18, color: '#d97706' }} />,
        });
      }
      if (props.estimated_generation_loss_mwh) {
        cards.push({
          id: 'gen_loss',
          label: 'Generation Loss',
          value: formatPropertyValue('estimated_generation_loss_mwh', props.estimated_generation_loss_mwh),
          icon: <UnitIcon sx={{ fontSize: 18, color: '#e11d48' }} />,
        });
      }
      break;
    }

    case 'HeatRateTest': {
      if (parentEntity?.name) {
        cards.push({
          id: 'test_unit',
          label: 'Generating Unit',
          value: parentEntity.name,
          icon: <UnitIcon sx={{ fontSize: 18, color: '#2563eb' }} />,
        });
      }
      if (props.test_date) {
        cards.push({
          id: 'test_date',
          label: 'Test Date',
          value: formatPropertyValue('test_date', props.test_date),
          icon: <ScheduleIcon sx={{ fontSize: 18, color: '#059669' }} />,
        });
      }
      if (props.measured_heat_rate) {
        cards.push({
          id: 'heat_rate',
          label: 'Measured Heat Rate',
          value: formatPropertyValue('measured_heat_rate', props.measured_heat_rate),
          icon: <HeatRateIcon sx={{ fontSize: 18, color: '#059669' }} />,
        });
      }
      if (props.deviation_percentage !== undefined) {
        cards.push({
          id: 'deviation',
          label: 'Deviation',
          value: formatPropertyValue('deviation_percentage', props.deviation_percentage),
          icon: <InfoIcon sx={{ fontSize: 18, color: '#d97706' }} />,
        });
      }
      break;
    }

    case 'Document': {
      if (props.document_type) {
        cards.push({
          id: 'doc_type',
          label: 'Document Type',
          value: String(props.document_type),
          icon: <DocumentIcon sx={{ fontSize: 18, color: '#475569' }} />,
        });
      }
      if (props.created_date) {
        cards.push({
          id: 'upload_date',
          label: 'Ingestion Date',
          value: formatPropertyValue('created_date', props.created_date),
          icon: <ScheduleIcon sx={{ fontSize: 18, color: '#64748b' }} />,
        });
      }
      cards.push({
        id: 'chunks_count',
        label: 'Extracted Chunks',
        value: String(countRels('HAS_CHUNK', 'Chunk')),
        icon: <ChunkIcon sx={{ fontSize: 18, color: '#64748b' }} />,
      });
      break;
    }

    case 'Chunk': {
      if (parentEntity?.name) {
        cards.push({
          id: 'parent_doc',
          label: 'Parent Document',
          value: parentEntity.name,
          icon: <DocumentIcon sx={{ fontSize: 18, color: '#475569' }} />,
        });
      }
      if (props.chunk_id) {
        cards.push({
          id: 'chunk_id',
          label: 'Chunk ID',
          value: String(props.chunk_id),
          icon: <ChunkIcon sx={{ fontSize: 18, color: '#64748b' }} />,
        });
      }
      if (props.embedding_model) {
        cards.push({
          id: 'embedding_model',
          label: 'Embedding Model',
          value: String(props.embedding_model),
          icon: <InfoIcon sx={{ fontSize: 18, color: '#0f766e' }} />,
        });
      }
      break;
    }

    case 'Utility': {
      cards.push({
        id: 'connected_plants',
        label: 'Connected Plants',
        value: String(countRels('HAS_PLANT', 'PowerPlant')),
        icon: <PlantIcon sx={{ fontSize: 18, color: '#0284c7' }} />,
      });
      if (props.region || props.country) {
        cards.push({
          id: 'region',
          label: 'Operating Region',
          value: [props.region, props.country].filter(Boolean).join(', '),
          icon: <UtilityIcon sx={{ fontSize: 18, color: '#0f766e' }} />,
        });
      }
      break;
    }

    default: {
      // General fallback metrics
      const totalConnected = Object.values(connectedByType).reduce((a, b) => a + b, 0) || relationships.length;
      cards.push({
        id: 'total_connected',
        label: 'Connected Entities',
        value: String(totalConnected),
        icon: <AssetIcon sx={{ fontSize: 18, color: '#0f766e' }} />,
      });
      if (parentEntity?.name) {
        cards.push({
          id: 'parent_entity',
          label: parentEntity.relationship,
          value: parentEntity.name,
          icon: <PlantIcon sx={{ fontSize: 18, color: '#0284c7' }} />,
        });
      }
      break;
    }
  }

  if (cards.length === 0) {
    return null;
  }

  return (
    <Box
      sx={{
        px: { xs: 2, sm: 3 },
        py: 1.5,
        bgcolor: '#f8fafc',
        borderBottom: '1px solid #e2e8f0',
        display: 'flex',
        alignItems: 'stretch',
        gap: 1.5,
        overflowX: 'auto',
        flexShrink: 0,
        '&::-webkit-scrollbar': { height: 4 },
        '&::-webkit-scrollbar-thumb': { bgcolor: '#cbd5e1', borderRadius: 2 },
      }}
    >
      {cards.map((card) => (
        <Card
          key={card.id}
          elevation={0}
          sx={{
            minWidth: { xs: 140, sm: 165 },
            flex: '1 1 0px',
            maxWidth: { xs: 220, md: 240 },
            p: 1.5,
            bgcolor: '#ffffff',
            border: card.highlight ? '1px solid #fecdd3' : '1px solid #e2e8f0',
            borderRadius: 2,
            boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.03)',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            transition: 'all 0.15s ease',
            '&:hover': {
              borderColor: '#0f766e',
              boxShadow: '0 2px 6px 0 rgba(15, 118, 110, 0.08)',
            },
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, mb: 0.5 }}>
            {card.icon}
            <Typography
              variant="caption"
              sx={{
                fontWeight: 700,
                color: '#64748b',
                textTransform: 'uppercase',
                fontSize: '0.68rem',
                letterSpacing: '0.04em',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
              }}
            >
              {card.label}
            </Typography>
          </Box>
          <Tooltip title={card.value}>
            <Typography
              variant="body1"
              sx={{
                fontWeight: 700,
                color: card.highlight ? '#be123c' : '#0f172a',
                fontSize: { xs: '0.875rem', sm: '0.95rem' },
                lineHeight: 1.3,
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
              }}
            >
              {card.value}
            </Typography>
          </Tooltip>
        </Card>
      ))}
    </Box>
  );
};
