import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Dialog,
  Box,
  CircularProgress,
  Typography,
  Alert,
  Button,
} from '@mui/material';
import {
  ArrowBack as BackIcon,
} from '@mui/icons-material';

import {
  GraphNode,
  GraphNodeDetailResponse,
  GraphNeighborsResponse,
  GraphRelationship,
} from '../../../types/graph';
import {
  getGraphNodeDetail,
  getGraphNodeNeighbors,
} from '../../../services/api';

import { NodeIdentityHeader } from './NodeIdentityHeader';
import { NodeSummaryCards } from './NodeSummaryCards';
import { NodeRelationshipMap } from './NodeRelationshipMap';
import { RelatedEntitiesList } from './RelatedEntitiesList';
import { NodeEntityInformation } from './NodeEntityInformation';
import { NodeModalActions } from './NodeModalActions';
import { getParentEntity, ParentEntityInfo } from '../utils/relationshipUtils';

interface NodeIntelligenceModalProps {
  open: boolean;
  nodeId: string | null;
  onClose: () => void;
  onViewInFullGraph: (nodeId: string) => void;
}

export const NodeIntelligenceModal: React.FC<NodeIntelligenceModalProps> = ({
  open,
  nodeId,
  onClose,
  onViewInFullGraph,
}) => {
  // Current active node inside the modal (can navigate between neighbors)
  const [currentNodeId, setCurrentNodeId] = useState<string | null>(nodeId);
  const [history, setHistory] = useState<string[]>([]);

  // Telemetry and neighborhood state
  const [nodeDetail, setNodeDetail] = useState<GraphNodeDetailResponse | null>(null);
  const [neighborsData, setNeighborsData] = useState<GraphNeighborsResponse | null>(null);

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isExpanding, setIsExpanding] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Stale request guard
  const activeReqIdRef = useRef<number>(0);

  // Sync with incoming prop
  useEffect(() => {
    if (nodeId && open) {
      setCurrentNodeId(nodeId);
      setHistory([]);
    }
  }, [nodeId, open]);

  // Fetch node detail and neighborhood in parallel
  const loadNodeIntelligence = useCallback(
    async (targetId: string, limit: number = 50) => {
      const currentReqId = ++activeReqIdRef.current;
      setIsLoading(true);
      setErrorMessage(null);

      try {
        const [detailRes, neighborsRes] = await Promise.all([
          getGraphNodeDetail(targetId),
          getGraphNodeNeighbors(targetId, limit),
        ]);

        if (currentReqId === activeReqIdRef.current) {
          setNodeDetail(detailRes);
          setNeighborsData(neighborsRes);
          setErrorMessage(null);
        }
      } catch (err: any) {
        if (currentReqId === activeReqIdRef.current) {
          console.error('Failed to load node intelligence:', err);
          const msg =
            err?.response?.data?.detail ||
            err?.message ||
            'Failed to load entity neighborhood telemetry.';
          setErrorMessage(msg);
        }
      } finally {
        if (currentReqId === activeReqIdRef.current) {
          setIsLoading(false);
        }
      }
    },
    []
  );

  useEffect(() => {
    if (currentNodeId && open) {
      loadNodeIntelligence(currentNodeId, 50);
    }
  }, [currentNodeId, open, loadNodeIntelligence]);

  // Handle drill-down into a neighbor node
  const handleSelectNeighbor = useCallback((newId: string) => {
    if (newId === currentNodeId) return;
    setHistory((prev) => (currentNodeId ? [...prev, currentNodeId] : prev));
    setCurrentNodeId(newId);
  }, [currentNodeId]);

  // Handle back navigation
  const handleNavigateBack = useCallback(() => {
    if (history.length === 0) return;
    const prevId = history[history.length - 1];
    setHistory((prev) => prev.slice(0, prev.length - 1));
    setCurrentNodeId(prevId);
  }, [history]);

  // Handle expand neighbors with higher limit
  const handleExpandNeighbors = useCallback(async () => {
    if (!currentNodeId) return;
    setIsExpanding(true);
    try {
      const expanded = await getGraphNodeNeighbors(currentNodeId, 100);
      setNeighborsData(expanded);
    } catch (err: any) {
      console.error('Failed to expand neighbors:', err);
    } finally {
      setIsExpanding(false);
    }
  }, [currentNodeId]);

  // Determine active node and neighbors
  const activeNode: GraphNode | null =
    nodeDetail?.node || neighborsData?.center_node || null;

  const activeNeighbors: GraphNode[] = neighborsData?.neighbor_nodes || [];
  const activeRelationships: GraphRelationship[] = neighborsData?.relationships || [];

  // Deterministically derive parent entity
  const parentEntity: ParentEntityInfo | null = activeNode
    ? getParentEntity(activeNode, activeNeighbors, activeRelationships)
    : null;

  return (
    <Dialog
      open={open && Boolean(nodeId)}
      onClose={onClose}
      maxWidth="xl"
      fullWidth
      aria-labelledby="node-intelligence-title"
      PaperProps={{
        sx: {
          width: { xs: '96vw', sm: '92vw', md: '90vw', lg: '86vw' },
          height: { xs: '96vh', md: '88vh' },
          maxHeight: '92vh',
          maxWidth: 1440,
          borderRadius: 3,
          display: 'flex',
          flexDirection: 'column',
          bgcolor: '#ffffff',
          overflow: 'hidden',
          boxShadow: '0 25px 50px -12px rgba(15, 23, 42, 0.25)',
        },
      }}
      BackdropProps={{
        sx: {
          backdropFilter: 'blur(4px)',
          bgcolor: 'rgba(15, 23, 42, 0.45)',
        },
      }}
    >
      {/* Navigation history bar (if user navigated through neighbors) */}
      {history.length > 0 && (
        <Box
          sx={{
            px: { xs: 2, sm: 3 },
            py: 0.75,
            bgcolor: '#f1f5f9',
            borderBottom: '1px solid #e2e8f0',
            display: 'flex',
            alignItems: 'center',
            gap: 1,
            flexShrink: 0,
          }}
        >
          <Button
            size="small"
            startIcon={<BackIcon sx={{ fontSize: 14 }} />}
            onClick={handleNavigateBack}
            sx={{
              textTransform: 'none',
              fontSize: '0.72rem',
              py: 0.25,
              px: 1,
              bgcolor: '#ffffff',
              color: '#0f766e',
              border: '1px solid #cbd5e1',
              borderRadius: 1.5,
              fontWeight: 600,
              '&:hover': { bgcolor: '#f0fdfa', borderColor: '#99f6e4' },
            }}
          >
            Back to previous entity ({history.length})
          </Button>
          <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.72rem' }}>
            Navigating neighborhood graph
          </Typography>
        </Box>
      )}

      {/* Header */}
      {activeNode ? (
        <NodeIdentityHeader
          node={activeNode}
          parentEntity={parentEntity}
          onClose={onClose}
          onSelectEntity={handleSelectNeighbor}
        />
      ) : (
        <Box
          sx={{
            p: 2.5,
            borderBottom: '1px solid #e2e8f0',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <Typography variant="h6" sx={{ color: '#0f172a', fontWeight: 700 }}>
            Node Intelligence
          </Typography>
          <Button size="small" onClick={onClose}>
            Close
          </Button>
        </Box>
      )}

      {/* Dynamic Summary Cards Row */}
      {activeNode && !errorMessage && (
        <NodeSummaryCards
          node={activeNode}
          parentEntity={parentEntity}
          neighbors={activeNeighbors}
          relationships={activeRelationships}
          connectedByType={nodeDetail?.connected_by_type}
        />
      )}

      {/* Main Content Area (Scrollable Work Area) */}
      <Box
        sx={{
          flexGrow: 1,
          overflowY: 'auto',
          p: { xs: 1.5, sm: 2.5 },
          bgcolor: '#f8fafc',
          display: 'flex',
          flexDirection: 'column',
          gap: 2,
        }}
      >
        {/* Loading Spinner for initial load */}
        {isLoading && !activeNode ? (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              minHeight: 360,
              gap: 2,
            }}
          >
            <CircularProgress size={36} sx={{ color: '#0f766e' }} />
            <Typography variant="body2" sx={{ color: '#64748b', fontWeight: 500 }}>
              Retrieving entity telemetry and neighborhood relationships...
            </Typography>
          </Box>
        ) : errorMessage ? (
          <Box sx={{ p: 3 }}>
            <Alert
              severity="error"
              action={
                <Button
                  color="inherit"
                  size="small"
                  onClick={() => currentNodeId && loadNodeIntelligence(currentNodeId)}
                >
                  Retry
                </Button>
              }
              sx={{ borderRadius: 2 }}
            >
              {errorMessage}
            </Alert>
          </Box>
        ) : activeNode ? (
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: { xs: '1fr', lg: '7fr 5fr' },
              gap: 2,
              alignItems: 'stretch',
            }}
          >
            {/* Left Column: Mini Relationship Map + Related Entities List */}
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                gap: 2,
                minHeight: 0,
              }}
            >
              {/* Mini Relationship Map */}
              <Box sx={{ height: { xs: 340, sm: 380, md: 410 }, flexShrink: 0 }}>
                <NodeRelationshipMap
                  centerNode={activeNode}
                  neighbors={activeNeighbors}
                  relationships={activeRelationships}
                  isLoading={isLoading}
                  error={errorMessage}
                  onSelectNeighbor={handleSelectNeighbor}
                  onExpandNeighbors={handleExpandNeighbors}
                  isExpanding={isExpanding}
                  totalNeighborsCount={
                    nodeDetail?.connected_count || neighborsData?.total_neighbors
                  }
                />
              </Box>

              {/* Related Entities List */}
              <Box sx={{ height: { xs: 300, sm: 320 }, flexShrink: 0 }}>
                <RelatedEntitiesList
                  centerNode={activeNode}
                  neighbors={activeNeighbors}
                  relationships={activeRelationships}
                  parentEntity={parentEntity}
                  onSelectNeighbor={handleSelectNeighbor}
                  onExpandNeighbors={handleExpandNeighbors}
                  hasMoreNeighbors={
                    (nodeDetail?.connected_count || 0) > activeNeighbors.length
                  }
                />
              </Box>
            </Box>

            {/* Right Column: Entity Information Panel */}
            <Box sx={{ minHeight: { xs: 380, lg: 710 }, display: 'flex' }}>
              <NodeEntityInformation node={activeNode} detail={nodeDetail} />
            </Box>
          </Box>
        ) : null}
      </Box>

      {/* Footer Actions Bar */}
      {activeNode && (
        <NodeModalActions
          node={activeNode}
          onViewInFullGraph={() => {
            onClose();
            onViewInFullGraph(activeNode.id);
          }}
          onClose={onClose}
        />
      )}
    </Dialog>
  );
};
