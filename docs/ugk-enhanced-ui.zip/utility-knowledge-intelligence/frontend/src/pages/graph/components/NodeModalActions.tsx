import React from 'react';
import { Box, Button } from '@mui/material';
import {
  Search as SearchIcon,
  Psychology as IntelligenceIcon,
  AccountTree as GraphIcon,
  Close as CloseIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { GraphNode } from '../../../types/graph';
import { formatEntityLabel } from '../utils/relationshipUtils';

interface NodeModalActionsProps {
  node: GraphNode;
  onViewInFullGraph: () => void;
  onClose: () => void;
}

export const NodeModalActions: React.FC<NodeModalActionsProps> = ({
  node,
  onViewInFullGraph,
  onClose,
}) => {
  const navigate = useNavigate();

  const handleSearchEvidence = () => {
    const searchTerm = node.name || node.entity_id;
    navigate(`/search?q=${encodeURIComponent(searchTerm)}`);
  };

  const handleAskIntelligence = () => {
    const friendly = formatEntityLabel(node.label);
    const question = `What is the operational status, history, and key relationships of ${friendly} ${node.name || node.entity_id}?`;
    navigate(`/intelligence?q=${encodeURIComponent(question)}`);
  };

  return (
    <Box
      sx={{
        px: { xs: 2, sm: 3 },
        py: 1.75,
        bgcolor: '#f8fafc',
        borderTop: '1px solid #e2e8f0',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: 1.5,
        flexShrink: 0,
      }}
    >
      {/* Primary Intelligence & Graph Actions */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
        <Button
          variant="contained"
          size="small"
          onClick={handleAskIntelligence}
          startIcon={<IntelligenceIcon sx={{ fontSize: 16 }} />}
          sx={{
            bgcolor: '#0f766e',
            color: '#ffffff',
            fontWeight: 600,
            textTransform: 'none',
            fontSize: '0.8125rem',
            px: 2,
            py: 0.75,
            borderRadius: 1.5,
            boxShadow: 'none',
            '&:hover': {
              bgcolor: '#115e59',
              boxShadow: '0 2px 4px rgba(15, 118, 110, 0.2)',
            },
          }}
        >
          Ask Intelligence
        </Button>

        <Button
          variant="outlined"
          size="small"
          onClick={handleSearchEvidence}
          startIcon={<SearchIcon sx={{ fontSize: 16 }} />}
          sx={{
            borderColor: '#cbd5e1',
            color: '#334155',
            bgcolor: '#ffffff',
            fontWeight: 600,
            textTransform: 'none',
            fontSize: '0.8125rem',
            px: 1.75,
            py: 0.75,
            borderRadius: 1.5,
            '&:hover': {
              borderColor: '#0f766e',
              color: '#0f766e',
              bgcolor: '#f0fdfa',
            },
          }}
        >
          Search Evidence
        </Button>

        <Button
          variant="outlined"
          size="small"
          onClick={onViewInFullGraph}
          startIcon={<GraphIcon sx={{ fontSize: 16 }} />}
          sx={{
            borderColor: '#99f6e4',
            color: '#0f766e',
            bgcolor: '#f0fdfa',
            fontWeight: 600,
            textTransform: 'none',
            fontSize: '0.8125rem',
            px: 1.75,
            py: 0.75,
            borderRadius: 1.5,
            '&:hover': {
              borderColor: '#0f766e',
              bgcolor: '#ccfbf1',
            },
          }}
        >
          View in Full Graph
        </Button>
      </Box>

      {/* Dismiss / Close Action */}
      <Button
        variant="text"
        size="small"
        onClick={onClose}
        startIcon={<CloseIcon sx={{ fontSize: 16 }} />}
        sx={{
          color: '#64748b',
          fontWeight: 600,
          textTransform: 'none',
          fontSize: '0.8125rem',
          px: 1.5,
          py: 0.75,
          borderRadius: 1.5,
          '&:hover': {
            bgcolor: '#f1f5f9',
            color: '#0f172a',
          },
        }}
      >
        Close
      </Button>
    </Box>
  );
};
