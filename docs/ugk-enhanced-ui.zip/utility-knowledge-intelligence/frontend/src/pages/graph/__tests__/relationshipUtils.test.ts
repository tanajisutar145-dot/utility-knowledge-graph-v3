import {
  formatEntityLabel,
  formatRelationshipLabel,
  describeRelationshipSentence,
  getParentEntity,
  getStatusColorInfo,
  formatPropertyLabel,
  formatPropertyValue,
  ENTITY_LABEL_MAP,
  RELATIONSHIP_LABELS_FORWARD,
  RELATIONSHIP_LABELS_REVERSE,
} from '../utils/relationshipUtils';
import { GraphNode, GraphRelationship } from '../../../types/graph';

describe('relationshipUtils', () => {
  describe('Entity label formatting for all 13 entity types', () => {
    const expectedLabels: Record<string, string> = {
      Utility: 'Utility',
      PowerPlant: 'Power Plant',
      GeneratingUnit: 'Generating Unit',
      Asset: 'Asset',
      Component: 'Component',
      Inspection: 'Inspection Record',
      FailureEvent: 'Failure Event',
      WorkOrder: 'Work Order',
      MaintenancePlan: 'Maintenance Plan',
      OutageEvent: 'Outage Event',
      HeatRateTest: 'Heat Rate Test',
      Document: 'Knowledge Document',
      Chunk: 'Document Chunk',
    };

    Object.entries(expectedLabels).forEach(([raw, expected]) => {
      it(`formats ${raw} to "${expected}"`, () => {
        expect(formatEntityLabel(raw)).toBe(expected);
      });
    });

    it('formats unknown camelCase labels with spacing', () => {
      expect(formatEntityLabel('CustomSensor')).toBe('Custom Sensor');
    });

    it('handles empty or missing label safely', () => {
      expect(formatEntityLabel('')).toBe('Entity');
    });
  });

  describe('Relationship label mapping in forward and reverse directions', () => {
    const relTypes = [
      'HAS_PLANT',
      'HAS_UNIT',
      'HAS_ASSET',
      'HAS_COMPONENT',
      'HAS_INSPECTION',
      'HAS_FAILURE',
      'HAS_WORK_ORDER',
      'HAS_MAINTENANCE_PLAN',
      'HAS_OUTAGE',
      'HAS_HEAT_RATE_TEST',
      'TRIGGERED_WORK_ORDER',
      'HAS_CHUNK',
      'ABOUT_ASSET',
      'ABOUT_UNIT',
      'ABOUT_INSPECTION',
      'ABOUT_FAILURE',
      'ABOUT_WORK_ORDER',
    ];

    relTypes.forEach((rType) => {
      it(`maps forward label for ${rType}`, () => {
        const forward = formatRelationshipLabel(rType, true);
        expect(forward).toBeDefined();
        expect(forward.length).toBeGreaterThan(0);
        expect(forward).not.toContain('_');
      });

      it(`maps reverse label for ${rType}`, () => {
        const reverse = formatRelationshipLabel(rType, false);
        expect(reverse).toBeDefined();
        expect(reverse.length).toBeGreaterThan(0);
        expect(reverse).not.toContain('_');
      });
    });

    it('produces directionally distinct labels', () => {
      expect(formatRelationshipLabel('HAS_UNIT', true)).toBe('Contains Generating Unit');
      expect(formatRelationshipLabel('HAS_UNIT', false)).toBe('Located at Power Plant');

      expect(formatRelationshipLabel('HAS_ASSET', true)).toBe('Contains Asset');
      expect(formatRelationshipLabel('HAS_ASSET', false)).toBe('Part of Generating Unit');

      expect(formatRelationshipLabel('TRIGGERED_WORK_ORDER', true)).toBe('Triggered Work Order');
      expect(formatRelationshipLabel('TRIGGERED_WORK_ORDER', false)).toBe('Triggered by Failure Event');
    });
  });

  describe('describeRelationshipSentence', () => {
    const plantNode: GraphNode = {
      id: 'p1',
      label: 'PowerPlant',
      labels: ['PowerPlant'],
      name: 'Columbia River Hydro Station',
      entity_id: 'PLANT-001',
      properties: {},
    };

    const unitNode: GraphNode = {
      id: 'u1',
      label: 'GeneratingUnit',
      labels: ['GeneratingUnit'],
      name: 'Unit 2',
      entity_id: 'UNT-009',
      properties: {},
    };

    const assetNode: GraphNode = {
      id: 'a1',
      label: 'Asset',
      labels: ['Asset'],
      name: 'Unit 2 Generator',
      entity_id: 'AST-040',
      properties: {},
    };

    const failureNode: GraphNode = {
      id: 'f1',
      label: 'FailureEvent',
      labels: ['FailureEvent'],
      name: 'Stator Ground Fault',
      entity_id: 'FLR-003',
      properties: {},
    };

    const woNode: GraphNode = {
      id: 'w1',
      label: 'WorkOrder',
      labels: ['WorkOrder'],
      name: 'Emergency Stator Rewind',
      entity_id: 'WO-502',
      properties: {},
    };

    it('generates sentence for plant -> unit', () => {
      const sentence = describeRelationshipSentence(plantNode, 'HAS_UNIT', unitNode);
      expect(sentence).toBe('Columbia River Hydro Station contains generating unit Unit 2.');
    });

    it('generates sentence for unit -> asset', () => {
      const sentence = describeRelationshipSentence(unitNode, 'HAS_ASSET', assetNode);
      expect(sentence).toBe('Unit 2 includes asset Unit 2 Generator.');
    });

    it('generates sentence for failure -> work order', () => {
      const sentence = describeRelationshipSentence(failureNode, 'TRIGGERED_WORK_ORDER', woNode);
      expect(sentence).toBe('Failure event Stator Ground Fault triggered work order Emergency Stator Rewind.');
    });
  });

  describe('getParentEntity deterministic resolution', () => {
    const plant: GraphNode = {
      id: 'plant-1',
      name: 'Columbia River Hydro Station',
      label: 'PowerPlant',
      labels: ['PowerPlant'],
      entity_id: 'PLANT-001',
      properties: {},
    };

    const unit: GraphNode = {
      id: 'unit-9',
      name: 'Unit 2',
      label: 'GeneratingUnit',
      labels: ['GeneratingUnit'],
      entity_id: 'UNT-009',
      properties: { plant_id: 'PLANT-001' },
    };

    const asset: GraphNode = {
      id: 'asset-40',
      name: 'Unit 2 Generator',
      label: 'Asset',
      labels: ['Asset'],
      entity_id: 'AST-040',
      properties: { unit_id: 'UNT-009' },
    };

    it('resolves parent PowerPlant for GeneratingUnit via HAS_UNIT relationship', () => {
      const rels: GraphRelationship[] = [
        { id: 'r1', source: 'plant-1', target: 'unit-9', type: 'HAS_UNIT', properties: {} },
      ];
      const parent = getParentEntity(unit, [plant], rels);
      expect(parent).not.toBeNull();
      expect(parent?.id).toBe('plant-1');
      expect(parent?.name).toBe('Columbia River Hydro Station');
      expect(parent?.relationship).toBe('Located at Power Plant');
    });

    it('resolves parent GeneratingUnit for Asset via HAS_ASSET relationship', () => {
      const rels: GraphRelationship[] = [
        { id: 'r2', source: 'unit-9', target: 'asset-40', type: 'HAS_ASSET', properties: {} },
      ];
      const parent = getParentEntity(asset, [unit], rels);
      expect(parent).not.toBeNull();
      expect(parent?.id).toBe('unit-9');
      expect(parent?.name).toBe('Unit 2');
      expect(parent?.relationship).toBe('Part of Generating Unit');
    });

    it('falls back to property ID if relationship edge is absent', () => {
      const parent = getParentEntity(unit, [plant], []);
      expect(parent).not.toBeNull();
      expect(parent?.id).toBe('plant-1');
      expect(parent?.name).toBe('Columbia River Hydro Station');
    });

    it('returns null when no parent relationship or property matches', () => {
      const orphan: GraphNode = {
        id: 'orphan',
        name: 'Independent Utility',
        label: 'Utility',
        labels: ['Utility'],
        entity_id: 'UTL-001',
        properties: {},
      };
      expect(getParentEntity(orphan, [], [])).toBeNull();
    });
  });

  describe('getStatusColorInfo', () => {
    it('returns green tokens for operational / active / passed states', () => {
      const s = getStatusColorInfo('operational');
      expect(s.text).toBe('#15803d');
      expect(s.bg).toBe('#f0fdf4');
    });

    it('returns amber tokens for pending / scheduled / warning states', () => {
      const s = getStatusColorInfo('scheduled');
      expect(s.text).toBe('#b45309');
      expect(s.bg).toBe('#fffbeb');
    });

    it('returns red tokens for critical / failed / outage states', () => {
      const s = getStatusColorInfo('critical');
      expect(s.text).toBe('#be123c');
      expect(s.bg).toBe('#fff1f2');
    });

    it('returns neutral tokens when status is absent', () => {
      const s = getStatusColorInfo(undefined);
      expect(s.text).toBe('#475569');
      expect(s.bg).toBe('#f8fafc');
    });
  });

  describe('formatPropertyLabel and formatPropertyValue', () => {
    it('formats known property keys into user-friendly names', () => {
      expect(formatPropertyLabel('asset_id')).toBe('Asset ID');
      expect(formatPropertyLabel('failure_date')).toBe('Failure Date');
      expect(formatPropertyLabel('repair_cost')).toBe('Repair Cost');
      expect(formatPropertyLabel('capacity_mw')).toBe('Capacity');
      expect(formatPropertyLabel('operational_status')).toBe('Operational Status');
      expect(formatPropertyLabel('next_due_date')).toBe('Next Due Date');
    });

    it('formats currency values correctly', () => {
      expect(formatPropertyValue('repair_cost', 45000)).toBe('$45,000');
      expect(formatPropertyValue('total_cost', '12500')).toBe('$12,500');
    });

    it('formats capacity with MW', () => {
      expect(formatPropertyValue('capacity_mw', 450)).toBe('450 MW');
    });

    it('formats downtime and duration with hrs', () => {
      expect(formatPropertyValue('downtime_hours', 24)).toBe('24 hrs');
      expect(formatPropertyValue('duration_hours', 12.5)).toBe('12.5 hrs');
    });

    it('formats heat rate with Btu/kWh', () => {
      expect(formatPropertyValue('measured_heat_rate', 9850)).toBe('9850 Btu/kWh');
    });

    it('formats percentage with %', () => {
      expect(formatPropertyValue('deviation_percentage', 2.4)).toBe('2.4%');
    });

    it('handles empty or missing values safely without crashing', () => {
      expect(formatPropertyValue('repair_cost', null)).toBe('Not available');
      expect(formatPropertyValue('asset_tag', undefined)).toBe('Not available');
      expect(formatPropertyValue('notes', '')).toBe('Not available');
    });
  });
});
