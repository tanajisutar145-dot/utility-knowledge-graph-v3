import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { MemoryRouter } from 'react-router-dom';

import { NodeIdentityHeader } from '../components/NodeIdentityHeader';
import { NodeSummaryCards } from '../components/NodeSummaryCards';
import { RelatedEntitiesList } from '../components/RelatedEntitiesList';
import { NodeEntityInformation } from '../components/NodeEntityInformation';
import { NodeModalActions } from '../components/NodeModalActions';
import { GraphNode, GraphRelationship } from '../../../types/graph';

// Mock test data for all 13 entity types
const mockNodes: Record<string, GraphNode> = {
  Utility: {
    id: 'utl-1',
    label: 'Utility',
    labels: ['Utility'],
    name: 'Pacific Northwest Energy',
    entity_id: 'UTL-001',
    properties: {
      utility_id: 'UTL-001',
      name: 'Pacific Northwest Energy',
      country: 'USA',
      region: 'Pacific Northwest',
      status: 'active',
      description: 'Regional generation and transmission utility',
    },
  },
  PowerPlant: {
    id: 'plt-1',
    label: 'PowerPlant',
    labels: ['PowerPlant'],
    name: 'Columbia River Hydro Station',
    entity_id: 'PLANT-001',
    properties: {
      plant_id: 'PLANT-001',
      name: 'Columbia River Hydro Station',
      plant_type: 'Hydroelectric',
      capacity_mw: 1200,
      location: 'Chelan County, WA',
      status: 'operational',
      utility_id: 'UTL-001',
    },
  },
  GeneratingUnit: {
    id: 'unt-9',
    label: 'GeneratingUnit',
    labels: ['GeneratingUnit'],
    name: 'Unit 2',
    entity_id: 'UNT-009',
    properties: {
      unit_id: 'UNT-009',
      unit_name: 'Unit 2',
      unit_type: 'Francis Hydro Turbine',
      capacity_mw: 200,
      status: 'operational',
      plant_id: 'PLANT-001',
    },
  },
  Asset: {
    id: 'ast-40',
    label: 'Asset',
    labels: ['Asset'],
    name: 'Unit 2 Main Generator',
    entity_id: 'AST-040',
    properties: {
      asset_id: 'AST-040',
      name: 'Unit 2 Main Generator',
      asset_tag: 'GEN-002',
      asset_class: 'generator',
      criticality: 'critical',
      operational_status: 'operational',
      manufacturer: 'General Electric',
      model: 'ATB-2',
      unit_id: 'UNT-009',
    },
  },
  Component: {
    id: 'cmp-12',
    label: 'Component',
    labels: ['Component'],
    name: 'Stator Core Assembly',
    entity_id: 'CMP-012',
    properties: {
      component_id: 'CMP-012',
      component_name: 'Stator Core Assembly',
      component_type: 'stator',
      criticality: 'high',
      status: 'operational',
      manufacturer: 'GE Hydro',
      asset_id: 'AST-040',
    },
  },
  Inspection: {
    id: 'ins-5',
    label: 'Inspection',
    labels: ['Inspection'],
    name: 'Annual Stator Insulation Assessment',
    entity_id: 'INS-005',
    properties: {
      inspection_id: 'INS-005',
      inspection_type: 'dielectric_testing',
      inspection_date: '2025-08-14',
      severity: 'moderate',
      condition: 'fair',
      findings: 'Partial discharge detected near slot 42',
      recommended_action: 'Perform wedge tightness check during next outage',
      asset_id: 'AST-040',
    },
  },
  FailureEvent: {
    id: 'flr-3',
    label: 'FailureEvent',
    labels: ['FailureEvent'],
    name: 'Step-Up Transformer Overheating Trip',
    entity_id: 'FLR-003',
    properties: {
      failure_id: 'FLR-003',
      failure_mode: 'overheating',
      failure_date: '2024-11-20',
      severity: 'critical',
      downtime_hours: 48,
      actual_cost: 85000,
      root_cause: 'Cooling fan contactor failure',
      status: 'resolved',
      asset_id: 'AST-040',
    },
  },
  WorkOrder: {
    id: 'wo-101',
    label: 'WorkOrder',
    labels: ['WorkOrder'],
    name: 'Replace Forced Air Cooling Fans',
    entity_id: 'WO-101',
    properties: {
      work_order_id: 'WO-101',
      work_type: 'corrective',
      priority: 'high',
      status: 'completed',
      scheduled_date: '2024-11-21',
      completion_date: '2024-11-23',
      total_cost: 32000,
      asset_id: 'AST-040',
    },
  },
  MaintenancePlan: {
    id: 'mp-8',
    label: 'MaintenancePlan',
    labels: ['MaintenancePlan'],
    name: 'Quarterly Bearing Oil Sampling',
    entity_id: 'MP-008',
    properties: {
      maintenance_plan_id: 'MP-008',
      plan_name: 'Quarterly Bearing Oil Sampling',
      maintenance_type: 'preventive',
      frequency: 'quarterly',
      next_due_date: '2026-12-01',
      status: 'active',
      asset_id: 'AST-040',
    },
  },
  OutageEvent: {
    id: 'out-4',
    label: 'OutageEvent',
    labels: ['OutageEvent'],
    name: 'Unit 2 Fall Scheduled Maintenance Outage',
    entity_id: 'OUT-004',
    properties: {
      outage_id: 'OUT-004',
      outage_type: 'planned',
      duration_hours: 120,
      estimated_generation_loss_mwh: 24000,
      estimated_cost: 150000,
      status: 'completed',
      unit_id: 'UNT-009',
    },
  },
  HeatRateTest: {
    id: 'hrt-2',
    label: 'HeatRateTest',
    labels: ['HeatRateTest'],
    name: 'Q3 Capacity and Heat Rate Performance Run',
    entity_id: 'HRT-002',
    properties: {
      test_id: 'HRT-002',
      test_date: '2025-09-10',
      measured_heat_rate: 9650,
      baseline_heat_rate: 9500,
      deviation_percentage: 1.58,
      test_status: 'passed',
      unit_id: 'UNT-009',
    },
  },
  Document: {
    id: 'doc-1',
    label: 'Document',
    labels: ['Document'],
    name: 'Columbia River Generating Unit 2 Operations Manual',
    entity_id: 'DOC-001',
    properties: {
      document_id: 'DOC-001',
      title: 'Columbia River Generating Unit 2 Operations Manual',
      document_type: 'technical_manual',
      created_date: '2024-01-15',
      processing_status: 'indexed',
    },
  },
  Chunk: {
    id: 'chk-55',
    label: 'Chunk',
    labels: ['Chunk'],
    name: 'Chunk 55',
    entity_id: 'CHK-055',
    properties: {
      chunk_id: 'CHK-055',
      chunk_index: 3,
      document_id: 'DOC-001',
      embedding_model: 'text-embedding-ada-002',
      text: 'Generator stator temperature alarms trigger when RTD readings exceed 120 degrees Celsius.',
    },
  },
};

describe('Node Intelligence Popup Components', () => {
  describe('NodeIdentityHeader', () => {
    it('renders friendly label, identifier, and title for GeneratingUnit', () => {
      const node = mockNodes.GeneratingUnit;
      const html = renderToStaticMarkup(
        <NodeIdentityHeader
          node={node}
          parentEntity={{
            id: 'plt-1',
            name: 'Columbia River Hydro Station',
            label: 'PowerPlant',
            friendlyLabel: 'Power Plant',
            entity_id: 'PLANT-001',
            relationship: 'Located at Power Plant',
          }}
          onClose={() => {}}
        />
      );

      expect(html).toContain('Generating Unit');
      expect(html).toContain('UNT-009');
      expect(html).toContain('Unit 2');
      expect(html).toContain('Located at Power Plant');
      expect(html).toContain('Columbia River Hydro Station');
      expect(html).toContain('operational');
    });

    it('renders close button with accessibility tooltip', () => {
      const html = renderToStaticMarkup(
        <NodeIdentityHeader node={mockNodes.Asset} onClose={() => {}} />
      );
      expect(html).toContain('aria-label="close"');
    });
  });

  describe('NodeSummaryCards adapts to all 13 entity types', () => {
    Object.entries(mockNodes).forEach(([label, node]) => {
      it(`renders dynamic summary cards correctly for ${label}`, () => {
        const html = renderToStaticMarkup(
          <NodeSummaryCards
            node={node}
            parentEntity={{
              id: 'parent-1',
              name: 'Parent Container',
              label: 'Parent',
              friendlyLabel: 'Parent',
              relationship: 'Parent Entity',
            }}
            neighbors={[node]}
            relationships={[]}
          />
        );

        expect(html.length).toBeGreaterThan(50);
        // Ensure no NaN or undefined leaked into markup
        expect(html).not.toContain('NaN');
        expect(html).not.toContain('undefined MW');
        expect(html).not.toContain('undefined hrs');
      });
    });

    it('displays unit capacity with MW formatting for GeneratingUnit', () => {
      const html = renderToStaticMarkup(
        <NodeSummaryCards node={mockNodes.GeneratingUnit} />
      );
      expect(html).toContain('200 MW');
      expect(html).toContain('Rated Capacity');
    });

    it('displays downtime hours and repair cost for FailureEvent', () => {
      const html = renderToStaticMarkup(
        <NodeSummaryCards node={mockNodes.FailureEvent} />
      );
      expect(html).toContain('48 hrs');
      expect(html).toContain('$85,000');
      expect(html).toContain('Failure Mode');
    });

    it('displays measured heat rate and deviation for HeatRateTest', () => {
      const html = renderToStaticMarkup(
        <NodeSummaryCards node={mockNodes.HeatRateTest} />
      );
      expect(html).toContain('9650 Btu/kWh');
      expect(html).toContain('1.58%');
    });

    it('gracefully handles missing optional properties without crashing', () => {
      const emptyPropsNode: GraphNode = {
        id: 'empty-1',
        label: 'GeneratingUnit',
        labels: ['GeneratingUnit'],
        name: 'Empty Unit',
        entity_id: 'UNT-999',
        properties: {},
      };

      const html = renderToStaticMarkup(
        <NodeSummaryCards node={emptyPropsNode} />
      );
      expect(html).not.toBeNull();
    });
  });

  describe('RelatedEntitiesList', () => {
    const centerNode = mockNodes.GeneratingUnit;
    const neighborNodes = [mockNodes.PowerPlant, mockNodes.Asset];
    const rels: GraphRelationship[] = [
      { id: 'r1', source: 'plt-1', target: 'unt-9', type: 'HAS_UNIT', properties: {} },
      { id: 'r2', source: 'unt-9', target: 'ast-40', type: 'HAS_ASSET', properties: {} },
    ];

    it('renders directional relationship descriptions', () => {
      const html = renderToStaticMarkup(
        <RelatedEntitiesList
          centerNode={centerNode}
          neighbors={neighborNodes}
          relationships={rels}
          parentEntity={{
            id: 'plt-1',
            name: 'Columbia River Hydro Station',
            label: 'PowerPlant',
            friendlyLabel: 'Power Plant',
            relationship: 'Located at Power Plant',
          }}
          onSelectNeighbor={() => {}}
        />
      );

      expect(html).toContain('Related Entities');
      expect(html).toContain('Columbia River Hydro Station');
      expect(html).toContain('Unit 2 Main Generator');
      expect(html).toContain('Contains Asset');
      expect(html).toContain('Located at Power Plant');
    });

    it('renders empty state when neighbors array is empty', () => {
      const html = renderToStaticMarkup(
        <RelatedEntitiesList
          centerNode={centerNode}
          neighbors={[]}
          relationships={[]}
          onSelectNeighbor={() => {}}
        />
      );
      expect(html).toContain('No related entities found.');
    });
  });

  describe('NodeEntityInformation', () => {
    it('groups properties into Identification, Operational, and History sections', () => {
      const html = renderToStaticMarkup(
        <MemoryRouter>
          <NodeEntityInformation node={mockNodes.FailureEvent} />
        </MemoryRouter>
      );

      expect(html).toContain('Entity Information');
      expect(html).toContain('Identification');
      expect(html).toContain('Failure Mode');
      expect(html).toContain('Downtime');
      expect(html).toContain('48 hrs');
      expect(html).toContain('Actual Cost');
      expect(html).toContain('$85,000');
      expect(html).toContain('Technical Details');
    });

    it('renders linked grounding documents when present in detail', () => {
      const detail = {
        node: mockNodes.Asset,
        connected_count: 5,
        connected_by_type: { HAS_COMPONENT: 2 },
        neighbors_preview: [],
        document_links: [
          {
            document_id: 'DOC-001',
            title: 'Generator Maintenance Manual',
            chunk_id: 'CHK-012',
            snippet: 'Inspect brushes and slip rings every 500 hours',
          },
        ],
      };

      const html = renderToStaticMarkup(
        <MemoryRouter>
          <NodeEntityInformation node={mockNodes.Asset} detail={detail} />
        </MemoryRouter>
      );

      expect(html).toContain('Linked Grounding Documents');
      expect(html).toContain('Generator Maintenance Manual');
      expect(html).toContain('CHK-012');
      expect(html).toContain('Inspect brushes and slip rings');
    });
  });

  describe('NodeModalActions', () => {
    it('renders Search Evidence, Ask Intelligence, View in Full Graph, and Close', () => {
      const html = renderToStaticMarkup(
        <MemoryRouter>
          <NodeModalActions
            node={mockNodes.Asset}
            onViewInFullGraph={() => {}}
            onClose={() => {}}
          />
        </MemoryRouter>
      );

      expect(html).toContain('Search Evidence');
      expect(html).toContain('Ask Intelligence');
      expect(html).toContain('View in Full Graph');
      expect(html).toContain('Close');
    });
  });
});
