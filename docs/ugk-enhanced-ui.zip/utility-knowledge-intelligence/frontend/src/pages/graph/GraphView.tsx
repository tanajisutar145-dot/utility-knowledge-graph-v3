import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Box,
  Typography,
  Card,
  Chip,
  Button,
  CircularProgress,
  Alert,
} from '@mui/material';
import {
  AccountTree as GraphIcon,
  Refresh as RefreshIcon,
  Hub as HubIcon,
  Storage as StorageIcon,
} from '@mui/icons-material';

import { useLocation } from 'react-router-dom';

import {
  GraphOverviewResponse,
  GraphNode,
  GraphRelationship,
  GraphNodeDetailResponse,
  GraphFilters,
} from '../../types/graph';
import {
  getGraphOverview,
  exploreGraph,
  getGraphNodeDetail,
  getGraphNodeNeighbors,
} from '../../services/api';

import { GraphToolbar } from './components/GraphToolbar';
import { GraphCanvas, GraphCanvasHandle } from './components/GraphCanvas';
import { GraphLegend } from './components/GraphLegend';
import { NodeIntelligenceModal } from './components/NodeIntelligenceModal';
import { Psychology as IntelligenceIcon } from '@mui/icons-material';

const GraphView: React.FC = () => {
  const location = useLocation();

  // Graph overview metadata
  const [overview, setOverview] = useState<GraphOverviewResponse | null>(null);
  const [isLoadingOverview, setIsLoadingOverview] = useState<boolean>(true);

  // Active filter state
  const [filters, setFilters] = useState<GraphFilters>({
    limit: 100,
  });

  // Active graph elements displayed
  const [nodes, setNodes] = useState<GraphNode[]>([]);
  const [relationships, setRelationships] = useState<GraphRelationship[]>([]);
  const [isTruncated, setIsTruncated] = useState<boolean>(false);
  const [isLoadingGraph, setIsLoadingGraph] = useState<boolean>(true);
  const [graphError, setGraphError] = useState<string | null>(null);

  // Selected node & details & modal state
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [nodeDetail, setNodeDetail] = useState<GraphNodeDetailResponse | null>(null);

  // Layout configuration
  const [layoutName, setLayoutName] = useState<string>('cose');

  // Canvas handle ref
  const canvasRef = useRef<GraphCanvasHandle>(null);

  // In-flight tracker to cancel stale requests
  const activeRequestIdRef = useRef<number>(0);

  // 1. Fetch overview
  const fetchOverview = useCallback(async () => {
    try {
      setIsLoadingOverview(true);
      const data = await getGraphOverview();
      setOverview(data);
    } catch (err: any) {
      console.error('Failed to fetch graph overview:', err);
    } finally {
      setIsLoadingOverview(false);
    }
  }, []);

  // 2. Fetch graph with current filters
  const fetchGraph = useCallback(
    async (appliedFilters: GraphFilters) => {
      const currentReqId = ++activeRequestIdRef.current;
      setIsLoadingGraph(true);
      setGraphError(null);

      try {
        const result = await exploreGraph(appliedFilters);
        if (currentReqId === activeRequestIdRef.current) {
          setNodes(result.nodes);
          setRelationships(result.relationships);
          setIsTruncated(result.is_truncated);
          setGraphError(null);
        }
      } catch (err: any) {
        if (currentReqId === activeRequestIdRef.current) {
          console.error('Failed to explore graph:', err);
          const msg =
            err?.response?.data?.detail ||
            err?.message ||
            'Failed to load graph data from Neo4j';
          setGraphError(msg);
        }
      } finally {
        if (currentReqId === activeRequestIdRef.current) {
          setIsLoadingGraph(false);
        }
      }
    },
    []
  );

  // Initial load
  useEffect(() => {
    fetchOverview();
    const params = new URLSearchParams(location.search);
    const queryParam = params.get('query') || params.get('search');
    const labelParam = params.get('node_label') || params.get('label');
    const relParam = params.get('rel_type');

    if (queryParam || labelParam || relParam) {
      const initialFilters: GraphFilters = {
        limit: 100,
        query: queryParam || undefined,
        node_label: labelParam || undefined,
        rel_type: relParam || undefined,
      };
      setFilters(initialFilters);
      fetchGraph(initialFilters);
    } else {
      fetchGraph(filters);
    }
  }, [fetchOverview, fetchGraph, location.search]); // eslint-disable-line react-hooks/exhaustive-deps

  // 3. Handle node selection and detail loading
  const handleSelectNode = useCallback(async (nodeId: string) => {
    setSelectedNodeId(nodeId);
    setIsModalOpen(true);

    try {
      const detail = await getGraphNodeDetail(nodeId);
      setNodeDetail(detail);
    } catch (err: any) {
      console.error('Failed to fetch node detail:', err);
    }
  }, []);

  const handleClearSelection = useCallback(() => {
    setSelectedNodeId(null);
    setNodeDetail(null);
    setIsModalOpen(false);
  }, []);

  const handleCloseModal = useCallback(() => {
    setIsModalOpen(false);
  }, []);

  // 4. Handle expanding node neighbors onto main graph canvas
  const handleExpandNeighbors = useCallback(
    async (nodeId: string) => {
      try {
        const neighborResult = await getGraphNodeNeighbors(nodeId, 50);

        setNodes((prevNodes) => {
          const existingIds = new Set(prevNodes.map((n) => n.id));
          const newNodes = neighborResult.neighbor_nodes.filter((n) => !existingIds.has(n.id));
          return [...prevNodes, ...newNodes];
        });

        setRelationships((prevRels) => {
          const existingIds = new Set(prevRels.map((r) => r.id));
          const newRels = neighborResult.relationships.filter((r) => !existingIds.has(r.id));
          return [...prevRels, ...newRels];
        });

        setTimeout(() => {
          canvasRef.current?.fit();
        }, 300);
      } catch (err: any) {
        console.error('Failed to expand neighbors on main canvas:', err);
      }
    },
    []
  );

  const handleViewInFullGraph = useCallback((nodeId: string) => {
    setIsModalOpen(false);
    setSelectedNodeId(nodeId);
    handleExpandNeighbors(nodeId);
    setTimeout(() => {
      canvasRef.current?.centerNode(nodeId);
    }, 150);
  }, [handleExpandNeighbors]);

  // Filter handlers
  const handleFilterChange = (newFilters: Partial<GraphFilters>) => {
    setFilters((prev) => ({ ...prev, ...newFilters }));
  };

  const handleApplyFilters = () => {
    fetchGraph(filters);
  };

  const handleResetFilters = () => {
    const reset = { limit: 100 };
    setFilters(reset);
    fetchGraph(reset);
  };

  const handleSelectLabelFromLegend = (lbl: string) => {
    const updated = { ...filters, node_label: lbl || undefined };
    setFilters(updated);
    fetchGraph(updated);
  };

  const handleFullRefresh = () => {
    fetchOverview();
    fetchGraph(filters);
    if (selectedNodeId) {
      handleSelectNode(selectedNodeId);
    }
  };

  return (
    <Box
      sx={{
        width: '100%',
        maxWidth: 1600,
        mx: 'auto',
        display: 'flex',
        flexDirection: 'column',
        height: 'calc(100vh - 110px)',
      }}
    >
      {/* Page Header */}
      <Box
        sx={{
          mb: 2,
          display: 'flex',
          flexDirection: { xs: 'column', md: 'row' },
          justifyContent: 'space-between',
          alignItems: { xs: 'flex-start', md: 'center' },
          gap: 1.5,
          flexShrink: 0,
        }}
      >
        <Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <GraphIcon sx={{ color: '#0f766e', fontSize: 26 }} />
            <Typography
              variant="h5"
              component="h1"
              sx={{ fontWeight: 700, color: '#0f172a', letterSpacing: '-0.02em' }}
            >
              Knowledge Graph Explorer
            </Typography>
          </Box>
          <Typography variant="body2" sx={{ color: '#64748b', mt: 0.25, fontSize: '0.875rem' }}>
            Interactive utility ontology, asset relationship mapping, and multi-hop dependency exploration.
          </Typography>
        </Box>

        {/* Overview Stats Badges & Refresh */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, flexWrap: 'wrap' }}>
          {overview && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Chip
                icon={<StorageIcon sx={{ fontSize: '15px !important' }} />}
                label={`${overview.total_nodes} Total Nodes`}
                size="small"
                sx={{
                  bgcolor: '#f0fdfa',
                  color: '#0f766e',
                  fontWeight: 600,
                  fontSize: '0.75rem',
                  border: '1px solid #99f6e4',
                }}
              />
              <Chip
                icon={<HubIcon sx={{ fontSize: '15px !important' }} />}
                label={`${overview.total_relationships} Relationships`}
                size="small"
                sx={{
                  bgcolor: '#f8fafc',
                  color: '#475569',
                  fontWeight: 600,
                  fontSize: '0.75rem',
                  border: '1px solid #e2e8f0',
                }}
              />
            </Box>
          )}

          <Button
            variant="outlined"
            size="small"
            onClick={handleFullRefresh}
            disabled={isLoadingGraph || isLoadingOverview}
            startIcon={
              isLoadingGraph ? (
                <CircularProgress size={14} color="inherit" />
              ) : (
                <RefreshIcon sx={{ fontSize: 16 }} />
              )
            }
            sx={{
              borderColor: '#cbd5e1',
              color: '#334155',
              bgcolor: '#ffffff',
              textTransform: 'none',
              fontWeight: 600,
              fontSize: '0.8125rem',
              px: 1.5,
              py: 0.5,
              borderRadius: 1.5,
              '&:hover': {
                borderColor: '#0f766e',
                bgcolor: '#f8fafc',
                color: '#0f766e',
              },
            }}
          >
            Refresh
          </Button>
        </Box>
      </Box>

      {/* Error Banner */}
      {graphError && (
        <Alert
          severity="error"
          sx={{ mb: 2, borderRadius: 1.5 }}
          action={
            <Button color="inherit" size="small" onClick={() => fetchGraph(filters)}>
              Retry
            </Button>
          }
        >
          {graphError}
        </Alert>
      )}

      {/* Toolbar */}
      <GraphToolbar
        filters={filters}
        overview={overview}
        onFilterChange={handleFilterChange}
        onApply={handleApplyFilters}
        onReset={handleResetFilters}
        onFitView={() => canvasRef.current?.fit()}
        onReLayout={() => canvasRef.current?.runLayout()}
        layoutName={layoutName}
        onLayoutChange={(l) => {
          setLayoutName(l);
          canvasRef.current?.runLayout(l);
        }}
        totalLoadedNodes={nodes.length}
        totalLoadedRels={relationships.length}
        isTruncated={isTruncated}
        isLoading={isLoadingGraph}
      />

      {/* Main Exploration Work Area */}
      <Box
        sx={{
          flexGrow: 1,
          display: 'flex',
          gap: 2,
          position: 'relative',
          overflow: 'hidden',
          minHeight: 480,
        }}
      >
        {/* Graph Canvas Panel (Center/Left) */}
        <Card
          sx={{
            flexGrow: 1,
            height: '100%',
            position: 'relative',
            border: '1px solid #e2e8f0',
            borderRadius: 2,
            boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
            overflow: 'hidden',
          }}
        >
          {isLoadingGraph && (
            <Box
              sx={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                bgcolor: 'rgba(255, 255, 255, 0.75)',
                backdropFilter: 'blur(3px)',
                zIndex: 20,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 1.5,
              }}
            >
              <CircularProgress size={36} sx={{ color: '#0f766e' }} />
              <Typography variant="body2" sx={{ color: '#64748b', fontWeight: 500 }}>
                Loading knowledge graph nodes...
              </Typography>
            </Box>
          )}

          {nodes.length === 0 && !isLoadingGraph ? (
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                height: '100%',
                p: 4,
                textAlign: 'center',
              }}
            >
              <HubIcon sx={{ fontSize: 48, color: '#cbd5e1', mb: 1.5 }} />
              <Typography variant="h6" sx={{ color: '#334155', fontWeight: 600 }}>
                No Matching Entities Found
              </Typography>
              <Typography variant="body2" sx={{ color: '#64748b', maxWidth: 400, mt: 0.5, mb: 2 }}>
                No graph nodes match the specified label or search filter. Try clearing filters to explore the full graph.
              </Typography>
              <Button
                variant="outlined"
                size="small"
                onClick={handleResetFilters}
                sx={{ textTransform: 'none', borderRadius: 1.5 }}
              >
                Reset Filters
              </Button>
            </Box>
          ) : (
            <GraphCanvas
              ref={canvasRef}
              nodes={nodes}
              relationships={relationships}
              selectedNodeId={selectedNodeId}
              onSelectNode={handleSelectNode}
              onClearSelection={handleClearSelection}
              layoutName={layoutName}
            />
          )}

          {/* Collapsible Entity Type Legend */}
          {overview && (
            <GraphLegend
              availableLabels={overview.available_labels}
              labelCounts={overview.node_counts_by_label}
              selectedLabel={filters.node_label}
              onSelectLabel={handleSelectLabelFromLegend}
            />
          )}
          {/* Floating Re-open Button when viewing in full graph */}
          {selectedNodeId && !isModalOpen && (
            <Button
              variant="contained"
              size="small"
              onClick={() => setIsModalOpen(true)}
              startIcon={<IntelligenceIcon sx={{ fontSize: 16 }} />}
              sx={{
                position: 'absolute',
                bottom: 16,
                right: 16,
                zIndex: 15,
                bgcolor: '#0f766e',
                color: '#ffffff',
                fontWeight: 600,
                textTransform: 'none',
                fontSize: '0.8125rem',
                borderRadius: 2,
                px: 2,
                py: 0.75,
                boxShadow: '0 4px 12px rgba(15, 118, 110, 0.25)',
                '&:hover': { bgcolor: '#115e59' },
              }}
            >
              Open Node Intelligence {nodeDetail ? `• ${nodeDetail.node.name}` : ''}
            </Button>
          )}
        </Card>

        {/* Polished, Interactive Node Intelligence Popup */}
        <NodeIntelligenceModal
          open={isModalOpen}
          nodeId={selectedNodeId}
          onClose={handleCloseModal}
          onViewInFullGraph={handleViewInFullGraph}
        />
      </Box>
    </Box>
  );
};

export default GraphView;