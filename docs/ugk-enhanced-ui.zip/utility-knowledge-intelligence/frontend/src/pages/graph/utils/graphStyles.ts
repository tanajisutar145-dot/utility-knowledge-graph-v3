/**
 * Graph visual design system: node colors, badge tokens, and Cytoscape stylesheets
 */

export const NODE_COLORS: Record<string, { bg: string; border: string; text: string }> = {
  Utility: { bg: '#0f766e', border: '#115e59', text: '#ffffff' },
  PowerPlant: { bg: '#0284c7', border: '#0369a1', text: '#ffffff' },
  GeneratingUnit: { bg: '#2563eb', border: '#1d4ed8', text: '#ffffff' },
  Asset: { bg: '#7c3aed', border: '#6d28d9', text: '#ffffff' },
  Component: { bg: '#4f46e5', border: '#4338ca', text: '#ffffff' },
  Inspection: { bg: '#16a34a', border: '#15803d', text: '#ffffff' },
  FailureEvent: { bg: '#e11d48', border: '#be123c', text: '#ffffff' },
  WorkOrder: { bg: '#ea580c', border: '#c2410c', text: '#ffffff' },
  MaintenancePlan: { bg: '#0891b2', border: '#0e7490', text: '#ffffff' },
  OutageEvent: { bg: '#d97706', border: '#b45309', text: '#ffffff' },
  HeatRateTest: { bg: '#059669', border: '#047857', text: '#ffffff' },
  Document: { bg: '#475569', border: '#334155', text: '#ffffff' },
  Chunk: { bg: '#64748b', border: '#475569', text: '#ffffff' },
};

export const DEFAULT_NODE_COLOR = { bg: '#64748b', border: '#475569', text: '#ffffff' };

export const getNodeColor = (label: string) => {
  return NODE_COLORS[label] || DEFAULT_NODE_COLOR;
};

export const CYTOSCAPE_STYLESHEET: any = [
  {
    selector: 'node',
    style: {
      'background-color': 'data(color)',
      'label': 'data(shortLabel)',
      'color': '#1e293b',
      'font-size': '10px',
      'font-weight': '600',
      'text-valign': 'bottom',
      'text-margin-y': 5,
      'text-background-color': '#ffffff',
      'text-background-opacity': 0.85,
      'text-background-padding': '2px',
      'text-background-shape': 'roundrectangle',
      'width': 34,
      'height': 34,
      'border-width': 2,
      'border-color': 'data(borderColor)',
      'transition-property': 'background-color, border-color, width, height, border-width',
      'transition-duration': '0.2s',
    },
  },
  {
    selector: 'node:selected',
    style: {
      'border-width': 4,
      'border-color': '#0f172a',
      'width': 42,
      'height': 42,
      'font-size': '11px',
      'font-weight': '700',
      'z-index': 999,
    },
  },
  {
    selector: 'node.highlighted',
    style: {
      'border-width': 4,
      'border-color': '#0f766e',
      'z-index': 900,
    },
  },
  {
    selector: 'edge',
    style: {
      'width': 1.5,
      'line-color': '#94a3b8',
      'target-arrow-color': '#94a3b8',
      'target-arrow-shape': 'triangle',
      'curve-style': 'bezier',
      'label': 'data(type)',
      'font-size': '8px',
      'color': '#64748b',
      'text-background-color': '#ffffff',
      'text-background-opacity': 0.9,
      'text-background-padding': '1px',
      'text-rotation': 'autorotate',
      'arrow-scale': 0.8,
      'opacity': 0.85,
    },
  },
  {
    selector: 'edge:selected',
    style: {
      'width': 3,
      'line-color': '#0f766e',
      'target-arrow-color': '#0f766e',
      'color': '#0f766e',
      'font-weight': '700',
      'z-index': 950,
      'opacity': 1,
    },
  },
  {
    selector: 'edge.highlighted',
    style: {
      'width': 2.5,
      'line-color': '#0f766e',
      'target-arrow-color': '#0f766e',
      'z-index': 900,
      'opacity': 1,
    },
  },
];
