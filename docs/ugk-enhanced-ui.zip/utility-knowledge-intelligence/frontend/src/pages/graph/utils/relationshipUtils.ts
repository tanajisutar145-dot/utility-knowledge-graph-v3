/**
 * Utility functions for friendly entity labels, relationship mapping, parent derivation,
 * and property formatting in the Knowledge Graph Node Intelligence Popup.
 */

import { GraphNode, GraphRelationship } from '../../../types/graph';

// 1. Friendly Entity Type Mapping
export const ENTITY_LABEL_MAP: Record<string, string> = {
  Utility: 'Utility',
  PowerPlant: 'Power Plant',
  GeneratingUnit: 'Generating Unit',
  Asset: 'Asset',
  Component: 'Component',
  Inspection: 'Inspection Record',
  FailureEvent: 'Failure Event',
  WorkOrder: 'Work Order',
  MaintenancePlan: 'Maintenance Plan',
  OutageEvent: 'Outage Event',
  HeatRateTest: 'Heat Rate Test',
  Document: 'Knowledge Document',
  Chunk: 'Document Chunk',
};

export const formatEntityLabel = (label: string): string => {
  if (!label) return 'Entity';
  if (ENTITY_LABEL_MAP[label]) return ENTITY_LABEL_MAP[label];
  // Insert spaces before capitals for unknown camelCase labels
  return label.replace(/([a-z])([A-Z])/g, '$1 $2');
};

// 2. Centralized Relationship Display Mapping (Forward & Reverse)
export const RELATIONSHIP_LABELS_FORWARD: Record<string, string> = {
  HAS_PLANT: 'Contains Power Plant',
  HAS_UNIT: 'Contains Generating Unit',
  HAS_ASSET: 'Contains Asset',
  HAS_COMPONENT: 'Contains Component',
  HAS_INSPECTION: 'Has Inspection Record',
  HAS_FAILURE: 'Has Recorded Failure',
  HAS_WORK_ORDER: 'Has Work Order',
  HAS_MAINTENANCE_PLAN: 'Has Maintenance Plan',
  HAS_OUTAGE: 'Has Outage Record',
  HAS_HEAT_RATE_TEST: 'Has Heat Rate Test',
  TRIGGERED_WORK_ORDER: 'Triggered Work Order',
  HAS_CHUNK: 'Contains Document Chunk',
  ABOUT_ASSET: 'References Asset',
  ABOUT_UNIT: 'References Generating Unit',
  ABOUT_INSPECTION: 'References Inspection',
  ABOUT_FAILURE: 'References Failure',
  ABOUT_WORK_ORDER: 'References Work Order',
};

export const RELATIONSHIP_LABELS_REVERSE: Record<string, string> = {
  HAS_PLANT: 'Operated by Utility',
  HAS_UNIT: 'Located at Power Plant',
  HAS_ASSET: 'Part of Generating Unit',
  HAS_COMPONENT: 'Installed on Asset',
  HAS_INSPECTION: 'Inspection for Asset',
  HAS_FAILURE: 'Failure on Asset',
  HAS_WORK_ORDER: 'Work Order for Asset',
  HAS_MAINTENANCE_PLAN: 'Maintenance Plan for Asset',
  HAS_OUTAGE: 'Outage for Generating Unit',
  HAS_HEAT_RATE_TEST: 'Heat Rate Test for Unit',
  TRIGGERED_WORK_ORDER: 'Triggered by Failure Event',
  HAS_CHUNK: 'Part of Document',
  ABOUT_ASSET: 'Referenced in Document / Chunk',
  ABOUT_UNIT: 'Referenced in Document / Chunk',
  ABOUT_INSPECTION: 'Referenced in Document / Chunk',
  ABOUT_FAILURE: 'Referenced in Document / Chunk',
  ABOUT_WORK_ORDER: 'Referenced in Document / Chunk',
};

/**
 * Format relationship label according to direction relative to current node
 */
export const formatRelationshipLabel = (
  relType: string,
  isOutbound: boolean = true
): string => {
  const dictionary = isOutbound
    ? RELATIONSHIP_LABELS_FORWARD
    : RELATIONSHIP_LABELS_REVERSE;

  if (dictionary[relType]) {
    return dictionary[relType];
  }

  // Fallback: convert SNAKE_CASE to Title Case
  return relType
    .toLowerCase()
    .split('_')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

/**
 * Generate a friendly human-readable sentence for two connected nodes
 */
export const describeRelationshipSentence = (
  sourceNode: GraphNode,
  relType: string,
  targetNode: GraphNode
): string => {
  switch (relType) {
    case 'HAS_PLANT':
      return `${sourceNode.name} operates the ${targetNode.name} power plant.`;
    case 'HAS_UNIT':
      return `${sourceNode.name} contains generating unit ${targetNode.name}.`;
    case 'HAS_ASSET':
      return `${sourceNode.name} includes asset ${targetNode.name}.`;
    case 'HAS_COMPONENT':
      return `${sourceNode.name} contains component ${targetNode.name}.`;
    case 'HAS_INSPECTION':
      return `${sourceNode.name} has recorded inspection ${targetNode.name}.`;
    case 'HAS_FAILURE':
      return `${sourceNode.name} experienced failure event ${targetNode.name}.`;
    case 'HAS_WORK_ORDER':
      return `${sourceNode.name} has associated work order ${targetNode.name}.`;
    case 'HAS_MAINTENANCE_PLAN':
      return `${sourceNode.name} is governed by maintenance plan ${targetNode.name}.`;
    case 'HAS_OUTAGE':
      return `${sourceNode.name} experienced outage record ${targetNode.name}.`;
    case 'HAS_HEAT_RATE_TEST':
      return `${sourceNode.name} has heat rate test ${targetNode.name}.`;
    case 'TRIGGERED_WORK_ORDER':
      return `Failure event ${sourceNode.name} triggered work order ${targetNode.name}.`;
    case 'HAS_CHUNK':
      return `Document ${sourceNode.name} contains chunk ${targetNode.name}.`;
    case 'ABOUT_ASSET':
      return `Document chunk ${sourceNode.name} references asset ${targetNode.name}.`;
    case 'ABOUT_UNIT':
      return `Document chunk ${sourceNode.name} references unit ${targetNode.name}.`;
    default:
      return `${sourceNode.name} is connected to ${targetNode.name} (${formatRelationshipLabel(relType, true)}).`;
  }
};

export interface ParentEntityInfo {
  id: string;
  name: string;
  label: string;
  friendlyLabel: string;
  entity_id?: string;
  relationship: string;
}

/**
 * Deterministically find the parent entity using actual graph topology
 */
export const getParentEntity = (
  node: GraphNode,
  neighbors: GraphNode[],
  relationships: GraphRelationship[]
): ParentEntityInfo | null => {
  if (!node || !neighbors || neighbors.length === 0) return null;

  const neighborMap = new Map<string, GraphNode>();
  neighbors.forEach((n) => {
    neighborMap.set(n.id, n);
    if (n.entity_id) neighborMap.set(n.entity_id, n);
  });

  // Priority hierarchical relationship types where center node is the target (incoming parent)
  const parentRelTypes = [
    'HAS_UNIT',            // PowerPlant -> GeneratingUnit
    'HAS_ASSET',           // GeneratingUnit -> Asset
    'HAS_COMPONENT',       // Asset -> Component
    'HAS_INSPECTION',      // Asset -> Inspection
    'HAS_FAILURE',         // Asset -> FailureEvent
    'HAS_WORK_ORDER',      // Asset -> WorkOrder
    'HAS_MAINTENANCE_PLAN',// Asset -> MaintenancePlan
    'HAS_OUTAGE',          // GeneratingUnit -> OutageEvent
    'HAS_HEAT_RATE_TEST',  // GeneratingUnit -> HeatRateTest
    'HAS_PLANT',           // Utility -> PowerPlant
    'HAS_CHUNK',           // Document -> Chunk
    'TRIGGERED_WORK_ORDER',// FailureEvent -> WorkOrder
  ];

  for (const relType of parentRelTypes) {
    const parentEdge = relationships.find(
      (r) => r.type === relType && r.target === node.id
    );
    if (parentEdge) {
      const parentNode = neighborMap.get(parentEdge.source);
      if (parentNode) {
        return {
          id: parentNode.id,
          name: parentNode.name,
          label: parentNode.label,
          friendlyLabel: formatEntityLabel(parentNode.label),
          entity_id: parentNode.entity_id,
          relationship: formatRelationshipLabel(relType, false),
        };
      }
    }
  }

  // Fallback: check if any neighbor matches parent property IDs (e.g. plant_id, unit_id, asset_id)
  const props = node.properties || {};
  const parentId = props.plant_id || props.unit_id || props.asset_id || props.utility_id || props.document_id;
  if (parentId) {
    const parentNode = neighbors.find(
      (n) => n.entity_id === parentId || n.id === parentId
    );
    if (parentNode) {
      return {
        id: parentNode.id,
        name: parentNode.name,
        label: parentNode.label,
        friendlyLabel: formatEntityLabel(parentNode.label),
        entity_id: parentNode.entity_id,
        relationship: 'Parent Entity',
      };
    }
  }

  return null;
};

// 3. Status Badge Color / Variant Resolver
export interface StatusColorInfo {
  bg: string;
  text: string;
  border: string;
}

export const getStatusColorInfo = (rawStatus?: any): StatusColorInfo => {
  if (!rawStatus) {
    return { bg: '#f8fafc', text: '#475569', border: '#e2e8f0' };
  }

  const s = String(rawStatus).toLowerCase().trim();

  // Green / Normal / Completed / Healthy / Passed
  if (
    s.includes('operational') ||
    s.includes('active') ||
    s.includes('normal') ||
    s.includes('completed') ||
    s.includes('passed') ||
    s.includes('healthy') ||
    s.includes('online') ||
    s.includes('good') ||
    s.includes('satisfactory') ||
    s.includes('success')
  ) {
    return { bg: '#f0fdf4', text: '#15803d', border: '#bbf7d0' };
  }

  // Amber / Warning / In Progress / Pending / Scheduled
  if (
    s.includes('warning') ||
    s.includes('progress') ||
    s.includes('scheduled') ||
    s.includes('pending') ||
    s.includes('fair') ||
    s.includes('moderate') ||
    s.includes('medium') ||
    s.includes('maintenance') ||
    s.includes('degraded') ||
    s.includes('attention')
  ) {
    return { bg: '#fffbeb', text: '#b45309', border: '#fde68a' };
  }

  // Red / Critical / Failure / Failed / Outage / Tripped
  if (
    s.includes('critical') ||
    s.includes('failed') ||
    s.includes('failure') ||
    s.includes('outage') ||
    s.includes('offline') ||
    s.includes('tripped') ||
    s.includes('poor') ||
    s.includes('unplanned') ||
    s.includes('immediate') ||
    s.includes('high')
  ) {
    return { bg: '#fff1f2', text: '#be123c', border: '#fecdd3' };
  }

  // Blue / Info
  if (s.includes('planned') || s.includes('info') || s.includes('draft')) {
    return { bg: '#eff6ff', text: '#1d4ed8', border: '#bfdbfe' };
  }

  // Default light slate
  return { bg: '#f8fafc', text: '#475569', border: '#cbd5e1' };
};

// 4. Human-Readable Property Labels
const PROPERTY_LABEL_OVERRIDES: Record<string, string> = {
  asset_id: 'Asset ID',
  unit_id: 'Unit ID',
  plant_id: 'Plant ID',
  utility_id: 'Utility ID',
  failure_id: 'Failure ID',
  work_order_id: 'Work Order ID',
  inspection_id: 'Inspection ID',
  maintenance_plan_id: 'Maintenance Plan ID',
  outage_id: 'Outage ID',
  test_id: 'Test ID',
  document_id: 'Document ID',
  chunk_id: 'Chunk ID',
  chunk_index: 'Chunk Index',
  asset_tag: 'Asset Tag',
  asset_class: 'Asset Class',
  component_type: 'Component Type',
  plant_type: 'Plant Type',
  unit_type: 'Unit Type',
  inspection_type: 'Inspection Type',
  work_type: 'Work Type',
  maintenance_type: 'Maintenance Type',
  outage_type: 'Outage Type',
  test_status: 'Test Status',
  operational_status: 'Operational Status',
  criticality: 'Criticality',
  capacity_mw: 'Capacity',
  failure_mode: 'Failure Mode',
  root_cause: 'Root Cause',
  recommended_action: 'Recommended Action',
  findings: 'Findings',
  inspector: 'Inspector',
  failure_date: 'Failure Date',
  inspection_date: 'Inspection Date',
  installation_date: 'Installation Date',
  commissioning_date: 'Commissioning Date',
  created_date: 'Created Date',
  scheduled_date: 'Scheduled Date',
  completion_date: 'Completion Date',
  start_date: 'Start Date',
  end_date: 'End Date',
  test_date: 'Test Date',
  last_execution_date: 'Last Execution Date',
  next_due_date: 'Next Due Date',
  repair_cost: 'Repair Cost',
  actual_cost: 'Actual Cost',
  estimated_cost: 'Estimated Cost',
  total_cost: 'Total Cost',
  material_cost: 'Material Cost',
  downtime_hours: 'Downtime',
  duration_hours: 'Duration',
  labor_hours: 'Labor Hours',
  measured_heat_rate: 'Measured Heat Rate',
  baseline_heat_rate: 'Baseline Heat Rate',
  deviation_percentage: 'Heat Rate Deviation',
  estimated_generation_loss_mwh: 'Estimated Loss',
  processing_status: 'Processing Status',
  source_reference: 'Source Reference',
  manufacturer: 'Manufacturer',
  model: 'Model',
  frequency: 'Frequency',
  condition: 'Condition',
  severity: 'Severity',
  priority: 'Priority',
  location: 'Location',
  country: 'Country',
  region: 'Region',
  observations: 'Observations',
};

export const formatPropertyLabel = (key: string): string => {
  if (PROPERTY_LABEL_OVERRIDES[key]) {
    return PROPERTY_LABEL_OVERRIDES[key];
  }
  return key
    .split('_')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};

// 5. Value Formatter
export const formatPropertyValue = (key: string, value: any): string => {
  if (value === null || value === undefined || value === '') {
    return 'Not available';
  }

  // Cost formatting
  if (
    key.includes('cost') &&
    (typeof value === 'number' || !isNaN(Number(value)))
  ) {
    const num = Number(value);
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(num);
  }

  // Capacity in MW
  if (key === 'capacity_mw') {
    return `${value} MW`;
  }

  // Hours
  if (key.includes('hours') || key === 'duration_hours' || key === 'downtime_hours') {
    return `${value} hrs`;
  }

  // Heat rate
  if (key.includes('heat_rate')) {
    return `${value} Btu/kWh`;
  }

  // Generation loss
  if (key === 'estimated_generation_loss_mwh') {
    return `${value} MWh`;
  }

  // Percentages
  if (key.includes('percentage') || key.includes('percent')) {
    return `${value}%`;
  }

  // Date formatting if ISO string
  if (
    (key.includes('date') || key.includes('_at')) &&
    typeof value === 'string' &&
    /^\d{4}-\d{2}-\d{2}/.test(value)
  ) {
    try {
      const parsed = new Date(value);
      if (!isNaN(parsed.getTime())) {
        return parsed.toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
        });
      }
    } catch {
      // Fall through to string value
    }
  }

  if (typeof value === 'boolean') {
    return value ? 'Yes' : 'No';
  }

  if (Array.isArray(value)) {
    return value.join(', ');
  }

  if (typeof value === 'object') {
    return JSON.stringify(value);
  }

  return String(value);
};
