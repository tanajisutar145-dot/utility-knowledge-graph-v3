import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Box,
  Grid,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Button,
} from '@mui/material';

import { useLocation } from 'react-router-dom';

import { GraphRAGRequest, ChatMessage, GraphRAGResponse } from '../../types/api';
import { askGraphRAG, isBackendReachable } from '../../services/api';
import { IntelligenceHeader } from './components/IntelligenceHeader';
import { QuestionComposer } from './components/QuestionComposer';
import { ConversationThread } from './components/ConversationThread';
import { EvidenceInspector } from './components/EvidenceInspector';

const IntelligencePage: React.FC = () => {
  const location = useLocation();

  // Conversation and active selection state
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [selectedMessageId, setSelectedMessageId] = useState<string | null>(null);
  const [questionInput, setQuestionInput] = useState<string>('');

  // GraphRAG parameters
  const [config, setConfig] = useState<Required<Omit<GraphRAGRequest, 'question'>>>({
    top_k: 5,
    graph_depth: 1,
    min_similarity: 0.0,
    include_verification: true,
  });

  // Loading & service status
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isBackendHealthy, setIsBackendHealthy] = useState<boolean | null>(null);

  // Clear confirmation dialog
  const [clearDialogOpen, setClearDialogOpen] = useState<boolean>(false);

  // In-flight request ID tracker
  const activeRequestIdRef = useRef<number>(0);

  // Check backend health on mount
  useEffect(() => {
    let isMounted = true;
    const checkHealth = async () => {
      try {
        const reachable = await isBackendReachable();
        if (isMounted) setIsBackendHealthy(reachable);
      } catch {
        if (isMounted) setIsBackendHealthy(false);
      }
    };
    checkHealth();
    return () => {
      isMounted = false;
    };
  }, []);

  // Populate question input from URL query parameters (e.g. from Dashboard or Asset page)
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const qParam = params.get('q') || params.get('question');
    if (qParam && qParam.trim()) {
      setQuestionInput(qParam.trim());
    }
  }, [location.search]);

  // Submit question to GraphRAG
  const handleAskQuestion = useCallback(
    async (overrideQuestion?: string) => {
      const targetQuestion = (overrideQuestion !== undefined ? overrideQuestion : questionInput).trim();
      if (!targetQuestion) return;

      const currentReqId = ++activeRequestIdRef.current;
      const messageId = `msg-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
      const timestamp = new Date().toISOString();

      // Add user message in loading state
      const newMessage: ChatMessage = {
        id: messageId,
        timestamp,
        question: targetQuestion,
        isLoading: true,
      };

      setMessages((prev) => [...prev, newMessage]);
      setSelectedMessageId(messageId);
      setQuestionInput('');
      setIsLoading(true);

      const requestPayload: GraphRAGRequest = {
        question: targetQuestion,
        top_k: config.top_k,
        graph_depth: config.graph_depth,
        min_similarity: config.min_similarity,
        include_verification: config.include_verification,
      };

      try {
        const response: GraphRAGResponse = await askGraphRAG(requestPayload);

        if (currentReqId === activeRequestIdRef.current) {
          setMessages((prev) =>
            prev.map((msg) =>
              msg.id === messageId
                ? { ...msg, response, isLoading: false, error: undefined }
                : msg
            )
          );
          setSelectedMessageId(messageId);
        }
      } catch (err: any) {
        if (currentReqId === activeRequestIdRef.current) {
          console.error('GraphRAG query error:', err);
          const errorMsg =
            err?.response?.data?.detail ||
            err?.message ||
            'GraphRAG question answering failed. Please verify LLM and Neo4j connectivity.';

          setMessages((prev) =>
            prev.map((msg) =>
              msg.id === messageId
                ? { ...msg, isLoading: false, error: errorMsg }
                : msg
            )
          );
        }
      } finally {
        if (currentReqId === activeRequestIdRef.current) {
          setIsLoading(false);
        }
      }
    },
    [questionInput, config]
  );

  // Clear conversation with confirmation
  const handleConfirmClear = () => {
    setMessages([]);
    setSelectedMessageId(null);
    setClearDialogOpen(false);
  };

  // Determine active response to show in EvidenceInspector
  const selectedMessage = messages.find((m) => m.id === selectedMessageId);
  const activeResponse = selectedMessage?.response || null;

  return (
    <Box
      sx={{
        width: '100%',
        maxWidth: 1600,
        mx: 'auto',
        p: { xs: 2, sm: 3 },
      }}
    >
      {/* 1. Page Header */}
      <IntelligenceHeader
        isBackendHealthy={isBackendHealthy}
        messageCount={messages.length}
        onClearConversation={() => setClearDialogOpen(true)}
      />

      {/* 2. Main Workspace Layout */}
      <Grid container spacing={3}>
        {/* Left Column: Conversation Thread & Question Composer */}
        <Grid item xs={12} md={7} lg={7}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}>
            {/* Conversation Thread */}
            <ConversationThread
              messages={messages}
              selectedMessageId={selectedMessageId}
              onSelectMessage={setSelectedMessageId}
              onSelectQuestionSuggestion={(q) => handleAskQuestion(q)}
              onRetry={(q) => handleAskQuestion(q)}
              isLoading={isLoading}
            />

            {/* Persistent Question Composer */}
            <QuestionComposer
              question={questionInput}
              onQuestionChange={setQuestionInput}
              config={config}
              onConfigChange={setConfig}
              onSubmit={handleAskQuestion}
              isLoading={isLoading}
            />
          </Box>
        </Grid>

        {/* Right Column: Evidence Inspector */}
        <Grid item xs={12} md={5} lg={5}>
          <EvidenceInspector
            response={activeResponse}
            questionText={selectedMessage?.question}
          />
        </Grid>
      </Grid>

      {/* Clear Conversation Confirmation Dialog */}
      <Dialog
        open={clearDialogOpen}
        onClose={() => setClearDialogOpen(false)}
        aria-labelledby="clear-conversation-dialog-title"
      >
        <DialogTitle id="clear-conversation-dialog-title" sx={{ fontWeight: 700, color: '#0f172a' }}>
          Start New Conversation?
        </DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ color: '#475569' }}>
            Clearing this conversation will remove all current question-and-answer exchanges and their
            associated evidence views. This action cannot be undone.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ p: 2, pt: 0 }}>
          <Button onClick={() => setClearDialogOpen(false)} sx={{ color: '#64748b', textTransform: 'none' }}>
            Cancel
          </Button>
          <Button
            onClick={handleConfirmClear}
            variant="contained"
            color="error"
            sx={{ textTransform: 'none', fontWeight: 600 }}
          >
            Clear Conversation
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default IntelligencePage;