import React from 'react';
import {
  Box,
  Card,
  Typography,
  Grid,
  Chip,
} from '@mui/material';
import {
  HelpOutline as HelpIcon,
  PrecisionManufacturing as AssetIcon,
  TrendingDown as DegradationIcon,
  BuildCircle as MaintenanceIcon,
  ReportProblem as FailureIcon,
  PowerOff as OutageIcon,
  WaterDrop as PumpIcon,
  ArrowForward as ArrowIcon,
} from '@mui/icons-material';

interface SuggestedQuestionsProps {
  onSelectQuestion: (question: string) => void;
  isLoading: boolean;
}

const SUGGESTIONS = [
  {
    category: 'Turbine Inspections',
    icon: <FailureIcon sx={{ fontSize: 18, color: '#e11d48' }} />,
    question: 'What inspections preceded the compressor blade failure?',
    description: 'Inspect vibration measurements and borescope findings prior to the August blade liberation.',
  },
  {
    category: 'Heat Rate Performance',
    icon: <DegradationIcon sx={{ fontSize: 18, color: '#059669' }} />,
    question: 'What evidence indicates heat-rate degradation in Unit 1?',
    description: 'Review efficiency tests, baseline comparisons, and compressor fouling indicators.',
  },
  {
    category: 'Corrective Maintenance',
    icon: <MaintenanceIcon sx={{ fontSize: 18, color: '#ea580c' }} />,
    question: 'What work orders followed the compressor blade failure?',
    description: 'Examine emergency work orders, rotor balancing, labor, and material expenditure.',
  },
  {
    category: 'Asset Reliability',
    icon: <AssetIcon sx={{ fontSize: 18, color: '#7c3aed' }} />,
    question: 'Which assets have recorded historical failures?',
    description: 'Identify critical power plant assets with recorded failure events and downtime.',
  },
  {
    category: 'Grid Operations',
    icon: <OutageIcon sx={{ fontSize: 18, color: '#d97706' }} />,
    question: 'What operational impact is associated with the recorded outage events?',
    description: 'Analyze capacity deratings, downtime hours, and unit availability records.',
  },
  {
    category: 'Pump Maintenance',
    icon: <PumpIcon sx={{ fontSize: 18, color: '#0284c7' }} />,
    question: 'What maintenance information is available for the boiler feed pump?',
    description: 'Check lubrication, thrust bearing alignment, and mechanical seal histories.',
  },
];

export const SuggestedQuestions: React.FC<SuggestedQuestionsProps> = ({
  onSelectQuestion,
  isLoading,
}) => {
  return (
    <Box sx={{ mb: 3 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
        <HelpIcon sx={{ fontSize: 18, color: '#0f766e' }} />
        <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#334155' }}>
          Suggested Operational Inquiries Grounded in Actual Utility Data
        </Typography>
      </Box>

      <Grid container spacing={2}>
        {SUGGESTIONS.map((item, idx) => (
          <Grid item xs={12} sm={6} md={4} key={idx}>
            <Card
              elevation={0}
              onClick={() => !isLoading && onSelectQuestion(item.question)}
              sx={{
                p: 2,
                height: '100%',
                bgcolor: '#ffffff',
                border: '1px solid #e2e8f0',
                borderRadius: 2,
                cursor: isLoading ? 'default' : 'pointer',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                transition: 'all 0.2s ease-in-out',
                '&:hover': {
                  borderColor: isLoading ? '#e2e8f0' : '#0f766e',
                  boxShadow: isLoading ? 'none' : '0 4px 12px rgba(15, 118, 110, 0.08)',
                  transform: isLoading ? 'none' : 'translateY(-2px)',
                },
              }}
            >
              <Box>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                  {item.icon}
                  <Chip
                    size="small"
                    label={item.category}
                    sx={{
                      height: 20,
                      fontSize: '0.6875rem',
                      fontWeight: 600,
                      bgcolor: '#f1f5f9',
                      color: '#475569',
                    }}
                  />
                </Box>
                <Typography
                  variant="body2"
                  sx={{
                    fontWeight: 600,
                    color: '#0f172a',
                    fontSize: '0.875rem',
                    lineHeight: 1.4,
                    mb: 0.75,
                  }}
                >
                  "{item.question}"
                </Typography>
                <Typography
                  variant="caption"
                  sx={{
                    color: '#64748b',
                    lineHeight: 1.4,
                    display: 'block',
                  }}
                >
                  {item.description}
                </Typography>
              </Box>

              <Box
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 0.5,
                  color: '#0f766e',
                  fontWeight: 600,
                  fontSize: '0.75rem',
                  mt: 1.5,
                }}
              >
                Ask GraphRAG <ArrowIcon sx={{ fontSize: 14 }} />
              </Box>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};
