import React, { useState } from 'react';
import {
  Box,
  Typography,
  Chip,
  Button,
  Tooltip,
} from '@mui/material';
import {
  Description as DocumentIcon,
  Fingerprint as ChunkIcon,
  Person as SourceIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
} from '@mui/icons-material';
import { SemanticSearchResult } from '../../../types/api';
import { formatGroundingScore } from '../utils/intelligenceUtils';

interface DocumentEvidenceCardProps {
  chunk: SemanticSearchResult;
  index: number;
}

export const DocumentEvidenceCard: React.FC<DocumentEvidenceCardProps> = ({ chunk, index }) => {
  const [expanded, setExpanded] = useState(false);

  return (
    <Box
      sx={{
        p: 2,
        bgcolor: '#ffffff',
        border: '1px solid #e2e8f0',
        borderRadius: 2,
        display: 'flex',
        flexDirection: 'column',
        gap: 1,
      }}
    >
      {/* Header: Rank, Title, Score */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1, flex: 1 }}>
          <Box
            sx={{
              minWidth: 24,
              height: 24,
              borderRadius: 1,
              bgcolor: 'rgba(15, 118, 110, 0.1)',
              color: '#0f766e',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 700,
              fontSize: '0.6875rem',
            }}
          >
            #{index + 1}
          </Box>
          <Box sx={{ flex: 1 }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 600, color: '#0f172a', fontSize: '0.875rem' }}>
              {chunk.document_title}
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.25, flexWrap: 'wrap' }}>
              <Typography variant="caption" sx={{ color: '#64748b', display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <DocumentIcon sx={{ fontSize: 13 }} />
                {chunk.document_id}
              </Typography>
              <Typography variant="caption" sx={{ color: '#cbd5e1' }}>•</Typography>
              <Typography variant="caption" sx={{ color: '#64748b', display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <ChunkIcon sx={{ fontSize: 13 }} />
                {chunk.chunk_id}
              </Typography>
            </Box>
          </Box>
        </Box>

        <Tooltip title={`Cosine vector similarity: ${chunk.score?.toFixed(4)}`}>
          <Chip
            size="small"
            label={`${formatGroundingScore(chunk.score)} Match`}
            sx={{
              bgcolor: 'rgba(15, 118, 110, 0.08)',
              color: '#0f766e',
              fontWeight: 700,
              fontSize: '0.6875rem',
              height: 22,
              border: '1px solid rgba(15, 118, 110, 0.2)',
            }}
          />
        </Tooltip>
      </Box>

      {/* Snippet / Full Text */}
      <Box
        sx={{
          p: 1.5,
          bgcolor: '#f8fafc',
          border: '1px solid #e2e8f0',
          borderRadius: 1.5,
          fontSize: '0.8125rem',
          lineHeight: 1.6,
          color: '#334155',
          whiteSpace: 'pre-wrap',
        }}
      >
        {expanded
          ? chunk.text
          : chunk.text.length > 200
          ? `${chunk.text.slice(0, 200)}...`
          : chunk.text}
      </Box>

      {/* Controls & Metadata */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, flexWrap: 'wrap' }}>
          {chunk.source && (
            <Chip
              size="small"
              icon={<SourceIcon sx={{ fontSize: '12px !important' }} />}
              label={chunk.source}
              variant="outlined"
              sx={{ height: 20, fontSize: '0.6875rem', color: '#475569', borderColor: '#cbd5e1' }}
            />
          )}
          {chunk.metadata?.document_type && (
            <Chip
              size="small"
              label={chunk.metadata.document_type.replace('_', ' ')}
              variant="outlined"
              sx={{ height: 20, fontSize: '0.6875rem', color: '#475569', borderColor: '#cbd5e1', textTransform: 'capitalize' }}
            />
          )}
        </Box>

        {chunk.text.length > 200 && (
          <Button
            size="small"
            onClick={() => setExpanded((prev) => !prev)}
            endIcon={expanded ? <ExpandLessIcon sx={{ fontSize: 14 }} /> : <ExpandMoreIcon sx={{ fontSize: 14 }} />}
            sx={{
              p: 0,
              minWidth: 'auto',
              color: '#0f766e',
              fontSize: '0.75rem',
              fontWeight: 600,
              textTransform: 'none',
              '&:hover': { bgcolor: 'transparent', textDecoration: 'underline' },
            }}
          >
            {expanded ? 'Show snippet' : 'Expand full chunk'}
          </Button>
        )}
      </Box>
    </Box>
  );
};
