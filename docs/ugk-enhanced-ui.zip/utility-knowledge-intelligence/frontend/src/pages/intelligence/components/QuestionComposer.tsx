import React, { useState } from 'react';
import {
  Box,
  Card,
  TextField,
  Button,
  IconButton,
  Collapse,
  Typography,
  Grid,
  Slider,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  FormControlLabel,
  Switch,
  Chip,
  CircularProgress,
} from '@mui/material';
import {
  Send as SendIcon,
  Tune as TuneIcon,
  Clear as ClearIcon,
  RestartAlt as ResetIcon,
} from '@mui/icons-material';
import { GraphRAGRequest } from '../../../types/api';

interface QuestionComposerProps {
  question: string;
  onQuestionChange: (q: string) => void;
  config: Required<Omit<GraphRAGRequest, 'question'>>;
  onConfigChange: (newConfig: Required<Omit<GraphRAGRequest, 'question'>>) => void;
  onSubmit: (questionOverride?: string) => void;
  isLoading: boolean;
}

export const QuestionComposer: React.FC<QuestionComposerProps> = ({
  question,
  onQuestionChange,
  config,
  onConfigChange,
  onSubmit,
  isLoading,
}) => {
  const [showConfig, setShowConfig] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleTriggerSubmit();
    }
  };

  const handleTriggerSubmit = () => {
    const trimmed = question.trim();
    if (!trimmed) {
      setValidationError('Please enter a question before submitting.');
      return;
    }
    setValidationError(null);
    onSubmit();
  };

  const handleResetDefaults = () => {
    onConfigChange({
      top_k: 5,
      graph_depth: 1,
      min_similarity: 0.0,
      include_verification: true,
    });
  };

  const isConfigModified =
    config.top_k !== 5 ||
    config.graph_depth !== 1 ||
    config.min_similarity !== 0.0 ||
    !config.include_verification;

  return (
    <Card
      elevation={0}
      sx={{
        p: 2,
        bgcolor: '#ffffff',
        border: '1px solid #e2e8f0',
        borderRadius: 2,
        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04)',
      }}
    >
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
        {/* Multiline Input Field */}
        <TextField
          id="intelligence-question-input"
          label="Operational Inquiry"
          placeholder="Ask a technical question regarding utility assets, failure events, inspections, or heat rate..."
          multiline
          minRows={2}
          maxRows={4}
          value={question}
          onChange={(e) => {
            onQuestionChange(e.target.value);
            if (validationError && e.target.value.trim()) {
              setValidationError(null);
            }
          }}
          onKeyDown={handleKeyDown}
          error={!!validationError}
          helperText={
            validationError ||
            'Press Ctrl+Enter to submit. Enter adds a new line.'
          }
          fullWidth
          disabled={isLoading}
          InputProps={{
            endAdornment: question ? (
              <IconButton
                size="small"
                onClick={() => {
                  onQuestionChange('');
                  setValidationError(null);
                }}
                disabled={isLoading}
                sx={{ alignSelf: 'flex-start', mt: 0.5, color: '#94a3b8' }}
              >
                <ClearIcon fontSize="small" />
              </IconButton>
            ) : undefined,
            sx: {
              fontSize: '0.9375rem',
              lineHeight: 1.5,
              '& .MuiOutlinedInput-notchedOutline': {
                borderColor: '#cbd5e1',
              },
              '&:hover .MuiOutlinedInput-notchedOutline': {
                borderColor: '#0284c7',
              },
              '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                borderColor: '#0284c7',
              },
            },
          }}
        />

        {/* Toolbar: Parameters Toggle and Submit Button */}
        <Box
          sx={{
            display: 'flex',
            flexDirection: { xs: 'column', sm: 'row' },
            justifyContent: 'space-between',
            alignItems: { xs: 'stretch', sm: 'center' },
            gap: 1.5,
          }}
        >
          {/* Config Parameters Button */}
          <Button
            size="small"
            startIcon={<TuneIcon sx={{ fontSize: 18 }} />}
            onClick={() => setShowConfig((prev) => !prev)}
            sx={{
              color: isConfigModified ? '#0284c7' : '#64748b',
              fontWeight: 600,
              textTransform: 'none',
              bgcolor: isConfigModified ? 'rgba(2, 132, 199, 0.08)' : 'transparent',
              alignSelf: { xs: 'flex-start', sm: 'center' },
              '&:hover': {
                bgcolor: 'rgba(2, 132, 199, 0.12)',
              },
            }}
          >
            {showConfig ? 'Hide Parameters' : 'GraphRAG Parameters'}
            {isConfigModified && (
              <Chip
                label="Custom"
                size="small"
                sx={{
                  ml: 1,
                  height: 18,
                  fontSize: '0.6875rem',
                  bgcolor: '#0284c7',
                  color: '#ffffff',
                }}
              />
            )}
          </Button>

          {/* Submit Question Button */}
          <Button
            id="intelligence-submit-btn"
            variant="contained"
            disabled={isLoading || !question.trim()}
            onClick={handleTriggerSubmit}
            startIcon={
              isLoading ? (
                <CircularProgress size={18} color="inherit" />
              ) : (
                <SendIcon sx={{ fontSize: 18 }} />
              )
            }
            sx={{
              bgcolor: '#0284c7',
              color: '#ffffff',
              fontWeight: 600,
              textTransform: 'none',
              px: 3,
              py: 1,
              borderRadius: 1.5,
              boxShadow: '0 1px 3px rgba(2, 132, 199, 0.3)',
              '&:hover': {
                bgcolor: '#0369a1',
              },
              '&.Mui-disabled': {
                bgcolor: '#e2e8f0',
                color: '#94a3b8',
              },
            }}
          >
            {isLoading ? 'Synthesizing...' : 'Ask Intelligence'}
          </Button>
        </Box>

        {/* Collapsible GraphRAG Parameters */}
        <Collapse in={showConfig}>
          <Box
            sx={{
              mt: 1,
              p: 2,
              bgcolor: '#f8fafc',
              border: '1px solid #e2e8f0',
              borderRadius: 1.5,
            }}
          >
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 600, color: '#334155' }}>
                GraphRAG Retrieval & Verification Parameters
              </Typography>
              {isConfigModified && (
                <Button
                  size="small"
                  startIcon={<ResetIcon sx={{ fontSize: 16 }} />}
                  onClick={handleResetDefaults}
                  sx={{ color: '#64748b', textTransform: 'none', fontSize: '0.75rem' }}
                >
                  Reset Defaults
                </Button>
              )}
            </Box>

            <Grid container spacing={3}>
              {/* Top K */}
              <Grid item xs={12} sm={6} md={3}>
                <Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                    <Typography variant="caption" sx={{ color: '#475569', fontWeight: 600 }}>
                      Retrieved Chunks (top_k)
                    </Typography>
                    <Typography variant="caption" sx={{ color: '#0284c7', fontWeight: 700 }}>
                      {config.top_k}
                    </Typography>
                  </Box>
                  <Slider
                    value={config.top_k}
                    min={1}
                    max={20}
                    step={1}
                    valueLabelDisplay="auto"
                    onChange={(_, val) =>
                      onConfigChange({ ...config, top_k: val as number })
                    }
                    sx={{ color: '#0284c7' }}
                  />
                </Box>
              </Grid>

              {/* Min Similarity */}
              <Grid item xs={12} sm={6} md={3}>
                <Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                    <Typography variant="caption" sx={{ color: '#475569', fontWeight: 600 }}>
                      Min Similarity
                    </Typography>
                    <Typography variant="caption" sx={{ color: '#0284c7', fontWeight: 700 }}>
                      {(config.min_similarity * 100).toFixed(0)}%
                    </Typography>
                  </Box>
                  <Slider
                    value={config.min_similarity}
                    min={0.0}
                    max={1.0}
                    step={0.05}
                    valueLabelDisplay="auto"
                    valueLabelFormat={(val) => `${(val * 100).toFixed(0)}%`}
                    onChange={(_, val) =>
                      onConfigChange({ ...config, min_similarity: val as number })
                    }
                    sx={{ color: '#0284c7' }}
                  />
                </Box>
              </Grid>

              {/* Graph Depth */}
              <Grid item xs={12} sm={6} md={3}>
                <FormControl fullWidth size="small">
                  <InputLabel id="intelligence-graph-depth-label" sx={{ fontSize: '0.8125rem' }}>
                    Graph Depth
                  </InputLabel>
                  <Select
                    labelId="intelligence-graph-depth-label"
                    value={config.graph_depth}
                    label="Graph Depth"
                    onChange={(e) =>
                      onConfigChange({ ...config, graph_depth: Number(e.target.value) })
                    }
                    sx={{ fontSize: '0.875rem' }}
                  >
                    <MenuItem value={0}>0 — Chunks Only</MenuItem>
                    <MenuItem value={1}>1 — Direct Entities</MenuItem>
                    <MenuItem value={2}>2 — 2-Hop Traversal</MenuItem>
                    <MenuItem value={3}>3 — 3-Hop Deep</MenuItem>
                  </Select>
                </FormControl>
              </Grid>

              {/* Verification Switch */}
              <Grid item xs={12} sm={6} md={3}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={config.include_verification}
                      onChange={(e) =>
                        onConfigChange({ ...config, include_verification: e.target.checked })
                      }
                      color="primary"
                    />
                  }
                  label={
                    <Typography variant="caption" sx={{ fontWeight: 600, color: '#334155' }}>
                      Answer Verification
                    </Typography>
                  }
                />
                <Typography variant="caption" sx={{ color: '#94a3b8', fontSize: '0.7rem', display: 'block' }}>
                  Audits claims against evidence
                </Typography>
              </Grid>
            </Grid>
          </Box>
        </Collapse>
      </Box>
    </Card>
  );
};
