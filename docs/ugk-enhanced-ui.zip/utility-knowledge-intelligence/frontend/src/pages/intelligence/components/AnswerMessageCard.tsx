import React from 'react';
import ReactMarkdown from 'react-markdown';
import {
  Box,
  Card,
  Typography,
  Chip,
  Button,
  Alert,
  AlertTitle,
  Tooltip,
  LinearProgress,
} from '@mui/material';
import {
  Person as UserIcon,
  Psychology as AssistantIcon,
  Verified as VerifiedIcon,
  WarningAmber as WarningIcon,
  Speed as LatencyIcon,
  Description as DocumentIcon,
  Hub as EntityIcon,
  Refresh as RetryIcon,
  ArrowForward as InspectIcon,
  CheckCircle as ActiveIcon,
} from '@mui/icons-material';
import { ChatMessage } from '../../../types/api';
import {
  getConfidenceBadge,
  formatGroundingScore,
  getGroundingColor,
  formatDuration,
  formatMessageTime,
} from '../utils/intelligenceUtils';

interface AnswerMessageCardProps {
  message: ChatMessage;
  isSelected: boolean;
  onSelectMessage: (id: string) => void;
  onRetry: (question: string) => void;
}

export const AnswerMessageCard: React.FC<AnswerMessageCardProps> = ({
  message,
  isSelected,
  onSelectMessage,
  onRetry,
}) => {
  const { question, response, error, isLoading, timestamp } = message;

  const confidenceBadge = response ? getConfidenceBadge(response.confidence) : null;
  const groundingColor = response ? getGroundingColor(response.verification?.grounding_score) : null;
  const docCount = response?.sources?.documents?.length || response?.evidence?.semantic_results?.length || 0;
  const entityCount = response?.sources?.entities?.length || response?.evidence?.graph_evidence?.entities?.length || 0;
  const executionTime = response?.metadata?.execution_time;

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mb: 3 }}>
      {/* 1. User Question Bubble */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'flex-end',
          alignItems: 'flex-start',
          gap: 1.5,
          pl: { xs: 2, md: 8 },
        }}
      >
        <Box
          sx={{
            p: 2,
            bgcolor: '#0369a1',
            color: '#ffffff',
            borderRadius: 2.5,
            borderTopRightRadius: 0.5,
            maxWidth: '100%',
            boxShadow: '0 2px 6px rgba(3, 105, 161, 0.2)',
          }}
        >
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 0.5, gap: 2 }}>
            <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.8)', fontWeight: 600 }}>
              Operational Inquiry
            </Typography>
            <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.7)', fontSize: '0.6875rem' }}>
              {formatMessageTime(timestamp)}
            </Typography>
          </Box>
          <Typography variant="body1" sx={{ fontWeight: 500, fontSize: '0.9375rem', lineHeight: 1.5 }}>
            {question}
          </Typography>
        </Box>
        <Box
          sx={{
            width: 34,
            height: 34,
            borderRadius: '50%',
            bgcolor: '#e0f2fe',
            color: '#0369a1',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
            mt: 0.5,
          }}
        >
          <UserIcon sx={{ fontSize: 20 }} />
        </Box>
      </Box>

      {/* 2. Loading State */}
      {isLoading && (
        <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1.5, pr: { xs: 2, md: 8 } }}>
          <Box
            sx={{
              width: 34,
              height: 34,
              borderRadius: '50%',
              bgcolor: 'rgba(15, 118, 110, 0.1)',
              color: '#0f766e',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
              mt: 0.5,
            }}
          >
            <AssistantIcon sx={{ fontSize: 20 }} />
          </Box>
          <Card
            elevation={0}
            sx={{
              p: 2.5,
              bgcolor: '#ffffff',
              border: '1px solid #e2e8f0',
              borderRadius: 2.5,
              borderTopLeftRadius: 0.5,
              flex: 1,
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 600, color: '#0f766e' }}>
                GraphRAG Synthesizing Answer...
              </Typography>
            </Box>
            <Typography variant="body2" sx={{ color: '#64748b', mb: 1.5, fontSize: '0.8125rem' }}>
              Retrieving relevant text chunks, expanding Neo4j entity relationships, and generating a verified answer.
            </Typography>
            <LinearProgress sx={{ height: 4, borderRadius: 2, bgcolor: '#f1f5f9', '& .MuiLinearProgress-bar': { bgcolor: '#0f766e' } }} />
          </Card>
        </Box>
      )}

      {/* 3. Error State */}
      {error && !isLoading && (
        <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1.5, pr: { xs: 2, md: 8 } }}>
          <Box
            sx={{
              width: 34,
              height: 34,
              borderRadius: '50%',
              bgcolor: 'rgba(239, 68, 68, 0.1)',
              color: '#dc2626',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
              mt: 0.5,
            }}
          >
            <AssistantIcon sx={{ fontSize: 20 }} />
          </Box>
          <Alert
            severity="error"
            sx={{ flex: 1, borderRadius: 2 }}
            action={
              <Button
                color="inherit"
                size="small"
                startIcon={<RetryIcon />}
                onClick={() => onRetry(question)}
              >
                Retry
              </Button>
            }
          >
            <AlertTitle sx={{ fontWeight: 700 }}>Synthesis Failed</AlertTitle>
            {error}
          </Alert>
        </Box>
      )}

      {/* 4. Assistant Answer Bubble */}
      {response && !isLoading && (
        <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1.5, pr: { xs: 2, md: 4 } }}>
          <Box
            sx={{
              width: 34,
              height: 34,
              borderRadius: '50%',
              bgcolor: 'rgba(15, 118, 110, 0.1)',
              color: '#0f766e',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
              mt: 0.5,
            }}
          >
            <AssistantIcon sx={{ fontSize: 20 }} />
          </Box>

          <Card
            elevation={0}
            onClick={() => onSelectMessage(message.id)}
            sx={{
              p: 2.5,
              bgcolor: '#ffffff',
              border: isSelected ? '2px solid #0f766e' : '1px solid #e2e8f0',
              borderRadius: 2.5,
              borderTopLeftRadius: 0.5,
              flex: 1,
              boxShadow: isSelected
                ? '0 4px 14px rgba(15, 118, 110, 0.12)'
                : '0 1px 4px rgba(0, 0, 0, 0.04)',
              transition: 'all 0.2s ease-in-out',
              cursor: 'pointer',
              '&:hover': {
                borderColor: isSelected ? '#0f766e' : '#cbd5e1',
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.06)',
              },
            }}
          >
            {/* Header: Confidence & Verification Badges */}
            <Box
              sx={{
                display: 'flex',
                flexWrap: 'wrap',
                justifyContent: 'space-between',
                alignItems: 'center',
                gap: 1,
                mb: 2,
                pb: 1.5,
                borderBottom: '1px solid #f1f5f9',
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 1 }}>
                {/* Confidence Badge */}
                {confidenceBadge && (
                  <Chip
                    size="small"
                    label={confidenceBadge.label}
                    sx={{
                      bgcolor: confidenceBadge.bg,
                      color: confidenceBadge.text,
                      border: `1px solid ${confidenceBadge.border}`,
                      fontWeight: 700,
                      fontSize: '0.75rem',
                      height: 24,
                    }}
                  />
                )}

                {/* Verification Badge */}
                {response.verification && (
                  <Tooltip
                    title={`Grounding score: ${formatGroundingScore(
                      response.verification.grounding_score
                    )}. Claims verified against retrieved evidence.`}
                  >
                    <Chip
                      size="small"
                      icon={
                        response.verification.verified ? (
                          <VerifiedIcon sx={{ fontSize: '15px !important', color: '#059669 !important' }} />
                        ) : (
                          <WarningIcon sx={{ fontSize: '15px !important', color: '#d97706 !important' }} />
                        )
                      }
                      label={
                        response.verification.verified
                          ? `Grounded (${formatGroundingScore(response.verification.grounding_score)})`
                          : `Partial Grounding (${formatGroundingScore(response.verification.grounding_score)})`
                      }
                      sx={{
                        bgcolor: groundingColor?.bg,
                        color: groundingColor?.text,
                        border: `1px solid ${groundingColor?.bar}40`,
                        fontWeight: 700,
                        fontSize: '0.75rem',
                        height: 24,
                      }}
                    />
                  </Tooltip>
                )}
              </Box>

              {/* Inspect Evidence Button / Active Indicator */}
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                {isSelected ? (
                  <Chip
                    size="small"
                    icon={<ActiveIcon sx={{ fontSize: '14px !important', color: '#0f766e !important' }} />}
                    label="Evidence Active"
                    sx={{
                      height: 22,
                      fontSize: '0.6875rem',
                      bgcolor: 'rgba(15, 118, 110, 0.1)',
                      color: '#0f766e',
                      fontWeight: 700,
                    }}
                  />
                ) : (
                  <Button
                    size="small"
                    endIcon={<InspectIcon sx={{ fontSize: 14 }} />}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectMessage(message.id);
                    }}
                    sx={{
                      color: '#0f766e',
                      fontSize: '0.75rem',
                      fontWeight: 600,
                      textTransform: 'none',
                      p: '2px 8px',
                    }}
                  >
                    Inspect Evidence
                  </Button>
                )}
              </Box>
            </Box>

            {/* Answer Content Rendered with Markdown */}
            <Box
              sx={{
                color: '#1e293b',
                fontSize: '0.9375rem',
                lineHeight: 1.7,
                '& p': { my: 1 },
                '& ul, & ol': { pl: 3, my: 1 },
                '& li': { my: 0.5 },
                '& strong': { color: '#0f172a', fontWeight: 600 },
                '& code': {
                  bgcolor: '#f1f5f9',
                  px: 0.75,
                  py: 0.25,
                  borderRadius: 1,
                  fontSize: '0.85em',
                  fontFamily: 'monospace',
                },
              }}
            >
              <ReactMarkdown>{response.answer}</ReactMarkdown>
            </Box>

            {/* Verification Warnings / Limitations Banner */}
            {response.verification && (!response.verification.verified || response.verification.warnings?.length > 0) && (
              <Box
                sx={{
                  mt: 2,
                  p: 1.5,
                  bgcolor: '#fffbeb',
                  border: '1px solid #fde68a',
                  borderRadius: 1.5,
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: 1,
                }}
              >
                <WarningIcon sx={{ fontSize: 18, color: '#d97706', mt: 0.25 }} />
                <Box sx={{ flex: 1 }}>
                  <Typography variant="caption" sx={{ fontWeight: 700, color: '#92400e', display: 'block' }}>
                    Evidence Grounding Notice
                  </Typography>
                  <Typography variant="caption" sx={{ color: '#b45309', lineHeight: 1.4, display: 'block' }}>
                    {response.verification.warnings?.length > 0
                      ? response.verification.warnings.join(' • ')
                      : 'Some claims in this response could not be fully grounded in the retrieved engineering chunks.'}
                  </Typography>
                </Box>
              </Box>
            )}

            {/* Answer Telemetry & Sources Bar */}
            <Box
              sx={{
                mt: 2,
                pt: 1.5,
                borderTop: '1px solid #f1f5f9',
                display: 'flex',
                flexWrap: 'wrap',
                justifyContent: 'space-between',
                alignItems: 'center',
                gap: 1,
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 1 }}>
                <Chip
                  size="small"
                  icon={<DocumentIcon sx={{ fontSize: '13px !important', color: '#0284c7 !important' }} />}
                  label={`${docCount} Doc Chunk${docCount === 1 ? '' : 's'}`}
                  sx={{
                    height: 22,
                    fontSize: '0.6875rem',
                    bgcolor: '#f0f9ff',
                    color: '#0369a1',
                    border: '1px solid #bae6fd',
                  }}
                />

                <Chip
                  size="small"
                  icon={<EntityIcon sx={{ fontSize: '13px !important', color: '#7c3aed !important' }} />}
                  label={`${entityCount} Graph Entit${entityCount === 1 ? 'y' : 'ies'}`}
                  sx={{
                    height: 22,
                    fontSize: '0.6875rem',
                    bgcolor: '#f5f3ff',
                    color: '#6d28d9',
                    border: '1px solid #ddd6fe',
                  }}
                />

                {executionTime !== undefined && (
                  <Chip
                    size="small"
                    icon={<LatencyIcon sx={{ fontSize: '13px !important', color: '#64748b !important' }} />}
                    label={formatDuration(executionTime)}
                    sx={{
                      height: 22,
                      fontSize: '0.6875rem',
                      bgcolor: '#f8fafc',
                      color: '#475569',
                      border: '1px solid #e2e8f0',
                    }}
                  />
                )}
              </Box>

              <Typography variant="caption" sx={{ color: '#94a3b8', fontSize: '0.6875rem' }}>
                Model: {response.metadata?.groq_model || 'Groq LLM'}
              </Typography>
            </Box>
          </Card>
        </Box>
      )}
    </Box>
  );
};
