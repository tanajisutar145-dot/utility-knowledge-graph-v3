import React, { useState } from 'react';
import {
  Box,
  Card,
  Typography,
  Chip,
  Tabs,
  Tab,
  Alert,
  AlertTitle,
} from '@mui/material';
import {
  Description as DocumentIcon,
  Hub as EntityIcon,
  AccountTree as RouteIcon,
  FactCheck as VerificationIcon,
  Verified as VerifiedIcon,
  WarningAmber as WarningIcon,
  ArrowForward as ArrowForwardIcon,
} from '@mui/icons-material';
import { GraphRAGResponse } from '../../../types/api';
import { DocumentEvidenceCard } from './DocumentEvidenceCard';
import { GraphEntityCard } from './GraphEntityCard';
import {
  formatGroundingScore,
  getGroundingColor,
} from '../utils/intelligenceUtils';

interface EvidenceInspectorProps {
  response: GraphRAGResponse | null;
  questionText?: string;
}

export const EvidenceInspector: React.FC<EvidenceInspectorProps> = ({
  response,
  questionText,
}) => {
  const [tabIndex, setTabIndex] = useState(0);

  if (!response) {
    return (
      <Card
        elevation={0}
        sx={{
          p: 4,
          bgcolor: '#ffffff',
          border: '1px dashed #cbd5e1',
          borderRadius: 2,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          minHeight: 360,
          textAlign: 'center',
          gap: 1.5,
        }}
      >
        <VerificationIcon sx={{ fontSize: 44, color: '#94a3b8' }} />
        <Typography variant="subtitle1" sx={{ fontWeight: 600, color: '#475569' }}>
          No Evidence Active
        </Typography>
        <Typography variant="body2" sx={{ color: '#64748b', maxWidth: 320 }}>
          Ask an operational question or select an answer from the conversation to inspect
          its retrieved document chunks, linked graph entities, and verification report.
        </Typography>
      </Card>
    );
  }

  const chunks = response.evidence?.semantic_results || [];
  const entities = response.evidence?.graph_evidence?.entities || [];
  const relationships = response.evidence?.graph_evidence?.relationships || [];
  const verification = response.verification;
  const groundingColor = getGroundingColor(verification?.grounding_score);

  return (
    <Card
      elevation={0}
      sx={{
        bgcolor: '#ffffff',
        border: '1px solid #e2e8f0',
        borderRadius: 2,
        display: 'flex',
        flexDirection: 'column',
        position: 'sticky',
        top: 24,
        maxHeight: 'calc(100vh - 120px)',
        overflow: 'hidden',
      }}
    >
      {/* Panel Top Title */}
      <Box sx={{ p: 2, pb: 1.5, borderBottom: '1px solid #f1f5f9' }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 0.5 }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 700, color: '#0f172a' }}>
            GraphRAG Evidence Inspector
          </Typography>
          {verification && (
            <Chip
              size="small"
              icon={
                verification.verified ? (
                  <VerifiedIcon sx={{ fontSize: '14px !important', color: '#059669 !important' }} />
                ) : (
                  <WarningIcon sx={{ fontSize: '14px !important', color: '#d97706 !important' }} />
                )
              }
              label={`${formatGroundingScore(verification.grounding_score)} Grounded`}
              sx={{
                bgcolor: groundingColor.bg,
                color: groundingColor.text,
                fontWeight: 700,
                fontSize: '0.6875rem',
                height: 22,
                border: `1px solid ${groundingColor.bar}40`,
              }}
            />
          )}
        </Box>
        {questionText && (
          <Typography
            variant="caption"
            sx={{
              color: '#64748b',
              display: 'block',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
            }}
            title={questionText}
          >
            For inquiry: "{questionText}"
          </Typography>
        )}
      </Box>

      {/* Navigation Tabs */}
      <Tabs
        value={tabIndex}
        onChange={(_, val) => setTabIndex(val)}
        variant="fullWidth"
        sx={{
          borderBottom: '1px solid #e2e8f0',
          minHeight: 40,
          '& .MuiTab-root': {
            minHeight: 40,
            fontSize: '0.75rem',
            fontWeight: 600,
            textTransform: 'none',
            color: '#64748b',
            '&.Mui-selected': {
              color: '#0f766e',
            },
          },
          '& .MuiTabs-indicator': {
            bgcolor: '#0f766e',
          },
        }}
      >
        <Tab icon={<DocumentIcon sx={{ fontSize: 16 }} />} iconPosition="start" label={`Chunks (${chunks.length})`} />
        <Tab icon={<EntityIcon sx={{ fontSize: 16 }} />} iconPosition="start" label={`Entities (${entities.length})`} />
        <Tab icon={<RouteIcon sx={{ fontSize: 16 }} />} iconPosition="start" label={`Relations (${relationships.length})`} />
        <Tab icon={<VerificationIcon sx={{ fontSize: 16 }} />} iconPosition="start" label="Audit" />
      </Tabs>

      {/* Tab Panels Container (Scrollable) */}
      <Box sx={{ p: 2, overflowY: 'auto', flex: 1, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
        {/* Tab 0: Document Chunks */}
        {tabIndex === 0 && (
          <>
            {chunks.length === 0 ? (
              <Typography variant="body2" sx={{ color: '#94a3b8', textAlign: 'center', py: 4 }}>
                No document chunks retrieved for this question.
              </Typography>
            ) : (
              chunks.map((chunk, i) => (
                <DocumentEvidenceCard key={chunk.chunk_id || i} chunk={chunk} index={i} />
              ))
            )}
          </>
        )}

        {/* Tab 1: Graph Entities */}
        {tabIndex === 1 && (
          <>
            {entities.length === 0 ? (
              <Typography variant="body2" sx={{ color: '#94a3b8', textAlign: 'center', py: 4 }}>
                No knowledge graph entities expanded for this question.
              </Typography>
            ) : (
              entities.map((entity) => (
                <GraphEntityCard key={entity.entity_id} entity={entity} />
              ))
            )}
          </>
        )}

        {/* Tab 2: Graph Relationships */}
        {tabIndex === 2 && (
          <>
            {relationships.length === 0 ? (
              <Typography variant="body2" sx={{ color: '#94a3b8', textAlign: 'center', py: 4 }}>
                No graph relationships traversed for this evidence set.
              </Typography>
            ) : (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.25 }}>
                {relationships.map((rel, i) => (
                  <Box
                    key={i}
                    sx={{
                      p: 1.5,
                      bgcolor: '#ffffff',
                      border: '1px solid #e2e8f0',
                      borderRadius: 1.5,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: 1,
                      fontSize: '0.75rem',
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75, flexWrap: 'wrap' }}>
                      <Chip
                        size="small"
                        label={`${rel.source_type}: ${rel.source_id}`}
                        sx={{ height: 20, fontSize: '0.6875rem', bgcolor: '#f1f5f9', color: '#334155' }}
                      />
                      <Box
                        sx={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: 0.5,
                          color: '#0f766e',
                          fontWeight: 700,
                          fontSize: '0.75rem',
                        }}
                      >
                        <RouteIcon sx={{ fontSize: 14 }} />
                        {rel.relationship_type}
                        <ArrowForwardIcon sx={{ fontSize: 13 }} />
                      </Box>
                      <Chip
                        size="small"
                        label={`${rel.target_type}: ${rel.target_id}`}
                        sx={{
                          height: 20,
                          fontSize: '0.6875rem',
                          bgcolor: 'rgba(15, 118, 110, 0.1)',
                          color: '#0f766e',
                          fontWeight: 600,
                        }}
                      />
                    </Box>
                  </Box>
                ))}
              </Box>
            )}
          </>
        )}

        {/* Tab 3: Verification Audit */}
        {tabIndex === 3 && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {verification ? (
              <>
                {/* Status Callout */}
                <Alert
                  severity={verification.verified ? 'success' : 'warning'}
                  sx={{ borderRadius: 1.5 }}
                >
                  <AlertTitle sx={{ fontWeight: 700, fontSize: '0.875rem' }}>
                    {verification.verified
                      ? 'Answer Fully Grounded in Evidence'
                      : 'Answer Contains Partial or Unverified Claims'}
                  </AlertTitle>
                  Grounding score: {formatGroundingScore(verification.grounding_score)}. Evaluated against
                  retrieved Neo4j graph nodes and ingested engineering chunks.
                </Alert>

                {/* Supported Claims */}
                {verification.supported_claims?.length > 0 && (
                  <Box>
                    <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#059669', mb: 0.75, fontSize: '0.8125rem' }}>
                      Supported Claims ({verification.supported_claims.length})
                    </Typography>
                    <Box sx={{ pl: 2 }}>
                      {verification.supported_claims.map((claim, idx) => (
                        <Typography key={idx} variant="caption" sx={{ display: 'block', color: '#334155', mb: 0.5 }}>
                          • {claim}
                        </Typography>
                      ))}
                    </Box>
                  </Box>
                )}

                {/* Unsupported Claims */}
                {verification.unsupported_claims?.length > 0 && (
                  <Box>
                    <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#dc2626', mb: 0.75, fontSize: '0.8125rem' }}>
                      Unsupported Claims ({verification.unsupported_claims.length})
                    </Typography>
                    <Box sx={{ pl: 2 }}>
                      {verification.unsupported_claims.map((claim, idx) => (
                        <Typography key={idx} variant="caption" sx={{ display: 'block', color: '#b91c1c', mb: 0.5 }}>
                          • {claim}
                        </Typography>
                      ))}
                    </Box>
                  </Box>
                )}

                {/* Warnings */}
                {verification.warnings?.length > 0 && (
                  <Box>
                    <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#d97706', mb: 0.75, fontSize: '0.8125rem' }}>
                      Verification Warnings ({verification.warnings.length})
                    </Typography>
                    <Box sx={{ pl: 2 }}>
                      {verification.warnings.map((warn, idx) => (
                        <Typography key={idx} variant="caption" sx={{ display: 'block', color: '#92400e', mb: 0.5 }}>
                          • {warn}
                        </Typography>
                      ))}
                    </Box>
                  </Box>
                )}

                {/* Evidence Gaps */}
                {verification.evidence_gaps?.length > 0 && (
                  <Box>
                    <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#64748b', mb: 0.75, fontSize: '0.8125rem' }}>
                      Evidence Gaps ({verification.evidence_gaps.length})
                    </Typography>
                    <Box sx={{ pl: 2 }}>
                      {verification.evidence_gaps.map((gap, idx) => (
                        <Typography key={idx} variant="caption" sx={{ display: 'block', color: '#64748b', mb: 0.5 }}>
                          • {gap}
                        </Typography>
                      ))}
                    </Box>
                  </Box>
                )}
              </>
            ) : (
              <Typography variant="body2" sx={{ color: '#94a3b8', textAlign: 'center', py: 4 }}>
                Verification audit was not enabled or not returned for this query.
              </Typography>
            )}
          </Box>
        )}
      </Box>
    </Card>
  );
};
