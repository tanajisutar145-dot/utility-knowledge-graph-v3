import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { MemoryRouter } from 'react-router-dom';
import { IntelligenceHeader } from '../components/IntelligenceHeader';
import { SuggestedQuestions } from '../components/SuggestedQuestions';
import { QuestionComposer } from '../components/QuestionComposer';
import { AnswerMessageCard } from '../components/AnswerMessageCard';
import { EvidenceInspector } from '../components/EvidenceInspector';
import { DocumentEvidenceCard } from '../components/DocumentEvidenceCard';
import { GraphEntityCard } from '../components/GraphEntityCard';
import { GraphRAGResponse, ChatMessage } from '../../../types/api';

const mockResponse: GraphRAGResponse = {
  question: 'What inspections preceded the compressor blade failure?',
  answer: 'Routine inspection performed on Unit 1 GT Gas Turbine (DOC-001) showed elevated vibration levels.',
  confidence: 'medium',
  verification: {
    verified: true,
    grounding_score: 0.85,
    supported_claims: ['Elevated vibration levels detected.'],
    unsupported_claims: [],
    warnings: [],
    evidence_gaps: [],
  },
  evidence: {
    semantic_results: [
      {
        chunk_id: 'DOC-001_chunk_000',
        document_id: 'DOC-001',
        document_title: 'Routine GT Inspection - Unit 1 GT Gas Turbine',
        text: 'Routine inspection revealed vibration levels exceeding normal parameters.',
        score: 0.885,
        source: 'Field Inspector',
        metadata: {
          document_type: 'inspection_report',
        },
      },
    ],
    graph_evidence: {
      entities: [
        {
          entity_id: 'AST-001',
          entity_type: 'Inspection',
          properties: {
            severity: 'medium',
            findings: 'Elevated vibration signatures.',
          },
        },
      ],
      relationships: [
        {
          source_id: 'DOC-001',
          target_id: 'AST-001',
          relationship_type: 'ABOUT_INSPECTION',
          source_type: 'Document',
          target_type: 'Inspection',
          properties: {},
        },
      ],
    },
  },
  sources: {
    documents: ['DOC-001'],
    entities: ['AST-001'],
  },
  metadata: {
    execution_time: 1.35,
    groq_model: 'qwen/qwen3.8-27b',
  },
};

const mockMessage: ChatMessage = {
  id: 'msg-1',
  timestamp: '2026-10-12T08:00:00Z',
  question: 'What inspections preceded the compressor blade failure?',
  response: mockResponse,
};

describe('Intelligence Subcomponents Rendering', () => {
  it('renders IntelligenceHeader with title and status badge', () => {
    const html = renderToStaticMarkup(
      <IntelligenceHeader
        isBackendHealthy={true}
        messageCount={1}
        onClearConversation={jest.fn()}
      />
    );
    expect(html).toContain('Utility Intelligence');
    expect(html).toContain('GraphRAG Active');
    expect(html).toContain('New Conversation');
  });

  it('renders SuggestedQuestions with grounding prompts', () => {
    const html = renderToStaticMarkup(
      <SuggestedQuestions onSelectQuestion={jest.fn()} isLoading={false} />
    );
    expect(html).toContain('What inspections preceded the compressor blade failure?');
    expect(html).toContain('What evidence indicates heat-rate degradation in Unit 1?');
    expect(html).toContain('What work orders followed the compressor blade failure?');
  });

  it('renders QuestionComposer with multiline input and submit button', () => {
    const html = renderToStaticMarkup(
      <QuestionComposer
        question=""
        onQuestionChange={jest.fn()}
        config={{ top_k: 5, graph_depth: 1, min_similarity: 0.0, include_verification: true }}
        onConfigChange={jest.fn()}
        onSubmit={jest.fn()}
        isLoading={false}
      />
    );
    expect(html).toContain('Operational Inquiry');
    expect(html).toContain('Ask Intelligence');
    expect(html).toContain('GraphRAG Parameters');
  });

  it('renders AnswerMessageCard with question, markdown answer, and confidence badge', () => {
    const html = renderToStaticMarkup(
      <AnswerMessageCard
        message={mockMessage}
        isSelected={true}
        onSelectMessage={jest.fn()}
        onRetry={jest.fn()}
      />
    );
    expect(html).toContain('What inspections preceded the compressor blade failure?');
    expect(html).toContain('Routine inspection performed on Unit 1 GT Gas Turbine');
    expect(html).toContain('Medium Confidence');
    expect(html).toContain('85%');
    expect(html).toContain('Evidence Active');
  });

  it('renders EvidenceInspector with chunks, entities, and verification audit', () => {
    const html = renderToStaticMarkup(
      <MemoryRouter>
        <EvidenceInspector
          response={mockResponse}
          questionText="What inspections preceded the compressor blade failure?"
        />
      </MemoryRouter>
    );
    expect(html).toContain('GraphRAG Evidence Inspector');
    expect(html).toContain('85% Grounded');
    expect(html).toContain('Routine GT Inspection - Unit 1 GT Gas Turbine');
  });

  it('renders DocumentEvidenceCard with metadata and match percentage', () => {
    const html = renderToStaticMarkup(
      <DocumentEvidenceCard
        chunk={mockResponse.evidence.semantic_results[0]}
        index={0}
      />
    );
    expect(html).toContain('DOC-001');
    expect(html).toContain('DOC-001_chunk_000');
    expect(html).toContain('89% Match');
    expect(html).toContain('Field Inspector');
  });

  it('renders GraphEntityCard with entity type and properties', () => {
    const html = renderToStaticMarkup(
      <MemoryRouter>
        <GraphEntityCard entity={mockResponse.evidence.graph_evidence.entities[0]} />
      </MemoryRouter>
    );
    expect(html).toContain('AST-001');
    expect(html).toContain('Inspection');
    expect(html).toContain('View in Graph');
  });
});
