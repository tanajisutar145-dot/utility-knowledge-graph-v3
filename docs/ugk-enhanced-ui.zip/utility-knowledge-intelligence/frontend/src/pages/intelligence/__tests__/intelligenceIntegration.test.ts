import { askGraphRAG, api } from '../../../services/api';
import { GraphRAGRequest, GraphRAGResponse, ChatMessage } from '../../../types/api';

describe('GraphRAG API and Conversation Integration', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  const mockGraphRAGResponse: GraphRAGResponse = {
    question: 'What inspections preceded the compressor blade failure?',
    answer: 'Based on the supplied evidence, a routine inspection on Unit 1 GT Gas Turbine (DOC-001) detected elevated vibration levels at 2X running frequency.',
    confidence: 'medium',
    verification: {
      verified: true,
      grounding_score: 0.85,
      supported_claims: ['Routine GT Inspection DOC-001 revealed vibration anomalies'],
      unsupported_claims: [],
      warnings: [],
      evidence_gaps: [],
    },
    evidence: {
      semantic_results: [
        {
          chunk_id: 'DOC-001_chunk_000',
          document_id: 'DOC-001',
          document_title: 'Routine GT Inspection - Unit 1 GT Gas Turbine',
          text: 'Elevated vibration levels detected at 2X running frequency.',
          score: 0.885,
          source: 'Field Inspector',
          metadata: {
            document_type: 'inspection_report',
            created_date: '2026-08-08T08:12:57.413643000+00:00',
            source_reference: 'INS-001',
          },
        },
      ],
      graph_evidence: {
        entities: [
          {
            entity_id: 'AST-001',
            entity_type: 'Inspection',
            properties: {
              severity: 'medium',
              findings: 'Elevated vibration levels detected.',
            },
          },
        ],
        relationships: [
          {
            source_id: 'DOC-001',
            target_id: 'AST-001',
            relationship_type: 'ABOUT_INSPECTION',
            source_type: 'Document',
            target_type: 'Inspection',
            properties: {},
          },
        ],
      },
    },
    sources: {
      documents: ['DOC-001'],
      entities: ['AST-001'],
    },
    metadata: {
      execution_time: 1.35,
      retrieval_method: 'vector+graph',
      groq_model: 'qwen/qwen3.8-27b',
      verification_enabled: true,
    },
  };

  it('sends valid GraphRAGRequest payload to POST /api/intelligence/ask', async () => {
    const postSpy = jest.spyOn(api, 'post').mockResolvedValueOnce({ data: mockGraphRAGResponse });

    const request: GraphRAGRequest = {
      question: 'What inspections preceded the compressor blade failure?',
      top_k: 5,
      graph_depth: 1,
      min_similarity: 0.0,
      include_verification: true,
    };

    const response = await askGraphRAG(request);

    expect(postSpy).toHaveBeenCalledWith('/api/intelligence/ask', request);
    expect(response.question).toBe('What inspections preceded the compressor blade failure?');
    expect(response.answer).toContain('Unit 1 GT Gas Turbine');
    expect(response.confidence).toBe('medium');
    expect(response.verification.verified).toBe(true);
    expect(response.verification.grounding_score).toBe(0.85);
    expect(response.evidence.semantic_results).toHaveLength(1);
    expect(response.evidence.graph_evidence.entities).toHaveLength(1);
  });

  it('propagates backend errors cleanly without fabricating answers', async () => {
    jest.spyOn(api, 'post').mockRejectedValueOnce(new Error('LLM service unavailable'));

    await expect(
      askGraphRAG({
        question: 'What caused the failure?',
      })
    ).rejects.toThrow('LLM service unavailable');
  });

  it('maintains independent evidence sets across sequential conversation messages', () => {
    const message1: ChatMessage = {
      id: 'msg-1',
      timestamp: '2026-10-12T08:00:00Z',
      question: 'Question 1',
      response: mockGraphRAGResponse,
    };

    const response2: GraphRAGResponse = {
      ...mockGraphRAGResponse,
      question: 'Question 2',
      answer: 'Answer for heat rate degradation.',
      sources: { documents: ['DOC-004'], entities: ['UNT-001'] },
      evidence: {
        semantic_results: [
          {
            chunk_id: 'DOC-004_chunk_000',
            document_id: 'DOC-004',
            document_title: 'Heat Rate Performance Analysis',
            text: 'Baseline heat rate increased by 2.3%.',
            score: 0.84,
            metadata: {},
          },
        ],
        graph_evidence: { entities: [], relationships: [] },
      },
    };

    const message2: ChatMessage = {
      id: 'msg-2',
      timestamp: '2026-10-12T08:01:00Z',
      question: 'Question 2',
      response: response2,
    };

    const conversation: ChatMessage[] = [message1, message2];

    // Inspecting message 1 preserves DOC-001
    const activeMsg1 = conversation.find((m) => m.id === 'msg-1');
    expect(activeMsg1?.response?.sources.documents).toEqual(['DOC-001']);

    // Inspecting message 2 preserves DOC-004
    const activeMsg2 = conversation.find((m) => m.id === 'msg-2');
    expect(activeMsg2?.response?.sources.documents).toEqual(['DOC-004']);
  });

  it('safely clears conversation state on user action', () => {
    let conversation: ChatMessage[] = [
      { id: '1', timestamp: '2026-10-12', question: 'Q1' },
      { id: '2', timestamp: '2026-10-12', question: 'Q2' },
    ];
    let selectedId: string | null = '2';

    // Execute clear
    conversation = [];
    selectedId = null;

    expect(conversation).toHaveLength(0);
    expect(selectedId).toBeNull();
  });
});
