import React, { useState } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Grid,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Switch,
  FormControlLabel,
  Divider,
  Alert,
  Tabs,
  Tab,
} from '@mui/material';
import { Save as SaveIcon } from '@mui/icons-material';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

const TabPanel: React.FC<TabPanelProps> = ({ children, value, index, ...other }) => (
  <div
    role="tabpanel"
    hidden={value !== index}
    id={`settings-tabpanel-${index}`}
    aria-labelledby={`settings-tab-${index}`}
    {...other}
  >
    {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
  </div>
);

const SettingsPage: React.FC = () => {
  const [tabValue, setTabValue] = useState(0);
  const [settings, setSettings] = useState({
    // General settings
    systemName: 'Utility Knowledge Intelligence',
    maxFileSize: '50',
    autoProcess: true,
    
    // Database settings
    neo4jUri: 'bolt://localhost:7687',
    neo4jDatabase: 'neo4j',
    
    // AI settings
    llmProvider: 'openai',
    openaiModel: 'gpt-4',
    temperature: '0.7',
    maxTokens: '2000',
    
    // Graph settings
    maxDepth: '5',
    similarityThreshold: '0.8',
    autoApproveThreshold: '0.9',
    
    // Notifications
    emailNotifications: true,
    verificationAlerts: true,
    processCompleteAlerts: false,
  });

  const [saveStatus, setSaveStatus] = useState<'success' | 'error' | null>(null);

  const handleInputChange = (field: string) => (event: any) => {
    setSettings((prev) => ({
      ...prev,
      [field]: event.target.value,
    }));
  };

  const handleSwitchChange = (field: string) => (event: any) => {
    setSettings((prev) => ({
      ...prev,
      [field]: event.target.checked,
    }));
  };

  const handleSave = async () => {
    try {
      // TODO: Implement API call to save settings
      console.log('Saving settings:', settings);
      setSaveStatus('success');
      setTimeout(() => setSaveStatus(null), 3000);
    } catch (error) {
      setSaveStatus('error');
      setTimeout(() => setSaveStatus(null), 3000);
    }
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Settings
      </Typography>

      {saveStatus && (
        <Alert
          severity={saveStatus}
          sx={{ mb: 2 }}
          onClose={() => setSaveStatus(null)}
        >
          {saveStatus === 'success'
            ? 'Settings saved successfully!'
            : 'Failed to save settings. Please try again.'}
        </Alert>
      )}

      <Card>
        <Tabs value={tabValue} onChange={(_, newValue) => setTabValue(newValue)}>
          <Tab label="General" />
          <Tab label="Database" />
          <Tab label="AI Models" />
          <Tab label="Knowledge Graph" />
          <Tab label="Notifications" />
        </Tabs>

        <TabPanel value={tabValue} index={0}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="System Name"
                value={settings.systemName}
                onChange={handleInputChange('systemName')}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Max File Size (MB)"
                type="number"
                value={settings.maxFileSize}
                onChange={handleInputChange('maxFileSize')}
              />
            </Grid>
            <Grid item xs={12}>
              <FormControlLabel
                control={
                  <Switch
                    checked={settings.autoProcess}
                    onChange={handleSwitchChange('autoProcess')}
                  />
                }
                label="Auto-process uploaded documents"
              />
            </Grid>
          </Grid>
        </TabPanel>

        <TabPanel value={tabValue} index={1}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={8}>
              <TextField
                fullWidth
                label="Neo4j URI"
                value={settings.neo4jUri}
                onChange={handleInputChange('neo4jUri')}
                helperText="Connection string for Neo4j database"
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Database Name"
                value={settings.neo4jDatabase}
                onChange={handleInputChange('neo4jDatabase')}
              />
            </Grid>
            <Grid item xs={12}>
              <Alert severity="info">
                Changes to database settings require system restart to take effect.
              </Alert>
            </Grid>
          </Grid>
        </TabPanel>

        <TabPanel value={tabValue} index={2}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel>LLM Provider</InputLabel>
                <Select
                  value={settings.llmProvider}
                  label="LLM Provider"
                  onChange={handleInputChange('llmProvider')}
                >
                  <MenuItem value="openai">OpenAI</MenuItem>
                  <MenuItem value="anthropic">Anthropic</MenuItem>
                  <MenuItem value="local">Local Model</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Model Name"
                value={settings.openaiModel}
                onChange={handleInputChange('openaiModel')}
                helperText="e.g., gpt-4, claude-3-sonnet"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Temperature"
                type="number"
                inputProps={{ min: 0, max: 2, step: 0.1 }}
                value={settings.temperature}
                onChange={handleInputChange('temperature')}
                helperText="Controls randomness (0.0 - 2.0)"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Max Tokens"
                type="number"
                value={settings.maxTokens}
                onChange={handleInputChange('maxTokens')}
                helperText="Maximum response length"
              />
            </Grid>
          </Grid>
        </TabPanel>

        <TabPanel value={tabValue} index={3}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Max Graph Depth"
                type="number"
                inputProps={{ min: 1, max: 10 }}
                value={settings.maxDepth}
                onChange={handleInputChange('maxDepth')}
                helperText="Maximum traversal depth for graph queries"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Similarity Threshold"
                type="number"
                inputProps={{ min: 0, max: 1, step: 0.1 }}
                value={settings.similarityThreshold}
                onChange={handleInputChange('similarityThreshold')}
                helperText="Minimum similarity score for relationships"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Auto-approve Threshold"
                type="number"
                inputProps={{ min: 0, max: 1, step: 0.1 }}
                value={settings.autoApproveThreshold}
                onChange={handleInputChange('autoApproveThreshold')}
                helperText="Confidence threshold for auto-approval"
              />
            </Grid>
          </Grid>
        </TabPanel>

        <TabPanel value={tabValue} index={4}>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <FormControlLabel
                control={
                  <Switch
                    checked={settings.emailNotifications}
                    onChange={handleSwitchChange('emailNotifications')}
                  />
                }
                label="Email notifications"
              />
            </Grid>
            <Grid item xs={12}>
              <FormControlLabel
                control={
                  <Switch
                    checked={settings.verificationAlerts}
                    onChange={handleSwitchChange('verificationAlerts')}
                  />
                }
                label="Verification alerts"
              />
            </Grid>
            <Grid item xs={12}>
              <FormControlLabel
                control={
                  <Switch
                    checked={settings.processCompleteAlerts}
                    onChange={handleSwitchChange('processCompleteAlerts')}
                  />
                }
                label="Process completion alerts"
              />
            </Grid>
          </Grid>
        </TabPanel>

        <Box sx={{ p: 3 }}>
          <Divider sx={{ mb: 3 }} />
          <Box display="flex" justifyContent="flex-end">
            <Button
              variant="contained"
              startIcon={<SaveIcon />}
              onClick={handleSave}
            >
              Save Settings
            </Button>
          </Box>
        </Box>
      </Card>
    </Box>
  );
};

export default SettingsPage;