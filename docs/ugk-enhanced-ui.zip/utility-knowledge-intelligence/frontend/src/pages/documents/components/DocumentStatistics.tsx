import React from 'react';
import { Grid, Card, CardContent, Typography, Box, Skeleton } from '@mui/material';
import {
  Description as DocumentIcon,
  Segment as ChunkIcon,
  CheckCircleOutline as VectorIcon,
  Category as TypesIcon,
} from '@mui/icons-material';
import { DocumentOverviewResponse } from '../../../types/documents';

interface DocumentStatisticsProps {
  overview: DocumentOverviewResponse | null;
  isLoading: boolean;
}

export const DocumentStatistics: React.FC<DocumentStatisticsProps> = ({
  overview,
  isLoading,
}) => {
  const cards = [
    {
      label: 'Total Documents',
      value: overview?.total_documents ?? 0,
      subtext: `${Object.keys(overview?.document_types || {}).length} document categories`,
      icon: <DocumentIcon sx={{ color: '#0284c7' }} />,
      bgColor: '#f0f9ff',
      borderColor: '#bae6fd',
    },
    {
      label: 'Text Chunks',
      value: overview?.total_chunks ?? 0,
      subtext: `${overview?.total_documents ? (overview.total_chunks / overview.total_documents).toFixed(1) : 0} avg chunks/doc`,
      icon: <ChunkIcon sx={{ color: '#00897b' }} />,
      bgColor: '#f0fdf4',
      borderColor: '#bbf7d0',
    },
    {
      label: 'Vector Embeddings',
      value: `${overview?.embedded_chunks ?? 0} / ${overview?.total_chunks ?? 0}`,
      subtext: `${overview?.embedding_model || 'BAAI/bge-small-en-v1.5'} (${overview?.embedding_dimension || 384}d)`,
      icon: <VectorIcon sx={{ color: '#16a34a' }} />,
      bgColor: '#f0fdf4',
      borderColor: '#86efac',
    },
    {
      label: 'Vector Index Status',
      value: overview?.vector_index_status ?? 'ONLINE',
      subtext: `${overview?.vector_index_population ?? 100}% populated (${overview?.vector_index_name ?? 'chunk_embedding_index'})`,
      icon: <TypesIcon sx={{ color: '#7c3aed' }} />,
      bgColor: '#faf5ff',
      borderColor: '#ddd6fe',
    },
  ];

  return (
    <Grid container spacing={2} mb={3}>
      {cards.map((c, i) => (
        <Grid item xs={12} sm={6} md={3} key={i}>
          <Card
            variant="outlined"
            sx={{
              backgroundColor: c.bgColor,
              borderColor: c.borderColor,
              borderRadius: 2,
            }}
          >
            <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
              <Box display="flex" justifyContent="space-between" alignItems="flex-start">
                <Box>
                  <Typography variant="caption" color="text.secondary" fontWeight={600}>
                    {c.label}
                  </Typography>
                  {isLoading ? (
                    <Skeleton width={80} height={32} />
                  ) : (
                    <Typography variant="h5" fontWeight={700} color="#0f172a" my={0.5}>
                      {c.value}
                    </Typography>
                  )}
                  <Typography variant="caption" color="text.secondary">
                    {c.subtext}
                  </Typography>
                </Box>
                <Box
                  p={1}
                  borderRadius={1.5}
                  bgcolor="#ffffff"
                  display="flex"
                  alignItems="center"
                  justifyContent="center"
                  boxShadow="0 1px 3px rgba(0,0,0,0.05)"
                >
                  {c.icon}
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
};
