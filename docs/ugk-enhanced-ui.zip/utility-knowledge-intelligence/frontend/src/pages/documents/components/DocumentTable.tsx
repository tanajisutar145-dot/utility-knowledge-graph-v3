import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  IconButton,
  Tooltip,
  Typography,
  Box,
  CircularProgress,
  TablePagination,
} from '@mui/material';
import {
  Visibility as ViewIcon,
  CheckCircle as EmbeddedIcon,
  Description as EmptyIcon,
  DeleteOutline as DeleteIcon,
  WarningAmber as WarningIcon,
} from '@mui/icons-material';
import { DocumentSummaryItem } from '../../../types/documents';
import { getDocumentTypeColor, formatDate } from '../utils/documentUtils';

interface DocumentTableProps {
  documents: DocumentSummaryItem[];
  total: number;
  page: number;
  rowsPerPage: number;
  isLoading: boolean;
  onPageChange: (newPage: number) => void;
  onRowsPerPageChange: (newRowsPerPage: number) => void;
  onSelectDocument: (documentId: string) => void;
  onDeleteDocument?: (doc: DocumentSummaryItem) => void;
}

export const DocumentTable: React.FC<DocumentTableProps> = ({
  documents,
  total,
  page,
  rowsPerPage,
  isLoading,
  onPageChange,
  onRowsPerPageChange,
  onSelectDocument,
  onDeleteDocument,
}) => {
  if (isLoading && documents.length === 0) {
    return (
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        p={8}
        bgcolor="#ffffff"
        borderRadius={2}
        border="1px solid #e2e8f0"
      >
        <CircularProgress size={40} sx={{ color: '#00897b', mb: 2 }} />
        <Typography color="text.secondary">Loading utility documents from Neo4j...</Typography>
      </Box>
    );
  }

  if (!isLoading && documents.length === 0) {
    return (
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        p={8}
        bgcolor="#ffffff"
        borderRadius={2}
        border="1px solid #e2e8f0"
        textAlign="center"
      >
        <EmptyIcon sx={{ fontSize: 48, color: '#94a3b8', mb: 1.5 }} />
        <Typography variant="h6" fontWeight={600} color="#1e293b">
          No Documents Found
        </Typography>
        <Typography variant="body2" color="text.secondary" maxWidth={400} mt={0.5}>
          No documents matched your active search query or type filter. Try adjusting your criteria or upload a new document.
        </Typography>
      </Box>
    );
  }

  return (
    <Paper variant="outlined" sx={{ borderRadius: 2, overflow: 'hidden', border: '1px solid #e2e8f0' }}>
      <TableContainer>
        <Table sx={{ minWidth: 750 }}>
          <TableHead sx={{ backgroundColor: '#f8fafc' }}>
            <TableRow>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }}>Document ID</TableCell>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }}>Title</TableCell>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }}>Type</TableCell>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }}>Source</TableCell>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }}>Created Date</TableCell>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }} align="center">Chunks</TableCell>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }} align="center">Vector Index</TableCell>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }} align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {documents.map((doc) => {
              const typeStyle = getDocumentTypeColor(doc.document_type);
              const allEmbedded = doc.chunk_count > 0 && doc.embedded_chunks === doc.chunk_count;

              return (
                <TableRow
                  key={doc.document_id}
                  hover
                  onClick={() => onSelectDocument(doc.document_id)}
                  sx={{
                    cursor: 'pointer',
                    '&:last-child td, &:last-child th': { border: 0 },
                  }}
                >
                  <TableCell sx={{ fontWeight: 600, color: '#00897b' }}>
                    {doc.document_id}
                  </TableCell>
                  <TableCell sx={{ fontWeight: 500, color: '#0f172a', maxWidth: 300 }}>
                    <Box display="flex" alignItems="center" gap={0.75}>
                      <Typography variant="body2" noWrap fontWeight={500} sx={{ maxWidth: 220 }}>
                        {doc.title}
                      </Typography>
                      {doc.format && (
                        <Chip
                          label={doc.format.toUpperCase()}
                          size="small"
                          sx={{
                            height: 18,
                            fontSize: '0.65rem',
                            fontWeight: 700,
                            backgroundColor: '#f1f5f9',
                            color: '#475569',
                          }}
                        />
                      )}
                      {doc.warnings && doc.warnings.length > 0 && (
                        <Tooltip title={doc.warnings.join(' | ')}>
                          <WarningIcon sx={{ fontSize: 16, color: '#f59e0b', cursor: 'help' }} />
                        </Tooltip>
                      )}
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={typeStyle.label}
                      size="small"
                      sx={{
                        backgroundColor: typeStyle.bg,
                        color: typeStyle.text,
                        border: `1px solid ${typeStyle.border}`,
                        fontWeight: 600,
                        fontSize: '0.72rem',
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ color: '#475569', fontSize: '0.85rem' }}>
                    {doc.source}
                  </TableCell>
                  <TableCell sx={{ color: '#64748b', fontSize: '0.85rem' }}>
                    {formatDate(doc.created_date)}
                  </TableCell>
                  <TableCell align="center">
                    <Chip
                      label={`${doc.chunk_count} chunk${doc.chunk_count === 1 ? '' : 's'}`}
                      size="small"
                      variant="outlined"
                      sx={{ fontSize: '0.72rem', borderColor: '#cbd5e1' }}
                    />
                  </TableCell>
                  <TableCell align="center">
                    <Chip
                      icon={<EmbeddedIcon sx={{ fontSize: '14px !important', color: allEmbedded ? '#16a34a !important' : '#d97706 !important' }} />}
                      label={allEmbedded ? 'Indexed' : `${doc.embedded_chunks}/${doc.chunk_count}`}
                      size="small"
                      sx={{
                        fontSize: '0.72rem',
                        fontWeight: 600,
                        backgroundColor: allEmbedded ? '#f0fdf4' : '#fffbeb',
                        color: allEmbedded ? '#16a34a' : '#d97706',
                        border: `1px solid ${allEmbedded ? '#bbf7d0' : '#fde68a'}`,
                      }}
                    />
                  </TableCell>
                  <TableCell align="right">
                    <Box display="flex" justifyContent="flex-end" alignItems="center" gap={0.5}>
                      <Tooltip title="View Document Details">
                        <IconButton
                          size="small"
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectDocument(doc.document_id);
                          }}
                          sx={{ color: '#00897b' }}
                        >
                          <ViewIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      {onDeleteDocument && (
                        <Tooltip title="Delete Document">
                          <IconButton
                            size="small"
                            onClick={(e) => {
                              e.stopPropagation();
                              onDeleteDocument(doc);
                            }}
                            sx={{ color: '#ef4444' }}
                          >
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}
                    </Box>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>

      <TablePagination
        rowsPerPageOptions={[10, 25, 50]}
        component="div"
        count={total}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={(_, newPage) => onPageChange(newPage)}
        onRowsPerPageChange={(e) => onRowsPerPageChange(parseInt(e.target.value, 10))}
        sx={{ borderTop: '1px solid #e2e8f0' }}
      />
    </Paper>
  );
};
