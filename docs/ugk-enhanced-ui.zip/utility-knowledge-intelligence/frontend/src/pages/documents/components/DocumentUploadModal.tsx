import React, { useState, useRef, DragEvent } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
  Alert,
  CircularProgress,
  IconButton,
  Chip,
  Stack,
} from '@mui/material';
import {
  Close as CloseIcon,
  CloudUpload as UploadIcon,
  CheckCircle as SuccessIcon,
  AttachFile as FileIcon,
  WarningAmber as WarningIcon,
  Description as DocumentIcon,
} from '@mui/icons-material';
import { uploadDocument } from '../../../services/api';
import { DocumentUploadResult } from '../../../types/documents';

interface DocumentUploadModalProps {
  open: boolean;
  onClose: () => void;
  onUploadSuccess: () => void;
}

const SUPPORTED_FORMATS: { ext: string; label: string; color: string; bg: string }[] = [
  { ext: 'pdf', label: 'PDF (.pdf)', color: '#b91c1c', bg: '#fef2f2' },
  { ext: 'xlsx', label: 'Excel (.xlsx)', color: '#15803d', bg: '#f0fdf4' },
  { ext: 'csv', label: 'CSV (.csv)', color: '#0e7490', bg: '#ecfeff' },
  { ext: 'docx', label: 'Word (.docx)', color: '#1d4ed8', bg: '#eff6ff' },
  { ext: 'txt', label: 'Text (.txt)', color: '#475569', bg: '#f8fafc' },
  { ext: 'json', label: 'JSON (.json)', color: '#6d28d9', bg: '#f5f3ff' },
];

export const DocumentUploadModal: React.FC<DocumentUploadModalProps> = ({
  open,
  onClose,
  onUploadSuccess,
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [detectedFormat, setDetectedFormat] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<DocumentUploadResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateAndSetFile = (file: File) => {
    setError(null);
    setResult(null);

    const ext = file.name.split('.').pop()?.toLowerCase();

    if (ext === 'xls') {
      setError(
        'Legacy Excel (.xls) is not supported due to security and format constraints. Please convert your file to modern .xlsx or .csv before uploading.'
      );
      setSelectedFile(null);
      setDetectedFormat(null);
      return;
    }

    const match = SUPPORTED_FORMATS.find((f) => f.ext === ext);
    if (!match) {
      setError(
        `Unsupported file format (.${ext || 'unknown'}). Supported formats are: PDF (.pdf), Excel (.xlsx), CSV (.csv), Word (.docx), Text (.txt), and JSON (.json).`
      );
      setSelectedFile(null);
      setDetectedFormat(null);
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      const sizeMb = (file.size / (1024 * 1024)).toFixed(2);
      setError(`File exceeds the 5 MB maximum size limit (${sizeMb} MB uploaded).`);
      setSelectedFile(null);
      setDetectedFormat(null);
      return;
    }

    if (file.size === 0) {
      setError('The selected file is empty (0 bytes). Please choose a valid document.');
      setSelectedFile(null);
      setDetectedFormat(null);
      return;
    }

    setSelectedFile(file);
    setDetectedFormat(match.ext);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      validateAndSetFile(e.target.files[0]);
    }
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndSetFile(e.dataTransfer.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile || isUploading) return;
    setIsUploading(true);
    setError(null);
    setResult(null);

    try {
      const uploadRes = await uploadDocument(selectedFile);
      setResult(uploadRes);
      onUploadSuccess();
    } catch (err: any) {
      console.error('Upload failed:', err);
      const msg = err?.response?.data?.detail || err?.message || 'Failed to upload and ingest document.';
      setError(msg);
    } finally {
      setIsUploading(false);
    }
  };

  const handleResetAndClose = () => {
    setSelectedFile(null);
    setDetectedFormat(null);
    setError(null);
    setResult(null);
    setIsUploading(false);
    onClose();
  };

  const formatBadge = detectedFormat
    ? SUPPORTED_FORMATS.find((f) => f.ext === detectedFormat)
    : null;

  return (
    <Dialog
      disablePortal
      open={open}
      onClose={handleResetAndClose}
      maxWidth="sm"
      fullWidth
      PaperProps={{ sx: { borderRadius: 2.5 } }}
    >
      <DialogTitle sx={{ p: 2.5, pb: 1.5, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Box display="flex" alignItems="center" gap={1}>
          <UploadIcon sx={{ color: '#00897b' }} />
          <Typography variant="h6" fontWeight={700} color="#0f172a">
            Upload & Ingest Document
          </Typography>
        </Box>
        <IconButton onClick={handleResetAndClose} size="small" sx={{ color: '#94a3b8' }}>
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      <DialogContent sx={{ p: 3 }}>
        <Typography variant="body2" color="text.secondary" mb={2}>
          Upload utility operational records, technical reports, spreadsheets, or inspection notes. The system parses content, chunks structure-aware records, links knowledge graph entities, and indexes Sentence Transformers vector embeddings.
        </Typography>

        {/* Supported Formats Banner */}
        <Box mb={2.5}>
          <Typography variant="caption" fontWeight={600} color="#64748b" display="block" mb={0.75}>
            SUPPORTED DOCUMENT FORMATS (5 MB LIMIT)
          </Typography>
          <Stack direction="row" spacing={0.75} flexWrap="wrap" useFlexGap>
            {SUPPORTED_FORMATS.map((f) => (
              <Chip
                key={f.ext}
                label={f.label}
                size="small"
                sx={{
                  backgroundColor: f.bg,
                  color: f.color,
                  fontWeight: 600,
                  fontSize: '0.72rem',
                  border: `1px solid ${f.color}30`,
                }}
              />
            ))}
          </Stack>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        {result && (
          <Box mb={2}>
            <Alert
              severity={result.action === 'skipped' ? 'info' : 'success'}
              icon={<SuccessIcon fontSize="inherit" />}
              sx={{ mb: 1.5 }}
            >
              <Typography variant="subtitle2" fontWeight={700}>
                {result.title} ({result.document_id})
              </Typography>
              <Typography variant="body2" mt={0.5}>
                {result.message}
              </Typography>
              <Box display="flex" gap={1} mt={1} flexWrap="wrap">
                {result.format && (
                  <Chip
                    label={`Format: ${result.format.toUpperCase()}`}
                    size="small"
                    sx={{ bgcolor: '#f1f5f9', color: '#334155', fontWeight: 600 }}
                  />
                )}
                <Chip
                  label={`${result.chunks_created} chunks`}
                  size="small"
                  sx={{ bgcolor: '#dcfce7', color: '#166534', fontWeight: 600 }}
                />
                <Chip
                  label={`${result.relationships_created} relationships`}
                  size="small"
                  sx={{ bgcolor: '#e0e7ff', color: '#4338ca', fontWeight: 600 }}
                />
                <Chip
                  label={result.embedded ? 'Embedded in Vector Index' : 'Pending Embedding'}
                  size="small"
                  sx={{ bgcolor: '#fef3c7', color: '#b45309', fontWeight: 600 }}
                />
              </Box>
            </Alert>

            {result.warnings && result.warnings.length > 0 && (
              <Alert severity="warning" icon={<WarningIcon fontSize="inherit" />}>
                <Typography variant="caption" fontWeight={700} display="block">
                  Extraction Notice:
                </Typography>
                {result.warnings.map((w, idx) => (
                  <Typography key={idx} variant="caption" display="block">
                    • {w}
                  </Typography>
                ))}
              </Alert>
            )}
          </Box>
        )}

        {!result && (
          <Box
            onClick={() => fileInputRef.current?.click()}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            sx={{
              border: '2px dashed',
              borderColor: isDragging ? '#00897b' : selectedFile ? '#00897b' : '#cbd5e1',
              borderRadius: 2,
              p: 3.5,
              textAlign: 'center',
              backgroundColor: isDragging ? '#f0fdf4' : selectedFile ? '#f8fafc' : '#f8fafc',
              cursor: 'pointer',
              transition: 'all 0.2s',
              '&:hover': {
                borderColor: '#00897b',
                backgroundColor: '#f0fdf4',
              },
            }}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".pdf,.xlsx,.csv,.docx,.txt,.json"
              style={{ display: 'none' }}
            />
            {selectedFile ? (
              <Box>
                <DocumentIcon sx={{ fontSize: 44, color: '#00897b', mb: 1 }} />
                <Typography variant="subtitle2" fontWeight={700} color="#0f172a">
                  {selectedFile.name}
                </Typography>
                <Box display="flex" justifyContent="center" alignItems="center" gap={1} mt={0.5}>
                  {formatBadge && (
                    <Chip
                      label={formatBadge.label}
                      size="small"
                      sx={{
                        bgcolor: formatBadge.bg,
                        color: formatBadge.color,
                        fontWeight: 600,
                        fontSize: '0.72rem',
                        height: 22,
                      }}
                    />
                  )}
                  <Typography variant="caption" color="text.secondary">
                    {(selectedFile.size / 1024).toFixed(1)} KB
                  </Typography>
                </Box>
                <Typography variant="caption" color="#00897b" display="block" mt={1} fontWeight={500}>
                  Ready for ingestion • Click to choose a different file
                </Typography>
              </Box>
            ) : (
              <Box>
                <FileIcon sx={{ fontSize: 44, color: isDragging ? '#00897b' : '#94a3b8', mb: 1 }} />
                <Typography variant="subtitle2" fontWeight={600} color="#334155">
                  Drag and drop your file here, or click to browse
                </Typography>
                <Typography variant="caption" color="text.secondary" display="block" mt={0.5}>
                  PDF, Excel (.xlsx), CSV, Word (.docx), TXT, or JSON • Max 5 MB
                </Typography>
              </Box>
            )}
          </Box>
        )}

        {isUploading && (
          <Box display="flex" alignItems="center" gap={1.5} mt={2} p={1.5} bgcolor="#f0fdf4" borderRadius={1.5}>
            <CircularProgress size={20} sx={{ color: '#00897b' }} />
            <Typography variant="body2" color="#0f766e" fontWeight={500}>
              Extracting content, generating chunks, and indexing into Neo4j...
            </Typography>
          </Box>
        )}
      </DialogContent>

      <DialogActions sx={{ p: 2, px: 2.5, borderTop: '1px solid #e2e8f0' }}>
        <Button onClick={handleResetAndClose} variant="text" sx={{ color: '#64748b' }}>
          {result ? 'Done' : 'Cancel'}
        </Button>
        {!result && (
          <Button
            onClick={handleUpload}
            disabled={!selectedFile || isUploading}
            variant="contained"
            startIcon={isUploading ? <CircularProgress size={18} color="inherit" /> : <UploadIcon />}
            sx={{
              backgroundColor: '#00897b',
              textTransform: 'none',
              fontWeight: 600,
              '&:hover': { backgroundColor: '#00796b' },
            }}
          >
            {isUploading ? 'Ingesting...' : 'Ingest Document'}
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
};
