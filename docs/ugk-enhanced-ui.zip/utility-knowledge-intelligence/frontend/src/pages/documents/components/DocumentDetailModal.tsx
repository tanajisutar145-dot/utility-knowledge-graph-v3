import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
  Chip,
  Tabs,
  Tab,
  CircularProgress,
  IconButton,
  Divider,
  Paper,
  Card,
  CardContent,
  Tooltip,
  Alert,
} from '@mui/material';
import {
  Close as CloseIcon,
  ContentCopy as CopyIcon,
  Check as CheckIcon,
  Hub as GraphIcon,
  Psychology as IntelligenceIcon,
  AccountTree as RelIcon,
  Segment as ChunkIcon,
  CheckCircle as EmbeddedIcon,
  DeleteOutline as DeleteIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { DocumentDetailResponse } from '../../../types/documents';
import { getDocumentTypeColor, formatDateTime } from '../utils/documentUtils';

interface DocumentDetailModalProps {
  open: boolean;
  document: DocumentDetailResponse | null;
  isLoading: boolean;
  onClose: () => void;
  onDeleteDocument?: (doc: { document_id: string; title: string }) => void;
  initialTab?: number;
}

export const DocumentDetailModal: React.FC<DocumentDetailModalProps> = ({
  open,
  document,
  isLoading,
  onClose,
  onDeleteDocument,
  initialTab = 0,
}) => {
  const [activeTab, setActiveTab] = useState<number>(initialTab);
  const [copied, setCopied] = useState<boolean>(false);
  const navigate = useNavigate();

  const handleCopyContent = () => {
    if (document?.content) {
      navigator.clipboard.writeText(document.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const typeStyle = document ? getDocumentTypeColor(document.document_type) : null;

  return (
    <Dialog
      disablePortal
      open={open}
      onClose={onClose}
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 2.5,
          minHeight: '60vh',
          maxHeight: '90vh',
        },
      }}
    >
      <DialogTitle sx={{ p: 2.5, pb: 1.5, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        {document ? (
          <Box pr={2}>
            <Box display="flex" alignItems="center" gap={1} flexWrap="wrap" mb={0.5}>
              <Chip
                label={document.document_id}
                size="small"
                sx={{ backgroundColor: '#f1f5f9', fontWeight: 700, color: '#334155' }}
              />
              {typeStyle && (
                <Chip
                  label={typeStyle.label}
                  size="small"
                  sx={{
                    backgroundColor: typeStyle.bg,
                    color: typeStyle.text,
                    border: `1px solid ${typeStyle.border}`,
                    fontWeight: 600,
                  }}
                />
              )}
              {document.format && (
                <Chip
                  label={document.format.toUpperCase()}
                  size="small"
                  sx={{ backgroundColor: '#e2e8f0', color: '#1e293b', fontWeight: 700 }}
                />
              )}
              <Chip
                label={`Status: ${document.processing_status}`}
                size="small"
                sx={{ backgroundColor: '#f0fdf4', color: '#16a34a', fontWeight: 600 }}
              />
            </Box>
            <Typography variant="h6" fontWeight={700} color="#0f172a">
              {document.title}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              Source: {document.source} • Created: {formatDateTime(document.created_date)}
              {document.source_reference && ` • Ref: ${document.source_reference}`}
              {document.source_filename && ` • File: ${document.source_filename}`}
            </Typography>
          </Box>
        ) : (
          <Typography variant="h6">Document Details</Typography>
        )}
        <IconButton onClick={onClose} size="small" sx={{ color: '#94a3b8' }}>
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      {document && document.warnings && document.warnings.length > 0 && (
        <Box px={2.5} pb={1.5}>
          <Alert severity="warning" sx={{ py: 0.5 }}>
            <Typography variant="caption" fontWeight={700} display="block">
              Extraction Notice:
            </Typography>
            {document.warnings.map((w, idx) => (
              <Typography key={idx} variant="caption" display="block">
                • {w}
              </Typography>
            ))}
          </Alert>
        </Box>
      )}

      <Divider />

      <Box sx={{ borderBottom: 1, borderColor: 'divider', px: 2.5, bgcolor: '#f8fafc' }}>
        <Tabs
          value={activeTab}
          onChange={(_, val) => setActiveTab(val)}
          sx={{
            '& .MuiTab-root': {
              textTransform: 'none',
              fontWeight: 600,
              minHeight: 48,
              color: '#64748b',
              '&.Mui-selected': { color: '#00897b' },
            },
            '& .MuiTabs-indicator': { backgroundColor: '#00897b' },
          }}
        >
          <Tab label="Document Content" />
          <Tab label={`Text Chunks (${document?.chunks.length || 0})`} />
          <Tab label={`Linked Entities (${document?.linked_entities.length || 0})`} />
        </Tabs>
      </Box>

      <DialogContent sx={{ p: 3 }}>
        {isLoading ? (
          <Box display="flex" justifyContent="center" alignItems="center" p={6}>
            <CircularProgress size={36} sx={{ color: '#00897b' }} />
          </Box>
        ) : !document ? (
          <Typography color="text.secondary">Document not found.</Typography>
        ) : (
          <>
            {/* Tab 0: Document Content */}
            {activeTab === 0 && (
              <Box>
                <Box display="flex" justifyContent="space-between" alignItems="center" mb={1.5}>
                  <Typography variant="subtitle2" fontWeight={600} color="#334155">
                    Original Document Text ({document.content.length} characters)
                  </Typography>
                  <Tooltip title={copied ? 'Copied!' : 'Copy Document Text'}>
                    <Button
                      size="small"
                      startIcon={copied ? <CheckIcon /> : <CopyIcon />}
                      onClick={handleCopyContent}
                      variant="outlined"
                      sx={{
                        textTransform: 'none',
                        borderColor: '#cbd5e1',
                        color: copied ? '#16a34a' : '#475569',
                      }}
                    >
                      {copied ? 'Copied' : 'Copy Text'}
                    </Button>
                  </Tooltip>
                </Box>
                <Paper
                  variant="outlined"
                  sx={{
                    p: 2.5,
                    backgroundColor: '#f8fafc',
                    borderColor: '#e2e8f0',
                    borderRadius: 2,
                    maxHeight: 380,
                    overflowY: 'auto',
                    whiteSpace: 'pre-wrap',
                    fontFamily: 'inherit',
                    fontSize: '0.9rem',
                    lineHeight: 1.6,
                    color: '#1e293b',
                  }}
                >
                  {document.content}
                </Paper>
                {document.content_hash && (
                  <Typography variant="caption" color="text.secondary" display="block" mt={1}>
                    Content SHA-256 Hash: <code>{document.content_hash}</code>
                  </Typography>
                )}
              </Box>
            )}

            {/* Tab 1: Text Chunks */}
            {activeTab === 1 && (
              <Box display="flex" flexDirection="column" gap={2}>
                <Typography variant="subtitle2" fontWeight={600} color="#334155">
                  Extracted Text Chunks & Vector Embedding Status
                </Typography>
                {document.chunks.map((chunk) => (
                  <Card
                    key={chunk.chunk_id}
                    variant="outlined"
                    sx={{
                      borderRadius: 2,
                      borderColor: '#e2e8f0',
                      backgroundColor: '#ffffff',
                    }}
                  >
                    <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                      <Box display="flex" justifyContent="space-between" alignItems="center" mb={1} flexWrap="wrap" gap={1}>
                        <Box display="flex" alignItems="center" gap={1}>
                          <ChunkIcon sx={{ color: '#00897b', fontSize: 18 }} />
                          <Typography variant="body2" fontWeight={700} color="#0f172a">
                            Chunk #{chunk.chunk_index + 1}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            ({chunk.chunk_id})
                          </Typography>
                        </Box>
                        <Chip
                          icon={<EmbeddedIcon sx={{ fontSize: '14px !important', color: chunk.is_embedded ? '#16a34a !important' : '#d97706 !important' }} />}
                          label={chunk.is_embedded ? `Embedded (${chunk.embedding_dimension || 384}d)` : 'Unembedded'}
                          size="small"
                          sx={{
                            backgroundColor: chunk.is_embedded ? '#f0fdf4' : '#fffbeb',
                            color: chunk.is_embedded ? '#16a34a' : '#d97706',
                            fontWeight: 600,
                            fontSize: '0.72rem',
                          }}
                        />
                      </Box>

                      {/* Source Provenance Indicators */}
                      {(chunk.page_number || chunk.sheet_name || chunk.row_range || chunk.section_title) && (
                        <Box display="flex" gap={0.75} flexWrap="wrap" mb={1}>
                          {chunk.page_number && (
                            <Chip
                              label={`Page ${chunk.page_number}`}
                              size="small"
                              sx={{ bgcolor: '#fee2e2', color: '#991b1b', fontWeight: 600, fontSize: '0.72rem' }}
                            />
                          )}
                          {chunk.sheet_name && (
                            <Chip
                              label={`Sheet: ${chunk.sheet_name}`}
                              size="small"
                              sx={{ bgcolor: '#dcfce7', color: '#166534', fontWeight: 600, fontSize: '0.72rem' }}
                            />
                          )}
                          {chunk.row_range && (
                            <Chip
                              label={chunk.row_range}
                              size="small"
                              sx={{ bgcolor: '#ecfeff', color: '#0e7490', fontWeight: 600, fontSize: '0.72rem' }}
                            />
                          )}
                          {chunk.section_title && (
                            <Chip
                              label={`Section: ${chunk.section_title}`}
                              size="small"
                              sx={{ bgcolor: '#eff6ff', color: '#1d4ed8', fontWeight: 600, fontSize: '0.72rem' }}
                            />
                          )}
                        </Box>
                      )}

                      <Paper
                        variant="outlined"
                        sx={{
                          p: 1.5,
                          bgcolor: '#f8fafc',
                          borderColor: '#f1f5f9',
                          borderRadius: 1.5,
                          fontSize: '0.85rem',
                          lineHeight: 1.5,
                          color: '#334155',
                          whiteSpace: 'pre-wrap',
                        }}
                      >
                        {chunk.text}
                      </Paper>
                      {Object.keys(chunk.metadata).length > 0 && (
                        <Box display="flex" gap={1} flexWrap="wrap" mt={1}>
                          {Object.entries(chunk.metadata).map(([k, v]) => (
                            <Chip
                              key={k}
                              label={`${k.replace('meta_', '')}: ${v}`}
                              size="small"
                              variant="outlined"
                              sx={{ fontSize: '0.68rem', borderColor: '#e2e8f0' }}
                            />
                          ))}
                        </Box>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </Box>
            )}

            {/* Tab 2: Linked Entities */}
            {activeTab === 2 && (
              <Box display="flex" flexDirection="column" gap={2}>
                <Typography variant="subtitle2" fontWeight={600} color="#334155">
                  Knowledge Graph Relational Grounding
                </Typography>
                {document.linked_entities.length === 0 ? (
                  <Box p={3} bgcolor="#f8fafc" borderRadius={2} textAlign="center">
                    <Typography color="text.secondary">
                      No direct entity relationships indexed for this document.
                    </Typography>
                  </Box>
                ) : (
                  document.linked_entities.map((link, idx) => (
                    <Card
                      key={idx}
                      variant="outlined"
                      sx={{
                        borderRadius: 2,
                        borderColor: '#e2e8f0',
                        backgroundColor: '#ffffff',
                      }}
                    >
                      <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                        <Box display="flex" justifyContent="space-between" alignItems="center" flexWrap="wrap" gap={1}>
                          <Box display="flex" alignItems="center" gap={1.5}>
                            <RelIcon sx={{ color: '#0284c7', fontSize: 20 }} />
                            <Box>
                              <Box display="flex" alignItems="center" gap={1}>
                                <Chip
                                  label={link.relationship}
                                  size="small"
                                  sx={{
                                    backgroundColor: '#e0f2fe',
                                    color: '#0284c7',
                                    fontWeight: 700,
                                    fontSize: '0.72rem',
                                  }}
                                />
                                <Typography variant="body2" fontWeight={700} color="#0f172a">
                                  {link.entity_name || link.entity_id}
                                </Typography>
                              </Box>
                              <Typography variant="caption" color="text.secondary">
                                Labels: {link.labels.join(', ')} • ID: {link.entity_id}
                              </Typography>
                            </Box>
                          </Box>

                          <Box display="flex" gap={1}>
                            <Button
                              size="small"
                              variant="outlined"
                              startIcon={<GraphIcon />}
                              onClick={() => {
                                onClose();
                                navigate(`/graph?query=${encodeURIComponent(link.entity_id)}`);
                              }}
                              sx={{
                                textTransform: 'none',
                                borderColor: '#cbd5e1',
                                color: '#475569',
                                fontSize: '0.75rem',
                              }}
                            >
                              Explore in Graph
                            </Button>
                            <Button
                              size="small"
                              variant="outlined"
                              startIcon={<IntelligenceIcon />}
                              onClick={() => {
                                onClose();
                                navigate(`/intelligence?q=${encodeURIComponent(`What is the context of ${link.entity_name || link.entity_id}?`)}`);
                              }}
                              sx={{
                                textTransform: 'none',
                                borderColor: '#00897b',
                                color: '#00897b',
                                fontSize: '0.75rem',
                              }}
                            >
                              Ask Intelligence
                            </Button>
                          </Box>
                        </Box>
                      </CardContent>
                    </Card>
                  ))
                )}
              </Box>
            )}
          </>
        )}
      </DialogContent>

      <DialogActions sx={{ p: 2, px: 2.5, borderTop: '1px solid #e2e8f0', justifyContent: 'space-between' }}>
        <Box>
          {onDeleteDocument && document && (
            <Button
              onClick={() => {
                const target = { document_id: document.document_id, title: document.title };
                onClose();
                onDeleteDocument(target);
              }}
              variant="outlined"
              color="error"
              size="small"
              startIcon={<DeleteIcon />}
              sx={{ textTransform: 'none' }}
            >
              Delete Document
            </Button>
          )}
        </Box>
        <Button onClick={onClose} variant="contained" sx={{ backgroundColor: '#00897b', textTransform: 'none', '&:hover': { backgroundColor: '#00796b' } }}>
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};
