import {
  getDocumentTypeColor,
  formatDate,
  formatDateTime,
  formatFileSize,
} from '../documentUtils';

describe('Document Utilities', () => {
  test('returns specific styling colors for known document types', () => {
    const insp = getDocumentTypeColor('inspection_report');
    expect(insp.text).toBe('#0284c7');
    expect(insp.label).toBe('Inspection Report');

    const fail = getDocumentTypeColor('failure_report');
    expect(fail.text).toBe('#dc2626');
    expect(fail.label).toBe('Failure Report');

    const eng = getDocumentTypeColor('engineering_note');
    expect(eng.text).toBe('#00897b');
    expect(eng.label).toBe('Engineering Note');
  });

  test('returns default styling for unknown or empty types', () => {
    const unknown = getDocumentTypeColor('some_custom_type');
    expect(unknown.label).toBe('some_custom_type');
    expect(unknown.text).toBe('#475569');

    const empty = getDocumentTypeColor('');
    expect(empty.label).toBe('Document');
  });

  test('formats dates safely', () => {
    expect(formatDate(null)).toBe('N/A');
    expect(formatDate(undefined)).toBe('N/A');
    const formatted = formatDate('2026-08-08T08:12:57.413643');
    expect(formatted).toContain('2026');
  });

  test('formats date-times safely', () => {
    expect(formatDateTime(null)).toBe('N/A');
    const formatted = formatDateTime('2026-08-08T08:12:57.413643');
    expect(formatted).toContain('2026');
  });

  test('formats file sizes accurately', () => {
    expect(formatFileSize(500)).toBe('500 B');
    expect(formatFileSize(2048)).toBe('2.0 KB');
    expect(formatFileSize(2 * 1024 * 1024)).toBe('2.00 MB');
  });
});
