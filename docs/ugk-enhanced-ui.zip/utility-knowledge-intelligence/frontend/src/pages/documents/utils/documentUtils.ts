/**
 * Utility helpers for Document Management styling and formatting
 */

export const getDocumentTypeColor = (
  docType: string
): { bg: string; text: string; border: string; label: string } => {
  switch (docType?.toLowerCase()) {
    case 'inspection_report':
      return { bg: '#e0f2fe', text: '#0284c7', border: '#bae6fd', label: 'Inspection Report' };
    case 'failure_report':
      return { bg: '#fee2e2', text: '#dc2626', border: '#fecaca', label: 'Failure Report' };
    case 'work_order_note':
      return { bg: '#fef3c7', text: '#d97706', border: '#fde68a', label: 'Work Order Note' };
    case 'maintenance_report':
      return { bg: '#e0e7ff', text: '#4f46e5', border: '#c7d2fe', label: 'Maintenance Report' };
    case 'engineering_note':
      return { bg: '#e0f2f1', text: '#00897b', border: '#b2dfdb', label: 'Engineering Note' };
    case 'operational_note':
      return { bg: '#f3e8ff', text: '#9333ea', border: '#e9d5ff', label: 'Operational Note' };
    case 'incident_report':
      return { bg: '#ffedd5', text: '#ea580c', border: '#fed7aa', label: 'Incident Report' };
    default:
      return { bg: '#f1f5f9', text: '#475569', border: '#cbd5e1', label: docType || 'Document' };
  }
};

export const formatDate = (dateStr?: string | null): string => {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? dateStr : d.toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return dateStr;
  }
};

export const formatDateTime = (dateStr?: string | null): string => {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? dateStr : d.toLocaleString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateStr;
  }
};

export const formatFileSize = (bytes: number): string => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
};
