import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
} from '@mui/material';
import {
  TrendingUp as TrendIcon,
  Speed as PerformanceIcon,
} from '@mui/icons-material';
import { format, parseISO } from 'date-fns';
import { HeatRateTrend, MaintenanceEffectiveness, InspectionOverview } from '../../../types/dashboard';

interface PerformanceIntelligenceProps {
  performance: HeatRateTrend;
  maintenance: MaintenanceEffectiveness;
  inspections: InspectionOverview;
}

export const PerformanceIntelligence: React.FC<PerformanceIntelligenceProps> = ({
  performance,
  maintenance,
  inspections,
}) => {
  const [activePointIndex, setActivePointIndex] = useState<number | null>(null);

  const { observations, baseline_heat_rate, unit, delta, delta_percentage, interpretation } = performance;

  // Chart coordinate calculations
  const svgWidth = 540;
  const svgHeight = 220;
  const padding = { top: 25, right: 30, bottom: 40, left: 60 };

  const innerWidth = svgWidth - padding.left - padding.right;
  const innerHeight = svgHeight - padding.top - padding.bottom;

  // Range for Y-axis
  const minY = 7750;
  const maxY = 8020;

  const getYCoord = (val: number) => {
    return padding.top + innerHeight - ((val - minY) / (maxY - minY)) * innerHeight;
  };

  const getXCoord = (index: number) => {
    if (observations.length <= 1) return padding.left + innerWidth / 2;
    return padding.left + (index / (observations.length - 1)) * innerWidth;
  };

  const baselineY = getYCoord(baseline_heat_rate);

  // Generate SVG polyline points
  const pointsString = observations
    .map((obs, idx) => `${getXCoord(idx)},${getYCoord(obs.measured_heat_rate)}`)
    .join(' ');

  // Generate area path under the curve
  const areaString = observations.length > 0
    ? `M ${getXCoord(0)},${padding.top + innerHeight} ` +
      observations.map((obs, idx) => `L ${getXCoord(idx)},${getYCoord(obs.measured_heat_rate)}`).join(' ') +
      ` L ${getXCoord(observations.length - 1)},${padding.top + innerHeight} Z`
    : '';

  const formatTestDate = (dateStr?: string) => {
    if (!dateStr) return '';
    try {
      return format(parseISO(dateStr), 'MMM d');
    } catch {
      return dateStr.slice(0, 10);
    }
  };

  return (
    <Box sx={{ mb: 3 }}>
      <Typography
        variant="h6"
        sx={{
          fontWeight: 700,
          color: '#0f172a',
          mb: 1.5,
          display: 'flex',
          alignItems: 'center',
          gap: 1,
          fontSize: '1.125rem',
        }}
      >
        <PerformanceIcon sx={{ color: '#0f766e', fontSize: 22 }} />
        Performance & Maintenance Intelligence
      </Typography>

      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', lg: '7fr 5fr' },
          gap: 2,
        }}
      >
        {/* Panel A: Heat-Rate Trend Line Chart */}
        <Card
          sx={{
            bgcolor: '#ffffff',
            borderRadius: 2,
            border: '1px solid #e2e8f0',
            boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <CardContent sx={{ p: 2.5, flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1.5 }}>
              <Box>
                <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#1e293b', fontSize: '0.9rem' }}>
                  Unit 1 GT Heat-Rate Degradation Trend ({unit})
                </Typography>
                <Typography variant="caption" sx={{ color: '#64748b' }}>
                  Generating Unit UNT-001 • Chronological test observations from Neo4j
                </Typography>
              </Box>

              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Chip
                  icon={<TrendIcon sx={{ fontSize: '14px !important' }} />}
                  label={`+${delta} ${unit} (+${delta_percentage}%)`}
                  size="small"
                  sx={{
                    bgcolor: '#fff7ed',
                    color: '#c2410c',
                    fontWeight: 700,
                    fontSize: '0.75rem',
                    border: '1px solid #ffedd5',
                  }}
                />
              </Box>
            </Box>

            {/* SVG Line Chart */}
            <Box
              sx={{
                width: '100%',
                overflowX: 'auto',
                py: 1,
                display: 'flex',
                justifyContent: 'center',
              }}
            >
              <svg
                viewBox={`0 0 ${svgWidth} ${svgHeight}`}
                style={{ width: '100%', maxWidth: '580px', height: 'auto', overflow: 'visible' }}
              >
                <defs>
                  <linearGradient id="heatRateGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#0d9488" stopOpacity="0.25" />
                    <stop offset="100%" stopColor="#0d9488" stopOpacity="0.01" />
                  </linearGradient>
                </defs>

                {/* Y-axis gridlines & labels */}
                {[7750, 7800, 7850, 7900, 7950, 8000].map((tick) => {
                  const y = getYCoord(tick);
                  const isBaseline = tick === 7800;
                  return (
                    <g key={tick}>
                      <line
                        x1={padding.left}
                        y1={y}
                        x2={svgWidth - padding.right}
                        y2={y}
                        stroke={isBaseline ? '#0284c7' : '#f1f5f9'}
                        strokeWidth={isBaseline ? 1.5 : 1}
                        strokeDasharray={isBaseline ? '4,4' : undefined}
                      />
                      <text
                        x={padding.left - 8}
                        y={y + 4}
                        fill={isBaseline ? '#0284c7' : '#94a3b8'}
                        fontSize="10"
                        fontWeight={isBaseline ? 600 : 400}
                        textAnchor="end"
                      >
                        {tick}
                      </text>
                    </g>
                  );
                })}

                {/* Baseline label */}
                <text
                  x={svgWidth - padding.right}
                  y={baselineY - 5}
                  fill="#0284c7"
                  fontSize="9.5"
                  fontWeight="600"
                  textAnchor="end"
                >
                  Baseline: 7,800 BTU/kWh
                </text>

                {/* Area fill */}
                {areaString && (
                  <path d={areaString} fill="url(#heatRateGradient)" />
                )}

                {/* Data polyline */}
                {pointsString && (
                  <polyline
                    fill="none"
                    stroke="#0d9488"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    points={pointsString}
                  />
                )}

                {/* Data points & X labels */}
                {observations.map((obs, idx) => {
                  const x = getXCoord(idx);
                  const y = getYCoord(obs.measured_heat_rate);
                  const isActive = activePointIndex === idx;

                  return (
                    <g
                      key={obs.test_id}
                      onMouseEnter={() => setActivePointIndex(idx)}
                      onMouseLeave={() => setActivePointIndex(null)}
                      style={{ cursor: 'pointer' }}
                    >
                      {/* Vertical helper line on hover */}
                      {isActive && (
                        <line
                          x1={x}
                          y1={padding.top}
                          x2={x}
                          y2={padding.top + innerHeight}
                          stroke="#cbd5e1"
                          strokeWidth="1"
                          strokeDasharray="2,2"
                        />
                      )}

                      {/* Dot */}
                      <circle
                        cx={x}
                        cy={y}
                        r={isActive ? 6 : 4}
                        fill="#ffffff"
                        stroke="#0d9488"
                        strokeWidth={isActive ? 3 : 2}
                      />

                      {/* Value label over dot */}
                      <text
                        x={x}
                        y={y - 8}
                        fill="#0f172a"
                        fontSize="10"
                        fontWeight="700"
                        textAnchor="middle"
                      >
                        {obs.measured_heat_rate}
                      </text>

                      {/* X-axis date tick */}
                      <text
                        x={x}
                        y={padding.top + innerHeight + 18}
                        fill="#64748b"
                        fontSize="10"
                        textAnchor="middle"
                      >
                        {formatTestDate(obs.test_date)}
                      </text>

                      {/* Test ID tick */}
                      <text
                        x={x}
                        y={padding.top + innerHeight + 30}
                        fill="#94a3b8"
                        fontSize="8.5"
                        textAnchor="middle"
                      >
                        {obs.test_id}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </Box>

            {/* Active tooltip detail or default summary */}
            <Box
              sx={{
                mt: 'auto',
                pt: 1.5,
                bgcolor: '#f8fafc',
                p: 1.5,
                borderRadius: 1.5,
                borderLeft: '3px solid #0d9488',
              }}
            >
              {activePointIndex !== null && observations[activePointIndex] ? (
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="body2" sx={{ color: '#0f172a', fontWeight: 600, fontSize: '0.8125rem' }}>
                    {observations[activePointIndex].test_id}: {observations[activePointIndex].measured_heat_rate} {unit} (+{observations[activePointIndex].deviation_percentage}% above baseline)
                  </Typography>
                  <Typography variant="caption" sx={{ color: '#64748b' }}>
                    {observations[activePointIndex].observations}
                  </Typography>
                </Box>
              ) : (
                <Typography variant="body2" sx={{ color: '#334155', fontSize: '0.8125rem', lineHeight: 1.4 }}>
                  <strong>Interpretation:</strong> {interpretation}
                </Typography>
              )}
            </Box>
          </CardContent>
        </Card>

        {/* Panel B: Maintenance Effectiveness */}
        <Card
          sx={{
            bgcolor: '#ffffff',
            borderRadius: 2,
            border: '1px solid #e2e8f0',
            boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <CardContent sx={{ p: 2.5, flexGrow: 1 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#1e293b', fontSize: '0.9rem' }}>
                Maintenance Program Indicators
              </Typography>
              <Chip
                label="Empirical"
                size="small"
                sx={{ bgcolor: '#f1f5f9', color: '#475569', fontSize: '0.7rem', fontWeight: 600, height: 22 }}
              />
            </Box>

            {/* 4 Key Count Badges */}
            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: 'repeat(2, 1fr)',
                gap: 1.5,
                mb: 2,
              }}
            >
              <Box sx={{ p: 1.5, bgcolor: '#f8fafc', borderRadius: 1.5, border: '1px solid #f1f5f9' }}>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.72rem', display: 'block' }}>
                  Active Maintenance Plans
                </Typography>
                <Typography variant="h6" sx={{ fontWeight: 700, color: '#0f172a', mt: 0.25 }}>
                  {maintenance.maintenance_plans_count}
                </Typography>
                <Typography variant="caption" sx={{ color: '#10b981', fontSize: '0.68rem', fontWeight: 600 }}>
                  100% active status
                </Typography>
              </Box>

              <Box sx={{ p: 1.5, bgcolor: '#f8fafc', borderRadius: 1.5, border: '1px solid #f1f5f9' }}>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.72rem', display: 'block' }}>
                  Total Inspections
                </Typography>
                <Typography variant="h6" sx={{ fontWeight: 700, color: '#0f172a', mt: 0.25 }}>
                  {maintenance.inspections_count}
                </Typography>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.68rem' }}>
                  Fleet condition audits
                </Typography>
              </Box>

              <Box sx={{ p: 1.5, bgcolor: '#f8fafc', borderRadius: 1.5, border: '1px solid #f1f5f9' }}>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.72rem', display: 'block' }}>
                  Preventive Work Orders
                </Typography>
                <Typography variant="h6" sx={{ fontWeight: 700, color: '#0f766e', mt: 0.25 }}>
                  {maintenance.preventive_count}
                </Typography>
                <Typography variant="caption" sx={{ color: '#0f766e', fontSize: '0.68rem', fontWeight: 600 }}>
                  {maintenance.preventive_percentage}% proactive ratio
                </Typography>
              </Box>

              <Box sx={{ p: 1.5, bgcolor: '#f8fafc', borderRadius: 1.5, border: '1px solid #f1f5f9' }}>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.72rem', display: 'block' }}>
                  Triggered from Failures
                </Typography>
                <Typography variant="h6" sx={{ fontWeight: 700, color: '#e11d48', mt: 0.25 }}>
                  {maintenance.triggered_work_orders_count}
                </Typography>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.68rem' }}>
                  Of {maintenance.failures_count} recorded failures
                </Typography>
              </Box>
            </Box>

            {/* Inspection Findings Distribution */}
            <Typography variant="caption" sx={{ color: '#475569', fontWeight: 600, mb: 1, display: 'block' }}>
              Inspection Condition Findings ({maintenance.inspections_count})
            </Typography>
            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 1, mb: 2 }}>
              <Box sx={{ textAlign: 'center', p: 1, bgcolor: '#f0fdf4', borderRadius: 1, border: '1px solid #dcfce7' }}>
                <Typography variant="caption" sx={{ color: '#166534', fontSize: '0.7rem', display: 'block' }}>
                  Excellent
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 700, color: '#166534' }}>
                  {inspections.condition_counts['excellent'] || 0}
                </Typography>
              </Box>
              <Box sx={{ textAlign: 'center', p: 1, bgcolor: '#f0fdfa', borderRadius: 1, border: '1px solid #ccfbf1' }}>
                <Typography variant="caption" sx={{ color: '#0f766e', fontSize: '0.7rem', display: 'block' }}>
                  Good
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 700, color: '#0f766e' }}>
                  {inspections.condition_counts['good'] || 0}
                </Typography>
              </Box>
              <Box sx={{ textAlign: 'center', p: 1, bgcolor: '#fffbeb', borderRadius: 1, border: '1px solid #fef3c7' }}>
                <Typography variant="caption" sx={{ color: '#b45309', fontSize: '0.7rem', display: 'block' }}>
                  Fair
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 700, color: '#b45309' }}>
                  {inspections.condition_counts['fair'] || 0}
                </Typography>
              </Box>
              <Box sx={{ textAlign: 'center', p: 1, bgcolor: '#fef2f2', borderRadius: 1, border: '1px solid #fee2e2' }}>
                <Typography variant="caption" sx={{ color: '#b91c1c', fontSize: '0.7rem', display: 'block' }}>
                  Poor
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 700, color: '#b91c1c' }}>
                  {inspections.condition_counts['poor'] || 0}
                </Typography>
              </Box>
            </Box>

            {/* Factual Note */}
            <Typography
              variant="caption"
              sx={{
                color: '#64748b',
                display: 'block',
                bgcolor: '#f8fafc',
                p: 1.25,
                borderRadius: 1,
                borderLeft: '3px solid #2563eb',
                fontSize: '0.75rem',
                lineHeight: 1.4,
              }}
            >
              {maintenance.summary_note}
            </Typography>
          </CardContent>
        </Card>
      </Box>
    </Box>
  );
};
