import React from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Chip,
} from '@mui/material';
import {
  Psychology as BrainIcon,
  AutoAwesome as SparkleIcon,
  FactCheck as VerifyIcon,
  ArrowForward as ArrowForwardIcon,
  QuestionAnswer as AskIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

export const AIIntelligenceSummary: React.FC = () => {
  const navigate = useNavigate();

  const sampleQuestions = [
    'What caused the compressor blade failure on AST-001?',
    'Why did heat rate increase on Unit 1 GT?',
    'What preventive maintenance is scheduled for Unit 1?',
    'What is the root cause of the bearing failure on AST-009?',
  ];

  const handleAskQuestion = (q?: string) => {
    if (q) {
      navigate(`/intelligence?q=${encodeURIComponent(q)}`);
    } else {
      navigate('/intelligence');
    }
  };

  return (
    <Box sx={{ mb: 3 }}>
      <Typography
        variant="h6"
        sx={{
          fontWeight: 700,
          color: '#0f172a',
          mb: 1.5,
          display: 'flex',
          alignItems: 'center',
          gap: 1,
          fontSize: '1.125rem',
        }}
      >
        <BrainIcon sx={{ color: '#0f766e', fontSize: 22 }} />
        AI Intelligence & GraphRAG
      </Typography>

      <Card
        sx={{
          bgcolor: '#ffffff',
          borderRadius: 2,
          border: '1px solid #e2e8f0',
          boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
          overflow: 'hidden',
        }}
      >
        <CardContent sx={{ p: 3 }}>
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: { xs: '1fr', md: '7fr 5fr' },
              gap: 3,
              alignItems: 'center',
            }}
          >
            {/* Left Column: Capability explanation */}
            <Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                <Chip
                  icon={<SparkleIcon sx={{ fontSize: '14px !important' }} />}
                  label="Grounded Domain QA"
                  size="small"
                  sx={{
                    bgcolor: '#f0fdfa',
                    color: '#0f766e',
                    fontWeight: 700,
                    fontSize: '0.75rem',
                    border: '1px solid #99f6e4',
                  }}
                />
                <Chip
                  icon={<VerifyIcon sx={{ fontSize: '14px !important' }} />}
                  label="Evidence Verified"
                  size="small"
                  sx={{
                    bgcolor: '#ecfdf5',
                    color: '#047857',
                    fontWeight: 700,
                    fontSize: '0.75rem',
                    border: '1px solid #a7f3d0',
                  }}
                />
              </Box>

              <Typography variant="h6" sx={{ fontWeight: 700, color: '#0f172a', mb: 1, fontSize: '1.1rem' }}>
                Enterprise Graph-Augmented Retrieval & Evidence Verification
              </Typography>

              <Typography variant="body2" sx={{ color: '#475569', mb: 2, lineHeight: 1.6, fontSize: '0.875rem' }}>
                The Utility Knowledge Intelligence system combines Neo4j vector semantic search across 13 technical document chunks with multi-hop graph relationship traversals over 338 entity nodes. Groq LLM synthesizes deterministic answers strictly supported by verifiable evidence and citation sources.
              </Typography>

              <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap' }}>
                <Button
                  variant="contained"
                  onClick={() => handleAskQuestion()}
                  endIcon={<ArrowForwardIcon sx={{ fontSize: 16 }} />}
                  sx={{
                    bgcolor: '#0f766e',
                    color: '#ffffff',
                    fontWeight: 600,
                    textTransform: 'none',
                    px: 2,
                    borderRadius: 1.5,
                    boxShadow: 'none',
                    '&:hover': {
                      bgcolor: '#115e59',
                      boxShadow: '0 2px 6px rgba(15, 118, 110, 0.25)',
                    },
                  }}
                >
                  Open GraphRAG Intelligence
                </Button>

                <Button
                  variant="outlined"
                  onClick={() => navigate('/search')}
                  sx={{
                    borderColor: '#cbd5e1',
                    color: '#334155',
                    fontWeight: 600,
                    textTransform: 'none',
                    px: 2,
                    borderRadius: 1.5,
                    '&:hover': {
                      borderColor: '#0f766e',
                      bgcolor: '#f8fafc',
                      color: '#0f766e',
                    },
                  }}
                >
                  Semantic Search
                </Button>
              </Box>
            </Box>

            {/* Right Column: Pre-configured sample questions */}
            <Box
              sx={{
                bgcolor: '#f8fafc',
                p: 2,
                borderRadius: 2,
                border: '1px solid #f1f5f9',
              }}
            >
              <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em', display: 'flex', alignItems: 'center', gap: 0.5, mb: 1.5 }}>
                <AskIcon sx={{ fontSize: 14, color: '#0f766e' }} />
                Suggested Domain Inquiries
              </Typography>

              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                {sampleQuestions.map((question, idx) => (
                  <Box
                    key={idx}
                    onClick={() => handleAskQuestion(question)}
                    sx={{
                      p: 1.25,
                      bgcolor: '#ffffff',
                      borderRadius: 1.5,
                      border: '1px solid #e2e8f0',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      '&:hover': {
                        borderColor: '#0f766e',
                        bgcolor: '#f0fdfa',
                        transform: 'translateX(2px)',
                      },
                    }}
                  >
                    <Typography variant="caption" sx={{ color: '#1e293b', fontWeight: 600, fontSize: '0.78rem' }}>
                      "{question}"
                    </Typography>
                    <ArrowForwardIcon sx={{ fontSize: 14, color: '#0f766e', flexShrink: 0, ml: 1 }} />
                  </Box>
                ))}
              </Box>
            </Box>
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
};
