import React from 'react';
import { Box, Card, Typography } from '@mui/material';
import {
  Factory as PlantIcon,
  PowerSettingsNew as UnitIcon,
  PrecisionManufacturing as AssetIcon,
  Extension as ComponentIcon,
  Assignment as WorkOrderIcon,
  FactCheck as InspectionIcon,
  WarningAmber as FailureIcon,
  PowerOff as OutageIcon,
  CalendarMonth as PlanIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { DashboardKPIs } from '../../../types/dashboard';

interface ExecutiveKPICardsProps {
  kpis: DashboardKPIs;
}

interface KPICardConfig {
  id: string;
  label: string;
  count: number;
  caption: string;
  icon: React.ReactNode;
  accentColor: string;
  bgColor: string;
  route: string;
}

export const ExecutiveKPICards: React.FC<ExecutiveKPICardsProps> = ({ kpis }) => {
  const navigate = useNavigate();

  const cards: KPICardConfig[] = [
    {
      id: 'plants',
      label: 'Power Plants',
      count: kpis.power_plants,
      caption: 'Active facilities',
      icon: <PlantIcon sx={{ fontSize: 20 }} />,
      accentColor: '#0f766e', // deep teal
      bgColor: '#f0fdfa',
      route: '/assets',
    },
    {
      id: 'units',
      label: 'Generating Units',
      count: kpis.generating_units,
      caption: 'Generation blocks',
      icon: <UnitIcon sx={{ fontSize: 20 }} />,
      accentColor: '#0284c7', // sky blue
      bgColor: '#f0f9ff',
      route: '/assets',
    },
    {
      id: 'assets',
      label: 'Assets',
      count: kpis.assets,
      caption: 'Monitored systems',
      icon: <AssetIcon sx={{ fontSize: 20 }} />,
      accentColor: '#2563eb', // royal blue
      bgColor: '#eff6ff',
      route: '/assets',
    },
    {
      id: 'components',
      label: 'Components',
      count: kpis.components,
      caption: 'Subsystem parts',
      icon: <ComponentIcon sx={{ fontSize: 20 }} />,
      accentColor: '#4f46e5', // indigo
      bgColor: '#eef2ff',
      route: '/assets',
    },
    {
      id: 'work_orders',
      label: 'Work Orders',
      count: kpis.work_orders,
      caption: 'Fleet work records',
      icon: <WorkOrderIcon sx={{ fontSize: 20 }} />,
      accentColor: '#0d9488', // teal
      bgColor: '#f0fdfa',
      route: '/graph?node_label=WorkOrder',
    },
    {
      id: 'inspections',
      label: 'Inspections',
      count: kpis.inspections,
      caption: 'Condition audits',
      icon: <InspectionIcon sx={{ fontSize: 20 }} />,
      accentColor: '#16a34a', // green
      bgColor: '#f0fdf4',
      route: '/graph?node_label=Inspection',
    },
    {
      id: 'failures',
      label: 'Failure Events',
      count: kpis.failure_events,
      caption: 'Critical incidents',
      icon: <FailureIcon sx={{ fontSize: 20 }} />,
      accentColor: '#e11d48', // rose red
      bgColor: '#fff1f2',
      route: '/graph?node_label=FailureEvent',
    },
    {
      id: 'outages',
      label: 'Outage Events',
      count: kpis.outage_events,
      caption: 'Recorded downtimes',
      icon: <OutageIcon sx={{ fontSize: 20 }} />,
      accentColor: '#d97706', // amber
      bgColor: '#fffbeb',
      route: '/graph?node_label=OutageEvent',
    },
    {
      id: 'plans',
      label: 'Maintenance Plans',
      count: kpis.maintenance_plans,
      caption: 'Scheduled programs',
      icon: <PlanIcon sx={{ fontSize: 20 }} />,
      accentColor: '#7c3aed', // violet
      bgColor: '#f5f3ff',
      route: '/assets',
    },
  ];

  return (
    <Box
      sx={{
        display: 'grid',
        gridTemplateColumns: {
          xs: 'repeat(2, 1fr)',
          sm: 'repeat(3, 1fr)',
          md: 'repeat(5, 1fr)',
          lg: 'repeat(9, 1fr)',
        },
        gap: 1.5,
        mb: 3,
      }}
    >
      {cards.map((card) => (
        <Card
          key={card.id}
          onClick={() => navigate(card.route)}
          sx={{
            p: 1.75,
            bgcolor: '#ffffff',
            borderRadius: 2,
            border: '1px solid #e2e8f0',
            boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
            cursor: 'pointer',
            transition: 'all 0.18s ease-in-out',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            '&:hover': {
              transform: 'translateY(-2px)',
              boxShadow: '0 4px 12px 0 rgba(0, 0, 0, 0.08)',
              borderColor: card.accentColor,
            },
          }}
        >
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              mb: 1,
            }}
          >
            <Typography
              variant="caption"
              sx={{
                fontWeight: 600,
                color: '#64748b',
                fontSize: '0.72rem',
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
                lineHeight: 1.2,
              }}
            >
              {card.label}
            </Typography>
            <Box
              sx={{
                width: 30,
                height: 30,
                borderRadius: '8px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                bgcolor: card.bgColor,
                color: card.accentColor,
                flexShrink: 0,
              }}
            >
              {card.icon}
            </Box>
          </Box>

          <Box>
            <Typography
              variant="h5"
              sx={{
                fontWeight: 700,
                color: '#0f172a',
                fontSize: '1.5rem',
                lineHeight: 1.1,
              }}
            >
              {card.count.toLocaleString()}
            </Typography>
            <Typography
              variant="caption"
              sx={{
                color: '#94a3b8',
                fontSize: '0.7rem',
                display: 'block',
                mt: 0.5,
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
              }}
            >
              {card.caption}
            </Typography>
          </Box>
        </Card>
      ))}
    </Box>
  );
};
