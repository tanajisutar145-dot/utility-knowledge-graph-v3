import React from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Chip,
  LinearProgress,
} from '@mui/material';
import {
  Shield as ShieldIcon,
  Schedule as TimeIcon,
  MonetizationOn as CostIcon,
  Bolt as PowerIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { OperationsStats } from '../../../types/dashboard';

interface OperationalIntelligenceProps {
  operations: OperationsStats;
}

export const OperationalIntelligence: React.FC<OperationalIntelligenceProps> = ({
  operations,
}) => {
  const navigate = useNavigate();
  const { asset_reliability, work_orders, failures, outages } = operations;

  const totalAssets = asset_reliability.total_assets || 57;
  const criticalCount = asset_reliability.criticality_counts['critical'] || 0;
  const highCount = asset_reliability.criticality_counts['high'] || 0;
  const mediumCount = asset_reliability.criticality_counts['medium'] || 0;

  return (
    <Box sx={{ mb: 3 }}>
      <Typography
        variant="h6"
        sx={{
          fontWeight: 700,
          color: '#0f172a',
          mb: 1.5,
          display: 'flex',
          alignItems: 'center',
          gap: 1,
          fontSize: '1.125rem',
        }}
      >
        <ShieldIcon sx={{ color: '#0f766e', fontSize: 22 }} />
        Operational Intelligence
      </Typography>

      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', lg: 'repeat(3, 1fr)' },
          gap: 2,
        }}
      >
        {/* Panel A: Asset Reliability */}
        <Card
          sx={{
            bgcolor: '#ffffff',
            borderRadius: 2,
            border: '1px solid #e2e8f0',
            boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <CardContent sx={{ p: 2.5, flexGrow: 1 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#1e293b', fontSize: '0.9rem' }}>
                Asset Reliability & Criticality
              </Typography>
              <Chip
                label="Factual Indicators"
                size="small"
                sx={{
                  bgcolor: '#f1f5f9',
                  color: '#475569',
                  fontSize: '0.7rem',
                  fontWeight: 600,
                  height: 22,
                }}
              />
            </Box>

            {/* Metric row */}
            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: 'repeat(3, 1fr)',
                gap: 1.5,
                mb: 2.5,
                bgcolor: '#f8fafc',
                p: 1.5,
                borderRadius: 1.5,
                border: '1px solid #f1f5f9',
              }}
            >
              <Box>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.7rem', fontWeight: 500 }}>
                  Monitored Assets
                </Typography>
                <Typography variant="h6" sx={{ fontWeight: 700, color: '#0f172a', fontSize: '1.25rem' }}>
                  {totalAssets}
                </Typography>
              </Box>
              <Box>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.7rem', fontWeight: 500 }}>
                  Operational
                </Typography>
                <Typography variant="h6" sx={{ fontWeight: 700, color: '#10b981', fontSize: '1.25rem' }}>
                  {asset_reliability.operational_assets}
                </Typography>
              </Box>
              <Box>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.7rem', fontWeight: 500 }}>
                  With Failures
                </Typography>
                <Typography variant="h6" sx={{ fontWeight: 700, color: '#e11d48', fontSize: '1.25rem' }}>
                  {asset_reliability.assets_with_failures}
                </Typography>
              </Box>
            </Box>

            {/* Criticality Breakdown */}
            <Typography variant="caption" sx={{ color: '#475569', fontWeight: 600, mb: 1, display: 'block' }}>
              Asset Criticality Distribution
            </Typography>

            {/* Stacked bar visualization */}
            <Box sx={{ display: 'flex', height: 8, borderRadius: 4, overflow: 'hidden', mb: 1.5 }}>
              <Box sx={{ width: `${(criticalCount / totalAssets) * 100}%`, bgcolor: '#e11d48' }} />
              <Box sx={{ width: `${(highCount / totalAssets) * 100}%`, bgcolor: '#f59e0b' }} />
              <Box sx={{ width: `${(mediumCount / totalAssets) * 100}%`, bgcolor: '#0284c7' }} />
            </Box>

            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: '#e11d48' }} />
                <Typography variant="caption" sx={{ color: '#334155', fontWeight: 500 }}>
                  Critical: <strong>{criticalCount}</strong> ({Math.round((criticalCount / totalAssets) * 100)}%)
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: '#f59e0b' }} />
                <Typography variant="caption" sx={{ color: '#334155', fontWeight: 500 }}>
                  High: <strong>{highCount}</strong> ({Math.round((highCount / totalAssets) * 100)}%)
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
                <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: '#0284c7' }} />
                <Typography variant="caption" sx={{ color: '#334155', fontWeight: 500 }}>
                  Medium: <strong>{mediumCount}</strong> ({Math.round((mediumCount / totalAssets) * 100)}%)
                </Typography>
              </Box>
            </Box>

            <Typography
              variant="caption"
              sx={{
                color: '#64748b',
                display: 'block',
                bgcolor: '#f8fafc',
                p: 1.25,
                borderRadius: 1,
                borderLeft: '3px solid #0f766e',
                fontSize: '0.75rem',
                lineHeight: 1.4,
              }}
            >
              Factual fleet data from Neo4j knowledge graph. 2 assets (AST-001 Gas Turbine, AST-009 Boiler Feed Pump) have recorded historical failures.
            </Typography>
          </CardContent>
        </Card>

        {/* Panel B: Work Order Overview */}
        <Card
          sx={{
            bgcolor: '#ffffff',
            borderRadius: 2,
            border: '1px solid #e2e8f0',
            boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <CardContent sx={{ p: 2.5, flexGrow: 1 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#1e293b', fontSize: '0.9rem' }}>
                Work Order Distribution
              </Typography>
              <Typography variant="caption" sx={{ color: '#64748b', fontWeight: 600 }}>
                Total: {work_orders.total_work_orders}
              </Typography>
            </Box>

            {/* Status Breakdown */}
            <Typography variant="caption" sx={{ color: '#475569', fontWeight: 600, mb: 1, display: 'block' }}>
              Execution Status
            </Typography>
            <Box sx={{ display: 'flex', gap: 1, mb: 2, flexWrap: 'wrap' }}>
              <Chip
                label={`Completed: ${work_orders.status_counts['completed'] || 0}`}
                size="small"
                sx={{ bgcolor: '#ecfdf5', color: '#047857', fontWeight: 600, fontSize: '0.75rem' }}
              />
              <Chip
                label={`In Progress: ${work_orders.status_counts['in_progress'] || 0}`}
                size="small"
                sx={{ bgcolor: '#eff6ff', color: '#1d4ed8', fontWeight: 600, fontSize: '0.75rem' }}
              />
              <Chip
                label={`Scheduled: ${work_orders.status_counts['scheduled'] || 0}`}
                size="small"
                sx={{ bgcolor: '#fffbeb', color: '#b45309', fontWeight: 600, fontSize: '0.75rem' }}
              />
            </Box>

            {/* Work Types */}
            <Typography variant="caption" sx={{ color: '#475569', fontWeight: 600, mb: 1, display: 'block' }}>
              Classification by Type
            </Typography>
            <Box sx={{ mb: 2 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                <Typography variant="caption" sx={{ color: '#64748b' }}>
                  Corrective Repairs: {work_orders.type_counts['corrective'] || 0}
                </Typography>
                <Typography variant="caption" sx={{ color: '#334155', fontWeight: 600 }}>
                  {Math.round(((work_orders.type_counts['corrective'] || 0) / work_orders.total_work_orders) * 100)}%
                </Typography>
              </Box>
              <LinearProgress
                variant="determinate"
                value={((work_orders.type_counts['corrective'] || 0) / work_orders.total_work_orders) * 100}
                sx={{ height: 6, borderRadius: 3, bgcolor: '#f1f5f9', '& .MuiLinearProgress-bar': { bgcolor: '#0284c7' } }}
              />

              <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1, mb: 0.5 }}>
                <Typography variant="caption" sx={{ color: '#64748b' }}>
                  Preventive Maintenance: {work_orders.type_counts['preventive'] || 0}
                </Typography>
                <Typography variant="caption" sx={{ color: '#334155', fontWeight: 600 }}>
                  {Math.round(((work_orders.type_counts['preventive'] || 0) / work_orders.total_work_orders) * 100)}%
                </Typography>
              </Box>
              <LinearProgress
                variant="determinate"
                value={((work_orders.type_counts['preventive'] || 0) / work_orders.total_work_orders) * 100}
                sx={{ height: 6, borderRadius: 3, bgcolor: '#f1f5f9', '& .MuiLinearProgress-bar': { bgcolor: '#10b981' } }}
              />

              <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1, mb: 0.5 }}>
                <Typography variant="caption" sx={{ color: '#64748b' }}>
                  Emergency Work Orders: {work_orders.type_counts['emergency'] || 0}
                </Typography>
                <Typography variant="caption" sx={{ color: '#334155', fontWeight: 600 }}>
                  {Math.round(((work_orders.type_counts['emergency'] || 0) / work_orders.total_work_orders) * 100)}%
                </Typography>
              </Box>
              <LinearProgress
                variant="determinate"
                value={((work_orders.type_counts['emergency'] || 0) / work_orders.total_work_orders) * 100}
                sx={{ height: 6, borderRadius: 3, bgcolor: '#f1f5f9', '& .MuiLinearProgress-bar': { bgcolor: '#e11d48' } }}
              />
            </Box>

            {/* Priority breakdown chips */}
            <Typography variant="caption" sx={{ color: '#475569', fontWeight: 600, mb: 0.75, display: 'block' }}>
              Priority Distribution
            </Typography>
            <Box sx={{ display: 'flex', gap: 0.75, flexWrap: 'wrap' }}>
              <Chip
                label={`Critical: ${work_orders.priority_counts['critical'] || 0}`}
                size="small"
                variant="outlined"
                sx={{ borderColor: '#fca5a5', color: '#b91c1c', fontSize: '0.7rem', height: 20 }}
              />
              <Chip
                label={`High: ${work_orders.priority_counts['high'] || 0}`}
                size="small"
                variant="outlined"
                sx={{ borderColor: '#fdba74', color: '#c2410c', fontSize: '0.7rem', height: 20 }}
              />
              <Chip
                label={`Medium: ${work_orders.priority_counts['medium'] || 0}`}
                size="small"
                variant="outlined"
                sx={{ borderColor: '#cbd5e1', color: '#475569', fontSize: '0.7rem', height: 20 }}
              />
              <Chip
                label={`Low: ${work_orders.priority_counts['low'] || 0}`}
                size="small"
                variant="outlined"
                sx={{ borderColor: '#cbd5e1', color: '#64748b', fontSize: '0.7rem', height: 20 }}
              />
            </Box>
          </CardContent>
        </Card>

        {/* Panel C: Outage & Failure Highlights */}
        <Card
          sx={{
            bgcolor: '#ffffff',
            borderRadius: 2,
            border: '1px solid #e2e8f0',
            boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.04)',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <CardContent sx={{ p: 2.5, flexGrow: 1 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#1e293b', fontSize: '0.9rem' }}>
                Failure & Outage Summary
              </Typography>
              <Chip
                label={`${outages.total_outages} Outages Recorded`}
                size="small"
                sx={{ bgcolor: '#fffbeb', color: '#b45309', fontWeight: 600, fontSize: '0.7rem', height: 22 }}
              />
            </Box>

            {/* Outage totals */}
            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: 'repeat(3, 1fr)',
                gap: 1,
                mb: 2,
                bgcolor: '#f8fafc',
                p: 1.5,
                borderRadius: 1.5,
              }}
            >
              <Box>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.7rem', display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <TimeIcon sx={{ fontSize: 13 }} /> Downtime
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 700, color: '#0f172a' }}>
                  {outages.total_duration_hours.toLocaleString()} hrs
                </Typography>
              </Box>
              <Box>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.7rem', display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <PowerIcon sx={{ fontSize: 13 }} /> Gen. Loss
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 700, color: '#0f172a' }}>
                  {(outages.total_loss_mwh / 1000).toFixed(1)} GWh
                </Typography>
              </Box>
              <Box>
                <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.7rem', display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  <CostIcon sx={{ fontSize: 13 }} /> Est. Cost
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 700, color: '#b91c1c' }}>
                  ${(outages.total_estimated_cost / 1000000).toFixed(2)}M
                </Typography>
              </Box>
            </Box>

            {/* Recorded Failures List */}
            <Typography variant="caption" sx={{ color: '#475569', fontWeight: 600, mb: 1, display: 'block' }}>
              Recorded Failure Events ({failures.length})
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              {failures.map((f) => (
                <Box
                  key={f.failure_id}
                  onClick={() => navigate('/graph')}
                  sx={{
                    p: 1,
                    borderRadius: 1.5,
                    border: '1px solid #f1f5f9',
                    bgcolor: '#ffffff',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease',
                    '&:hover': {
                      borderColor: '#cbd5e1',
                      bgcolor: '#f8fafc',
                    },
                  }}
                >
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 0.25 }}>
                    <Typography variant="caption" sx={{ fontWeight: 700, color: '#0f172a' }}>
                      {f.failure_id}: {f.failure_mode}
                    </Typography>
                    <Chip
                      label={f.severity.toUpperCase()}
                      size="small"
                      sx={{
                        height: 18,
                        fontSize: '0.65rem',
                        fontWeight: 700,
                        bgcolor: f.severity === 'high' ? '#fee2e2' : '#fef3c7',
                        color: f.severity === 'high' ? '#b91c1c' : '#92400e',
                      }}
                    />
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography variant="caption" sx={{ color: '#64748b', fontSize: '0.7rem' }}>
                      {f.asset_name} ({f.asset_id}) • {f.downtime_hours}h downtime
                    </Typography>
                    {f.actual_cost && (
                      <Typography variant="caption" sx={{ color: '#0f172a', fontWeight: 600, fontSize: '0.7rem' }}>
                        ${f.actual_cost.toLocaleString()}
                      </Typography>
                    )}
                  </Box>
                </Box>
              ))}
            </Box>
          </CardContent>
        </Card>
      </Box>
    </Box>
  );
};
