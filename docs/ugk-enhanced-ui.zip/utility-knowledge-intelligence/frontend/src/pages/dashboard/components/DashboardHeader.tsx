import React from 'react';
import {
  Box,
  Typography,
  Button,
  Chip,
  CircularProgress,
  Tooltip,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  CheckCircle as CheckCircleIcon,
  Storage as StorageIcon,
  Psychology as PsychologyIcon,
} from '@mui/icons-material';
import { format } from 'date-fns';

interface DashboardHeaderProps {
  lastUpdated: Date | null;
  isRefreshing: boolean;
  onRefresh: () => void;
  neo4jStatus?: string;
  groqStatus?: string;
}

export const DashboardHeader: React.FC<DashboardHeaderProps> = ({
  lastUpdated,
  isRefreshing,
  onRefresh,
  neo4jStatus = 'connected',
  groqStatus = 'configured',
}) => {
  const formattedDate = lastUpdated
    ? format(lastUpdated, 'MMM d, yyyy h:mm:ss a')
    : 'Updating...';

  return (
    <Box
      sx={{
        mb: 3,
        display: 'flex',
        flexDirection: { xs: 'column', md: 'row' },
        justifyContent: 'space-between',
        alignItems: { xs: 'flex-start', md: 'center' },
        gap: 2,
        pb: 2,
        borderBottom: '1px solid #e2e8f0',
      }}
    >
      <Box>
        <Typography
          variant="h4"
          component="h1"
          sx={{
            fontWeight: 700,
            color: '#0f172a',
            letterSpacing: '-0.02em',
            fontSize: { xs: '1.5rem', sm: '1.875rem' },
          }}
        >
          Utility Intelligence Dashboard
        </Typography>
        <Typography
          variant="body1"
          sx={{
            color: '#64748b',
            mt: 0.5,
            fontSize: '0.95rem',
          }}
        >
          Fleet-wide operational intelligence, asset reliability, maintenance performance, and evidence-backed insights.
        </Typography>
      </Box>

      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: 1.5,
        }}
      >
        {/* System Source Indicators */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Tooltip title={`Neo4j Knowledge Graph: ${neo4jStatus}`}>
            <Chip
              icon={<StorageIcon sx={{ fontSize: '16px !important' }} />}
              label={`Neo4j: ${neo4jStatus === 'connected' ? 'Connected' : 'Offline'}`}
              size="small"
              sx={{
                bgcolor: neo4jStatus === 'connected' ? '#ecfdf5' : '#fef2f2',
                color: neo4jStatus === 'connected' ? '#047857' : '#b91c1c',
                fontWeight: 600,
                fontSize: '0.75rem',
                border: '1px solid',
                borderColor: neo4jStatus === 'connected' ? '#a7f3d0' : '#fecaca',
              }}
            />
          </Tooltip>

          <Tooltip title={`Groq LLM Engine: ${groqStatus}`}>
            <Chip
              icon={<PsychologyIcon sx={{ fontSize: '16px !important' }} />}
              label={`GraphRAG: ${groqStatus === 'configured' ? 'Ready' : 'Not Ready'}`}
              size="small"
              sx={{
                bgcolor: groqStatus === 'configured' ? '#f0fdfa' : '#fffbeb',
                color: groqStatus === 'configured' ? '#0f766e' : '#b45309',
                fontWeight: 600,
                fontSize: '0.75rem',
                border: '1px solid',
                borderColor: groqStatus === 'configured' ? '#99f6e4' : '#fde68a',
              }}
            />
          </Tooltip>
        </Box>

        {/* Timestamp */}
        <Typography
          variant="caption"
          sx={{
            color: '#64748b',
            display: 'inline-flex',
            alignItems: 'center',
            gap: 0.5,
            fontSize: '0.8rem',
            whiteSpace: 'nowrap',
          }}
        >
          <CheckCircleIcon sx={{ fontSize: 14, color: '#10b981' }} />
          Updated: {formattedDate}
        </Typography>

        {/* Refresh Button */}
        <Button
          variant="outlined"
          size="small"
          onClick={onRefresh}
          disabled={isRefreshing}
          startIcon={
            isRefreshing ? (
              <CircularProgress size={14} color="inherit" />
            ) : (
              <RefreshIcon sx={{ fontSize: 16 }} />
            )
          }
          sx={{
            borderColor: '#cbd5e1',
            color: '#334155',
            bgcolor: '#ffffff',
            textTransform: 'none',
            fontWeight: 600,
            fontSize: '0.8125rem',
            px: 1.5,
            py: 0.5,
            borderRadius: 1.5,
            '&:hover': {
              borderColor: '#0f766e',
              bgcolor: '#f8fafc',
              color: '#0f766e',
            },
          }}
        >
          {isRefreshing ? 'Refreshing...' : 'Refresh'}
        </Button>
      </Box>
    </Box>
  );
};
