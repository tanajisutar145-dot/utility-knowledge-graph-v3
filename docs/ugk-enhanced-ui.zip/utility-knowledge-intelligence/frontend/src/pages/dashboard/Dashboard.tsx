import React from 'react';
import {
  Box,
  CircularProgress,
  Typography,
  Button,
  Card,
  CardContent,
  Alert,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  Warning as WarningIcon,
} from '@mui/icons-material';

import { useDashboard } from '../../hooks/useDashboard';
import { useHealth } from '../../hooks/useHealth';
import { DashboardHeader } from './components/DashboardHeader';
import { ExecutiveKPICards } from './components/ExecutiveKPICards';
import { OperationalIntelligence } from './components/OperationalIntelligence';
import { PerformanceIntelligence } from './components/PerformanceIntelligence';
import { KnowledgeIntelligence } from './components/KnowledgeIntelligence';
import { AIIntelligenceSummary } from './components/AIIntelligenceSummary';

const Dashboard: React.FC = () => {
  const { data, loading, isRefreshing, error, lastUpdated, refresh } = useDashboard();
  const { health } = useHealth();

  if (loading && !data) {
    return (
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          minHeight: '60vh',
          gap: 2,
        }}
      >
        <CircularProgress size={42} sx={{ color: '#0f766e' }} />
        <Typography variant="body2" sx={{ color: '#64748b', fontWeight: 500 }}>
          Loading Utility Knowledge Intelligence metrics...
        </Typography>
      </Box>
    );
  }

  if (error && !data) {
    return (
      <Box sx={{ maxWidth: 640, mx: 'auto', mt: 6 }}>
        <Card
          sx={{
            bgcolor: '#ffffff',
            borderRadius: 2,
            border: '1px solid #fee2e2',
            boxShadow: '0 4px 12px rgba(239, 68, 68, 0.08)',
          }}
        >
          <CardContent sx={{ p: 4, textAlign: 'center' }}>
            <Box
              sx={{
                width: 48,
                height: 48,
                borderRadius: '50%',
                bgcolor: '#fef2f2',
                color: '#ef4444',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                mx: 'auto',
                mb: 2,
              }}
            >
              <WarningIcon sx={{ fontSize: 26 }} />
            </Box>
            <Typography variant="h6" sx={{ fontWeight: 700, color: '#0f172a', mb: 1 }}>
              Dashboard Metrics Unavailable
            </Typography>
            <Typography variant="body2" sx={{ color: '#64748b', mb: 3 }}>
              {error.message || 'Unable to retrieve live telemetry from the backend service.'}
            </Typography>
            <Button
              variant="contained"
              onClick={refresh}
              startIcon={<RefreshIcon />}
              sx={{
                bgcolor: '#0f766e',
                color: '#ffffff',
                textTransform: 'none',
                fontWeight: 600,
                px: 3,
                py: 1,
                borderRadius: 1.5,
                '&:hover': {
                  bgcolor: '#115e59',
                },
              }}
            >
              Retry Connection
            </Button>
          </CardContent>
        </Card>
      </Box>
    );
  }

  if (!data) {
    return null;
  }

  const neo4jStatus = health?.neo4j || 'connected';
  const groqStatus = health?.groq || 'configured';

  return (
    <Box
      sx={{
        width: '100%',
        maxWidth: 1600,
        mx: 'auto',
        pb: 4,
      }}
    >
      {/* Dashboard Top Header */}
      <DashboardHeader
        lastUpdated={lastUpdated}
        isRefreshing={isRefreshing}
        onRefresh={refresh}
        neo4jStatus={neo4jStatus}
        groqStatus={groqStatus}
      />

      {/* Any background error banner during background refresh */}
      {error && (
        <Alert
          severity="warning"
          sx={{ mb: 2.5, borderRadius: 1.5 }}
          action={
            <Button color="inherit" size="small" onClick={refresh}>
              Retry
            </Button>
          }
        >
          {error.message}
        </Alert>
      )}

      {/* 1. Executive Fleet KPIs */}
      <ExecutiveKPICards kpis={data.kpis} />

      {/* 2. Operational Intelligence */}
      <OperationalIntelligence operations={data.operations} />

      {/* 3. Performance & Maintenance Intelligence */}
      <PerformanceIntelligence
        performance={data.performance}
        maintenance={data.maintenance}
        inspections={data.operations.inspections}
      />

      {/* 4. Knowledge Graph & Document Intelligence */}
      <KnowledgeIntelligence graph={data.graph} documents={data.documents} />

      {/* 5. AI GraphRAG Intelligence Summary */}
      <AIIntelligenceSummary />
    </Box>
  );
};

export default Dashboard;