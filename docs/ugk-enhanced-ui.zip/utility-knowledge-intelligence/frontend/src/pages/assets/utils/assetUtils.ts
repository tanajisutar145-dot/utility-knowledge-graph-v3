/**
 * Utility helpers for Asset Management styling and formatting
 */

export const getCriticalityColor = (
  criticality?: string | null
): { bg: string; text: string; border: string; label: string } => {
  switch (criticality?.toLowerCase()) {
    case 'critical':
      return { bg: '#fee2e2', text: '#dc2626', border: '#fecaca', label: 'Critical' };
    case 'high':
      return { bg: '#ffedd5', text: '#ea580c', border: '#fed7aa', label: 'High' };
    case 'medium':
      return { bg: '#fef3c7', text: '#d97706', border: '#fde68a', label: 'Medium' };
    case 'low':
      return { bg: '#f1f5f9', text: '#475569', border: '#cbd5e1', label: 'Low' };
    default:
      return { bg: '#f1f5f9', text: '#64748b', border: '#e2e8f0', label: criticality || 'Unknown' };
  }
};

export const getStatusColor = (
  status?: string | null
): { bg: string; text: string; border: string; label: string } => {
  switch (status?.toLowerCase()) {
    case 'operational':
      return { bg: '#f0fdf4', text: '#16a34a', border: '#bbf7d0', label: 'Operational' };
    case 'maintenance':
      return { bg: '#fffbeb', text: '#d97706', border: '#fde68a', label: 'Maintenance' };
    case 'outage':
      return { bg: '#fef2f2', text: '#dc2626', border: '#fecaca', label: 'Outage' };
    case 'retired':
      return { bg: '#f1f5f9', text: '#64748b', border: '#cbd5e1', label: 'Retired' };
    default:
      return { bg: '#f8fafc', text: '#475569', border: '#e2e8f0', label: status || 'Unknown' };
  }
};

export const getAssetClassLabel = (assetClass?: string | null): string => {
  if (!assetClass) return 'General Asset';
  return assetClass
    .split('_')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
};

export const formatDate = (dateStr?: string | null): string => {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(dateStr);
    return isNaN(d.getTime()) ? dateStr : d.toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return dateStr;
  }
};

export const formatCurrency = (val?: number | null): string => {
  if (val === undefined || val === null) return 'N/A';
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(val);
};
