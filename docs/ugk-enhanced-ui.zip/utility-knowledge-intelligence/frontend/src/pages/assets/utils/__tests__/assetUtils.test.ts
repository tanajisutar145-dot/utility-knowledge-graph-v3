import {
  getCriticalityColor,
  getStatusColor,
  getAssetClassLabel,
  formatDate,
  formatCurrency,
} from '../assetUtils';

describe('Asset Utilities', () => {
  test('returns correct styles for criticality levels', () => {
    const crit = getCriticalityColor('critical');
    expect(crit.label).toBe('Critical');
    expect(crit.text).toBe('#dc2626');

    const high = getCriticalityColor('high');
    expect(high.label).toBe('High');
    expect(high.text).toBe('#ea580c');

    const med = getCriticalityColor('medium');
    expect(med.label).toBe('Medium');
    expect(med.text).toBe('#d97706');

    const low = getCriticalityColor('low');
    expect(low.label).toBe('Low');

    const unk = getCriticalityColor(null);
    expect(unk.label).toBe('Unknown');
  });

  test('returns correct styles for operational statuses', () => {
    const op = getStatusColor('operational');
    expect(op.label).toBe('Operational');
    expect(op.text).toBe('#16a34a');

    const maint = getStatusColor('maintenance');
    expect(maint.label).toBe('Maintenance');

    const outage = getStatusColor('outage');
    expect(outage.label).toBe('Outage');
  });

  test('converts equipment class to human readable title', () => {
    expect(getAssetClassLabel('gas_turbine')).toBe('Gas Turbine');
    expect(getAssetClassLabel('control_system')).toBe('Control System');
    expect(getAssetClassLabel(null)).toBe('General Asset');
  });

  test('formats dates and currency safely', () => {
    expect(formatDate(null)).toBe('N/A');
    expect(formatDate('2026-06-15')).toContain('2026');

    expect(formatCurrency(null)).toBe('N/A');
    expect(formatCurrency(50000)).toContain('50,000');
  });
});
