import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { MemoryRouter } from 'react-router-dom';
import { AssetsHeader } from '../components/AssetsHeader';
import { AssetStatistics } from '../components/AssetStatistics';
import { AssetFiltersBar } from '../components/AssetFiltersBar';
import { AssetTable } from '../components/AssetTable';
import { AssetDetailModal } from '../components/AssetDetailModal';
import { AssetSummaryItem, AssetDetailResponse, AssetOverviewResponse } from '../../../types/assets';

const mockOverview: AssetOverviewResponse = {
  total_assets: 57,
  operational_assets: 57,
  assets_with_failures: 2,
  criticality_counts: { critical: 20, high: 23, medium: 14 },
  asset_class_counts: { gas_turbine: 5, generator: 13 },
  status_counts: { operational: 57 },
};

const mockAssets: AssetSummaryItem[] = [
  {
    asset_id: 'AST-001',
    name: 'Unit 1 GT Gas Turbine',
    asset_class: 'gas_turbine',
    criticality: 'critical',
    operational_status: 'operational',
    manufacturer: 'Mitsubishi',
    model: 'M501F',
    installation_date: '2010-06-15',
    asset_tag: 'UNT-001-GAS_TURBINE-001',
    unit_id: 'UNT-001',
    unit_name: 'Unit 1 GT',
    plant_id: 'PLANT-001',
    plant_name: 'Riverside Combined Cycle Plant',
    component_count: 3,
    inspection_count: 2,
    failure_count: 1,
    work_order_count: 3,
    document_count: 3,
  },
];

const mockDetail: AssetDetailResponse = {
  asset: mockAssets[0],
  hierarchy: {
    power_plant: {
      plant_id: 'PLANT-001',
      name: 'Riverside Combined Cycle Plant',
      location: 'Riverside County',
      plant_type: 'combined_cycle',
      capacity_mw: 550.0,
    },
    generating_unit: {
      unit_id: 'UNT-001',
      unit_name: 'Unit 1 GT',
      unit_type: 'gas_turbine',
      capacity_mw: 180.0,
      status: 'operational',
    },
  },
  components: [
    {
      component_id: 'COMP-001',
      component_name: 'Compressor Rotor Assembly',
      component_type: 'rotor',
      status: 'operational',
    },
  ],
  inspections: [
    {
      inspection_id: 'INS-001',
      inspection_date: '2026-08-08',
      inspection_type: 'routine',
      inspector: 'Field Inspector',
      condition: 'fair',
      findings: 'Elevated vibration signatures detected.',
      severity: 'medium',
    },
  ],
  work_orders: [
    {
      work_order_id: 'WO-001',
      created_date: '2026-08-10',
      work_type: 'corrective',
      priority: 'high',
      status: 'completed',
      description: 'Emergency compressor section inspection.',
      total_cost: 15000,
    },
  ],
  maintenance_plans: [
    {
      maintenance_plan_id: 'MP-001',
      plan_name: 'Annual Turbine Inspection',
      maintenance_type: 'preventive',
      frequency: 'annually',
      status: 'active',
    },
  ],
  failures: [
    {
      failure_id: 'FAIL-001',
      failure_date: '2026-08-15',
      failure_mode: 'Blade Liberation',
      severity: 'critical',
      description: 'Foreign object damage in compressor stage 3.',
      root_cause: 'Fatigue crack',
      downtime_hours: 48.0,
      estimated_cost: 250000,
      status: 'resolved',
    },
  ],
  outages: [
    {
      outage_id: 'OUT-001',
      outage_type: 'forced',
      start_date: '2026-08-15',
      duration_hours: 48.0,
      cause: 'Blade Liberation',
      status: 'completed',
    },
  ],
  documents: [
    {
      document_id: 'DOC-001',
      title: 'Routine GT Inspection - Unit 1 GT Gas Turbine',
      document_type: 'inspection_report',
      source: 'Field Inspector',
      created_date: '2026-08-08',
    },
  ],
};

describe('Asset Management Components', () => {
  test('AssetsHeader renders title and operational counts', () => {
    const html = renderToStaticMarkup(
      <AssetsHeader
        totalAssets={57}
        operationalAssets={57}
        isLoading={false}
        onRefresh={jest.fn()}
      />
    );

    expect(html).toContain('Asset Intelligence');
    expect(html).toContain('57 Assets • 57 Operational');
    expect(html).toContain('Refresh');
  });

  test('AssetStatistics renders inventory metrics', () => {
    const html = renderToStaticMarkup(
      <AssetStatistics overview={mockOverview} isLoading={false} />
    );

    expect(html).toContain('Total Asset Inventory');
    expect(html).toContain('57');
    expect(html).toContain('2');
    expect(html).toContain('20 Critical');
  });

  test('AssetFiltersBar renders filter controls', () => {
    const html = renderToStaticMarkup(
      <AssetFiltersBar
        search="M501F"
        assetClass="gas_turbine"
        criticality="critical"
        operationalStatus="operational"
        onSearchChange={jest.fn()}
        onAssetClassChange={jest.fn()}
        onCriticalityChange={jest.fn()}
        onOperationalStatusChange={jest.fn()}
        onClearFilters={jest.fn()}
      />
    );

    expect(html).toContain('M501F');
    expect(html).toContain('Clear Filters');
  });

  test('AssetTable renders equipment rows and metadata badges', () => {
    const html = renderToStaticMarkup(
      <AssetTable
        assets={mockAssets}
        total={1}
        page={0}
        rowsPerPage={10}
        isLoading={false}
        onPageChange={jest.fn()}
        onRowsPerPageChange={jest.fn()}
        onSelectAsset={jest.fn()}
      />
    );

    expect(html).toContain('AST-001');
    expect(html).toContain('Unit 1 GT Gas Turbine');
    expect(html).toContain('Gas Turbine');
    expect(html).toContain('Critical');
  });

  test('AssetDetailModal renders hierarchy, components, and historical records', () => {
    const html = renderToStaticMarkup(
      <MemoryRouter>
        <AssetDetailModal
          open={true}
          assetDetail={mockDetail}
          isLoading={false}
          onClose={jest.fn()}
        />
      </MemoryRouter>
    );

    expect(html).toContain('Unit 1 GT Gas Turbine');
    expect(html).toContain('Riverside Combined Cycle Plant');
    expect(html).toContain('Unit 1 GT');
    expect(html).toContain('Components (1)');
    expect(html).toContain('Inspections (1)');
    expect(html).toContain('Historical Failures (1)');
    expect(html).toContain('Technical Documents (1)');
  });
});
