import React, { useState, useEffect, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import { Box, Alert, Button } from '@mui/material';
import { Refresh as RefreshIcon } from '@mui/icons-material';

import {
  AssetOverviewResponse,
  AssetSummaryItem,
  AssetDetailResponse,
} from '../../types/assets';
import {
  getAssetsOverview,
  listAssets,
  getAssetDetail,
} from '../../services/api';

import { AssetsHeader } from './components/AssetsHeader';
import { AssetStatistics } from './components/AssetStatistics';
import { AssetFiltersBar } from './components/AssetFiltersBar';
import { AssetTable } from './components/AssetTable';
import { AssetDetailModal } from './components/AssetDetailModal';

const AssetsPage: React.FC = () => {
  const location = useLocation();

  // Overview metrics
  const [overview, setOverview] = useState<AssetOverviewResponse | null>(null);
  const [isLoadingOverview, setIsLoadingOverview] = useState<boolean>(true);

  // Assets listing
  const [assets, setAssets] = useState<AssetSummaryItem[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [isLoadingList, setIsLoadingList] = useState<boolean>(true);
  const [listError, setListError] = useState<string | null>(null);

  // Filters & Pagination
  const [search, setSearch] = useState<string>('');
  const [assetClass, setAssetClass] = useState<string>('');
  const [criticality, setCriticality] = useState<string>('');
  const [operationalStatus, setOperationalStatus] = useState<string>('');
  const [page, setPage] = useState<number>(0);
  const [rowsPerPage, setRowsPerPage] = useState<number>(10);

  // Detail Modal
  const [assetDetail, setAssetDetail] = useState<AssetDetailResponse | null>(null);
  const [isLoadingDetail, setIsLoadingDetail] = useState<boolean>(false);
  const [detailModalOpen, setDetailModalOpen] = useState<boolean>(false);

  // Initialize filters from query parameters
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const searchParam = params.get('search') || params.get('q');
    const classParam = params.get('asset_class') || params.get('class');
    const critParam = params.get('criticality');
    const statusParam = params.get('status') || params.get('operational_status');
    if (searchParam) setSearch(searchParam);
    if (classParam) setAssetClass(classParam);
    if (critParam) setCriticality(critParam);
    if (statusParam) setOperationalStatus(statusParam);
  }, [location.search]);

  // Fetch overview statistics
  const fetchOverview = useCallback(async () => {
    try {
      setIsLoadingOverview(true);
      const data = await getAssetsOverview();
      setOverview(data);
    } catch (err: any) {
      console.error('Failed to fetch asset overview:', err);
    } finally {
      setIsLoadingOverview(false);
    }
  }, []);

  // Fetch assets list
  const fetchAssets = useCallback(async () => {
    try {
      setIsLoadingList(true);
      setListError(null);
      const data = await listAssets({
        search: search.trim() || undefined,
        asset_class: assetClass || undefined,
        criticality: criticality || undefined,
        operational_status: operationalStatus || undefined,
        skip: page * rowsPerPage,
        limit: rowsPerPage,
      });
      setAssets(data.assets);
      setTotal(data.total);
    } catch (err: any) {
      console.error('Failed to list assets:', err);
      const msg = err?.response?.data?.detail || err?.message || 'Failed to retrieve assets from Neo4j.';
      setListError(msg);
    } finally {
      setIsLoadingList(false);
    }
  }, [search, assetClass, criticality, operationalStatus, page, rowsPerPage]);

  useEffect(() => {
    fetchOverview();
  }, [fetchOverview]);

  useEffect(() => {
    fetchAssets();
  }, [fetchAssets]);

  // Open detail modal and fetch data
  const handleSelectAsset = async (assetId: string) => {
    setDetailModalOpen(true);
    setIsLoadingDetail(true);
    try {
      const data = await getAssetDetail(assetId);
      setAssetDetail(data);
    } catch (err: any) {
      console.error('Failed to fetch asset details:', err);
    } finally {
      setIsLoadingDetail(false);
    }
  };

  const handleCloseDetailModal = () => {
    setDetailModalOpen(false);
    setAssetDetail(null);
  };

  const handleClearFilters = () => {
    setSearch('');
    setAssetClass('');
    setCriticality('');
    setOperationalStatus('');
    setPage(0);
  };

  const handleRefreshAll = () => {
    fetchOverview();
    fetchAssets();
  };

  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto', p: { xs: 2, md: 3 } }}>
      <AssetsHeader
        totalAssets={overview?.total_assets ?? 0}
        operationalAssets={overview?.operational_assets ?? 0}
        isLoading={isLoadingOverview || isLoadingList}
        onRefresh={handleRefreshAll}
      />

      <AssetStatistics
        overview={overview}
        isLoading={isLoadingOverview}
      />

      <AssetFiltersBar
        search={search}
        assetClass={assetClass}
        criticality={criticality}
        operationalStatus={operationalStatus}
        onSearchChange={(val) => {
          setSearch(val);
          setPage(0);
        }}
        onAssetClassChange={(val) => {
          setAssetClass(val);
          setPage(0);
        }}
        onCriticalityChange={(val) => {
          setCriticality(val);
          setPage(0);
        }}
        onOperationalStatusChange={(val) => {
          setOperationalStatus(val);
          setPage(0);
        }}
        onClearFilters={handleClearFilters}
      />

      {listError && (
        <Alert
          severity="error"
          sx={{ mb: 2 }}
          action={
            <Button color="inherit" size="small" onClick={fetchAssets} startIcon={<RefreshIcon />}>
              Retry
            </Button>
          }
        >
          {listError}
        </Alert>
      )}

      <AssetTable
        assets={assets}
        total={total}
        page={page}
        rowsPerPage={rowsPerPage}
        isLoading={isLoadingList}
        onPageChange={(newPage) => setPage(newPage)}
        onRowsPerPageChange={(newRows) => {
          setRowsPerPage(newRows);
          setPage(0);
        }}
        onSelectAsset={handleSelectAsset}
      />

      <AssetDetailModal
        open={detailModalOpen}
        assetDetail={assetDetail}
        isLoading={isLoadingDetail}
        onClose={handleCloseDetailModal}
      />
    </Box>
  );
};

export default AssetsPage;