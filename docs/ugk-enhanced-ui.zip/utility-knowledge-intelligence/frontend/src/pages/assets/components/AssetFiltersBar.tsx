import React from 'react';
import {
  Box,
  TextField,
  MenuItem,
  Button,
  InputAdornment,
} from '@mui/material';
import {
  Search as SearchIcon,
  Clear as ClearIcon,
} from '@mui/icons-material';

interface AssetFiltersBarProps {
  search: string;
  assetClass: string;
  criticality: string;
  operationalStatus: string;
  onSearchChange: (val: string) => void;
  onAssetClassChange: (val: string) => void;
  onCriticalityChange: (val: string) => void;
  onOperationalStatusChange: (val: string) => void;
  onClearFilters: () => void;
}

const ASSET_CLASSES = [
  { value: '', label: 'All Asset Classes' },
  { value: 'gas_turbine', label: 'Gas Turbine' },
  { value: 'steam_turbine', label: 'Steam Turbine' },
  { value: 'generator', label: 'Generator' },
  { value: 'compressor', label: 'Compressor' },
  { value: 'boiler', label: 'Boiler' },
  { value: 'pump', label: 'Pump' },
  { value: 'transformer', label: 'Transformer' },
  { value: 'cooling_system', label: 'Cooling System' },
  { value: 'control_system', label: 'Control System' },
];

const CRITICALITIES = [
  { value: '', label: 'All Criticalities' },
  { value: 'critical', label: 'Critical' },
  { value: 'high', label: 'High' },
  { value: 'medium', label: 'Medium' },
  { value: 'low', label: 'Low' },
];

const STATUSES = [
  { value: '', label: 'All Statuses' },
  { value: 'operational', label: 'Operational' },
  { value: 'maintenance', label: 'Maintenance' },
  { value: 'outage', label: 'Outage' },
];

export const AssetFiltersBar: React.FC<AssetFiltersBarProps> = ({
  search,
  assetClass,
  criticality,
  operationalStatus,
  onSearchChange,
  onAssetClassChange,
  onCriticalityChange,
  onOperationalStatusChange,
  onClearFilters,
}) => {
  const hasActiveFilters = Boolean(search || assetClass || criticality || operationalStatus);

  return (
    <Box
      display="flex"
      gap={2}
      mb={2.5}
      flexWrap="wrap"
      alignItems="center"
      bgcolor="#ffffff"
      p={2}
      borderRadius={2}
      border="1px solid #e2e8f0"
    >
      <TextField
        placeholder="Search assets by name, ID, model, or manufacturer..."
        value={search}
        onChange={(e) => onSearchChange(e.target.value)}
        size="small"
        sx={{ flex: { xs: '1 1 100%', sm: '1 1 240px' } }}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon sx={{ color: '#94a3b8' }} />
            </InputAdornment>
          ),
        }}
      />

      <TextField
        select
        label="Asset Class"
        value={assetClass}
        onChange={(e) => onAssetClassChange(e.target.value)}
        size="small"
        sx={{ minWidth: 170, flex: { xs: '1 1 100%', sm: '0 0 180px' } }}
      >
        {ASSET_CLASSES.map((opt) => (
          <MenuItem key={opt.value} value={opt.value}>
            {opt.label}
          </MenuItem>
        ))}
      </TextField>

      <TextField
        select
        label="Criticality"
        value={criticality}
        onChange={(e) => onCriticalityChange(e.target.value)}
        size="small"
        sx={{ minWidth: 150, flex: { xs: '1 1 100%', sm: '0 0 160px' } }}
      >
        {CRITICALITIES.map((opt) => (
          <MenuItem key={opt.value} value={opt.value}>
            {opt.label}
          </MenuItem>
        ))}
      </TextField>

      <TextField
        select
        label="Operational Status"
        value={operationalStatus}
        onChange={(e) => onOperationalStatusChange(e.target.value)}
        size="small"
        sx={{ minWidth: 150, flex: { xs: '1 1 100%', sm: '0 0 160px' } }}
      >
        {STATUSES.map((opt) => (
          <MenuItem key={opt.value} value={opt.value}>
            {opt.label}
          </MenuItem>
        ))}
      </TextField>

      {hasActiveFilters && (
        <Button
          variant="text"
          startIcon={<ClearIcon />}
          onClick={onClearFilters}
          size="small"
          sx={{
            color: '#64748b',
            textTransform: 'none',
            fontWeight: 600,
            '&:hover': { color: '#0f172a' },
          }}
        >
          Clear Filters
        </Button>
      )}
    </Box>
  );
};
