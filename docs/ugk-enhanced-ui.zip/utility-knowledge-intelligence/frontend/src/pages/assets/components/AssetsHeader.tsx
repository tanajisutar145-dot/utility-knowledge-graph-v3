import React from 'react';
import { Box, Typography, Button, Chip } from '@mui/material';
import {
  Settings as AssetIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';

interface AssetsHeaderProps {
  totalAssets: number;
  operationalAssets: number;
  isLoading: boolean;
  onRefresh: () => void;
}

export const AssetsHeader: React.FC<AssetsHeaderProps> = ({
  totalAssets,
  operationalAssets,
  isLoading,
  onRefresh,
}) => {
  return (
    <Box
      display="flex"
      justifyContent="space-between"
      alignItems={{ xs: 'flex-start', sm: 'center' }}
      flexDirection={{ xs: 'column', sm: 'row' }}
      gap={2}
      mb={3}
    >
      <Box>
        <Box display="flex" alignItems="center" gap={1.5} flexWrap="wrap">
          <AssetIcon sx={{ color: '#1976d2', fontSize: 32 }} />
          <Typography variant="h4" fontWeight={700} color="#0f172a">
            Asset Intelligence
          </Typography>
          <Chip
            label={`${totalAssets} Assets • ${operationalAssets} Operational`}
            size="small"
            sx={{
              backgroundColor: '#eff6ff',
              color: '#1d4ed8',
              fontWeight: 600,
              border: '1px solid #bfdbfe',
            }}
          />
        </Box>
        <Typography variant="body2" color="text.secondary" mt={0.5}>
          Monitor utility generation assets, component hierarchies, inspection histories, work orders, and failure events.
        </Typography>
      </Box>

      <Box display="flex" alignItems="center" gap={1.5}>
        <Button
          variant="outlined"
          startIcon={<RefreshIcon />}
          onClick={onRefresh}
          disabled={isLoading}
          size="small"
          sx={{
            borderColor: '#cbd5e1',
            color: '#475569',
            textTransform: 'none',
            fontWeight: 600,
            '&:hover': { borderColor: '#94a3b8', backgroundColor: '#f8fafc' },
          }}
        >
          Refresh
        </Button>
      </Box>
    </Box>
  );
};
