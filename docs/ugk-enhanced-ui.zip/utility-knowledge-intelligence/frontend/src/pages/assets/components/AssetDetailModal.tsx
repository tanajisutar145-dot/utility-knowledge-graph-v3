import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
  Chip,
  Tabs,
  Tab,
  CircularProgress,
  IconButton,
  Paper,
  Grid,
  Card,
  CardContent,
} from '@mui/material';
import {
  Close as CloseIcon,
  Hub as GraphIcon,
  Search as SearchIcon,
  Psychology as IntelligenceIcon,
  PrecisionManufacturing as ComponentIcon,
  FactCheck as InspectionIcon,
  Build as WorkOrderIcon,
  EventNote as PlanIcon,
  Warning as FailureIcon,
  PowerOff as OutageIcon,
  Description as DocumentIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { AssetDetailResponse } from '../../../types/assets';
import {
  getCriticalityColor,
  getStatusColor,
  getAssetClassLabel,
  formatDate,
  formatCurrency,
} from '../utils/assetUtils';

interface AssetDetailModalProps {
  open: boolean;
  assetDetail: AssetDetailResponse | null;
  isLoading: boolean;
  onClose: () => void;
}

export const AssetDetailModal: React.FC<AssetDetailModalProps> = ({
  open,
  assetDetail,
  isLoading,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<number>(0);
  const navigate = useNavigate();

  const asset = assetDetail?.asset;
  const critStyle = asset ? getCriticalityColor(asset.criticality) : null;
  const statusStyle = asset ? getStatusColor(asset.operational_status) : null;

  return (
    <Dialog
      disablePortal
      open={open}
      onClose={onClose}
      maxWidth="lg"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 2.5,
          minHeight: '65vh',
          maxHeight: '90vh',
        },
      }}
    >
      <DialogTitle sx={{ p: 2.5, pb: 1.5, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        {asset ? (
          <Box pr={2}>
            <Box display="flex" alignItems="center" gap={1} flexWrap="wrap" mb={0.5}>
              <Chip
                label={asset.asset_id}
                size="small"
                sx={{ backgroundColor: '#eff6ff', color: '#1d4ed8', fontWeight: 700 }}
              />
              <Chip
                label={getAssetClassLabel(asset.asset_class)}
                size="small"
                sx={{ backgroundColor: '#f1f5f9', color: '#334155', fontWeight: 600 }}
              />
              {critStyle && (
                <Chip
                  label={critStyle.label}
                  size="small"
                  sx={{
                    backgroundColor: critStyle.bg,
                    color: critStyle.text,
                    border: `1px solid ${critStyle.border}`,
                    fontWeight: 700,
                  }}
                />
              )}
              {statusStyle && (
                <Chip
                  label={statusStyle.label}
                  size="small"
                  sx={{
                    backgroundColor: statusStyle.bg,
                    color: statusStyle.text,
                    border: `1px solid ${statusStyle.border}`,
                    fontWeight: 600,
                  }}
                />
              )}
            </Box>
            <Typography variant="h5" fontWeight={700} color="#0f172a">
              {asset.name}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              Tag: {asset.asset_tag || 'N/A'} • Model: {asset.model || 'N/A'} • Manufacturer: {asset.manufacturer || 'N/A'} • Installed: {formatDate(asset.installation_date)}
            </Typography>
          </Box>
        ) : (
          <Typography variant="h6">Asset Details</Typography>
        )}
        <IconButton onClick={onClose} size="small" sx={{ color: '#94a3b8' }}>
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      <Box px={2.5} py={1} bgcolor="#f8fafc" display="flex" gap={1.5} flexWrap="wrap" borderTop="1px solid #e2e8f0" borderBottom="1px solid #e2e8f0">
        <Button
          size="small"
          variant="outlined"
          startIcon={<GraphIcon />}
          onClick={() => {
            onClose();
            navigate(`/graph?query=${encodeURIComponent(asset?.asset_id || '')}`);
          }}
          sx={{ textTransform: 'none', borderColor: '#cbd5e1', color: '#334155', fontWeight: 600 }}
        >
          Explore in Graph Explorer
        </Button>
        <Button
          size="small"
          variant="outlined"
          startIcon={<SearchIcon />}
          onClick={() => {
            onClose();
            navigate(`/search?q=${encodeURIComponent(asset?.name || asset?.asset_id || '')}`);
          }}
          sx={{ textTransform: 'none', borderColor: '#cbd5e1', color: '#334155', fontWeight: 600 }}
        >
          Search Supporting Documents
        </Button>
        <Button
          size="small"
          variant="outlined"
          startIcon={<IntelligenceIcon />}
          onClick={() => {
            onClose();
            navigate(`/intelligence?q=${encodeURIComponent(`What is the operational condition, failure history, and maintenance status of ${asset?.name || asset?.asset_id}?`)}`);
          }}
          sx={{ textTransform: 'none', borderColor: '#00897b', color: '#00897b', fontWeight: 600 }}
        >
          Investigate in Intelligence
        </Button>
      </Box>

      <Box sx={{ borderBottom: 1, borderColor: 'divider', px: 2.5, bgcolor: '#ffffff' }}>
        <Tabs
          value={activeTab}
          onChange={(_, val) => setActiveTab(val)}
          variant="scrollable"
          scrollButtons="auto"
          sx={{
            '& .MuiTab-root': {
              textTransform: 'none',
              fontWeight: 600,
              minHeight: 48,
              color: '#64748b',
              '&.Mui-selected': { color: '#1976d2' },
            },
            '& .MuiTabs-indicator': { backgroundColor: '#1976d2' },
          }}
        >
          <Tab label="Hierarchy & Overview" />
          <Tab label={`Components (${assetDetail?.components.length || 0})`} />
          <Tab label={`Inspections (${assetDetail?.inspections.length || 0})`} />
          <Tab label={`Work Orders (${assetDetail?.work_orders.length || 0})`} />
          <Tab label={`Maintenance Plans (${assetDetail?.maintenance_plans.length || 0})`} />
          <Tab label={`Historical Failures (${assetDetail?.failures.length || 0})`} />
          <Tab label={`Unit Outages (${assetDetail?.outages.length || 0})`} />
          <Tab label={`Technical Documents (${assetDetail?.documents.length || 0})`} />
        </Tabs>
      </Box>

      <DialogContent sx={{ p: 3 }}>
        {isLoading ? (
          <Box display="flex" justifyContent="center" alignItems="center" p={6}>
            <CircularProgress size={36} sx={{ color: '#1976d2' }} />
          </Box>
        ) : !assetDetail ? (
          <Typography color="text.secondary">Asset information not found.</Typography>
        ) : (
          <>
            {/* Tab 0: Hierarchy & Overview */}
            {activeTab === 0 && (
              <Box>
                <Grid container spacing={3}>
                  <Grid item xs={12} md={6}>
                    <Paper variant="outlined" sx={{ p: 2.5, borderRadius: 2, height: '100%' }}>
                      <Typography variant="subtitle2" fontWeight={700} color="#0f172a" mb={2}>
                        Parent Operational Hierarchy
                      </Typography>
                      {assetDetail.hierarchy.power_plant && (
                        <Box mb={2} p={1.5} bgcolor="#f8fafc" borderRadius={1.5}>
                          <Typography variant="caption" color="text.secondary" fontWeight={600}>
                            POWER PLANT
                          </Typography>
                          <Typography variant="subtitle1" fontWeight={700} color="#1e293b">
                            {assetDetail.hierarchy.power_plant.name}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            ID: {assetDetail.hierarchy.power_plant.plant_id} • Type: {assetDetail.hierarchy.power_plant.plant_type || 'N/A'} • Capacity: {assetDetail.hierarchy.power_plant.capacity_mw} MW
                          </Typography>
                          {assetDetail.hierarchy.power_plant.location && (
                            <Typography variant="caption" color="text.secondary" display="block">
                              Location: {assetDetail.hierarchy.power_plant.location}
                            </Typography>
                          )}
                        </Box>
                      )}
                      {assetDetail.hierarchy.generating_unit && (
                        <Box p={1.5} bgcolor="#f8fafc" borderRadius={1.5}>
                          <Typography variant="caption" color="text.secondary" fontWeight={600}>
                            GENERATING UNIT
                          </Typography>
                          <Typography variant="subtitle1" fontWeight={700} color="#1e293b">
                            {assetDetail.hierarchy.generating_unit.unit_name}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Unit ID: {assetDetail.hierarchy.generating_unit.unit_id} • Type: {assetDetail.hierarchy.generating_unit.unit_type || 'N/A'} • Capacity: {assetDetail.hierarchy.generating_unit.capacity_mw} MW
                          </Typography>
                        </Box>
                      )}
                    </Paper>
                  </Grid>

                  <Grid item xs={12} md={6}>
                    <Paper variant="outlined" sx={{ p: 2.5, borderRadius: 2, height: '100%' }}>
                      <Typography variant="subtitle2" fontWeight={700} color="#0f172a" mb={2}>
                        Technical Specifications & Metadata
                      </Typography>
                      <Box display="flex" flexDirection="column" gap={1.5}>
                        <Box display="flex" justifyContent="space-between">
                          <Typography variant="body2" color="text.secondary">Asset ID:</Typography>
                          <Typography variant="body2" fontWeight={600}>{asset?.asset_id}</Typography>
                        </Box>
                        <Box display="flex" justifyContent="space-between">
                          <Typography variant="body2" color="text.secondary">Asset Tag:</Typography>
                          <Typography variant="body2" fontWeight={600}>{asset?.asset_tag || '—'}</Typography>
                        </Box>
                        <Box display="flex" justifyContent="space-between">
                          <Typography variant="body2" color="text.secondary">Equipment Class:</Typography>
                          <Typography variant="body2" fontWeight={600}>{getAssetClassLabel(asset?.asset_class)}</Typography>
                        </Box>
                        <Box display="flex" justifyContent="space-between">
                          <Typography variant="body2" color="text.secondary">Manufacturer:</Typography>
                          <Typography variant="body2" fontWeight={600}>{asset?.manufacturer || '—'}</Typography>
                        </Box>
                        <Box display="flex" justifyContent="space-between">
                          <Typography variant="body2" color="text.secondary">Model:</Typography>
                          <Typography variant="body2" fontWeight={600}>{asset?.model || '—'}</Typography>
                        </Box>
                        <Box display="flex" justifyContent="space-between">
                          <Typography variant="body2" color="text.secondary">Installation Date:</Typography>
                          <Typography variant="body2" fontWeight={600}>{formatDate(asset?.installation_date)}</Typography>
                        </Box>
                        <Box display="flex" justifyContent="space-between">
                          <Typography variant="body2" color="text.secondary">Criticality:</Typography>
                          <Typography variant="body2" fontWeight={600}>{asset?.criticality?.toUpperCase()}</Typography>
                        </Box>
                      </Box>
                    </Paper>
                  </Grid>
                </Grid>
              </Box>
            )}

            {/* Tab 1: Components */}
            {activeTab === 1 && (
              <Box display="flex" flexDirection="column" gap={2}>
                <Typography variant="subtitle2" fontWeight={600} color="#334155">
                  Connected Sub-Components ({assetDetail.components.length})
                </Typography>
                {assetDetail.components.length === 0 ? (
                  <Paper variant="outlined" sx={{ p: 4, textAlign: 'center', bgcolor: '#f8fafc' }}>
                    <Typography color="text.secondary">No sub-components directly registered for this asset.</Typography>
                  </Paper>
                ) : (
                  <Grid container spacing={2}>
                    {assetDetail.components.map((comp) => (
                      <Grid item xs={12} sm={6} md={4} key={comp.component_id}>
                        <Card variant="outlined" sx={{ borderRadius: 2 }}>
                          <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                            <Box display="flex" alignItems="center" gap={1} mb={1}>
                              <ComponentIcon sx={{ color: '#0284c7', fontSize: 20 }} />
                              <Typography variant="subtitle2" fontWeight={700}>
                                {comp.component_name}
                              </Typography>
                            </Box>
                            <Typography variant="caption" color="text.secondary" display="block">
                              ID: {comp.component_id} • Type: {comp.component_type || 'N/A'}
                            </Typography>
                            <Typography variant="caption" color="text.secondary" display="block">
                              Model: {comp.model || '—'} • Status: {comp.status || 'operational'}
                            </Typography>
                          </CardContent>
                        </Card>
                      </Grid>
                    ))}
                  </Grid>
                )}
              </Box>
            )}

            {/* Tab 2: Inspections */}
            {activeTab === 2 && (
              <Box display="flex" flexDirection="column" gap={2}>
                <Typography variant="subtitle2" fontWeight={600} color="#334155">
                  Inspection History ({assetDetail.inspections.length})
                </Typography>
                {assetDetail.inspections.length === 0 ? (
                  <Paper variant="outlined" sx={{ p: 4, textAlign: 'center', bgcolor: '#f8fafc' }}>
                    <Typography color="text.secondary">No historical inspections recorded.</Typography>
                  </Paper>
                ) : (
                  assetDetail.inspections.map((insp) => (
                    <Card key={insp.inspection_id} variant="outlined" sx={{ borderRadius: 2 }}>
                      <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                        <Box display="flex" justifyContent="space-between" alignItems="center" mb={1} flexWrap="wrap">
                          <Box display="flex" alignItems="center" gap={1}>
                            <InspectionIcon sx={{ color: '#16a34a', fontSize: 20 }} />
                            <Typography variant="subtitle2" fontWeight={700}>
                              {insp.inspection_type?.toUpperCase()} Inspection ({insp.inspection_id})
                            </Typography>
                          </Box>
                          <Typography variant="caption" color="text.secondary">
                            Date: {formatDate(insp.inspection_date)} • Inspector: {insp.inspector || 'N/A'}
                          </Typography>
                        </Box>
                        <Box display="flex" gap={1} mb={1}>
                          <Chip label={`Condition: ${insp.condition || 'N/A'}`} size="small" sx={{ fontWeight: 600 }} />
                          <Chip label={`Severity: ${insp.severity || 'low'}`} size="small" variant="outlined" />
                        </Box>
                        <Typography variant="body2" color="#1e293b" mb={1}>
                          {insp.findings || 'No findings recorded.'}
                        </Typography>
                        {insp.recommended_action && (
                          <Typography variant="caption" color="text.secondary" display="block">
                            Recommended Action: {insp.recommended_action}
                          </Typography>
                        )}
                      </CardContent>
                    </Card>
                  ))
                )}
              </Box>
            )}

            {/* Tab 3: Work Orders */}
            {activeTab === 3 && (
              <Box display="flex" flexDirection="column" gap={2}>
                <Typography variant="subtitle2" fontWeight={600} color="#334155">
                  Associated Work Orders ({assetDetail.work_orders.length})
                </Typography>
                {assetDetail.work_orders.length === 0 ? (
                  <Paper variant="outlined" sx={{ p: 4, textAlign: 'center', bgcolor: '#f8fafc' }}>
                    <Typography color="text.secondary">No work orders recorded for this asset.</Typography>
                  </Paper>
                ) : (
                  assetDetail.work_orders.map((wo) => (
                    <Card key={wo.work_order_id} variant="outlined" sx={{ borderRadius: 2 }}>
                      <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                        <Box display="flex" justifyContent="space-between" alignItems="center" mb={1} flexWrap="wrap">
                          <Box display="flex" alignItems="center" gap={1}>
                            <WorkOrderIcon sx={{ color: '#2563eb', fontSize: 20 }} />
                            <Typography variant="subtitle2" fontWeight={700}>
                              {wo.work_order_id} ({wo.work_type || 'Maintenance'})
                            </Typography>
                          </Box>
                          <Typography variant="caption" color="text.secondary">
                            Created: {formatDate(wo.created_date)} • Total Cost: {formatCurrency(wo.total_cost)}
                          </Typography>
                        </Box>
                        <Box display="flex" gap={1} mb={1}>
                          <Chip label={`Priority: ${wo.priority || 'medium'}`} size="small" />
                          <Chip label={`Status: ${wo.status || 'created'}`} size="small" sx={{ bgcolor: '#eff6ff', color: '#1d4ed8', fontWeight: 600 }} />
                        </Box>
                        <Typography variant="body2" color="#1e293b">
                          {wo.description}
                        </Typography>
                      </CardContent>
                    </Card>
                  ))
                )}
              </Box>
            )}

            {/* Tab 4: Maintenance Plans */}
            {activeTab === 4 && (
              <Box display="flex" flexDirection="column" gap={2}>
                <Typography variant="subtitle2" fontWeight={600} color="#334155">
                  Maintenance Plans ({assetDetail.maintenance_plans.length})
                </Typography>
                {assetDetail.maintenance_plans.length === 0 ? (
                  <Paper variant="outlined" sx={{ p: 4, textAlign: 'center', bgcolor: '#f8fafc' }}>
                    <Typography color="text.secondary">No maintenance plans assigned to this asset.</Typography>
                  </Paper>
                ) : (
                  assetDetail.maintenance_plans.map((mp) => (
                    <Card key={mp.maintenance_plan_id} variant="outlined" sx={{ borderRadius: 2 }}>
                      <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                        <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
                          <Box display="flex" alignItems="center" gap={1}>
                            <PlanIcon sx={{ color: '#7c3aed', fontSize: 20 }} />
                            <Typography variant="subtitle2" fontWeight={700}>
                              {mp.plan_name}
                            </Typography>
                          </Box>
                          <Chip label={mp.status || 'active'} size="small" sx={{ bgcolor: '#f0fdf4', color: '#16a34a', fontWeight: 600 }} />
                        </Box>
                        <Typography variant="body2" color="text.secondary">
                          Type: {mp.maintenance_type || 'preventive'} • Frequency: {mp.frequency || 'N/A'} • Next Due: {formatDate(mp.next_due_date)}
                        </Typography>
                      </CardContent>
                    </Card>
                  ))
                )}
              </Box>
            )}

            {/* Tab 5: Failure Events */}
            {activeTab === 5 && (
              <Box display="flex" flexDirection="column" gap={2}>
                <Typography variant="subtitle2" fontWeight={600} color="#334155">
                  Recorded Failure Events ({assetDetail.failures.length})
                </Typography>
                {assetDetail.failures.length === 0 ? (
                  <Paper variant="outlined" sx={{ p: 4, textAlign: 'center', bgcolor: '#f0fdf4' }}>
                    <Typography color="#16a34a" fontWeight={600}>
                      No historical failures recorded for this asset.
                    </Typography>
                  </Paper>
                ) : (
                  assetDetail.failures.map((fail) => (
                    <Card key={fail.failure_id} variant="outlined" sx={{ borderRadius: 2, borderColor: '#fecaca' }}>
                      <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                        <Box display="flex" justifyContent="space-between" alignItems="center" mb={1} flexWrap="wrap">
                          <Box display="flex" alignItems="center" gap={1}>
                            <FailureIcon sx={{ color: '#dc2626', fontSize: 20 }} />
                            <Typography variant="subtitle2" fontWeight={700} color="#dc2626">
                              {fail.failure_mode || fail.failure_id}
                            </Typography>
                          </Box>
                          <Typography variant="caption" color="text.secondary">
                            Date: {formatDate(fail.failure_date)} • Downtime: {fail.downtime_hours || 0} hrs
                          </Typography>
                        </Box>
                        <Box display="flex" gap={1} mb={1}>
                          <Chip label={`Severity: ${fail.severity || 'high'}`} size="small" sx={{ bgcolor: '#fee2e2', color: '#dc2626', fontWeight: 700 }} />
                          <Chip label={`Status: ${fail.status || 'resolved'}`} size="small" />
                        </Box>
                        <Typography variant="body2" color="#1e293b" mb={1}>
                          {fail.description}
                        </Typography>
                        {fail.root_cause && (
                          <Typography variant="caption" color="text.secondary" display="block">
                            Root Cause: {fail.root_cause}
                          </Typography>
                        )}
                        <Typography variant="caption" color="text.secondary" display="block">
                          Estimated Cost: {formatCurrency(fail.estimated_cost)} • Actual Cost: {formatCurrency(fail.actual_cost)}
                        </Typography>
                      </CardContent>
                    </Card>
                  ))
                )}
              </Box>
            )}

            {/* Tab 6: Unit Outages */}
            {activeTab === 6 && (
              <Box display="flex" flexDirection="column" gap={2}>
                <Typography variant="subtitle2" fontWeight={600} color="#334155">
                  Parent Unit Outage Events ({assetDetail.outages.length})
                </Typography>
                {assetDetail.outages.length === 0 ? (
                  <Paper variant="outlined" sx={{ p: 4, textAlign: 'center', bgcolor: '#f8fafc' }}>
                    <Typography color="text.secondary">No outage events recorded on parent unit.</Typography>
                  </Paper>
                ) : (
                  assetDetail.outages.map((outage) => (
                    <Card key={outage.outage_id} variant="outlined" sx={{ borderRadius: 2 }}>
                      <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                        <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
                          <Box display="flex" alignItems="center" gap={1}>
                            <OutageIcon sx={{ color: '#ea580c', fontSize: 20 }} />
                            <Typography variant="subtitle2" fontWeight={700}>
                              {outage.outage_type?.toUpperCase()} Outage ({outage.outage_id})
                            </Typography>
                          </Box>
                          <Typography variant="caption" color="text.secondary">
                            Started: {formatDate(outage.start_date)} • Duration: {outage.duration_hours || 'N/A'} hrs
                          </Typography>
                        </Box>
                        <Typography variant="body2" color="#1e293b" mb={0.5}>
                          Cause: {outage.cause}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          Status: {outage.status} • Cost Impact: {formatCurrency(outage.estimated_cost)}
                        </Typography>
                      </CardContent>
                    </Card>
                  ))
                )}
              </Box>
            )}

            {/* Tab 7: Technical Documents */}
            {activeTab === 7 && (
              <Box display="flex" flexDirection="column" gap={2}>
                <Typography variant="subtitle2" fontWeight={600} color="#334155">
                  Referencing Technical Documents ({assetDetail.documents.length})
                </Typography>
                {assetDetail.documents.length === 0 ? (
                  <Paper variant="outlined" sx={{ p: 4, textAlign: 'center', bgcolor: '#f8fafc' }}>
                    <Typography color="text.secondary">No technical documents directly referencing this asset.</Typography>
                  </Paper>
                ) : (
                  assetDetail.documents.map((doc) => (
                    <Card key={doc.document_id} variant="outlined" sx={{ borderRadius: 2 }}>
                      <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                        <Box display="flex" justifyContent="space-between" alignItems="center">
                          <Box display="flex" alignItems="center" gap={1}>
                            <DocumentIcon sx={{ color: '#00897b', fontSize: 20 }} />
                            <Box>
                              <Typography variant="subtitle2" fontWeight={700}>
                                {doc.title}
                              </Typography>
                              <Typography variant="caption" color="text.secondary">
                                ID: {doc.document_id} • Type: {doc.document_type || 'report'} • Source: {doc.source || 'N/A'} • Created: {formatDate(doc.created_date)}
                              </Typography>
                            </Box>
                          </Box>
                          <Button
                            size="small"
                            variant="outlined"
                            onClick={() => {
                              onClose();
                              navigate(`/documents?search=${encodeURIComponent(doc.document_id)}`);
                            }}
                            sx={{ textTransform: 'none', borderColor: '#00897b', color: '#00897b' }}
                          >
                            View in Documents
                          </Button>
                        </Box>
                      </CardContent>
                    </Card>
                  ))
                )}
              </Box>
            )}
          </>
        )}
      </DialogContent>

      <DialogActions sx={{ p: 2, px: 2.5, borderTop: '1px solid #e2e8f0' }}>
        <Button onClick={onClose} variant="contained" sx={{ backgroundColor: '#1976d2', textTransform: 'none' }}>
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};
