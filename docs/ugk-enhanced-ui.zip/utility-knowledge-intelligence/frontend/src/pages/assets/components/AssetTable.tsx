import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  IconButton,
  Tooltip,
  Typography,
  Box,
  CircularProgress,
  TablePagination,
} from '@mui/material';
import {
  Visibility as ViewIcon,
  PrecisionManufacturing as EmptyIcon,
  Warning as FailIcon,
} from '@mui/icons-material';
import { AssetSummaryItem } from '../../../types/assets';
import {
  getCriticalityColor,
  getStatusColor,
  getAssetClassLabel,
} from '../utils/assetUtils';

interface AssetTableProps {
  assets: AssetSummaryItem[];
  total: number;
  page: number;
  rowsPerPage: number;
  isLoading: boolean;
  onPageChange: (newPage: number) => void;
  onRowsPerPageChange: (newRowsPerPage: number) => void;
  onSelectAsset: (assetId: string) => void;
}

export const AssetTable: React.FC<AssetTableProps> = ({
  assets,
  total,
  page,
  rowsPerPage,
  isLoading,
  onPageChange,
  onRowsPerPageChange,
  onSelectAsset,
}) => {
  if (isLoading && assets.length === 0) {
    return (
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        p={8}
        bgcolor="#ffffff"
        borderRadius={2}
        border="1px solid #e2e8f0"
      >
        <CircularProgress size={40} sx={{ color: '#1976d2', mb: 2 }} />
        <Typography color="text.secondary">Loading assets from Neo4j knowledge graph...</Typography>
      </Box>
    );
  }

  if (!isLoading && assets.length === 0) {
    return (
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        p={8}
        bgcolor="#ffffff"
        borderRadius={2}
        border="1px solid #e2e8f0"
        textAlign="center"
      >
        <EmptyIcon sx={{ fontSize: 48, color: '#94a3b8', mb: 1.5 }} />
        <Typography variant="h6" fontWeight={600} color="#1e293b">
          No Assets Found
        </Typography>
        <Typography variant="body2" color="text.secondary" maxWidth={400} mt={0.5}>
          No utility assets matched your search query or filters. Try clearing your filters to see the full equipment inventory.
        </Typography>
      </Box>
    );
  }

  return (
    <Paper variant="outlined" sx={{ borderRadius: 2, overflow: 'hidden', border: '1px solid #e2e8f0' }}>
      <TableContainer>
        <Table sx={{ minWidth: 850 }}>
          <TableHead sx={{ backgroundColor: '#f8fafc' }}>
            <TableRow>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }}>Asset ID</TableCell>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }}>Name</TableCell>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }}>Equipment Class</TableCell>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }}>Criticality</TableCell>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }}>Status</TableCell>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }}>Model / Manufacturer</TableCell>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }}>Parent Unit & Plant</TableCell>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }} align="center">Graph Context</TableCell>
              <TableCell sx={{ fontWeight: 600, color: '#475569', py: 1.5 }} align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {assets.map((asset) => {
              const critStyle = getCriticalityColor(asset.criticality);
              const statusStyle = getStatusColor(asset.operational_status);

              return (
                <TableRow
                  key={asset.asset_id}
                  hover
                  onClick={() => onSelectAsset(asset.asset_id)}
                  sx={{
                    cursor: 'pointer',
                    '&:last-child td, &:last-child th': { border: 0 },
                  }}
                >
                  <TableCell sx={{ fontWeight: 600, color: '#1976d2' }}>
                    {asset.asset_id}
                  </TableCell>
                  <TableCell sx={{ fontWeight: 500, color: '#0f172a', maxWidth: 220 }}>
                    <Typography variant="body2" noWrap fontWeight={600}>
                      {asset.name}
                    </Typography>
                    {asset.asset_tag && (
                      <Typography variant="caption" color="text.secondary">
                        {asset.asset_tag}
                      </Typography>
                    )}
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={getAssetClassLabel(asset.asset_class)}
                      size="small"
                      sx={{
                        backgroundColor: '#f1f5f9',
                        color: '#334155',
                        fontWeight: 600,
                        fontSize: '0.72rem',
                      }}
                    />
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={critStyle.label}
                      size="small"
                      sx={{
                        backgroundColor: critStyle.bg,
                        color: critStyle.text,
                        border: `1px solid ${critStyle.border}`,
                        fontWeight: 700,
                        fontSize: '0.72rem',
                      }}
                    />
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={statusStyle.label}
                      size="small"
                      sx={{
                        backgroundColor: statusStyle.bg,
                        color: statusStyle.text,
                        border: `1px solid ${statusStyle.border}`,
                        fontWeight: 600,
                        fontSize: '0.72rem',
                      }}
                    />
                  </TableCell>
                  <TableCell sx={{ color: '#475569', fontSize: '0.85rem' }}>
                    {asset.model || asset.manufacturer ? (
                      <>
                        <Typography variant="body2" fontSize="0.85rem">
                          {asset.model || '—'}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {asset.manufacturer || '—'}
                        </Typography>
                      </>
                    ) : (
                      '—'
                    )}
                  </TableCell>
                  <TableCell sx={{ color: '#475569', fontSize: '0.85rem' }}>
                    <Typography variant="body2" fontSize="0.85rem" fontWeight={500}>
                      {asset.unit_name || asset.unit_id || '—'}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {asset.plant_name || '—'}
                    </Typography>
                  </TableCell>
                  <TableCell align="center">
                    <Box display="flex" gap={0.5} justifyContent="center" flexWrap="wrap">
                      <Tooltip title={`${asset.component_count} Connected Components`}>
                        <Chip
                          label={`${asset.component_count} C`}
                          size="small"
                          sx={{ fontSize: '0.68rem', height: 20, bgcolor: '#f8fafc', border: '1px solid #e2e8f0' }}
                        />
                      </Tooltip>
                      <Tooltip title={`${asset.inspection_count} Inspections`}>
                        <Chip
                          label={`${asset.inspection_count} I`}
                          size="small"
                          sx={{ fontSize: '0.68rem', height: 20, bgcolor: '#f0fdf4', color: '#16a34a', border: '1px solid #bbf7d0' }}
                        />
                      </Tooltip>
                      <Tooltip title={`${asset.work_order_count} Work Orders`}>
                        <Chip
                          label={`${asset.work_order_count} W`}
                          size="small"
                          sx={{ fontSize: '0.68rem', height: 20, bgcolor: '#eff6ff', color: '#2563eb', border: '1px solid #bfdbfe' }}
                        />
                      </Tooltip>
                      {asset.failure_count > 0 && (
                        <Tooltip title={`${asset.failure_count} Historical Failures`}>
                          <Chip
                            icon={<FailIcon sx={{ fontSize: '12px !important', color: '#dc2626 !important' }} />}
                            label={`${asset.failure_count} F`}
                            size="small"
                            sx={{ fontSize: '0.68rem', height: 20, bgcolor: '#fee2e2', color: '#dc2626', border: '1px solid #fecaca', fontWeight: 700 }}
                          />
                        </Tooltip>
                      )}
                    </Box>
                  </TableCell>
                  <TableCell align="right">
                    <Tooltip title="View Asset Intelligence & Relationships">
                      <IconButton
                        size="small"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectAsset(asset.asset_id);
                        }}
                        sx={{ color: '#1976d2' }}
                      >
                        <ViewIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>

      <TablePagination
        rowsPerPageOptions={[10, 25, 50]}
        component="div"
        count={total}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={(_, newPage) => onPageChange(newPage)}
        onRowsPerPageChange={(e) => onRowsPerPageChange(parseInt(e.target.value, 10))}
        sx={{ borderTop: '1px solid #e2e8f0' }}
      />
    </Paper>
  );
};
