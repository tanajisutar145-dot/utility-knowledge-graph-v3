import React from 'react';
import { Grid, Card, CardContent, Typography, Box, Skeleton } from '@mui/material';
import {
  PrecisionManufacturing as TotalIcon,
  CheckCircle as OperationalIcon,
  WarningAmber as FailIcon,
  CrisisAlert as CriticalIcon,
} from '@mui/icons-material';
import { AssetOverviewResponse } from '../../../types/assets';

interface AssetStatisticsProps {
  overview: AssetOverviewResponse | null;
  isLoading: boolean;
}

export const AssetStatistics: React.FC<AssetStatisticsProps> = ({
  overview,
  isLoading,
}) => {
  const criticalCount = overview?.criticality_counts?.critical || 0;
  const highCount = overview?.criticality_counts?.high || 0;
  const mediumCount = overview?.criticality_counts?.medium || 0;

  const cards = [
    {
      label: 'Total Asset Inventory',
      value: overview?.total_assets ?? 0,
      subtext: `${Object.keys(overview?.asset_class_counts || {}).length} equipment classes`,
      icon: <TotalIcon sx={{ color: '#1976d2' }} />,
      bgColor: '#eff6ff',
      borderColor: '#bfdbfe',
    },
    {
      label: 'Operational Status',
      value: `${overview?.operational_assets ?? 0} / ${overview?.total_assets ?? 0}`,
      subtext: '100% operational availability',
      icon: <OperationalIcon sx={{ color: '#16a34a' }} />,
      bgColor: '#f0fdf4',
      borderColor: '#bbf7d0',
    },
    {
      label: 'Recorded Failure Events',
      value: overview?.assets_with_failures ?? 0,
      subtext: 'Assets with historical failure events',
      icon: <FailIcon sx={{ color: '#dc2626' }} />,
      bgColor: '#fef2f2',
      borderColor: '#fecaca',
    },
    {
      label: 'Criticality Profile',
      value: `${criticalCount} Critical`,
      subtext: `${highCount} High • ${mediumCount} Medium`,
      icon: <CriticalIcon sx={{ color: '#ea580c' }} />,
      bgColor: '#fff7ed',
      borderColor: '#fed7aa',
    },
  ];

  return (
    <Grid container spacing={2} mb={3}>
      {cards.map((c, i) => (
        <Grid item xs={12} sm={6} md={3} key={i}>
          <Card
            variant="outlined"
            sx={{
              backgroundColor: c.bgColor,
              borderColor: c.borderColor,
              borderRadius: 2,
            }}
          >
            <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
              <Box display="flex" justifyContent="space-between" alignItems="flex-start">
                <Box>
                  <Typography variant="caption" color="text.secondary" fontWeight={600}>
                    {c.label}
                  </Typography>
                  {isLoading ? (
                    <Skeleton width={80} height={32} />
                  ) : (
                    <Typography variant="h5" fontWeight={700} color="#0f172a" my={0.5}>
                      {c.value}
                    </Typography>
                  )}
                  <Typography variant="caption" color="text.secondary">
                    {c.subtext}
                  </Typography>
                </Box>
                <Box
                  p={1}
                  borderRadius={1.5}
                  bgcolor="#ffffff"
                  display="flex"
                  alignItems="center"
                  justifyContent="center"
                  boxShadow="0 1px 3px rgba(0,0,0,0.05)"
                >
                  {c.icon}
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
};
