/**
 * TypeScript interfaces for backend API integration
 * Based on actual backend Pydantic models
 */

// Health endpoint response
export interface HealthResponse {
  status: string;
  application: string;
  environment: string;
  services: {
    backend: string;
    groq: string;
    neo4j: string;
  };
}

// Confidence levels from backend
export type ConfidenceLevel = 'high' | 'medium' | 'low' | 'very_low';

// Verification result from backend
export interface VerificationResult {
  verified: boolean;
  grounding_score: number;
  supported_claims: string[];
  unsupported_claims: string[];
  warnings: string[];
  evidence_gaps: string[];
}

// GraphRAG request
export interface GraphRAGRequest {
  question: string;
  top_k?: number;
  graph_depth?: number;
  min_similarity?: number;
  include_verification?: boolean;
}

// GraphRAG response
export interface GraphRAGResponse {
  question: string;
  answer: string;
  confidence: ConfidenceLevel;
  verification: VerificationResult;
  evidence: {
    semantic_results: SemanticSearchResult[];
    graph_evidence: GraphEvidence;
  };
  sources: {
    documents: string[];
    entities: string[];
  };
  metadata: {
    execution_time: number;
    retrieval_method?: string;
    context_stats?: any;
    groq_model?: string;
    verification_enabled?: boolean;
    [key: string]: any;
  };
}

// In-memory conversation message pair
export interface ChatMessage {
  id: string;
  timestamp: string;
  question: string;
  response?: GraphRAGResponse;
  error?: string;
  isLoading?: boolean;
}

// Simple GraphRAG response
export interface SimpleGraphRAGResponse {
  question: string;
  answer: string;
  confidence: ConfidenceLevel;
  verified: boolean;
  execution_time: number;
}

// Semantic retrieval request
export interface RetrievalRequest {
  query: string;
  top_k?: number;
  graph_depth?: number;
  min_similarity?: number;
  include_metadata?: boolean;
}

// Semantic search result
export interface SemanticSearchResult {
  chunk_id: string;
  document_id: string;
  document_title: string;
  text: string;
  score: number;
  source?: string;
  metadata: Record<string, any>;
}

// Graph evidence entities
export interface GraphEntity {
  entity_id: string;
  entity_type: string;
  properties: Record<string, any>;
}

// Graph evidence relationships
export interface GraphRelationship {
  source_id: string;
  target_id: string;
  relationship_type: string;
  source_type: string;
  target_type: string;
  properties: Record<string, any>;
}

// Graph evidence
export interface GraphEvidence {
  entities: GraphEntity[];
  relationships: GraphRelationship[];
}

// Retrieval result
export interface RetrievalResult {
  query: string;
  semantic_results: SemanticSearchResult[];
  graph_evidence: GraphEvidence;
  metadata: {
    execution_time: number;
    retrieval_method?: string;
    top_k?: number;
    graph_depth?: number;
    min_similarity?: number;
    semantic_results_count?: number;
    graph_entities_count?: number;
    graph_relationships_count?: number;
    error?: string;
    [key: string]: any;
  };
}

// API Error types
export interface ApiError {
  message: string;
  status?: number;
  details?: any;
}

// Status types for components
export type ServiceStatus = 'connected' | 'configured' | 'healthy' | 'offline' | 'unavailable' | 'disconnected' | 'not_configured' | 'loading' | 'unknown';

export interface ServiceHealth {
  backend: ServiceStatus;
  groq: ServiceStatus;
  neo4j: ServiceStatus;
}