/**
 * TypeScript interfaces for Dashboard API
 */

export interface DashboardKPIs {
  power_plants: number;
  generating_units: number;
  assets: number;
  components: number;
  work_orders: number;
  inspections: number;
  failure_events: number;
  outage_events: number;
  maintenance_plans: number;
}

export interface DashboardGraphStats {
  total_nodes: number;
  total_relationships: number;
  structured_nodes: number;
  document_nodes: number;
}

export interface DashboardDocumentStats {
  total_documents: number;
  total_chunks: number;
  embedded_chunks: number;
  embedding_dimension: number;
  embedding_model: string;
  vector_index_name: string;
  vector_index_status: string;
  vector_index_population: number;
}

export interface AssetReliabilityStats {
  total_assets: number;
  operational_assets: number;
  assets_with_failures: number;
  criticality_counts: Record<string, number>;
}

export interface WorkOrderOverview {
  total_work_orders: number;
  status_counts: Record<string, number>;
  priority_counts: Record<string, number>;
  type_counts: Record<string, number>;
}

export interface FailureItem {
  failure_id: string;
  asset_id: string;
  asset_name?: string;
  failure_mode: string;
  severity: string;
  downtime_hours: number;
  actual_cost?: number;
  status: string;
  failure_date?: string;
}

export interface OutageTypeSummary {
  count: number;
  duration_hours: number;
  estimated_cost: number;
  loss_mwh: number;
}

export interface OutageOverview {
  total_outages: number;
  total_duration_hours: number;
  total_estimated_cost: number;
  total_loss_mwh: number;
  by_type: Record<string, OutageTypeSummary>;
}

export interface InspectionOverview {
  total_inspections: number;
  condition_counts: Record<string, number>;
  severity_counts: Record<string, number>;
}

export interface OperationsStats {
  asset_reliability: AssetReliabilityStats;
  work_orders: WorkOrderOverview;
  failures: FailureItem[];
  outages: OutageOverview;
  inspections: InspectionOverview;
}

export interface HeatRateObservation {
  test_id: string;
  unit_id: string;
  unit_name?: string;
  test_date?: string;
  measured_heat_rate: number;
  baseline_heat_rate: number;
  deviation_percentage: number;
  test_status: string;
  observations?: string;
}

export interface HeatRateTrend {
  observations: HeatRateObservation[];
  baseline_heat_rate: number;
  unit: string;
  initial_rate: number;
  latest_rate: number;
  delta: number;
  delta_percentage: number;
  interpretation: string;
}

export interface MaintenanceEffectiveness {
  maintenance_plans_count: number;
  work_orders_count: number;
  inspections_count: number;
  failures_count: number;
  triggered_work_orders_count: number;
  preventive_count: number;
  corrective_count: number;
  emergency_count: number;
  preventive_percentage: number;
  corrective_percentage: number;
  summary_note: string;
}

export interface DashboardSummaryResponse {
  generated_at: string;
  status: string;
  kpis: DashboardKPIs;
  graph: DashboardGraphStats;
  documents: DashboardDocumentStats;
  operations: OperationsStats;
  performance: HeatRateTrend;
  maintenance: MaintenanceEffectiveness;
}
