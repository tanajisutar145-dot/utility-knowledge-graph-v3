/**
 * TypeScript types for Document Management
 */

export interface DocumentOverviewResponse {
  total_documents: number;
  total_chunks: number;
  embedded_chunks: number;
  document_types: Record<string, number>;
  processing_statuses: Record<string, number>;
  vector_index_name: string;
  vector_index_status: string;
  vector_index_population: number;
  embedding_model: string;
  embedding_dimension: number;
}

export interface DocumentSummaryItem {
  document_id: string;
  title: string;
  document_type: string;
  source: string;
  source_reference?: string | null;
  created_date?: string | null;
  processing_status: string;
  content_hash?: string | null;
  content_length: number;
  chunk_count: number;
  embedded_chunks: number;
  format?: string | null;
  source_filename?: string | null;
  warnings?: string[];
}

export interface DocumentListResponse {
  documents: DocumentSummaryItem[];
  total: number;
  skip: number;
  limit: number;
}

export interface DocumentChunkDetail {
  chunk_id: string;
  chunk_index: number;
  text: string;
  is_embedded: boolean;
  embedding_model?: string | null;
  embedding_dimension?: number | null;
  created_at?: string | null;
  page_number?: number | null;
  sheet_name?: string | null;
  row_range?: string | null;
  section_title?: string | null;
  metadata: Record<string, any>;
}

export interface DocumentEntityLink {
  relationship: string;
  labels: string[];
  entity_id: string;
  entity_name: string;
  properties: Record<string, any>;
}

export interface DocumentDetailResponse {
  document_id: string;
  title: string;
  document_type: string;
  source: string;
  source_reference?: string | null;
  created_date?: string | null;
  processing_status: string;
  content_hash?: string | null;
  content: string;
  format?: string | null;
  source_filename?: string | null;
  warnings?: string[];
  chunks: DocumentChunkDetail[];
  linked_entities: DocumentEntityLink[];
}

export interface DocumentUploadResult {
  document_id: string;
  title: string;
  action: string;
  chunks_created: number;
  relationships_created: number;
  entity_links: number;
  embedded: boolean;
  format?: string | null;
  warnings?: string[];
  message: string;
}

export interface DocumentFilters {
  search?: string;
  document_type?: string;
}
