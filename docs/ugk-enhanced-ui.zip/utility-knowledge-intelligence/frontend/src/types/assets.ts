/**
 * TypeScript types for Asset Management
 */

export interface AssetOverviewResponse {
  total_assets: number;
  operational_assets: number;
  assets_with_failures: number;
  criticality_counts: Record<string, number>;
  asset_class_counts: Record<string, number>;
  status_counts: Record<string, number>;
}

export interface AssetSummaryItem {
  asset_id: string;
  name: string;
  asset_class: string;
  criticality: string;
  operational_status: string;
  manufacturer?: string | null;
  model?: string | null;
  installation_date?: string | null;
  asset_tag?: string | null;
  unit_id?: string | null;
  unit_name?: string | null;
  plant_id?: string | null;
  plant_name?: string | null;
  component_count: number;
  inspection_count: number;
  failure_count: number;
  work_order_count: number;
  document_count: number;
}

export interface AssetListResponse {
  assets: AssetSummaryItem[];
  total: number;
  skip: number;
  limit: number;
}

export interface GeneratingUnitHierarchy {
  unit_id: string;
  unit_name: string;
  unit_type?: string | null;
  capacity_mw?: number | null;
  status?: string | null;
}

export interface PowerPlantHierarchy {
  plant_id: string;
  name: string;
  location?: string | null;
  plant_type?: string | null;
  capacity_mw?: number | null;
}

export interface AssetParentHierarchy {
  generating_unit?: GeneratingUnitHierarchy | null;
  power_plant?: PowerPlantHierarchy | null;
}

export interface AssetComponent {
  component_id: string;
  component_name: string;
  component_type?: string | null;
  manufacturer?: string | null;
  model?: string | null;
  criticality?: string | null;
  status?: string | null;
}

export interface AssetInspection {
  inspection_id: string;
  inspection_date?: string | null;
  inspection_type?: string | null;
  inspector?: string | null;
  condition?: string | null;
  findings?: string | null;
  severity?: string | null;
  recommended_action?: string | null;
}

export interface AssetWorkOrder {
  work_order_id: string;
  created_date?: string | null;
  scheduled_date?: string | null;
  completion_date?: string | null;
  work_type?: string | null;
  priority?: string | null;
  status?: string | null;
  description?: string | null;
  total_cost?: number | null;
}

export interface AssetMaintenancePlan {
  maintenance_plan_id: string;
  plan_name: string;
  maintenance_type?: string | null;
  frequency?: string | null;
  last_execution_date?: string | null;
  next_due_date?: string | null;
  status?: string | null;
}

export interface AssetFailureEvent {
  failure_id: string;
  failure_date?: string | null;
  failure_mode?: string | null;
  severity?: string | null;
  description?: string | null;
  root_cause?: string | null;
  downtime_hours?: number;
  estimated_cost?: number | null;
  actual_cost?: number | null;
  status?: string | null;
}

export interface AssetOutageEvent {
  outage_id: string;
  outage_type?: string | null;
  start_date?: string | null;
  end_date?: string | null;
  duration_hours?: number | null;
  cause?: string | null;
  status?: string | null;
  estimated_cost?: number | null;
}

export interface AssetDocument {
  document_id: string;
  title: string;
  document_type?: string | null;
  source?: string | null;
  created_date?: string | null;
}

export interface AssetDetailResponse {
  asset: AssetSummaryItem;
  hierarchy: AssetParentHierarchy;
  components: AssetComponent[];
  inspections: AssetInspection[];
  work_orders: AssetWorkOrder[];
  maintenance_plans: AssetMaintenancePlan[];
  failures: AssetFailureEvent[];
  outages: AssetOutageEvent[];
  documents: AssetDocument[];
}

export interface AssetFilters {
  search?: string;
  asset_class?: string;
  criticality?: string;
  operational_status?: string;
  unit_id?: string;
}
