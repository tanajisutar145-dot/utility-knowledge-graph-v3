import React, { useState } from 'react';
import {
  AppBar,
  Box,
  CssBaseline,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
  Chip,
  Tooltip,
} from '@mui/material';
import {
  Menu as MenuIcon,
  Dashboard as DashboardIcon,
  AccountTree as GraphIcon,
  Description as DocumentsIcon,
  Search as SearchIcon,
  Psychology as IntelligenceIcon,
  Settings as SettingsIcon,
  MonitorHeart as HealthIcon,
} from '@mui/icons-material';
import { useNavigate, useLocation } from 'react-router-dom';
import { useHealth } from '../../hooks/useHealth';

const drawerWidth = 240;

interface LayoutProps {
  children: React.ReactNode;
}

const menuItems = [
  { text: 'Dashboard', icon: <DashboardIcon />, path: '/' },
  { text: 'Knowledge Graph', icon: <GraphIcon />, path: '/graph' },
  { text: 'Search', icon: <SearchIcon />, path: '/search' },
  { text: 'Intelligence', icon: <IntelligenceIcon />, path: '/intelligence' },
  { text: 'Documents', icon: <DocumentsIcon />, path: '/documents' },
  { text: 'Assets', icon: <SettingsIcon />, path: '/assets' },
  { text: 'System Health', icon: <HealthIcon />, path: '/health' },
];

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { health, loading } = useHealth();

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const getOverallStatus = () => {
    if (loading || !health) return 'loading';
    if (health.backend === 'offline' || health.backend === 'disconnected') return 'offline';
    if (health.neo4j === 'disconnected' || health.groq === 'not_configured') return 'warning';
    return 'connected';
  };

  const getStatusText = () => {
    const status = getOverallStatus();
    if (status === 'loading') return 'Backend Checking...';
    if (status === 'offline') return 'Backend Offline';
    if (status === 'warning') return 'Service Issues';
    return 'Backend Online';
  };

  const getStatusColor = (): 'success' | 'warning' | 'error' | 'default' => {
    const status = getOverallStatus();
    if (status === 'connected') return 'success';
    if (status === 'warning') return 'warning';
    if (status === 'offline') return 'error';
    return 'default';
  };

  const drawer = (
    <div>
      <Toolbar>
        <Typography variant="h6" noWrap component="div" sx={{ fontWeight: 600 }}>
          Utility Knowledge Intelligence
        </Typography>
      </Toolbar>
      <List>
        {menuItems.map((item) => (
          <ListItem key={item.text} disablePadding>
            <ListItemButton
              selected={location.pathname === item.path}
              onClick={() => navigate(item.path)}
            >
              <ListItemIcon>{item.icon}</ListItemIcon>
              <ListItemText primary={item.text} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </div>
  );

  return (
    <Box sx={{ display: 'flex' }}>
      <CssBaseline />
      <AppBar
        position="fixed"
        sx={{
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          ml: { sm: `${drawerWidth}px` },
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: 'none' } }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap component="div" sx={{ flexGrow: 1 }}>
            Utility Knowledge Intelligence
          </Typography>
          <Box display="flex" alignItems="center" gap={2}>
            <Tooltip title={getOverallStatus() === 'connected' ? 'All systems operational' : 'Some services may have issues'}>
              <Chip
                label={getStatusText()}
                color={getStatusColor()}
                size="small"
                variant="outlined"
              />
            </Tooltip>
          </Box>
        </Toolbar>
      </AppBar>
      <Box
        component="nav"
        sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
        aria-label="navigation"
      >
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true,
          }}
          sx={{
            display: { xs: 'block', sm: 'none' },
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
          }}
        >
          {drawer}
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: 'none', sm: 'block' },
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
          }}
          open
        >
          {drawer}
        </Drawer>
      </Box>
      <Box
        component="main"
        sx={{ flexGrow: 1, p: 3, width: { sm: `calc(100% - ${drawerWidth}px)` } }}
      >
        <Toolbar />
        {children}
      </Box>
    </Box>
  );
};

export default Layout;