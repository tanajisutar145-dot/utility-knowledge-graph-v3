/**
 * Reusable loading state components
 */

import React from 'react';
import {
  Box,
  CircularProgress,
  Typography,
  Skeleton,
  Card,
  CardContent,
} from '@mui/material';

interface LoadingStateProps {
  message?: string;
  size?: 'small' | 'medium' | 'large';
  variant?: 'circular' | 'skeleton' | 'inline';
}

export const LoadingState: React.FC<LoadingStateProps> = ({
  message = 'Loading...',
  size = 'medium',
  variant = 'circular',
}) => {
  const getSize = () => {
    switch (size) {
      case 'small':
        return 24;
      case 'large':
        return 60;
      case 'medium':
      default:
        return 40;
    }
  };

  if (variant === 'inline') {
    return (
      <Box display="flex" alignItems="center" gap={1}>
        <CircularProgress size={20} />
        <Typography variant="body2" color="textSecondary">
          {message}
        </Typography>
      </Box>
    );
  }

  if (variant === 'skeleton') {
    return (
      <Box>
        <Skeleton variant="text" height={40} />
        <Skeleton variant="rectangular" height={200} sx={{ mt: 1 }} />
        <Skeleton variant="text" height={30} sx={{ mt: 1 }} />
      </Box>
    );
  }

  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      py={4}
    >
      <CircularProgress size={getSize()} />
      <Typography variant="body2" color="textSecondary" sx={{ mt: 2 }}>
        {message}
      </Typography>
    </Box>
  );
};

export const PageLoadingSkeleton: React.FC = () => {
  return (
    <Box>
      <Skeleton variant="text" height={60} width="60%" />
      <Skeleton variant="text" height={30} width="40%" sx={{ mb: 3 }} />
      
      <Box display="flex" gap={2} mb={3}>
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} sx={{ flex: 1 }}>
            <CardContent>
              <Skeleton variant="rectangular" height={80} />
              <Skeleton variant="text" height={30} sx={{ mt: 1 }} />
            </CardContent>
          </Card>
        ))}
      </Box>

      <Card>
        <CardContent>
          <Skeleton variant="text" height={40} width="30%" />
          <Skeleton variant="rectangular" height={300} sx={{ mt: 2 }} />
        </CardContent>
      </Card>
    </Box>
  );
};

export const ButtonLoading: React.FC<{ loading: boolean; children: React.ReactNode }> = ({
  loading,
  children,
}) => {
  if (loading) {
    return <CircularProgress size={20} />;
  }
  return <>{children}</>;
};

export default LoadingState;