/**
 * Health panel component showing backend service status
 */

import React from 'react';
import {
  Card,
  CardContent,
  Typography,
  Box,
  IconButton,
  Tooltip,
  Divider,
} from '@mui/material';
import {
  Refresh as RefreshIcon,
  Info as InfoIcon,
} from '@mui/icons-material';
import { useHealth } from '../../hooks/useHealth';
import { StatusIndicator } from './StatusIndicator';
import { ErrorState } from './ErrorState';

interface HealthPanelProps {
  title?: string;
  showRefresh?: boolean;
  autoRefresh?: boolean;
  variant?: 'card' | 'inline';
  size?: 'small' | 'medium';
}

export const HealthPanel: React.FC<HealthPanelProps> = ({
  title = 'System Status',
  showRefresh = true,
  autoRefresh = true,
  variant = 'card',
  size = 'medium',
}) => {
  const { health, loading, error, lastChecked, refresh } = useHealth(
    autoRefresh ? 30000 : undefined // Auto-refresh every 30 seconds
  );

  const formatLastChecked = (date: Date | null) => {
    if (!date) return 'Never';
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    
    if (minutes < 1) return 'Just now';
    if (minutes === 1) return '1 minute ago';
    if (minutes < 60) return `${minutes} minutes ago`;
    
    return date.toLocaleTimeString();
  };

  const handleRefresh = async () => {
    await refresh();
  };

  const content = (
    <>
      {variant === 'card' && (
        <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
          <Typography variant="h6">{title}</Typography>
          <Box display="flex" alignItems="center" gap={1}>
            {lastChecked && (
              <Tooltip title={`Last checked: ${lastChecked.toLocaleString()}`}>
                <Typography variant="caption" color="textSecondary">
                  {formatLastChecked(lastChecked)}
                </Typography>
              </Tooltip>
            )}
            {showRefresh && (
              <Tooltip title="Refresh status">
                <IconButton size="small" onClick={handleRefresh} disabled={loading}>
                  <RefreshIcon />
                </IconButton>
              </Tooltip>
            )}
          </Box>
        </Box>
      )}

      {loading && !health && (
        <Box display="flex" flexDirection="column" gap={size === 'small' ? 1 : 2}>
          <StatusIndicator 
            label="Backend" 
            status="loading"
            size={size}
          />
          <StatusIndicator 
            label="Groq LLM" 
            status="loading"
            size={size}
          />
          <StatusIndicator 
            label="Neo4j" 
            status="loading"
            size={size}
          />
        </Box>
      )}

      {error && !health && (
        <ErrorState error={error} onRetry={handleRefresh} variant="inline" />
      )}

      {health && (
        <Box display="flex" flexDirection="column" gap={size === 'small' ? 1 : 2}>
          <StatusIndicator 
            label="Backend" 
            status={health.backend}
            size={size}
          />
          <StatusIndicator 
            label="Groq LLM" 
            status={health.groq}
            size={size}
          />
          <StatusIndicator 
            label="Neo4j" 
            status={health.neo4j}
            size={size}
          />

          {variant === 'card' && error && (
            <>
              <Divider sx={{ my: 1 }} />
              <Box display="flex" alignItems="center" gap={1}>
                <InfoIcon fontSize="small" color="warning" />
                <Typography variant="caption" color="textSecondary">
                  Some services may be experiencing issues
                </Typography>
              </Box>
            </>
          )}
        </Box>
      )}
    </>
  );

  if (variant === 'inline') {
    return <Box>{content}</Box>;
  }

  return (
    <Card>
      <CardContent>{content}</CardContent>
    </Card>
  );
};

export default HealthPanel;