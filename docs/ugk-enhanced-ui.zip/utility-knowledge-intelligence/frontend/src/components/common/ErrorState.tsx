/**
 * Reusable error state components
 */

import React from 'react';
import {
  Box,
  Typography,
  Button,
  Card,
  CardContent,
  Alert,
  AlertTitle,
} from '@mui/material';
import {
  Error as ErrorIcon,
  Refresh as RefreshIcon,
  Warning as WarningIcon,
} from '@mui/icons-material';
import { ApiError } from '../../types/api';

interface ErrorStateProps {
  error: ApiError | Error | string;
  onRetry?: () => void;
  variant?: 'page' | 'inline' | 'card';
  showDetails?: boolean;
}

export const ErrorState: React.FC<ErrorStateProps> = ({
  error,
  onRetry,
  variant = 'page',
  showDetails = false,
}) => {
  const getMessage = () => {
    if (typeof error === 'string') return error;
    if (error instanceof Error) return error.message;
    return (error as ApiError).message || 'An unexpected error occurred';
  };

  const getStatus = () => {
    if (typeof error === 'object' && 'status' in error) {
      return (error as ApiError).status;
    }
    return undefined;
  };

  const isNetworkError = () => {
    const message = getMessage().toLowerCase();
    return message.includes('connect') || message.includes('network') || getStatus() === 0;
  };

  const getErrorTitle = () => {
    if (isNetworkError()) {
      return 'Connection Error';
    }
    const status = getStatus();
    if (status) {
      if (status >= 500) return 'Server Error';
      if (status >= 400) return 'Request Error';
    }
    return 'Error';
  };

  const getErrorIcon = () => {
    if (isNetworkError()) return <WarningIcon color="warning" />;
    return <ErrorIcon color="error" />;
  };

  const content = (
    <Box display="flex" flexDirection="column" alignItems="center" gap={2}>
      {getErrorIcon()}
      <Typography variant="h6" color="textPrimary" align="center">
        {getErrorTitle()}
      </Typography>
      <Typography variant="body1" color="textSecondary" align="center">
        {getMessage()}
      </Typography>
      
      {showDetails && getStatus() && (
        <Typography variant="caption" color="textSecondary">
          Status: {getStatus()}
        </Typography>
      )}

      {onRetry && (
        <Button
          variant="outlined"
          startIcon={<RefreshIcon />}
          onClick={onRetry}
          sx={{ mt: 1 }}
        >
          Try Again
        </Button>
      )}
    </Box>
  );

  if (variant === 'inline') {
    return (
      <Alert severity={isNetworkError() ? 'warning' : 'error'}>
        <AlertTitle>{getErrorTitle()}</AlertTitle>
        {getMessage()}
        {onRetry && (
          <Button
            size="small"
            startIcon={<RefreshIcon />}
            onClick={onRetry}
            sx={{ mt: 1 }}
          >
            Retry
          </Button>
        )}
      </Alert>
    );
  }

  if (variant === 'card') {
    return (
      <Card>
        <CardContent>
          {content}
        </CardContent>
      </Card>
    );
  }

  // Page variant
  return (
    <Box
      display="flex"
      justifyContent="center"
      alignItems="center"
      minHeight="400px"
      p={3}
    >
      {content}
    </Box>
  );
};

export const ConnectionError: React.FC<{ onRetry?: () => void }> = ({ onRetry }) => {
  return (
    <ErrorState
      error="Unable to connect to the Utility Knowledge Intelligence backend. Please check your connection and try again."
      onRetry={onRetry}
      variant="inline"
    />
  );
};

export const ServiceUnavailableError: React.FC<{ serviceName: string; onRetry?: () => void }> = ({
  serviceName,
  onRetry,
}) => {
  return (
    <ErrorState
      error={`The ${serviceName} service is temporarily unavailable. Please try again later.`}
      onRetry={onRetry}
      variant="inline"
    />
  );
};

export default ErrorState;