/**
 * Status indicator component for service health
 */

import React from 'react';
import {
  Box,
  Typography,
  Chip,
  CircularProgress,
  Tooltip,
  useTheme,
} from '@mui/material';
import {
  CheckCircle as ConnectedIcon,
  Warning as WarningIcon,
  Error as ErrorIcon,
  Help as UnknownIcon,
} from '@mui/icons-material';
import { ServiceStatus } from '../../types/api';

interface StatusIndicatorProps {
  label: string;
  status: ServiceStatus;
  size?: 'small' | 'medium';
  showIcon?: boolean;
  showLabel?: boolean;
}

export const StatusIndicator: React.FC<StatusIndicatorProps> = ({
  label,
  status,
  size = 'medium',
  showIcon = true,
  showLabel = true,
}) => {
  const theme = useTheme();

  const getStatusConfig = (status: ServiceStatus) => {
    switch (status) {
      case 'healthy':
        return {
          color: 'success' as const,
          icon: <ConnectedIcon />,
          text: 'Online',
          dotColor: theme.palette.success.main,
        };
      case 'connected':
        return {
          color: 'success' as const,
          icon: <ConnectedIcon />,
          text: 'Connected',
          dotColor: theme.palette.success.main,
        };
      case 'configured':
        return {
          color: 'success' as const,
          icon: <ConnectedIcon />,
          text: 'Configured',
          dotColor: theme.palette.success.main,
        };
      case 'unavailable':
      case 'offline':
        return {
          color: 'error' as const,
          icon: <ErrorIcon />,
          text: 'Offline',
          dotColor: theme.palette.error.main,
        };
      case 'disconnected':
        return {
          color: 'error' as const,
          icon: <ErrorIcon />,
          text: 'Disconnected',
          dotColor: theme.palette.error.main,
        };
      case 'not_configured':
        return {
          color: 'warning' as const,
          icon: <WarningIcon />,
          text: 'Not Configured',
          dotColor: theme.palette.warning.main,
        };
      case 'loading':
        return {
          color: 'default' as const,
          icon: <CircularProgress size={16} />,
          text: 'Checking...',
          dotColor: theme.palette.grey[500],
        };
      case 'unknown':
      default:
        return {
          color: 'default' as const,
          icon: <UnknownIcon />,
          text: 'Unknown',
          dotColor: theme.palette.grey[500],
        };
    }
  };

  const config = getStatusConfig(status);

  const statusDot = (
    <Box
      sx={{
        width: 8,
        height: 8,
        borderRadius: '50%',
        backgroundColor: config.dotColor,
        mr: 1,
      }}
    />
  );

  if (size === 'small') {
    return (
      <Tooltip title={`${label}: ${config.text}`}>
        <Box display="flex" alignItems="center">
          {statusDot}
          {showLabel && (
            <Typography variant="caption" color="textSecondary">
              {label}
            </Typography>
          )}
        </Box>
      </Tooltip>
    );
  }

  return (
    <Box display="flex" alignItems="center" gap={1}>
      <Typography variant="body2" color="textSecondary" minWidth={80}>
        {label}
      </Typography>
      <Box display="flex" alignItems="center">
        {statusDot}
        <Typography variant="body2" color="textPrimary">
          {config.text}
        </Typography>
      </Box>
    </Box>
  );
};

interface StatusChipProps {
  status: ServiceStatus;
  label?: string;
}

export const StatusChip: React.FC<StatusChipProps> = ({ status, label }) => {
  const theme = useTheme();
  
  const getConfig = (status: ServiceStatus) => {
    switch (status) {
      case 'healthy':
        return {
          color: 'success' as const,
          icon: <ConnectedIcon />,
          text: 'Online',
          dotColor: theme.palette.success.main,
        };
      case 'connected':
        return {
          color: 'success' as const,
          icon: <ConnectedIcon />,
          text: 'Connected',
          dotColor: theme.palette.success.main,
        };
      case 'configured':
        return {
          color: 'success' as const,
          icon: <ConnectedIcon />,
          text: 'Configured',
          dotColor: theme.palette.success.main,
        };
      case 'unavailable':
      case 'offline':
        return {
          color: 'error' as const,
          icon: <ErrorIcon />,
          text: 'Offline',
          dotColor: theme.palette.error.main,
        };
      case 'disconnected':
        return {
          color: 'error' as const,
          icon: <ErrorIcon />,
          text: 'Disconnected',
          dotColor: theme.palette.error.main,
        };
      case 'not_configured':
        return {
          color: 'warning' as const,
          icon: <WarningIcon />,
          text: 'Not Configured',
          dotColor: theme.palette.warning.main,
        };
      case 'loading':
        return {
          color: 'default' as const,
          icon: <CircularProgress size={16} />,
          text: 'Loading',
          dotColor: theme.palette.grey[500],
        };
      case 'unknown':
      default:
        return {
          color: 'default' as const,
          icon: <UnknownIcon />,
          text: 'Unknown',
          dotColor: theme.palette.grey[500],
        };
    }
  };

  const config = getConfig(status);

  return (
    <Chip
      icon={config.icon}
      label={label || config.text}
      color={config.color}
      size="small"
      variant="outlined"
    />
  );
};

export default StatusIndicator;