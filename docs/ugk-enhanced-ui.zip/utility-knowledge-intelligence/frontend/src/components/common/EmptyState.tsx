/**
 * Reusable empty state components
 */

import React from 'react';
import {
  Box,
  Typography,
  Button,
} from '@mui/material';
import {
  Search as SearchIcon,
  Description as DocumentIcon,
  AccountTree as GraphIcon,
  Psychology as IntelligenceIcon,
  Add as AddIcon,
} from '@mui/icons-material';

interface EmptyStateProps {
  title: string;
  description?: string;
  action?: {
    label: string;
    onClick: () => void;
  };
  variant?: 'search' | 'documents' | 'graph' | 'intelligence' | 'generic';
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  title,
  description,
  action,
  variant = 'generic',
}) => {
  const getIcon = () => {
    switch (variant) {
      case 'search':
        return <SearchIcon sx={{ fontSize: 64, color: 'text.secondary' }} />;
      case 'documents':
        return <DocumentIcon sx={{ fontSize: 64, color: 'text.secondary' }} />;
      case 'graph':
        return <GraphIcon sx={{ fontSize: 64, color: 'text.secondary' }} />;
      case 'intelligence':
        return <IntelligenceIcon sx={{ fontSize: 64, color: 'text.secondary' }} />;
      default:
        return <AddIcon sx={{ fontSize: 64, color: 'text.secondary' }} />;
    }
  };

  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      py={8}
      px={3}
    >
      {getIcon()}
      <Typography variant="h6" color="textSecondary" sx={{ mt: 2, mb: 1 }}>
        {title}
      </Typography>
      {description && (
        <Typography
          variant="body2"
          color="textSecondary"
          align="center"
          sx={{ mb: 3, maxWidth: 400 }}
        >
          {description}
        </Typography>
      )}
      {action && (
        <Button variant="outlined" onClick={action.onClick}>
          {action.label}
        </Button>
      )}
    </Box>
  );
};

export const NoSearchResults: React.FC<{ query?: string; onClearSearch?: () => void }> = ({
  query,
  onClearSearch,
}) => {
  return (
    <EmptyState
      variant="search"
      title="No search results found"
      description={
        query
          ? `No results found for "${query}". Try adjusting your search terms.`
          : 'Start by entering a search query to find relevant information.'
      }
      action={
        onClearSearch
          ? {
              label: 'Clear Search',
              onClick: onClearSearch,
            }
          : undefined
      }
    />
  );
};

export const NoDocuments: React.FC<{ onUpload?: () => void }> = ({ onUpload }) => {
  return (
    <EmptyState
      variant="documents"
      title="No documents available"
      description="Upload documents to start building your knowledge base and enable intelligent queries."
      action={
        onUpload
          ? {
              label: 'Upload Documents',
              onClick: onUpload,
            }
          : undefined
      }
    />
  );
};

export const NoGraphData: React.FC = () => {
  return (
    <EmptyState
      variant="graph"
      title="No graph data available"
      description="The knowledge graph will appear here once documents are processed and entities are extracted."
    />
  );
};

export const NoIntelligenceData: React.FC = () => {
  return (
    <EmptyState
      variant="intelligence"
      title="No intelligence queries yet"
      description="Ask questions about your documents and knowledge base to get AI-powered insights."
    />
  );
};

export default EmptyState;