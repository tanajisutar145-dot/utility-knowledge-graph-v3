# Embedding System Documentation

## Overview

Phase 5A adds local text embedding capability using Sentence Transformers to the existing document/chunk pipeline. This enables semantic search over document chunks stored in Neo4j.

## Architecture

```
Documents → Phase 4 Chunking → Chunks → Local Embedding Model → Embeddings → Neo4j Vector Index → Semantic Search
```

## Configuration

### Environment Variables

Add to `.env` file:

```bash
# Embeddings
EMBEDDING_PROVIDER=sentence_transformers
EMBEDDING_MODEL=BAAI/bge-small-en-v1.5
EMBEDDING_DIMENSION=384
EMBEDDING_DEVICE=cpu
EMBEDDING_BATCH_SIZE=32
```

### Model Selection

- **Model**: BAAI/bge-small-en-v1.5
- **Dimension**: 384
- **Similarity Function**: cosine
- **Device**: CPU (for local development)
- **Provider**: Sentence Transformers (local, no API key required)

## Usage

### Generate Embeddings for All Chunks

```bash
cd backend
python -m app.graph embed
```

### Force Regenerate All Embeddings

```bash
python -m app.graph embed --force
```

### Custom Batch Size

```bash
python -m app.graph embed --batch-size 16
```

### Check Embedding Statistics

```bash
python -m app.graph embed-stats
```

### Test Vector Search

```bash
python -m app.graph vector-test "compressor blade failure"
python -m app.graph vector-test "abnormal vibration" --limit 3
python -m app.graph vector-test "mechanical seal" --threshold 0.8
```

### Initialize Schema (including vector index)

```bash
python -m app.graph init-schema
```

### View Schema Information

```bash
python -m app.graph schema-info
```

## Technical Details

### Embedding Service

- **Location**: `app/services/embedding_service.py`
- **Features**:
  - Lazy model loading
  - Batch processing
  - Empty text handling (zero vectors)
  - Embedding validation
  - Cosine similarity computation

### Embedding Manager

- **Location**: `app/graph/embeddings.py`
- **Features**:
  - Idempotent embedding generation
  - Batch processing with progress tracking
  - Neo4j integration
  - Vector similarity search
  - Statistics and monitoring

### Neo4j Integration

- **Vector Index**: `chunk_embedding_index`
- **Label**: `Chunk`
- **Property**: `embedding`
- **Dimensions**: 384
- **Similarity**: cosine

### Schema Extensions

- Added vector index creation to `app/graph/schema.py`
- Extended CLI in `app/graph/__main__.py`
- Preserved all existing constraints and indexes

## Data Flow

1. **Existing Chunks**: Use chunks created by Phase 4 document ingestion
2. **Embedding Generation**: 
   - Query chunks without valid embeddings
   - Generate embeddings in configurable batches
   - Store embeddings as properties on Chunk nodes
3. **Vector Search**:
   - Generate embedding for query text
   - Use Neo4j vector index for similarity search
   - Return ranked results with similarity scores

## Idempotency

- Embeddings are only generated for chunks that need them
- Existing valid embeddings are not regenerated unless `--force` is used
- Content-based validation ensures embedding consistency
- Safe to run multiple times

## Testing

Run embedding tests:

```bash
cd backend
python tests/test_embeddings.py
```

## Performance

- **Model Loading**: One-time initialization per process
- **Batch Processing**: Configurable batch size (default: 32)
- **Local Execution**: No external API calls required
- **CPU Optimized**: Uses CPU by default for consistent performance

## Integration with Existing System

- **Preserves Phase 1-4**: All existing functionality unchanged
- **Structured Graph**: 317 nodes + 318 relationships preserved
- **Document Layer**: 8 documents + 13 chunks with embeddings
- **Health Endpoint**: Continues to work normally
- **Frontend**: No changes required

## Future Phases

Phase 5A provides the foundation for:
- **Phase 5B**: GraphRAG and hybrid retrieval
- **Phase 5C**: AI answer generation with Groq
- **Advanced Search**: Combining vector search with graph traversal

## Troubleshooting

### Model Download Issues

The embedding model is downloaded automatically on first use. If download fails:

1. Check internet connection
2. Verify disk space (model is ~133MB)
3. Check HuggingFace Hub accessibility

### Vector Index Issues

If vector search fails:
1. Verify Neo4j version supports vector indexes
2. Check if vector index exists: `python -m app.graph schema-info`
3. Recreate schema: `python -m app.graph init-schema`

### Performance Optimization

For better performance:
- Increase `EMBEDDING_BATCH_SIZE` if memory allows
- Use GPU by setting `EMBEDDING_DEVICE=cuda` (requires CUDA)
- Consider smaller batch size if running out of memory