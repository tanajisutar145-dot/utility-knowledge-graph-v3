"""
Tests for synthetic data generation
"""

import pytest
from pathlib import Path
import tempfile
import shutil

from app.ingestion.data_generator import UtilityDataGenerator
from app.ingestion.data_validator import DataValidator


class TestDataGeneration:
    """Test synthetic data generation"""
    
    def test_data_generator_initialization(self):
        """Test data generator initialization"""
        generator = UtilityDataGenerator()
        
        assert generator.utilities == []
        assert generator.power_plants == []
        assert generator.generating_units == []
        assert len(generator.manufacturers) > 0
        assert len(generator.models) > 0
    
    def test_utility_generation(self):
        """Test utility data generation"""
        generator = UtilityDataGenerator()
        generator.generate_utility_data()
        
        assert len(generator.utilities) == 1
        utility = generator.utilities[0]
        assert utility.utility_id == "UTL-001"
        assert utility.name == "Pacific Power Corporation"
    
    def test_power_plant_generation(self):
        """Test power plant generation"""
        generator = UtilityDataGenerator()
        generator.generate_utility_data()
        generator.generate_power_plants()
        
        assert len(generator.power_plants) == 4
        plant_names = {plant.name for plant in generator.power_plants}
        assert "Riverside Combined Cycle Plant" in plant_names
        assert "Mountain View Natural Gas Plant" in plant_names
    
    def test_generating_unit_generation(self):
        """Test generating unit generation"""
        generator = UtilityDataGenerator()
        generator.generate_utility_data()
        generator.generate_power_plants()
        generator.generate_generating_units()
        
        assert len(generator.generating_units) > 0
        
        # Check that units reference valid plants
        plant_ids = {plant.plant_id for plant in generator.power_plants}
        for unit in generator.generating_units:
            assert unit.plant_id in plant_ids
    
    def test_asset_generation(self):
        """Test asset generation"""
        generator = UtilityDataGenerator()
        generator.generate_utility_data()
        generator.generate_power_plants()
        generator.generate_generating_units()
        generator.generate_assets()
        
        assert len(generator.assets) > 0
        
        # Check that assets reference valid units
        unit_ids = {unit.unit_id for unit in generator.generating_units}
        for asset in generator.assets:
            assert asset.unit_id in unit_ids
    
    def test_csv_file_writing(self):
        """Test CSV file writing"""
        with tempfile.TemporaryDirectory() as temp_dir:
            data_dir = Path(temp_dir)
            
            generator = UtilityDataGenerator()
            generator.generate_utility_data()
            generator.generate_power_plants()
            generator.write_csv_files(data_dir)
            
            # Check that CSV files were created
            assert (data_dir / "utilities.csv").exists()
            assert (data_dir / "power_plants.csv").exists()
            
            # Check file contents
            with open(data_dir / "utilities.csv", 'r') as f:
                content = f.read()
                assert "utility_id" in content
                assert "UTL-001" in content
    
    def test_data_validation_integration(self):
        """Test integration between data generation and validation"""
        with tempfile.TemporaryDirectory() as temp_dir:
            data_dir = Path(temp_dir)
            
            # Generate minimal dataset
            generator = UtilityDataGenerator()
            generator.generate_utility_data()
            generator.generate_power_plants()
            generator.generate_generating_units()
            generator.write_csv_files(data_dir)
            
            # Validate the generated data
            validator = DataValidator(data_dir)
            success = validator.validate_all_data()
            
            assert success, f"Validation failed with errors: {validator.errors}"
    
    def test_foreign_key_integrity(self):
        """Test that generated data maintains foreign key integrity"""
        generator = UtilityDataGenerator()
        generator.generate_all_data()
        
        # Check utility -> plant references
        utility_ids = {u.utility_id for u in generator.utilities}
        for plant in generator.power_plants:
            assert plant.utility_id in utility_ids
        
        # Check plant -> unit references  
        plant_ids = {p.plant_id for p in generator.power_plants}
        for unit in generator.generating_units:
            assert unit.plant_id in plant_ids
        
        # Check unit -> asset references
        unit_ids = {u.unit_id for u in generator.generating_units}
        for asset in generator.assets:
            assert asset.unit_id in unit_ids
        
        # Check asset -> component references
        asset_ids = {a.asset_id for a in generator.assets}
        for component in generator.components:
            assert component.asset_id in asset_ids
    
    def test_scenario_data_generation(self):
        """Test that scenario data is generated correctly"""
        generator = UtilityDataGenerator()
        generator.generate_all_data()
        
        # Should have some failures, inspections, work orders
        assert len(generator.failure_events) > 0
        assert len(generator.inspections) > 0
        assert len(generator.work_orders) > 0
        assert len(generator.heat_rate_tests) > 0
        
        # Check that failure-related work orders reference valid failures
        failure_ids = {f.failure_id for f in generator.failure_events}
        failure_work_orders = [wo for wo in generator.work_orders if wo.failure_id]
        
        for wo in failure_work_orders:
            assert wo.failure_id in failure_ids