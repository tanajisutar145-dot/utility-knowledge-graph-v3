"""
Tests for semantic retrieval and graph expansion
"""

try:
    import pytest
    HAS_PYTEST = True
except ImportError:
    HAS_PYTEST = False

from app.retrieval import semantic_retriever, RetrievalRequest
from app.services.embedding_service import embedding_service
from app.graph.neo4j_client import neo4j_client


class TestSemanticRetrieval:
    """Test semantic retrieval functionality"""
    
    def test_retrieval_request_model(self):
        """Test retrieval request model validation"""
        # Valid request
        request = RetrievalRequest(
            query="What caused the compressor failure?",
            top_k=5,
            graph_depth=1
        )
        assert request.query == "What caused the compressor failure?"
        assert request.top_k == 5
        assert request.graph_depth == 1
        
        # Test limits
        request_max = RetrievalRequest(
            query="test",
            top_k=20,  # max allowed
            graph_depth=3  # max allowed
        )
        assert request_max.top_k == 20
        assert request_max.graph_depth == 3
    
    def test_query_embedding_generation(self):
        """Test that query embeddings are generated correctly"""
        test_query = "compressor blade failure"
        embedding = embedding_service.embed_text(test_query)
        
        assert isinstance(embedding, list)
        assert len(embedding) == 384  # Expected dimension
        assert all(isinstance(x, float) for x in embedding)
    
    def test_semantic_retrieval_basic(self):
        """Test basic semantic retrieval functionality"""
        request = RetrievalRequest(
            query="compressor blade failure",
            top_k=3,
            graph_depth=0  # No graph expansion for basic test
        )
        
        result = semantic_retriever.retrieve(request)
        
        assert result.query == "compressor blade failure"
        assert isinstance(result.semantic_results, list)
        assert isinstance(result.metadata, dict)
        assert "execution_time" in result.metadata
        assert "retrieval_method" in result.metadata
    
    def test_semantic_retrieval_with_results(self):
        """Test semantic retrieval returns relevant results"""
        request = RetrievalRequest(
            query="compressor blade failure",
            top_k=5,
            graph_depth=1
        )
        
        result = semantic_retriever.retrieve(request)
        
        # Should have some results if embeddings exist
        if result.semantic_results:
            first_result = result.semantic_results[0]
            assert hasattr(first_result, 'chunk_id')
            assert hasattr(first_result, 'document_id')
            assert hasattr(first_result, 'text')
            assert hasattr(first_result, 'score')
            assert 0.0 <= first_result.score <= 1.0
    
    def test_graph_expansion(self):
        """Test graph expansion functionality"""
        request = RetrievalRequest(
            query="compressor blade failure",
            top_k=3,
            graph_depth=1  # Enable graph expansion
        )
        
        result = semantic_retriever.retrieve(request)
        
        assert hasattr(result, 'graph_evidence')
        assert hasattr(result.graph_evidence, 'entities')
        assert hasattr(result.graph_evidence, 'relationships')
        assert isinstance(result.graph_evidence.entities, list)
        assert isinstance(result.graph_evidence.relationships, list)
    
    def test_empty_query_handling(self):
        """Test handling of empty or whitespace queries"""
        request = RetrievalRequest(
            query="",
            top_k=5,
            graph_depth=1
        )
        
        result = semantic_retriever.retrieve(request)
        
        # Should handle gracefully without crashing
        assert result.query == ""
        assert isinstance(result.semantic_results, list)
    
    def test_no_results_handling(self):
        """Test handling when no results are found"""
        request = RetrievalRequest(
            query="extremely specific query that should match nothing xyz123",
            top_k=5,
            graph_depth=1,
            min_similarity=0.99  # Very high threshold
        )
        
        result = semantic_retriever.retrieve(request)
        
        # Should handle gracefully
        assert isinstance(result.semantic_results, list)
        assert isinstance(result.graph_evidence.entities, list)
        assert isinstance(result.graph_evidence.relationships, list)
    
    def test_similarity_threshold(self):
        """Test similarity threshold filtering"""
        request_low = RetrievalRequest(
            query="compressor",
            top_k=5,
            min_similarity=0.0  # Low threshold
        )
        
        request_high = RetrievalRequest(
            query="compressor",
            top_k=5,
            min_similarity=0.95  # High threshold
        )
        
        result_low = semantic_retriever.retrieve(request_low)
        result_high = semantic_retriever.retrieve(request_high)
        
        # High threshold should return fewer or equal results
        assert len(result_high.semantic_results) <= len(result_low.semantic_results)
    
    def test_top_k_limiting(self):
        """Test that top_k parameter limits results correctly"""
        request_small = RetrievalRequest(
            query="failure",
            top_k=2,
            graph_depth=0
        )
        
        request_large = RetrievalRequest(
            query="failure",
            top_k=10,
            graph_depth=0
        )
        
        result_small = semantic_retriever.retrieve(request_small)
        result_large = semantic_retriever.retrieve(request_large)
        
        # Small request should have <= results than large request
        assert len(result_small.semantic_results) <= len(result_large.semantic_results)
        # Small request should respect the limit
        assert len(result_small.semantic_results) <= 2


class TestGraphExpansion:
    """Test graph expansion functionality"""
    
    def test_entity_extraction(self):
        """Test extraction of entities from semantic results"""
        # This test requires actual data in Neo4j
        request = RetrievalRequest(
            query="compressor blade failure",
            top_k=3,
            graph_depth=1
        )
        
        result = semantic_retriever.retrieve(request)
        
        # If we have entities, they should have proper structure
        for entity in result.graph_evidence.entities:
            assert hasattr(entity, 'entity_id')
            assert hasattr(entity, 'entity_type')
            assert hasattr(entity, 'properties')
            assert isinstance(entity.properties, dict)
    
    def test_relationship_extraction(self):
        """Test extraction of relationships from graph"""
        request = RetrievalRequest(
            query="inspection failure",
            top_k=3,
            graph_depth=1
        )
        
        result = semantic_retriever.retrieve(request)
        
        # If we have relationships, they should have proper structure
        for relationship in result.graph_evidence.relationships:
            assert hasattr(relationship, 'source_id')
            assert hasattr(relationship, 'target_id')
            assert hasattr(relationship, 'relationship_type')
            assert hasattr(relationship, 'source_type')
            assert hasattr(relationship, 'target_type')


def run_integration_tests():
    """Run integration tests that require Neo4j data"""
    print("Running integration tests...")
    
    # Test with known scenario queries
    test_queries = [
        "What inspections preceded the compressor blade failure?",
        "What caused the compressor blade failure?", 
        "Which pump experienced repeated mechanical failures?",
        "How did heat rate change over time?",
        "abnormal vibration",
        "mechanical seal failure"
    ]
    
    for query in test_queries:
        print(f"\nTesting query: '{query}'")
        
        request = RetrievalRequest(
            query=query,
            top_k=3,
            graph_depth=1
        )
        
        try:
            result = semantic_retriever.retrieve(request)
            print(f"  Semantic results: {len(result.semantic_results)}")
            print(f"  Graph entities: {len(result.graph_evidence.entities)}")
            print(f"  Graph relationships: {len(result.graph_evidence.relationships)}")
            print(f"  Execution time: {result.metadata.get('execution_time', 0):.3f}s")
            
            if result.semantic_results:
                top_result = result.semantic_results[0]
                print(f"  Top result: {top_result.document_id} (score: {top_result.score:.4f})")
            
        except Exception as e:
            print(f"  ERROR: {e}")


if __name__ == "__main__":
    # Simple test runner if pytest is not available
    test_retrieval = TestSemanticRetrieval()
    test_expansion = TestGraphExpansion()
    
    try:
        print("Testing retrieval request model...")
        test_retrieval.test_retrieval_request_model()
        print("✓ Passed")
        
        print("Testing query embedding generation...")
        test_retrieval.test_query_embedding_generation()
        print("✓ Passed")
        
        print("Testing semantic retrieval basic...")
        test_retrieval.test_semantic_retrieval_basic()
        print("✓ Passed")
        
        print("Testing semantic retrieval with results...")
        test_retrieval.test_semantic_retrieval_with_results()
        print("✓ Passed")
        
        print("Testing graph expansion...")
        test_retrieval.test_graph_expansion()
        print("✓ Passed")
        
        print("Testing empty query handling...")
        test_retrieval.test_empty_query_handling()
        print("✓ Passed")
        
        print("Testing no results handling...")
        test_retrieval.test_no_results_handling()
        print("✓ Passed")
        
        print("Testing similarity threshold...")
        test_retrieval.test_similarity_threshold()
        print("✓ Passed")
        
        print("Testing top_k limiting...")
        test_retrieval.test_top_k_limiting()
        print("✓ Passed")
        
        print("Testing entity extraction...")
        test_expansion.test_entity_extraction()
        print("✓ Passed")
        
        print("Testing relationship extraction...")
        test_expansion.test_relationship_extraction()
        print("✓ Passed")
        
        print("\n" + "="*50)
        print("All unit tests passed! ✓")
        print("="*50)
        
        # Run integration tests
        run_integration_tests()
        
        print("\n" + "="*50)
        print("All tests completed! ✓")
        print("="*50)
        
    except Exception as e:
        print(f"Test failed: {e}")
        import traceback
        traceback.print_exc()