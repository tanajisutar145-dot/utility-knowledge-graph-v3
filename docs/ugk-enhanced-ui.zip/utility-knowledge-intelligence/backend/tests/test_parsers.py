"""
Comprehensive unit tests for modular document parsers, structure-aware chunking, and factory resolution
"""

import io
import json
import unittest
import fitz
import openpyxl
import docx

from app.documents.parsers import (
    PDFParser,
    ExcelParser,
    CSVParser,
    WordParser,
    TextParser,
    JSONParser,
    get_parser_for_file,
    SUPPORTED_EXTENSIONS,
)
from app.documents.parsers.factory import LEGACY_EXTENSIONS
from app.documents.models import Document, DocumentType
from app.documents.chunker import DocumentChunker


class TestDocumentParsers(unittest.TestCase):
    """Test suite covering format extraction, error resilience, provenance, and chunking"""

    def test_parser_factory_resolution(self):
        """Verify factory resolves each supported extension and rejects unsupported formats"""
        self.assertIsInstance(get_parser_for_file("doc.pdf"), PDFParser)
        self.assertIsInstance(get_parser_for_file("sheet.xlsx"), ExcelParser)
        self.assertIsInstance(get_parser_for_file("data.csv"), CSVParser)
        self.assertIsInstance(get_parser_for_file("report.docx"), WordParser)
        self.assertIsInstance(get_parser_for_file("notes.txt"), TextParser)
        self.assertIsInstance(get_parser_for_file("record.json"), JSONParser)

        # Legacy XLS rejection
        with self.assertRaises(ValueError) as ctx_xls:
            get_parser_for_file("legacy_sheet.xls")
        self.assertIn("Legacy Excel (.xls) format is not supported", str(ctx_xls.exception))

        # Unsupported formats
        with self.assertRaises(ValueError) as ctx_unsupported:
            get_parser_for_file("archive.zip")
        self.assertIn("Unsupported file format", str(ctx_unsupported.exception))

    def test_pdf_multi_page_extraction_and_metadata(self):
        """Verify multi-page PDF text extraction and page provenance"""
        doc = fitz.open()
        p1 = doc.new_page()
        p1.insert_text((50, 72), "Unit 1 Gas Turbine routine inspection notes on page 1.")
        p2 = doc.new_page()
        p2.insert_text((50, 72), "Vibration analysis indicates normal operation on page 2.")
        doc.set_metadata({"title": "Turbine Inspection Report", "author": "Field Engineer"})
        pdf_bytes = doc.tobytes()
        doc.close()

        parser = PDFParser()
        result = parser.parse(pdf_bytes, "turbine_inspection.pdf")

        self.assertEqual(result.format, "pdf")
        self.assertEqual(result.title, "Turbine Inspection Report")
        self.assertEqual(result.page_count, 2)
        self.assertEqual(len(result.sections), 2)
        self.assertEqual(result.sections[0].page_number, 1)
        self.assertEqual(result.sections[1].page_number, 2)
        self.assertIn("routine inspection notes on page 1", result.sections[0].content)
        self.assertIn("normal operation on page 2", result.sections[1].content)
        self.assertEqual(len(result.warnings), 0)

    def test_pdf_empty_and_scanned_detection(self):
        """Verify detection of image-only / scanned PDFs emits clear OCR-required warning"""
        doc = fitz.open()
        page = doc.new_page()
        # Insert a small synthetic RGB image without text
        pix = fitz.Pixmap(fitz.csRGB, fitz.IRect(0, 0, 100, 100), 0)
        pix.clear_with(255)
        page.insert_image(page.rect, pixmap=pix)
        scanned_bytes = doc.tobytes()
        doc.close()

        parser = PDFParser()
        result = parser.parse(scanned_bytes, "scanned_invoice.pdf")
        self.assertEqual(result.format, "pdf")
        self.assertTrue(any("OCR is required" in w for w in result.warnings))

    def test_pdf_malformed_handling(self):
        """Verify malformed PDF bytes raise clear descriptive error"""
        parser = PDFParser()
        with self.assertRaises(ValueError) as ctx:
            parser.parse(b"NOT A REAL PDF HEADER", "corrupt.pdf")
        self.assertIn("Failed to open PDF document", str(ctx.exception))

    def test_excel_multi_sheet_and_row_provenance(self):
        """Verify XLSX extracts multiple sheets, headers, and record batches with row ranges"""
        wb = openpyxl.Workbook()
        ws1 = wb.active
        ws1.title = "Assets"
        ws1.append(["AssetID", "Name", "Criticality"])
        ws1.append(["AST-001", "Unit 1 GT", "critical"])
        ws1.append(["AST-002", "Generator 1", "high"])

        ws2 = wb.create_sheet(title="Inspections")
        ws2.append(["InspectionID", "Status", "Notes"])
        ws2.append(["INS-101", "PASSED", "Blades in good condition"])

        buf = io.BytesIO()
        wb.save(buf)
        xlsx_bytes = buf.getvalue()

        parser = ExcelParser()
        result = parser.parse(xlsx_bytes, "plant_inventory.xlsx")

        self.assertEqual(result.format, "xlsx")
        self.assertEqual(result.sheet_names, ["Assets", "Inspections"])
        self.assertEqual(len(result.sections), 2)

        # First section
        sec1 = result.sections[0]
        self.assertEqual(sec1.sheet_name, "Assets")
        self.assertEqual(sec1.row_start, 2)
        self.assertEqual(sec1.row_end, 3)
        self.assertIn("AssetID: AST-001", sec1.content)

        # Second section
        sec2 = result.sections[1]
        self.assertEqual(sec2.sheet_name, "Inspections")
        self.assertEqual(sec2.row_start, 2)
        self.assertEqual(sec2.row_end, 2)
        self.assertIn("InspectionID: INS-101", sec2.content)

    def test_excel_empty_workbook_and_malformed(self):
        """Verify handling of empty sheets and corrupted Excel files"""
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "EmptySheet"
        buf = io.BytesIO()
        wb.save(buf)
        empty_xlsx = buf.getvalue()

        parser = ExcelParser()
        res = parser.parse(empty_xlsx, "empty.xlsx")
        self.assertTrue(len(res.warnings) > 0)

        with self.assertRaises(ValueError):
            parser.parse(b"Corrupted Excel Bytes", "corrupt.xlsx")

    def test_csv_extraction_encoding_and_rows(self):
        """Verify CSV parsing with unicode content, delimiter sniffing, and row ranges"""
        csv_text = "Asset ID,Asset Name,Rating\nAST-001,Turbine α,250 MW\nAST-002,Generator β,300 MVA\n"
        csv_bytes = csv_text.encode("utf-8-sig")

        parser = CSVParser()
        result = parser.parse(csv_bytes, "equipment_list.csv")

        self.assertEqual(result.format, "csv")
        self.assertEqual(len(result.sections), 1)
        sec = result.sections[0]
        self.assertEqual(sec.row_start, 2)
        self.assertEqual(sec.row_end, 3)
        self.assertIn("Turbine α", sec.content)
        self.assertIn("Generator β", sec.content)

    def test_csv_empty_and_malformed(self):
        """Verify empty CSV produces clear warning or error"""
        parser = CSVParser()
        with self.assertRaises(ValueError):
            parser.parse(b"", "empty.csv")

    def test_docx_paragraphs_headings_and_tables(self):
        """Verify Word document extraction preserving heading context, ordering, and tables"""
        doc = docx.Document()
        doc.add_heading("Section 1: General Inspection", level=1)
        doc.add_paragraph("Visual inspection of the combustion chamber completed.")
        doc.add_heading("Section 2: Measurements Table", level=1)

        table = doc.add_table(rows=2, cols=2)
        table.rows[0].cells[0].text = "Sensor"
        table.rows[0].cells[1].text = "Value"
        table.rows[1].cells[0].text = "Bearing Temperature"
        table.rows[1].cells[1].text = "68 C"

        buf = io.BytesIO()
        doc.save(buf)
        docx_bytes = buf.getvalue()

        parser = WordParser()
        result = parser.parse(docx_bytes, "inspection_findings.docx")

        self.assertEqual(result.format, "docx")
        self.assertEqual(result.table_count, 1)
        self.assertGreaterEqual(len(result.sections), 2)
        self.assertIn("combustion chamber", result.sections[0].content)
        self.assertIn("Bearing Temperature", result.sections[1].content)

    def test_txt_and_json_regression(self):
        """Verify TXT and JSON extractors preserve existing working behavior"""
        # TXT
        txt_parser = TextParser()
        txt_res = txt_parser.parse(b"Line 1 text.\n\nLine 2 text.", "report.txt")
        self.assertEqual(txt_res.format, "txt")
        self.assertIn("Line 1 text", txt_res.content)

        # JSON
        json_parser = JSONParser()
        data = {
            "document_id": "DOC-TEST-01",
            "title": "Substation Log",
            "document_type": "operational_note",
            "content": "Substation breaker test completed successfully.",
            "asset_id": "AST-005"
        }
        json_res = json_parser.parse(json.dumps(data).encode("utf-8"), "substation.json")
        self.assertEqual(json_res.format, "json")
        self.assertEqual(json_res.title, "Substation Log")
        self.assertIn("Substation breaker test", json_res.content)
        self.assertEqual(json_res.metadata.get("document_id"), "DOC-TEST-01")
        self.assertEqual(json_res.metadata.get("asset_id"), "AST-005")

    def test_structure_aware_chunking_provenance(self):
        """Verify DocumentChunker preserves page, sheet, row, and heading metadata on Chunk objects"""
        chunker = DocumentChunker(chunk_size=500, overlap=50)

        # Document with PDF sections
        doc = Document(
            document_id="DOC-PROV-01",
            title="Provenance Test",
            document_type=DocumentType.INSPECTION_REPORT,
            source="Manual",
            created_date="2026-10-14T10:00:00",
            content="Page 1 text content.\n\nPage 2 text content.",
            metadata={
                "format": "pdf",
                "source_filename": "manual.pdf",
                "sections": [
                    {"content": "Page 1: Turbine inlet inspection normal.", "page_number": 1, "title": "Page 1"},
                    {"content": "Page 2: Exhaust thermocouple readings stable.", "page_number": 2, "title": "Page 2"}
                ]
            }
        )

        chunks = chunker.chunk_document(doc)
        self.assertEqual(len(chunks), 2)
        self.assertEqual(chunks[0].metadata.get("page_number"), 1)
        self.assertEqual(chunks[0].metadata.get("format"), "pdf")
        self.assertEqual(chunks[0].metadata.get("source_filename"), "manual.pdf")
        self.assertEqual(chunks[1].metadata.get("page_number"), 2)

        # Document with Excel spreadsheet sections
        excel_doc = Document(
            document_id="DOC-PROV-02",
            title="Excel Provenance",
            document_type=DocumentType.MAINTENANCE_REPORT,
            source="Upload",
            created_date="2026-10-14T10:00:00",
            content="Tabular data",
            metadata={
                "format": "xlsx",
                "source_filename": "data.xlsx",
                "sections": [
                    {
                        "content": "Row 2: AST-001, Generator | Row 3: AST-002, Transformer",
                        "sheet_name": "Assets",
                        "row_start": 2,
                        "row_end": 3
                    }
                ]
            }
        )
        xl_chunks = chunker.chunk_document(excel_doc)
        self.assertEqual(len(xl_chunks), 1)
        self.assertEqual(xl_chunks[0].metadata.get("sheet_name"), "Assets")
        self.assertEqual(xl_chunks[0].metadata.get("row_range"), "Rows 2-3")


if __name__ == "__main__":
    unittest.main()
