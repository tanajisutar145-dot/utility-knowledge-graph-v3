"""
Tests for embedding functionality
"""

try:
    import pytest
    HAS_PYTEST = True
except ImportError:
    HAS_PYTEST = False

from app.services.embedding_service import embedding_service
from app.graph.embeddings import embedding_manager
from app.core.config import settings


class TestEmbeddingService:
    """Test the embedding service"""
    
    def test_embedding_service_initialization(self):
        """Test that embedding service initializes correctly"""
        assert embedding_service.model_name == settings.embedding_model
        assert embedding_service.dimension == settings.embedding_dimension
        assert embedding_service.device == settings.embedding_device
    
    def test_single_text_embedding(self):
        """Test embedding generation for single text"""
        text = "This is a test document about compressor failure"
        embedding = embedding_service.embed_text(text)
        
        assert isinstance(embedding, list)
        assert len(embedding) == settings.embedding_dimension
        assert all(isinstance(x, float) for x in embedding)
    
    def test_batch_text_embedding(self):
        """Test embedding generation for multiple texts"""
        texts = [
            "Compressor blade failure analysis",
            "Heat rate performance degradation", 
            "Mechanical seal replacement procedure"
        ]
        embeddings = embedding_service.embed_texts(texts)
        
        assert len(embeddings) == len(texts)
        for embedding in embeddings:
            assert len(embedding) == settings.embedding_dimension
            assert all(isinstance(x, float) for x in embedding)
    
    def test_empty_text_handling(self):
        """Test handling of empty text"""
        embedding = embedding_service.embed_text("")
        assert len(embedding) == settings.embedding_dimension
        assert all(x == 0.0 for x in embedding)
    
    def test_embedding_validation(self):
        """Test embedding validation"""
        valid_embedding = [0.1] * settings.embedding_dimension
        invalid_embedding_wrong_size = [0.1] * (settings.embedding_dimension - 1)
        
        assert embedding_service.is_valid_embedding(valid_embedding) == True
        assert embedding_service.is_valid_embedding(invalid_embedding_wrong_size) == False
        assert embedding_service.is_valid_embedding(None) == False
        assert embedding_service.is_valid_embedding([]) == False
    
    def test_similarity_computation(self):
        """Test cosine similarity computation"""
        # Identical vectors should have similarity of 1
        vec1 = [1.0, 0.0, 0.0]
        vec2 = [1.0, 0.0, 0.0]
        similarity = embedding_service.compute_similarity(vec1, vec2)
        assert abs(similarity - 1.0) < 0.001
        
        # Orthogonal vectors should have similarity near 0
        vec3 = [1.0, 0.0, 0.0]
        vec4 = [0.0, 1.0, 0.0]
        similarity = embedding_service.compute_similarity(vec3, vec4)
        assert abs(similarity) < 0.001


class TestEmbeddingManager:
    """Test the embedding manager"""
    
    def test_embedding_stats(self):
        """Test getting embedding statistics"""
        stats = embedding_manager.get_embedding_stats()
        
        assert 'total_chunks' in stats
        assert 'chunks_with_embeddings' in stats
        assert 'chunks_without_embeddings' in stats
        assert 'embedding_model' in stats
        assert 'embedding_dimension' in stats
        
        assert isinstance(stats['total_chunks'], int)
        assert isinstance(stats['chunks_with_embeddings'], int)
        assert isinstance(stats['chunks_without_embeddings'], int)
    
    def test_vector_search(self):
        """Test vector similarity search"""
        # Test with a query that should match existing content
        results = embedding_manager.vector_search("compressor failure", limit=3)
        
        assert isinstance(results, list)
        if results:  # Only test if we have results
            for result in results:
                assert 'chunk_id' in result
                assert 'document_id' in result
                assert 'similarity_score' in result
                assert isinstance(result['similarity_score'], float)
                assert 0.0 <= result['similarity_score'] <= 1.0


if __name__ == "__main__":
    # Simple test runner if pytest is not available
    test_service = TestEmbeddingService()
    test_manager = TestEmbeddingManager()
    
    try:
        print("Testing embedding service initialization...")
        test_service.test_embedding_service_initialization()
        print("✓ Passed")
        
        print("Testing single text embedding...")
        test_service.test_single_text_embedding()
        print("✓ Passed")
        
        print("Testing batch text embedding...")
        test_service.test_batch_text_embedding()
        print("✓ Passed")
        
        print("Testing empty text handling...")
        test_service.test_empty_text_handling()
        print("✓ Passed")
        
        print("Testing embedding validation...")
        test_service.test_embedding_validation()
        print("✓ Passed")
        
        print("Testing similarity computation...")
        test_service.test_similarity_computation()
        print("✓ Passed")
        
        print("Testing embedding stats...")
        test_manager.test_embedding_stats()
        print("✓ Passed")
        
        print("Testing vector search...")
        test_manager.test_vector_search()
        print("✓ Passed")
        
        print("\nAll tests passed! ✓")
        
    except Exception as e:
        print(f"Test failed: {e}")
        import traceback
        traceback.print_exc()