"""
Unit and integration tests for Document Management and Asset Management APIs
"""

import unittest
import requests

from app.services.document_service import document_service
from app.services.asset_service import asset_service


class TestDocumentsAndAssetsAPI(unittest.TestCase):
    """Test suite for Phase 6F Document and Asset management endpoints"""

    BASE_DOCS_URL = "http://localhost:8000/api/documents"
    BASE_ASSETS_URL = "http://localhost:8000/api/assets"

    def test_document_overview(self):
        """Verify document overview returns real counts and vector index status"""
        response = requests.get(f"{self.BASE_DOCS_URL}/overview")
        self.assertEqual(response.status_code, 200)
        data = response.json()

        self.assertEqual(data["total_documents"], 8)
        self.assertEqual(data["total_chunks"], 13)
        self.assertEqual(data["embedded_chunks"], 13)
        self.assertEqual(data["vector_index_name"], "chunk_embedding_index")
        self.assertEqual(data["vector_index_status"], "ONLINE")
        self.assertIn("inspection_report", data["document_types"])
        self.assertIn("failure_report", data["document_types"])

    def test_document_list_and_filtering(self):
        """Verify document listing, search, and type filtering"""
        # List all
        res = requests.get(f"{self.BASE_DOCS_URL}/")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["total"], 8)
        self.assertEqual(len(data["documents"]), 8)

        # Filter by document_type
        res_filtered = requests.get(f"{self.BASE_DOCS_URL}/?document_type=inspection_report")
        self.assertEqual(res_filtered.status_code, 200)
        filtered_data = res_filtered.json()
        self.assertGreater(filtered_data["total"], 0)
        for doc in filtered_data["documents"]:
            self.assertEqual(doc["document_type"], "inspection_report")

        # Search filter
        res_search = requests.get(f"{self.BASE_DOCS_URL}/?search=vibration")
        self.assertEqual(res_search.status_code, 200)
        search_data = res_search.json()
        self.assertGreater(search_data["total"], 0)

    def test_document_detail_lookup(self):
        """Verify document detail returns content, chunks, and entity links safely"""
        res = requests.get(f"{self.BASE_DOCS_URL}/DOC-001")
        self.assertEqual(res.status_code, 200)
        data = res.json()

        self.assertEqual(data["document_id"], "DOC-001")
        self.assertIn("Routine GT Inspection", data["title"])
        self.assertTrue(len(data["content"]) > 0)
        self.assertGreater(len(data["chunks"]), 0)

        # Check chunk structure (no raw float vectors exposed)
        chunk = data["chunks"][0]
        self.assertIn("chunk_id", chunk)
        self.assertIn("text", chunk)
        self.assertTrue(chunk["is_embedded"])
        self.assertNotIn("embedding", chunk["metadata"])

        # Check linked entities
        self.assertGreater(len(data["linked_entities"]), 0)
        first_entity = data["linked_entities"][0]
        self.assertIn("relationship", first_entity)
        self.assertIn("entity_id", first_entity)

    def test_document_not_found(self):
        """Verify non-existent document returns 404"""
        res = requests.get(f"{self.BASE_DOCS_URL}/DOC-DOES-NOT-EXIST")
        self.assertEqual(res.status_code, 404)

    def test_document_upload_validation(self):
        """Verify upload endpoint validates file types and contents"""
        # Unsupported extension (.exe)
        files = {"file": ("unsupported.exe", b"Dummy EXE content", "application/octet-stream")}
        res = requests.post(f"{self.BASE_DOCS_URL}/upload", files=files)
        self.assertEqual(res.status_code, 400)
        self.assertIn("Unsupported file format", res.json()["detail"])

        # Legacy Excel (.xls) rejection
        xls_files = {"file": ("legacy.xls", b"Legacy Excel binary content", "application/vnd.ms-excel")}
        res_xls = requests.post(f"{self.BASE_DOCS_URL}/upload", files=xls_files)
        self.assertEqual(res_xls.status_code, 400)
        self.assertIn("Legacy Excel (.xls) format is not supported", res_xls.json()["detail"])

        # Empty file
        empty_files = {"file": ("empty.txt", b"", "text/plain")}
        res_empty = requests.post(f"{self.BASE_DOCS_URL}/upload", files=empty_files)
        self.assertEqual(res_empty.status_code, 400)

    def test_asset_overview(self):
        """Verify asset overview returns real total count and breakdowns"""
        res = requests.get(f"{self.BASE_ASSETS_URL}/overview")
        self.assertEqual(res.status_code, 200)
        data = res.json()

        self.assertEqual(data["total_assets"], 57)
        self.assertEqual(data["operational_assets"], 57)
        self.assertEqual(data["assets_with_failures"], 2)
        self.assertIn("gas_turbine", data["asset_class_counts"])
        self.assertIn("critical", data["criticality_counts"])
        self.assertIn("operational", data["status_counts"])

    def test_asset_list_and_filtering(self):
        """Verify asset inventory search, pagination, and filters"""
        # List with limit
        res = requests.get(f"{self.BASE_ASSETS_URL}/?limit=10")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["total"], 57)
        self.assertEqual(len(data["assets"]), 10)

        # Filter by asset_class
        res_gt = requests.get(f"{self.BASE_ASSETS_URL}/?asset_class=gas_turbine")
        self.assertEqual(res_gt.status_code, 200)
        gt_data = res_gt.json()
        self.assertEqual(gt_data["total"], 5)
        for a in gt_data["assets"]:
            self.assertEqual(a["asset_class"], "gas_turbine")

        # Filter by criticality
        res_crit = requests.get(f"{self.BASE_ASSETS_URL}/?criticality=critical")
        self.assertEqual(res_crit.status_code, 200)
        crit_data = res_crit.json()
        self.assertEqual(crit_data["total"], 20)

        # Search query matching model or manufacturer
        res_search = requests.get(f"{self.BASE_ASSETS_URL}/?search=Mitsubishi")
        self.assertEqual(res_search.status_code, 200)
        search_data = res_search.json()
        self.assertGreater(search_data["total"], 0)

    def test_asset_detail_lookup(self):
        """Verify asset detail returns complete relational hierarchy"""
        res = requests.get(f"{self.BASE_ASSETS_URL}/AST-001")
        self.assertEqual(res.status_code, 200)
        data = res.json()

        # Base asset
        asset = data["asset"]
        self.assertEqual(asset["asset_id"], "AST-001")
        self.assertEqual(asset["name"], "Unit 1 GT Gas Turbine")
        self.assertEqual(asset["asset_class"], "gas_turbine")
        self.assertEqual(asset["criticality"], "critical")

        # Parent hierarchy
        hierarchy = data["hierarchy"]
        self.assertIsNotNone(hierarchy["generating_unit"])
        self.assertEqual(hierarchy["generating_unit"]["unit_name"], "Unit 1 GT")
        self.assertIsNotNone(hierarchy["power_plant"])
        self.assertEqual(hierarchy["power_plant"]["name"], "Riverside Combined Cycle Plant")

        # Connected components
        self.assertEqual(len(data["components"]), 3)
        # Inspections
        self.assertEqual(len(data["inspections"]), 2)
        # Work orders
        self.assertEqual(len(data["work_orders"]), 3)
        # Failures
        self.assertEqual(len(data["failures"]), 1)
        # Maintenance plans
        self.assertEqual(len(data["maintenance_plans"]), 2)
        # Outages
        self.assertGreaterEqual(len(data["outages"]), 1)
        # Documents
        self.assertEqual(len(data["documents"]), 3)

    def test_asset_not_found(self):
        """Verify non-existent asset returns 404"""
        res = requests.get(f"{self.BASE_ASSETS_URL}/AST-DOES-NOT-EXIST")
        self.assertEqual(res.status_code, 404)

    def test_read_only_data_integrity(self):
        """Verify database node counts remain untouched after read queries"""
        res_docs = requests.get(f"{self.BASE_DOCS_URL}/overview")
        self.assertEqual(res_docs.json()["total_documents"], 8)
        self.assertEqual(res_docs.json()["total_chunks"], 13)

        res_assets = requests.get(f"{self.BASE_ASSETS_URL}/overview")
        self.assertEqual(res_assets.json()["total_assets"], 57)


if __name__ == "__main__":
    unittest.main()
