"""
Unit and integration tests for Knowledge Graph API endpoints and service
"""

import unittest
from unittest.mock import patch
import requests

from app.graph.neo4j_client import neo4j_client
from app.services.graph_service import graph_service


class TestGraphAPI(unittest.TestCase):
    """Tests for Knowledge Graph API endpoints and services"""

    BASE_URL = "http://localhost:8000/api/graph"

    def test_graph_overview_counts(self):
        """Verify overview endpoint returns correct total counts and grouped labels"""
        response = requests.get(f"{self.BASE_URL}/overview")
        self.assertEqual(response.status_code, 200)
        data = response.json()

        self.assertEqual(data["total_nodes"], 338)
        self.assertEqual(data["total_relationships"], 346)
        self.assertIn("Asset", data["node_counts_by_label"])
        self.assertIn("PowerPlant", data["node_counts_by_label"])
        self.assertEqual(data["node_counts_by_label"]["PowerPlant"], 4)
        self.assertEqual(data["node_counts_by_label"]["Asset"], 57)
        self.assertIn("HAS_PLANT", data["relationship_counts_by_type"])
        self.assertIn("HAS_ASSET", data["relationship_counts_by_type"])

    def test_node_and_relationship_serialization(self):
        """Verify nodes and relationships serialize with correct fields and types"""
        response = requests.get(f"{self.BASE_URL}/explore?limit=10")
        self.assertEqual(response.status_code, 200)
        data = response.json()

        self.assertGreater(data["total_nodes"], 0)
        first_node = data["nodes"][0]
        self.assertIn("id", first_node)
        self.assertIn("label", first_node)
        self.assertIn("name", first_node)
        self.assertIn("properties", first_node)
        self.assertIsInstance(first_node["properties"], dict)

        if data["relationships"]:
            first_rel = data["relationships"][0]
            self.assertIn("id", first_rel)
            self.assertIn("source", first_rel)
            self.assertIn("target", first_rel)
            self.assertIn("type", first_rel)

    def test_search_and_label_filtering(self):
        """Verify filtering by node_label and search query"""
        # Test label filter
        response = requests.get(f"{self.BASE_URL}/explore?node_label=PowerPlant")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["total_nodes"], 4)
        for node in data["nodes"]:
            self.assertEqual(node["label"], "PowerPlant")

        # Test search query
        response = requests.get(f"{self.BASE_URL}/explore?query=Riverside")
        self.assertEqual(response.status_code, 200)
        search_data = response.json()
        self.assertGreater(search_data["total_nodes"], 0)
        self.assertTrue(any("Riverside" in n["name"] for n in search_data["nodes"]))

    def test_result_limit_enforcement(self):
        """Verify result-limit is strictly enforced (max 250)"""
        # Explicit small limit
        res_small = requests.get(f"{self.BASE_URL}/explore?limit=15")
        self.assertEqual(res_small.status_code, 200)
        self.assertEqual(res_small.json()["total_nodes"], 15)

        # Upper bound limit rejection by FastAPI schema
        res_capped = requests.get(f"{self.BASE_URL}/explore?limit=500")
        self.assertEqual(res_capped.status_code, 422)

        # Maximum allowed bound (250)
        res_max = requests.get(f"{self.BASE_URL}/explore?limit=250")
        self.assertEqual(res_max.status_code, 200)
        self.assertLessEqual(res_max.json()["total_nodes"], 250)

    def test_node_lookup_by_element_id(self):
        """Verify node lookup by stable elementId"""
        # First retrieve a node
        explore = requests.get(f"{self.BASE_URL}/explore?limit=1").json()
        target_id = explore["nodes"][0]["id"]

        response = requests.get(f"{self.BASE_URL}/node/{target_id}")
        self.assertEqual(response.status_code, 200)
        detail = response.json()
        self.assertEqual(detail["node"]["id"], target_id)
        self.assertIn("connected_count", detail)
        self.assertIn("connected_by_type", detail)

    def test_neighbor_expansion(self):
        """Verify expanding immediate neighbors around a center node"""
        # Get a PowerPlant node
        plants = requests.get(f"{self.BASE_URL}/explore?node_label=PowerPlant&limit=1").json()
        plant_id = plants["nodes"][0]["id"]

        response = requests.get(f"{self.BASE_URL}/node/{plant_id}/neighbors?limit=20")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["center_node"]["id"], plant_id)
        self.assertGreater(data["total_neighbors"], 0)
        self.assertGreater(len(data["relationships"]), 0)

    def test_unknown_node_handling(self):
        """Verify 404 response when querying non-existent node ID"""
        response = requests.get(f"{self.BASE_URL}/node/non_existent_element_id_12345")
        self.assertEqual(response.status_code, 404)

        neighbor_response = requests.get(f"{self.BASE_URL}/node/non_existent_element_id_12345/neighbors")
        self.assertEqual(neighbor_response.status_code, 404)

    def test_neo4j_unavailable_behavior(self):
        """Verify graceful 503 error when database is disconnected"""
        with patch.object(neo4j_client, "verify_connectivity", return_value=False):
            with self.assertRaises(Exception) as exc_info:
                graph_service.get_overview()
            self.assertIn("503", str(exc_info.exception))

    def test_read_only_graph_integrity(self):
        """Verify graph explore operations do not alter node or relationship counts"""
        before_nodes = neo4j_client.get_node_count()
        before_rels = neo4j_client.get_relationship_count()

        # Run explore, detail, and neighbor queries
        requests.get(f"{self.BASE_URL}/explore?limit=100")
        requests.get(f"{self.BASE_URL}/overview")

        after_nodes = neo4j_client.get_node_count()
        after_rels = neo4j_client.get_relationship_count()

        self.assertEqual(before_nodes, after_nodes)
        self.assertEqual(before_rels, after_rels)

    def test_existing_dashboard_regression(self):
        """Verify Phase 6B dashboard endpoint remains healthy and functional"""
        dash_res = requests.get("http://localhost:8000/api/dashboard/summary")
        self.assertEqual(dash_res.status_code, 200)
        data = dash_res.json()
        self.assertEqual(data["status"], "healthy")
        self.assertEqual(data["kpis"]["assets"], 57)


if __name__ == "__main__":
    unittest.main()
