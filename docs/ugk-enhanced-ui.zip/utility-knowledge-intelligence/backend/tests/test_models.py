"""
Tests for utility domain models
"""

import pytest
from datetime import datetime, date
from pydantic import ValidationError

from app.models.utility_models import (
    Utility, PowerPlant, GeneratingUnit, Asset, Component,
    Inspection, FailureEvent, WorkOrder, MaintenancePlan,
    OutageEvent, HeatRateTest,
    UtilityStatus, PlantType, UnitType, OperationalStatus,
    AssetClass, CriticalityLevel, InspectionType, ConditionRating
)


class TestUtilityModels:
    """Test utility domain models"""
    
    def test_utility_model_valid(self):
        """Test valid utility model creation"""
        utility = Utility(
            utility_id="UTL-001",
            name="Test Utility",
            region="Test Region",
            country="Test Country",
            description="Test utility description",
            status=UtilityStatus.ACTIVE
        )
        
        assert utility.utility_id == "UTL-001"
        assert utility.name == "Test Utility"
        assert utility.status == UtilityStatus.ACTIVE
    
    def test_power_plant_model_valid(self):
        """Test valid power plant model creation"""
        plant = PowerPlant(
            plant_id="PLT-001",
            utility_id="UTL-001",
            name="Test Plant",
            location="Test Location",
            plant_type=PlantType.NATURAL_GAS,
            capacity_mw=100.0,
            commissioning_date=date(2020, 1, 1),
            status=OperationalStatus.OPERATIONAL
        )
        
        assert plant.plant_id == "PLT-001"
        assert plant.capacity_mw == 100.0
        assert plant.plant_type == PlantType.NATURAL_GAS
    
    def test_power_plant_invalid_capacity(self):
        """Test power plant with invalid capacity"""
        with pytest.raises(ValidationError):
            PowerPlant(
                plant_id="PLT-001",
                utility_id="UTL-001", 
                name="Test Plant",
                location="Test Location",
                plant_type=PlantType.NATURAL_GAS,
                capacity_mw=-100.0,  # Invalid negative capacity
                commissioning_date=date(2020, 1, 1)
            )
    
    def test_work_order_date_validation(self):
        """Test work order date validation"""
        created_date = datetime(2024, 1, 1, 10, 0, 0)
        
        # Valid work order with completion after creation
        wo = WorkOrder(
            work_order_id="WO-001",
            asset_id="AST-001",
            created_date=created_date,
            completion_date=datetime(2024, 1, 2, 10, 0, 0),
            work_type="corrective",
            priority="medium",
            status="completed",
            description="Test work order"
        )
        assert wo.completion_date > wo.created_date
        
        # Invalid work order with completion before creation
        with pytest.raises(ValidationError):
            WorkOrder(
                work_order_id="WO-002",
                asset_id="AST-001",
                created_date=created_date,
                completion_date=datetime(2023, 12, 31, 10, 0, 0),  # Before creation
                work_type="corrective",
                priority="medium", 
                status="completed",
                description="Test work order"
            )
    
    def test_outage_event_date_validation(self):
        """Test outage event date validation"""
        start_date = datetime(2024, 1, 1, 10, 0, 0)
        
        # Valid outage with end after start
        outage = OutageEvent(
            outage_id="OUT-001",
            unit_id="UNT-001",
            outage_type="planned",
            start_date=start_date,
            end_date=datetime(2024, 1, 2, 10, 0, 0),
            cause="Maintenance",
            status="completed"
        )
        assert outage.end_date > outage.start_date
        
        # Invalid outage with end before start
        with pytest.raises(ValidationError):
            OutageEvent(
                outage_id="OUT-002",
                unit_id="UNT-001",
                outage_type="planned",
                start_date=start_date,
                end_date=datetime(2023, 12, 31, 10, 0, 0),  # Before start
                cause="Maintenance",
                status="completed"
            )
    
    def test_heat_rate_test_valid(self):
        """Test valid heat rate test"""
        test = HeatRateTest(
            test_id="HRT-001",
            unit_id="UNT-001",
            test_date=datetime(2024, 1, 1, 10, 0, 0),
            measured_heat_rate=7850.0,
            baseline_heat_rate=7800.0,
            deviation_percentage=0.64,
            test_status="valid"
        )
        
        assert test.measured_heat_rate == 7850.0
        assert test.deviation_percentage == 0.64
    
    def test_asset_criticality_levels(self):
        """Test asset criticality enumeration"""
        asset = Asset(
            asset_id="AST-001",
            unit_id="UNT-001",
            asset_tag="TAG-001",
            name="Test Asset",
            asset_class=AssetClass.GAS_TURBINE,
            criticality=CriticalityLevel.CRITICAL,
            operational_status=OperationalStatus.OPERATIONAL
        )
        
        assert asset.criticality == CriticalityLevel.CRITICAL
        assert asset.asset_class == AssetClass.GAS_TURBINE