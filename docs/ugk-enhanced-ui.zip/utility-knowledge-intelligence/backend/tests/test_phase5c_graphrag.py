"""
Tests for Phase 5C GraphRAG functionality
"""

try:
    import pytest
    HAS_PYTEST = True
except ImportError:
    HAS_PYTEST = False

import asyncio
from unittest.mock import Mock, AsyncMock, patch
from app.intelligence import (
    GraphRAGService, GraphRAGRequest, GraphRAGResponse, 
    ConfidenceLevel, ContextBuilder, ContextConfig
)
from app.intelligence.prompts import GRAPHRAG_SYSTEM_PROMPT, get_graphrag_user_prompt
from app.verification import AnswerVerifier
from app.retrieval.models import (
    RetrievalResult, SemanticSearchResult, GraphEvidence, 
    GraphEntity, GraphRelationship
)


class TestGraphRAGModels:
    """Test GraphRAG data models"""
    
    def test_graphrag_request_validation(self):
        """Test GraphRAG request model validation"""
        # Valid request
        request = GraphRAGRequest(
            question="What caused the compressor failure?",
            top_k=5,
            graph_depth=1
        )
        assert request.question == "What caused the compressor failure?"
        assert request.top_k == 5
        assert request.graph_depth == 1
        assert request.include_verification is True
        
        # Test parameter bounds
        request = GraphRAGRequest(
            question="Test question",
            top_k=1,  # minimum
            graph_depth=0  # minimum
        )
        assert request.top_k == 1
        assert request.graph_depth == 0
        
        request = GraphRAGRequest(
            question="Test question",
            top_k=20,  # maximum
            graph_depth=3  # maximum
        )
        assert request.top_k == 20
        assert request.graph_depth == 3
    
    def test_confidence_levels(self):
        """Test confidence level enum"""
        assert ConfidenceLevel.HIGH == "high"
        assert ConfidenceLevel.MEDIUM == "medium"
        assert ConfidenceLevel.LOW == "low"
        assert ConfidenceLevel.VERY_LOW == "very_low"


class TestContextBuilder:
    """Test context building functionality"""
    
    def setup_method(self):
        """Setup test data"""
        self.context_builder = ContextBuilder()
        
        # Create mock retrieval result
        self.semantic_results = [
            SemanticSearchResult(
                chunk_id="DOC-001_chunk_000",
                document_id="DOC-001",
                document_title="Compressor Inspection Report",
                text="The compressor showed signs of excessive vibration during the inspection.",
                score=0.95,
                source="Inspector"
            ),
            SemanticSearchResult(
                chunk_id="DOC-002_chunk_000", 
                document_id="DOC-002",
                document_title="Failure Analysis",
                text="Blade liberation occurred at 14:15 hours due to fatigue failure.",
                score=0.87,
                source="Engineer"
            )
        ]
        
        self.graph_entities = [
            GraphEntity(
                entity_id="AST-001",
                entity_type="Asset",
                properties={"name": "Unit 1 Compressor", "status": "failed"}
            ),
            GraphEntity(
                entity_id="FAIL-001", 
                entity_type="Failure",
                properties={"severity": "high", "cause": "fatigue"}
            )
        ]
        
        self.graph_relationships = [
            GraphRelationship(
                source_id="DOC-001",
                target_id="AST-001",
                relationship_type="ABOUT_ASSET",
                source_type="Document",
                target_type="Asset"
            )
        ]
        
        self.retrieval_result = RetrievalResult(
            query="What caused the compressor failure?",
            semantic_results=self.semantic_results,
            graph_evidence=GraphEvidence(
                entities=self.graph_entities,
                relationships=self.graph_relationships
            ),
            metadata={
                "execution_time": 0.5,
                "retrieval_method": "vector+graph",
                "top_k": 5,
                "graph_depth": 1
            }
        )
    
    def test_build_context_complete(self):
        """Test building complete context with all evidence types"""
        question = "What caused the compressor failure?"
        context = self.context_builder.build_context(question, self.retrieval_result)
        
        # Check structure
        assert "=== USER QUESTION ===" in context
        assert "What caused the compressor failure?" in context
        assert "=== SEMANTIC EVIDENCE ===" in context
        assert "=== GRAPH EVIDENCE ===" in context
        assert "=== RETRIEVAL METADATA ===" in context
        
        # Check semantic evidence
        assert "DOC-001_chunk_000" in context
        assert "Compressor Inspection Report" in context
        assert "excessive vibration" in context
        assert "Similarity Score: 0.9500" in context
        
        # Check graph evidence
        assert "AST-001" in context
        assert "Asset: AST-001" in context
        assert "status=failed" in context
        
        # Check relationships
        assert "DOC-001 --[ABOUT_ASSET]--> AST-001" in context
    
    def test_build_context_empty_evidence(self):
        """Test building context with no evidence"""
        empty_result = RetrievalResult(
            query="Unknown question",
            semantic_results=[],
            graph_evidence=GraphEvidence(),
            metadata={}
        )
        
        context = self.context_builder.build_context("Unknown question", empty_result)
        
        assert "=== USER QUESTION ===" in context
        assert "Unknown question" in context
        # Should not contain evidence sections for empty results
        assert "=== SEMANTIC EVIDENCE ===" not in context
        assert "=== GRAPH EVIDENCE ===" not in context
    
    def test_context_truncation(self):
        """Test context truncation with long text"""
        config = ContextConfig(max_chunk_length=50, truncate_long_text=True)
        builder = ContextBuilder(config)
        
        # Create result with long text
        long_text_result = SemanticSearchResult(
            chunk_id="LONG-001",
            document_id="LONG-DOC",
            document_title="Long Document",
            text="This is a very long piece of text " * 20,  # 700+ characters
            score=0.8
        )
        
        long_result = RetrievalResult(
            query="Test",
            semantic_results=[long_text_result],
            graph_evidence=GraphEvidence()
        )
        
        context = builder.build_context("Test", long_result)
        assert "[truncated]" in context
        assert len([line for line in context.split('\n') if 'This is a very long' in line][0]) < 200
    
    def test_context_stats(self):
        """Test context statistics"""
        context = self.context_builder.build_context("Test", self.retrieval_result)
        stats = self.context_builder.get_context_stats(context)
        
        assert stats["context_length"] > 0
        assert stats["context_lines"] > 0
        assert stats["has_semantic_evidence"] is True
        assert stats["has_graph_evidence"] is True
        assert stats["has_metadata"] is True


class TestAnswerVerifier:
    """Test answer verification functionality"""
    
    def setup_method(self):
        """Setup test data"""
        self.verifier = AnswerVerifier()
        
        # Create test retrieval result
        self.retrieval_result = RetrievalResult(
            query="What caused the failure?",
            semantic_results=[
                SemanticSearchResult(
                    chunk_id="DOC-001_chunk_000",
                    document_id="DOC-001", 
                    document_title="Failure Report",
                    text="The failure was caused by excessive vibration at 2X frequency, leading to fatigue crack in the blade root. Cost was $50,000.",
                    score=0.9
                )
            ],
            graph_evidence=GraphEvidence(
                entities=[
                    GraphEntity(
                        entity_id="FAIL-001",
                        entity_type="Failure",
                        properties={"cost": 50000, "cause": "fatigue"}
                    )
                ]
            )
        )
    
    def test_verify_well_grounded_answer(self):
        """Test verification of well-grounded answer"""
        answer = "Based on the evidence in DOC-001, the failure was caused by excessive vibration leading to fatigue crack. The failure FAIL-001 had a cost of $50,000."
        
        result = self.verifier.verify_answer(answer, self.retrieval_result, "What caused the failure?")
        
        assert result.verified is True
        assert result.grounding_score > 0.7
        assert len(result.supported_claims) > 0
        assert len(result.unsupported_claims) == 0
    
    def test_verify_hallucinated_answer(self):
        """Test verification of answer with hallucinations"""
        answer = "Based on my knowledge, failures typically occur due to wear and tear. Generally speaking, this costs around $100,000."
        
        result = self.verifier.verify_answer(answer, self.retrieval_result, "What caused the failure?")
        
        assert result.verified is False
        assert result.grounding_score < 0.6
        assert len(result.warnings) > 0
        assert any("hallucination" in warning.lower() for warning in result.warnings)
    
    def test_verify_uncertain_answer(self):
        """Test verification of answer that acknowledges uncertainty"""
        answer = "There is insufficient evidence to determine the exact cause of the failure. DOC-001 mentions vibration but does not provide complete analysis."
        
        result = self.verifier.verify_answer(answer, self.retrieval_result, "What was the root cause?")
        
        # Check that uncertainty acknowledgment was detected
        assert "Appropriately acknowledges evidence limitations" in result.supported_claims
        assert result.grounding_score > 0.6  # Good behavior bonus
    
    def test_verify_invalid_references(self):
        """Test verification with invalid evidence references"""
        answer = "According to DOC-999 and entity FAKE-001, the cause was unknown."
        
        result = self.verifier.verify_answer(answer, self.retrieval_result, "What caused the failure?")
        
        assert len(result.unsupported_claims) > 0
        assert len(result.warnings) > 0
        assert result.verified is False
    
    def test_verify_numeric_claims(self):
        """Test verification of numeric claims"""
        # Valid numeric claim
        answer = "The cost was $50,000 as documented in the evidence."
        result = self.verifier.verify_answer(answer, self.retrieval_result, "What was the cost?")
        assert len(result.warnings) == 0  # Should find 50,000 in evidence
        
        # Invalid numeric claim 
        answer = "The cost was $200,000 which is not mentioned anywhere."
        result = self.verifier.verify_answer(answer, self.retrieval_result, "What was the cost?")
        assert any("unsupported numeric" in warning.lower() for warning in result.warnings)


class TestGraphRAGPrompts:
    """Test GraphRAG prompt generation"""
    
    def test_system_prompt_structure(self):
        """Test system prompt contains key instructions"""
        prompt = GRAPHRAG_SYSTEM_PROMPT
        
        assert "evidence" in prompt.lower()
        assert "do not" in prompt.lower()
        assert "insufficient" in prompt.lower()
        assert "reference" in prompt.lower()
    
    def test_user_prompt_generation(self):
        """Test user prompt generation"""
        question = "What caused the failure?"
        context = "=== SEMANTIC EVIDENCE ===\nDOC-001: Failure report"
        
        prompt = get_graphrag_user_prompt(question, context)
        
        assert question in prompt
        assert context in prompt
        assert "QUESTION:" in prompt
        assert "EVIDENCE:" in prompt
        assert "ANSWER:" in prompt


class TestGraphRAGServiceMocked:
    """Test GraphRAG service with mocked dependencies"""
    
    def setup_method(self):
        """Setup mocked service"""
        self.service = GraphRAGService()
        
        # Create mock retrieval result
        self.mock_retrieval = RetrievalResult(
            query="Test question",
            semantic_results=[
                SemanticSearchResult(
                    chunk_id="TEST-001",
                    document_id="DOC-001",
                    document_title="Test Document",
                    text="Test evidence text",
                    score=0.9
                )
            ],
            graph_evidence=GraphEvidence(
                entities=[
                    GraphEntity(
                        entity_id="ENT-001",
                        entity_type="TestEntity",
                        properties={"status": "test"}
                    )
                ]
            ),
            metadata={"execution_time": 0.1}
        )
    
    @patch('app.intelligence.graphrag_service.semantic_retriever')
    @patch('app.intelligence.graphrag_service.groq_client')
    def test_ask_question_success(self, mock_groq, mock_retriever):
        """Test successful question answering"""
        # Setup mocks
        mock_retriever.retrieve.return_value = self.mock_retrieval
        mock_groq.is_configured.return_value = True
        mock_groq.chat_completion.return_value = "Based on DOC-001, the answer is that test evidence shows the status."
        
        request = GraphRAGRequest(question="What is the status?")
        response = self.service.ask_question(request)
        
        assert isinstance(response, GraphRAGResponse)
        assert response.question == "What is the status?"
        assert response.answer
        assert response.confidence in list(ConfidenceLevel)
        assert response.verification
        assert "DOC-001" in response.sources["documents"]
    
    @patch('app.intelligence.graphrag_service.semantic_retriever')
    @patch('app.intelligence.graphrag_service.groq_client')
    def test_ask_question_groq_failure(self, mock_groq, mock_retriever):
        """Test handling of Groq failure"""
        mock_retriever.retrieve.return_value = self.mock_retrieval
        mock_groq.is_configured.return_value = True
        mock_groq.chat_completion.return_value = None  # Simulate failure
        
        request = GraphRAGRequest(question="Test question")
        
        try:
            self.service.ask_question(request)
            assert False, "Should have raised RuntimeError"
        except RuntimeError as e:
            assert "Failed to generate answer from Groq" in str(e)
    
    @patch('app.intelligence.graphrag_service.groq_client')
    def test_ask_question_empty_question(self, mock_groq):
        """Test handling of empty question"""
        request = GraphRAGRequest(question="  ")  # Whitespace only
        
        try:
            self.service.ask_question(request)
            assert False, "Should have raised ValueError"
        except ValueError as e:
            assert "cannot be empty" in str(e).lower()
    
    def test_confidence_determination(self):
        """Test confidence level determination"""
        from app.intelligence.models import VerificationResult, ConfidenceLevel
        
        # Create mock retrieval with more evidence for higher confidence
        from app.retrieval.models import SemanticSearchResult, GraphEvidence, GraphEntity, RetrievalResult
        
        rich_retrieval = RetrievalResult(
            query="Test question",
            semantic_results=[
                SemanticSearchResult(chunk_id=f"TEST-{i:03d}", document_id=f"DOC-{i:03d}", 
                                   document_title=f"Test Document {i}", text=f"Test evidence {i}", score=0.9)
                for i in range(1, 6)  # 5 semantic results
            ],
            graph_evidence=GraphEvidence(
                entities=[
                    GraphEntity(entity_id=f"ENT-{i:03d}", entity_type="TestEntity", properties={"status": "test"})
                    for i in range(1, 6)  # 5 entities
                ]
            ),
            metadata={"execution_time": 0.1}
        )
        
        # High confidence case
        high_verification = VerificationResult(
            verified=True,
            grounding_score=0.9,
            supported_claims=["Good evidence"],
            unsupported_claims=[],
            warnings=[]
        )
        
        confidence = self.service._determine_confidence(high_verification, rich_retrieval)
        assert confidence in [ConfidenceLevel.HIGH, ConfidenceLevel.MEDIUM]
        
        # Low confidence case (keep original mock with less evidence)
        low_verification = VerificationResult(
            verified=False,
            grounding_score=0.2,
            supported_claims=[],
            unsupported_claims=["Bad claim"],
            warnings=["Warning"]
        )
        
        confidence = self.service._determine_confidence(low_verification, self.mock_retrieval)
        assert confidence in [ConfidenceLevel.LOW, ConfidenceLevel.VERY_LOW]


def run_unit_tests():
    """Run all unit tests"""
    print("Running Phase 5C unit tests...")
    
    test_classes = [
        TestGraphRAGModels,
        TestContextBuilder, 
        TestAnswerVerifier,
        TestGraphRAGPrompts,
        TestGraphRAGServiceMocked
    ]
    
    total_tests = 0
    passed_tests = 0
    
    for test_class in test_classes:
        print(f"\nTesting {test_class.__name__}...")
        
        # Get test methods
        test_methods = [method for method in dir(test_class) if method.startswith('test_')]
        
        for method_name in test_methods:
            total_tests += 1
            
            try:
                # Create instance and run setup if exists
                instance = test_class()
                if hasattr(instance, 'setup_method'):
                    instance.setup_method()
                
                # Get and run test method
                test_method = getattr(instance, method_name)
                
                # Handle async tests
                if asyncio.iscoroutinefunction(test_method):
                    try:
                        loop = asyncio.get_event_loop()
                        loop.run_until_complete(test_method())
                    except RuntimeError:
                        # Create new event loop if none exists
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                        try:
                            loop.run_until_complete(test_method())
                        finally:
                            loop.close()
                else:
                    test_method()
                
                print(f"  ✓ {method_name}")
                passed_tests += 1
                
            except Exception as e:
                print(f"  ✗ {method_name}: {e}")
    
    print(f"\n{'='*50}")
    print(f"Phase 5C Unit Tests Results:")
    print(f"Total: {total_tests}, Passed: {passed_tests}, Failed: {total_tests - passed_tests}")
    
    if passed_tests == total_tests:
        print("All unit tests passed! ✓")
    else:
        print(f"Some tests failed. Success rate: {passed_tests/total_tests*100:.1f}%")
    
    print("="*50)
    return passed_tests == total_tests


def run_integration_tests():
    """Run integration tests that require live services"""
    print("\nRunning Phase 5C integration tests...")
    
    try:
        # Test 1: Context builder with real retrieval
        print("Testing context builder integration...")
        from app.retrieval import semantic_retriever, RetrievalRequest
        
        request = RetrievalRequest(query="compressor blade failure", top_k=2)
        retrieval_result = semantic_retriever.retrieve(request)
        
        builder = ContextBuilder()
        context = builder.build_context("What caused the compressor failure?", retrieval_result)
        
        assert len(context) > 100
        assert "compressor" in context.lower()
        print("  ✓ Context builder integration")
        
        # Test 2: Answer verifier with real data
        print("Testing answer verifier integration...")
        from app.verification import answer_verifier
        
        test_answer = "Based on the evidence, there was a compressor blade failure."
        verification = answer_verifier.verify_answer(test_answer, retrieval_result, "What happened?")
        
        assert isinstance(verification.grounding_score, float)
        assert 0.0 <= verification.grounding_score <= 1.0
        print("  ✓ Answer verifier integration")
        
        # Test 3: Full GraphRAG pipeline (mocked Groq)
        print("Testing GraphRAG service integration (mocked LLM)...")
        from app.intelligence import graphrag_service, GraphRAGRequest
        
        with patch('app.intelligence.graphrag_service.groq_client') as mock_groq:
            mock_groq.is_configured.return_value = True
            mock_groq.chat_completion.return_value = "Based on DOC-002, there was a compressor blade liberation event due to excessive vibration."
            
            request = GraphRAGRequest(question="What caused the compressor blade failure?")
            response = graphrag_service.ask_question(request)
            
            assert response.question == "What caused the compressor blade failure?"
            assert response.answer
            assert response.verification.grounding_score >= 0.0
            print("  ✓ GraphRAG service integration")
        
        print("All integration tests passed! ✓")
        return True
        
    except Exception as e:
        print(f"Integration test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    try:
        print("="*60)
        print("PHASE 5C GRAPHRAG TESTING")
        print("="*60)
        
        # Run unit tests
        unit_success = run_unit_tests()
        
        # Run integration tests
        integration_success = run_integration_tests()
        
        print(f"\n{'='*60}")
        print("OVERALL TEST RESULTS")
        print("─" * 60)
        print(f"Unit Tests: {'PASS' if unit_success else 'FAIL'}")
        print(f"Integration Tests: {'PASS' if integration_success else 'FAIL'}")
        
        if unit_success and integration_success:
            print("All Phase 5C tests passed! ✓")
        else:
            print("Some Phase 5C tests failed.")
            
        print("="*60)
        
    except Exception as e:
        print(f"Test execution failed: {e}")
        import traceback
        traceback.print_exc()