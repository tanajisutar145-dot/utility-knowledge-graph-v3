"""
Unit and integration tests for Dashboard API endpoint and service
Supports standard unittest and pytest
"""

import unittest
from unittest.mock import patch, MagicMock
import requests

from app.graph.neo4j_client import neo4j_client
from app.services.dashboard_service import dashboard_service


class TestDashboardEndpoint(unittest.TestCase):
    """Tests for Dashboard service and GET /api/dashboard/summary endpoint"""

    API_URL = "http://localhost:8000/api/dashboard/summary"

    def test_dashboard_summary_status_code(self):
        """Verify endpoint returns HTTP 200 OK and healthy status"""
        response = requests.get(self.API_URL)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["status"], "healthy")
        self.assertIn("generated_at", data)

    def test_kpi_counts_match_neo4j(self):
        """Verify KPI counts match live Neo4j data"""
        summary = dashboard_service.get_dashboard_summary()
        kpis = summary.kpis
        
        # Verify exact counts matching live graph
        self.assertEqual(kpis.power_plants, 4)
        self.assertEqual(kpis.generating_units, 13)
        self.assertEqual(kpis.assets, 57)
        self.assertEqual(kpis.components, 81)
        self.assertEqual(kpis.work_orders, 31)
        self.assertEqual(kpis.inspections, 35)
        self.assertEqual(kpis.failure_events, 3)
        self.assertEqual(kpis.outage_events, 9)
        self.assertEqual(kpis.maintenance_plans, 77)

    def test_document_and_chunk_counts_separation(self):
        """Verify documents are not mixed up with chunks"""
        summary = dashboard_service.get_dashboard_summary()
        docs = summary.documents
        graph = summary.graph
        
        # Documents vs chunks
        self.assertEqual(docs.total_documents, 8)
        self.assertEqual(docs.total_chunks, 13)
        self.assertEqual(docs.embedded_chunks, 13)
        self.assertNotEqual(docs.total_documents, docs.total_chunks)
        
        # Graph node counts
        self.assertEqual(graph.total_nodes, 338)
        self.assertEqual(graph.total_relationships, 346)
        self.assertEqual(graph.structured_nodes, 317)
        self.assertEqual(graph.document_nodes, 21)
        self.assertEqual(graph.structured_nodes + graph.document_nodes, graph.total_nodes)

    def test_heat_rate_ordering_and_units(self):
        """Verify heat rate observations are in strict chronological order with correct units"""
        summary = dashboard_service.get_dashboard_summary()
        perf = summary.performance
        
        self.assertEqual(perf.unit, "BTU/kWh")
        self.assertEqual(perf.baseline_heat_rate, 7800.0)
        self.assertEqual(len(perf.observations), 6)
        
        # Verify chronological order
        dates = [obs.test_date for obs in perf.observations]
        self.assertEqual(dates, sorted(dates))
        
        # Verify values progression
        rates = [obs.measured_heat_rate for obs in perf.observations]
        self.assertEqual(rates, [7800.0, 7820.0, 7850.0, 7890.0, 7935.0, 7980.0])
        self.assertEqual(perf.initial_rate, 7800.0)
        self.assertEqual(perf.latest_rate, 7980.0)
        self.assertEqual(perf.delta, 180.0)
        self.assertEqual(perf.delta_percentage, 2.31)
        self.assertIn("7800", perf.interpretation)
        self.assertIn("7980", perf.interpretation)

    def test_endpoint_is_read_only(self):
        """Verify dashboard retrieval does not mutate graph nodes or relationships"""
        initial_nodes = neo4j_client.get_node_count()
        initial_rels = neo4j_client.get_relationship_count()
        
        summary = dashboard_service.get_dashboard_summary()
        self.assertIsNotNone(summary)
        
        final_nodes = neo4j_client.get_node_count()
        final_rels = neo4j_client.get_relationship_count()
        
        self.assertEqual(initial_nodes, final_nodes)
        self.assertEqual(initial_rels, final_rels)

    @patch("app.llm.groq_client.groq_client.chat_completion")
    def test_no_llm_calls_during_dashboard(self, mock_groq):
        """Verify that retrieving dashboard summary does not call Groq LLM"""
        dashboard_service.get_dashboard_summary()
        mock_groq.assert_not_called()

    def test_database_unavailability_handling(self):
        """Verify graceful handling when Neo4j is disconnected"""
        with patch.object(neo4j_client, "verify_connectivity", return_value=False):
            with self.assertRaises(Exception) as exc_info:
                dashboard_service.get_dashboard_summary()
            self.assertIn("503", str(exc_info.exception))


if __name__ == "__main__":
    unittest.main()
