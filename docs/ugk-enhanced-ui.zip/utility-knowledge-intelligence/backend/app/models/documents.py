"""
Pydantic response models for Document Management API
"""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any


class DocumentOverviewResponse(BaseModel):
    """Overview statistics for Document Management"""
    total_documents: int = Field(..., description="Total document count in knowledge graph")
    total_chunks: int = Field(..., description="Total chunk count in knowledge graph")
    embedded_chunks: int = Field(..., description="Number of chunks with vector embeddings")
    document_types: Dict[str, int] = Field(default_factory=dict, description="Counts by document type")
    processing_statuses: Dict[str, int] = Field(default_factory=dict, description="Counts by processing status")
    vector_index_name: str = Field("chunk_embedding_index", description="Name of Neo4j vector index")
    vector_index_status: str = Field("ONLINE", description="State of the vector index")
    vector_index_population: float = Field(100.0, description="Population percentage of the vector index")
    embedding_model: str = Field("BAAI/bge-small-en-v1.5", description="Embedding model name")
    embedding_dimension: int = Field(384, description="Embedding vector dimension")


class DocumentSummaryItem(BaseModel):
    """Summary item for document table listing"""
    document_id: str = Field(..., description="Unique document ID")
    title: str = Field(..., description="Document title")
    document_type: str = Field(..., description="Document category/type")
    source: str = Field(..., description="Source system or author")
    source_reference: Optional[str] = Field(None, description="External reference ID")
    created_date: Optional[str] = Field(None, description="ISO timestamp of creation")
    processing_status: str = Field("completed", description="Processing status")
    content_hash: Optional[str] = Field(None, description="Content hash for deduplication")
    content_length: int = Field(0, description="Character length of content")
    chunk_count: int = Field(0, description="Number of text chunks created")
    embedded_chunks: int = Field(0, description="Number of embedded chunks")
    format: Optional[str] = Field(None, description="Document file format (e.g. pdf, xlsx, docx, csv, json, txt)")
    source_filename: Optional[str] = Field(None, description="Original uploaded filename")
    warnings: List[str] = Field(default_factory=list, description="Extraction warnings")


class DocumentListResponse(BaseModel):
    """List response for documents with pagination"""
    documents: List[DocumentSummaryItem] = Field(default_factory=list, description="Documents matching query")
    total: int = Field(..., description="Total matching documents")
    skip: int = Field(0, description="Number of skipped items")
    limit: int = Field(50, description="Maximum items returned")


class DocumentChunkDetail(BaseModel):
    """Detail of a single text chunk with provenance"""
    chunk_id: str = Field(..., description="Unique chunk ID")
    chunk_index: int = Field(..., description="Zero-based index of chunk in document")
    text: str = Field(..., description="Chunk content text")
    is_embedded: bool = Field(False, description="Whether this chunk has an embedding vector")
    embedding_model: Optional[str] = Field(None, description="Model used to embed chunk")
    embedding_dimension: Optional[int] = Field(None, description="Dimension of embedding")
    created_at: Optional[str] = Field(None, description="ISO timestamp of chunk creation")
    page_number: Optional[int] = Field(None, description="1-indexed page number if PDF")
    sheet_name: Optional[str] = Field(None, description="Worksheet name if spreadsheet")
    row_range: Optional[str] = Field(None, description="Row range if spreadsheet or CSV")
    section_title: Optional[str] = Field(None, description="Heading or section title")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Metadata properties on chunk")


class DocumentEntityLink(BaseModel):
    """Entity linked to a document in the knowledge graph"""
    relationship: str = Field(..., description="Graph relationship type (e.g. ABOUT_ASSET)")
    labels: List[str] = Field(default_factory=list, description="Neo4j node labels")
    entity_id: str = Field(..., description="Entity identifier")
    entity_name: str = Field("", description="Human-readable name of entity")
    properties: Dict[str, Any] = Field(default_factory=dict, description="Node properties")


class DocumentDetailResponse(BaseModel):
    """Complete detail of a document including text, chunks, and graph links"""
    document_id: str = Field(..., description="Unique document ID")
    title: str = Field(..., description="Document title")
    document_type: str = Field(..., description="Document category/type")
    source: str = Field(..., description="Source system or author")
    source_reference: Optional[str] = Field(None, description="External reference ID")
    created_date: Optional[str] = Field(None, description="ISO timestamp of creation")
    processing_status: str = Field("completed", description="Processing status")
    content_hash: Optional[str] = Field(None, description="Content hash for deduplication")
    content: str = Field(..., description="Full text content of document")
    format: Optional[str] = Field(None, description="Document file format")
    source_filename: Optional[str] = Field(None, description="Original uploaded filename")
    warnings: List[str] = Field(default_factory=list, description="Extraction warnings")
    chunks: List[DocumentChunkDetail] = Field(default_factory=list, description="Associated text chunks")
    linked_entities: List[DocumentEntityLink] = Field(default_factory=list, description="Linked graph entities")


class DocumentUploadResult(BaseModel):
    """Result of document upload and ingestion"""
    document_id: str = Field(..., description="Assigned or extracted document ID")
    title: str = Field(..., description="Document title")
    action: str = Field(..., description="Action taken: created, updated, or skipped")
    chunks_created: int = Field(0, description="Number of text chunks created")
    relationships_created: int = Field(0, description="Total Neo4j relationships created")
    entity_links: int = Field(0, description="Entity links identified")
    embedded: bool = Field(False, description="Whether chunk embeddings were generated")
    format: Optional[str] = Field(None, description="Detected document format")
    warnings: List[str] = Field(default_factory=list, description="Extraction warnings")
    message: str = Field(..., description="Human-readable outcome description")
