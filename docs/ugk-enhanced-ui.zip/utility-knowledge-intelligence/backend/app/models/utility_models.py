"""
Utility domain data models using Pydantic
"""

from pydantic import BaseModel, Field, validator
from typing import Optional, List, Literal
from datetime import datetime, date
from enum import Enum


class UtilityStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    DIVESTED = "divested"


class PlantType(str, Enum):
    NATURAL_GAS = "natural_gas"
    COAL = "coal"
    NUCLEAR = "nuclear"
    HYDROELECTRIC = "hydroelectric"
    WIND = "wind"
    SOLAR = "solar"
    BIOMASS = "biomass"
    COMBINED_CYCLE = "combined_cycle"


class UnitType(str, Enum):
    STEAM_TURBINE = "steam_turbine"
    GAS_TURBINE = "gas_turbine"
    COMBINED_CYCLE = "combined_cycle"
    HYDROELECTRIC = "hydroelectric"
    WIND_TURBINE = "wind_turbine"
    SOLAR_PV = "solar_pv"
    NUCLEAR_REACTOR = "nuclear_reactor"


class OperationalStatus(str, Enum):
    OPERATIONAL = "operational"
    MAINTENANCE = "maintenance"
    OUTAGE = "outage"
    RETIRED = "retired"
    UNDER_CONSTRUCTION = "under_construction"


class AssetClass(str, Enum):
    GAS_TURBINE = "gas_turbine"
    STEAM_TURBINE = "steam_turbine"
    GENERATOR = "generator"
    COMPRESSOR = "compressor"
    BOILER = "boiler"
    PUMP = "pump"
    TRANSFORMER = "transformer"
    COOLING_SYSTEM = "cooling_system"
    CONTROL_SYSTEM = "control_system"
    HRSG = "hrsg"  # Heat Recovery Steam Generator


class CriticalityLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class InspectionType(str, Enum):
    ROUTINE = "routine"
    EMERGENCY = "emergency"
    STATUTORY = "statutory"
    CONDITION_BASED = "condition_based"
    PREDICTIVE = "predictive"


class ConditionRating(str, Enum):
    EXCELLENT = "excellent"
    GOOD = "good"
    FAIR = "fair"
    POOR = "poor"
    CRITICAL = "critical"


class SeverityLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class WorkOrderType(str, Enum):
    PREVENTIVE = "preventive"
    CORRECTIVE = "corrective"
    EMERGENCY = "emergency"
    IMPROVEMENT = "improvement"
    INSPECTION = "inspection"


class WorkOrderStatus(str, Enum):
    CREATED = "created"
    SCHEDULED = "scheduled"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class WorkOrderPriority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class MaintenanceType(str, Enum):
    PREVENTIVE = "preventive"
    PREDICTIVE = "predictive"
    CORRECTIVE = "corrective"
    STATUTORY = "statutory"


class MaintenanceFrequency(str, Enum):
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    SEMI_ANNUALLY = "semi_annually"
    ANNUALLY = "annually"
    HOURS_BASED = "hours_based"
    CONDITION_BASED = "condition_based"


class OutageType(str, Enum):
    PLANNED = "planned"
    FORCED = "forced"
    MAINTENANCE = "maintenance"
    EMERGENCY = "emergency"


# Domain Models

class Utility(BaseModel):
    utility_id: str = Field(..., description="Unique utility identifier")
    name: str = Field(..., description="Utility company name")
    region: str = Field(..., description="Geographic region")
    country: str = Field(..., description="Country of operation")
    description: Optional[str] = Field(None, description="Utility description")
    status: UtilityStatus = Field(UtilityStatus.ACTIVE, description="Operational status")
    
    class Config:
        use_enum_values = True


class PowerPlant(BaseModel):
    plant_id: str = Field(..., description="Unique plant identifier")
    utility_id: str = Field(..., description="Parent utility ID")
    name: str = Field(..., description="Power plant name")
    location: str = Field(..., description="Plant location")
    plant_type: PlantType = Field(..., description="Type of power plant")
    capacity_mw: float = Field(..., gt=0, description="Plant capacity in MW")
    commissioning_date: date = Field(..., description="Date plant was commissioned")
    status: OperationalStatus = Field(OperationalStatus.OPERATIONAL, description="Plant status")
    
    class Config:
        use_enum_values = True


class GeneratingUnit(BaseModel):
    unit_id: str = Field(..., description="Unique unit identifier")
    plant_id: str = Field(..., description="Parent plant ID")
    unit_name: str = Field(..., description="Generating unit name")
    unit_type: UnitType = Field(..., description="Type of generating unit")
    capacity_mw: float = Field(..., gt=0, description="Unit capacity in MW")
    commissioning_date: date = Field(..., description="Date unit was commissioned")
    status: OperationalStatus = Field(OperationalStatus.OPERATIONAL, description="Unit status")
    
    class Config:
        use_enum_values = True


class Asset(BaseModel):
    asset_id: str = Field(..., description="Unique asset identifier")
    unit_id: str = Field(..., description="Parent unit ID")
    asset_tag: str = Field(..., description="Asset tag/number")
    name: str = Field(..., description="Asset name")
    asset_class: AssetClass = Field(..., description="Class/type of asset")
    manufacturer: Optional[str] = Field(None, description="Asset manufacturer")
    model: Optional[str] = Field(None, description="Asset model")
    installation_date: Optional[date] = Field(None, description="Installation date")
    criticality: CriticalityLevel = Field(CriticalityLevel.MEDIUM, description="Asset criticality")
    operational_status: OperationalStatus = Field(OperationalStatus.OPERATIONAL, description="Asset operational status")
    
    class Config:
        use_enum_values = True


class Component(BaseModel):
    component_id: str = Field(..., description="Unique component identifier")
    asset_id: str = Field(..., description="Parent asset ID")
    component_name: str = Field(..., description="Component name")
    component_type: str = Field(..., description="Component type")
    manufacturer: Optional[str] = Field(None, description="Component manufacturer")
    model: Optional[str] = Field(None, description="Component model")
    criticality: CriticalityLevel = Field(CriticalityLevel.MEDIUM, description="Component criticality")
    installation_date: Optional[date] = Field(None, description="Installation date")
    status: OperationalStatus = Field(OperationalStatus.OPERATIONAL, description="Component status")
    
    class Config:
        use_enum_values = True


class Inspection(BaseModel):
    inspection_id: str = Field(..., description="Unique inspection identifier")
    asset_id: str = Field(..., description="Inspected asset ID")
    inspection_date: datetime = Field(..., description="Date and time of inspection")
    inspection_type: InspectionType = Field(..., description="Type of inspection")
    inspector: str = Field(..., description="Inspector name/ID")
    condition: ConditionRating = Field(..., description="Overall condition rating")
    findings: str = Field(..., description="Inspection findings")
    severity: SeverityLevel = Field(SeverityLevel.LOW, description="Severity of findings")
    recommended_action: Optional[str] = Field(None, description="Recommended corrective action")
    
    class Config:
        use_enum_values = True


class FailureEvent(BaseModel):
    failure_id: str = Field(..., description="Unique failure identifier")
    asset_id: str = Field(..., description="Failed asset ID")
    failure_date: datetime = Field(..., description="Date and time of failure")
    failure_mode: str = Field(..., description="Mode of failure")
    severity: SeverityLevel = Field(..., description="Failure severity")
    description: str = Field(..., description="Failure description")
    root_cause: Optional[str] = Field(None, description="Root cause analysis")
    downtime_hours: float = Field(0, ge=0, description="Downtime in hours")
    estimated_cost: Optional[float] = Field(None, ge=0, description="Estimated repair cost")
    actual_cost: Optional[float] = Field(None, ge=0, description="Actual repair cost")
    status: Literal["open", "investigating", "resolved", "closed"] = Field("open", description="Failure event status")
    
    class Config:
        use_enum_values = True


class WorkOrder(BaseModel):
    work_order_id: str = Field(..., description="Unique work order identifier")
    asset_id: str = Field(..., description="Target asset ID")
    failure_id: Optional[str] = Field(None, description="Related failure ID if applicable")
    created_date: datetime = Field(..., description="Work order creation date")
    scheduled_date: Optional[datetime] = Field(None, description="Scheduled execution date")
    completion_date: Optional[datetime] = Field(None, description="Actual completion date")
    work_type: WorkOrderType = Field(..., description="Type of work")
    priority: WorkOrderPriority = Field(WorkOrderPriority.MEDIUM, description="Work order priority")
    status: WorkOrderStatus = Field(WorkOrderStatus.CREATED, description="Work order status")
    description: str = Field(..., description="Work order description")
    labor_hours: Optional[float] = Field(None, ge=0, description="Labor hours required/actual")
    material_cost: Optional[float] = Field(None, ge=0, description="Material cost")
    total_cost: Optional[float] = Field(None, ge=0, description="Total work order cost")
    
    @validator('completion_date')
    def completion_after_creation(cls, v, values):
        if v and 'created_date' in values and v < values['created_date']:
            raise ValueError('Completion date cannot be before creation date')
        return v
    
    @validator('scheduled_date')
    def scheduled_after_creation(cls, v, values):
        if v and 'created_date' in values and v < values['created_date']:
            raise ValueError('Scheduled date cannot be before creation date')
        return v
    
    class Config:
        use_enum_values = True


class MaintenancePlan(BaseModel):
    maintenance_plan_id: str = Field(..., description="Unique maintenance plan identifier")
    asset_id: str = Field(..., description="Target asset ID")
    plan_name: str = Field(..., description="Maintenance plan name")
    maintenance_type: MaintenanceType = Field(..., description="Type of maintenance")
    frequency: MaintenanceFrequency = Field(..., description="Maintenance frequency")
    last_execution_date: Optional[datetime] = Field(None, description="Last execution date")
    next_due_date: Optional[datetime] = Field(None, description="Next due date")
    status: Literal["active", "suspended", "cancelled"] = Field("active", description="Plan status")
    
    @validator('next_due_date')
    def next_due_after_last_execution(cls, v, values):
        if v and 'last_execution_date' in values and values['last_execution_date'] and v < values['last_execution_date']:
            raise ValueError('Next due date should not be before last execution date')
        return v
    
    class Config:
        use_enum_values = True


class OutageEvent(BaseModel):
    outage_id: str = Field(..., description="Unique outage identifier")
    unit_id: str = Field(..., description="Affected unit ID")
    outage_type: OutageType = Field(..., description="Type of outage")
    start_date: datetime = Field(..., description="Outage start date")
    end_date: Optional[datetime] = Field(None, description="Outage end date")
    duration_hours: Optional[float] = Field(None, ge=0, description="Outage duration in hours")
    cause: str = Field(..., description="Outage cause")
    status: Literal["ongoing", "completed", "cancelled"] = Field("ongoing", description="Outage status")
    estimated_generation_loss_mwh: Optional[float] = Field(None, ge=0, description="Estimated generation loss in MWh")
    estimated_cost: Optional[float] = Field(None, ge=0, description="Estimated cost impact")
    
    @validator('end_date')
    def end_after_start(cls, v, values):
        if v and 'start_date' in values and v < values['start_date']:
            raise ValueError('End date cannot be before start date')
        return v
    
    class Config:
        use_enum_values = True


class HeatRateTest(BaseModel):
    test_id: str = Field(..., description="Unique test identifier")
    unit_id: str = Field(..., description="Tested unit ID")
    test_date: datetime = Field(..., description="Test date")
    measured_heat_rate: float = Field(..., gt=0, description="Measured heat rate (BTU/kWh)")
    baseline_heat_rate: float = Field(..., gt=0, description="Baseline heat rate (BTU/kWh)")
    deviation_percentage: float = Field(..., description="Deviation from baseline (%)")
    test_status: Literal["valid", "invalid", "under_review"] = Field("valid", description="Test validity status")
    observations: Optional[str] = Field(None, description="Test observations")
    
    class Config:
        use_enum_values = True