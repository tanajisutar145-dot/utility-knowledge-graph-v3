"""
Pydantic response models for Asset Management API
"""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any


class AssetOverviewResponse(BaseModel):
    """Overview statistics for Asset Management"""
    total_assets: int = Field(..., description="Total assets in the knowledge graph")
    operational_assets: int = Field(..., description="Assets currently operational")
    assets_with_failures: int = Field(0, description="Assets with historical failure events")
    criticality_counts: Dict[str, int] = Field(default_factory=dict, description="Counts by criticality")
    asset_class_counts: Dict[str, int] = Field(default_factory=dict, description="Counts by asset class")
    status_counts: Dict[str, int] = Field(default_factory=dict, description="Counts by operational status")


class AssetSummaryItem(BaseModel):
    """Summary item for asset inventory table"""
    asset_id: str = Field(..., description="Asset identifier (e.g. AST-001)")
    name: str = Field(..., description="Asset name")
    asset_class: str = Field(..., description="Asset class/type (e.g. gas_turbine)")
    criticality: str = Field(..., description="Criticality level (low, medium, high, critical)")
    operational_status: str = Field(..., description="Operational status (operational, maintenance, outage)")
    manufacturer: Optional[str] = Field(None, description="Manufacturer")
    model: Optional[str] = Field(None, description="Model number/name")
    installation_date: Optional[str] = Field(None, description="Installation date")
    asset_tag: Optional[str] = Field(None, description="Asset tag")
    unit_id: Optional[str] = Field(None, description="Parent generating unit ID")
    unit_name: Optional[str] = Field(None, description="Parent generating unit name")
    plant_id: Optional[str] = Field(None, description="Power plant ID")
    plant_name: Optional[str] = Field(None, description="Power plant name")
    component_count: int = Field(0, description="Number of connected components")
    inspection_count: int = Field(0, description="Number of recorded inspections")
    failure_count: int = Field(0, description="Number of recorded failure events")
    work_order_count: int = Field(0, description="Number of associated work orders")
    document_count: int = Field(0, description="Number of referencing technical documents")


class AssetListResponse(BaseModel):
    """Paginated list response for assets"""
    assets: List[AssetSummaryItem] = Field(default_factory=list, description="Assets matching query")
    total: int = Field(..., description="Total matching assets")
    skip: int = Field(0, description="Number of skipped items")
    limit: int = Field(50, description="Maximum items returned")


class GeneratingUnitHierarchy(BaseModel):
    """Parent generating unit summary"""
    unit_id: str
    unit_name: str
    unit_type: Optional[str] = None
    capacity_mw: Optional[float] = None
    status: Optional[str] = None


class PowerPlantHierarchy(BaseModel):
    """Parent power plant summary"""
    plant_id: str
    name: str
    location: Optional[str] = None
    plant_type: Optional[str] = None
    capacity_mw: Optional[float] = None


class AssetParentHierarchy(BaseModel):
    """Parent hierarchy containing generating unit and plant"""
    generating_unit: Optional[GeneratingUnitHierarchy] = None
    power_plant: Optional[PowerPlantHierarchy] = None


class AssetComponent(BaseModel):
    """Connected component of an asset"""
    component_id: str
    component_name: str
    component_type: Optional[str] = None
    manufacturer: Optional[str] = None
    model: Optional[str] = None
    criticality: Optional[str] = None
    status: Optional[str] = None


class AssetInspection(BaseModel):
    """Inspection record for an asset"""
    inspection_id: str
    inspection_date: Optional[str] = None
    inspection_type: Optional[str] = None
    inspector: Optional[str] = None
    condition: Optional[str] = None
    findings: Optional[str] = None
    severity: Optional[str] = None
    recommended_action: Optional[str] = None


class AssetWorkOrder(BaseModel):
    """Work order associated with an asset"""
    work_order_id: str
    created_date: Optional[str] = None
    scheduled_date: Optional[str] = None
    completion_date: Optional[str] = None
    work_type: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[str] = None
    description: Optional[str] = None
    total_cost: Optional[float] = None


class AssetMaintenancePlan(BaseModel):
    """Maintenance plan for an asset"""
    maintenance_plan_id: str
    plan_name: str
    maintenance_type: Optional[str] = None
    frequency: Optional[str] = None
    last_execution_date: Optional[str] = None
    next_due_date: Optional[str] = None
    status: Optional[str] = None


class AssetFailureEvent(BaseModel):
    """Recorded failure event for an asset"""
    failure_id: str
    failure_date: Optional[str] = None
    failure_mode: Optional[str] = None
    severity: Optional[str] = None
    description: Optional[str] = None
    root_cause: Optional[str] = None
    downtime_hours: Optional[float] = 0.0
    estimated_cost: Optional[float] = None
    actual_cost: Optional[float] = None
    status: Optional[str] = None


class AssetOutageEvent(BaseModel):
    """Outage event on the parent unit related to this asset"""
    outage_id: str
    outage_type: Optional[str] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    duration_hours: Optional[float] = None
    cause: Optional[str] = None
    status: Optional[str] = None
    estimated_cost: Optional[float] = None


class AssetDocument(BaseModel):
    """Technical document referencing an asset"""
    document_id: str
    title: str
    document_type: Optional[str] = None
    source: Optional[str] = None
    created_date: Optional[str] = None


class AssetDetailResponse(BaseModel):
    """Comprehensive asset detail view with full relational context"""
    asset: AssetSummaryItem
    hierarchy: AssetParentHierarchy
    components: List[AssetComponent] = Field(default_factory=list)
    inspections: List[AssetInspection] = Field(default_factory=list)
    work_orders: List[AssetWorkOrder] = Field(default_factory=list)
    maintenance_plans: List[AssetMaintenancePlan] = Field(default_factory=list)
    failures: List[AssetFailureEvent] = Field(default_factory=list)
    outages: List[AssetOutageEvent] = Field(default_factory=list)
    documents: List[AssetDocument] = Field(default_factory=list)
