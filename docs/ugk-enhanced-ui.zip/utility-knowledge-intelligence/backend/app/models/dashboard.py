"""
Dashboard Pydantic response models
"""

from typing import List, Dict, Optional, Any
from pydantic import BaseModel, Field


class DashboardKPIs(BaseModel):
    """Executive high-level fleet KPIs"""
    power_plants: int = Field(..., description="Total power plants")
    generating_units: int = Field(..., description="Total generating units")
    assets: int = Field(..., description="Total assets")
    components: int = Field(..., description="Total components")
    work_orders: int = Field(..., description="Total work orders")
    inspections: int = Field(..., description="Total inspections")
    failure_events: int = Field(..., description="Total failure events")
    outage_events: int = Field(..., description="Total outage events")
    maintenance_plans: int = Field(..., description="Total maintenance plans")


class DashboardGraphStats(BaseModel):
    """Graph database node and relationship statistics"""
    total_nodes: int = Field(..., description="Total graph nodes")
    total_relationships: int = Field(..., description="Total graph relationships")
    structured_nodes: int = Field(..., description="Structured domain entities count")
    document_nodes: int = Field(..., description="Document and chunk nodes count")


class DashboardDocumentStats(BaseModel):
    """Document repository and chunk vector indexing statistics"""
    total_documents: int = Field(..., description="Total uploaded documents")
    total_chunks: int = Field(..., description="Total text chunks generated")
    embedded_chunks: int = Field(..., description="Chunks with generated vector embeddings")
    embedding_dimension: int = Field(384, description="Embedding vector dimension")
    embedding_model: str = Field(..., description="Sentence transformer model name")
    vector_index_name: str = Field("chunk_embedding_index", description="Neo4j vector index name")
    vector_index_status: str = Field("ONLINE", description="Neo4j vector index state")
    vector_index_population: float = Field(100.0, description="Vector index population percentage")


class AssetReliabilityStats(BaseModel):
    """Asset reliability factual indicators"""
    total_assets: int = Field(..., description="Total fleet assets")
    operational_assets: int = Field(..., description="Assets currently marked operational")
    assets_with_failures: int = Field(..., description="Assets associated with recorded failure events")
    criticality_counts: Dict[str, int] = Field(..., description="Asset count by criticality level")


class WorkOrderOverview(BaseModel):
    """Work order factual distribution"""
    total_work_orders: int = Field(..., description="Total work orders")
    status_counts: Dict[str, int] = Field(..., description="Work orders by status")
    priority_counts: Dict[str, int] = Field(..., description="Work orders by priority")
    type_counts: Dict[str, int] = Field(..., description="Work orders by work type")


class FailureItem(BaseModel):
    """Individual failure event record"""
    failure_id: str
    asset_id: str
    asset_name: Optional[str] = None
    failure_mode: str
    severity: str
    downtime_hours: float
    actual_cost: Optional[float] = None
    status: str
    failure_date: Optional[str] = None


class OutageTypeSummary(BaseModel):
    """Aggregated stats for an outage type"""
    count: int
    duration_hours: float
    estimated_cost: float
    loss_mwh: float


class OutageOverview(BaseModel):
    """Outage summary metrics and breakdown"""
    total_outages: int
    total_duration_hours: float
    total_estimated_cost: float
    total_loss_mwh: float
    by_type: Dict[str, OutageTypeSummary]


class InspectionOverview(BaseModel):
    """Inspection factual distribution"""
    total_inspections: int
    condition_counts: Dict[str, int]
    severity_counts: Dict[str, int]


class OperationsStats(BaseModel):
    """Operational intelligence collection"""
    asset_reliability: AssetReliabilityStats
    work_orders: WorkOrderOverview
    failures: List[FailureItem]
    outages: OutageOverview
    inspections: InspectionOverview


class HeatRateObservation(BaseModel):
    """Individual heat rate observation point"""
    test_id: str
    unit_id: str
    unit_name: Optional[str] = None
    test_date: Optional[str] = None
    measured_heat_rate: float
    baseline_heat_rate: float
    deviation_percentage: float
    test_status: str
    observations: Optional[str] = None


class HeatRateTrend(BaseModel):
    """Performance heat rate timeline and factual summary"""
    observations: List[HeatRateObservation]
    baseline_heat_rate: float
    unit: str = "BTU/kWh"
    initial_rate: float
    latest_rate: float
    delta: float
    delta_percentage: float
    interpretation: str


class MaintenanceEffectiveness(BaseModel):
    """Factual maintenance indicators"""
    maintenance_plans_count: int
    work_orders_count: int
    inspections_count: int
    failures_count: int
    triggered_work_orders_count: int
    preventive_count: int
    corrective_count: int
    emergency_count: int
    preventive_percentage: float
    corrective_percentage: float
    summary_note: str


class DashboardSummaryResponse(BaseModel):
    """Complete dashboard response model"""
    generated_at: str
    status: str
    kpis: DashboardKPIs
    graph: DashboardGraphStats
    documents: DashboardDocumentStats
    operations: OperationsStats
    performance: HeatRateTrend
    maintenance: MaintenanceEffectiveness
