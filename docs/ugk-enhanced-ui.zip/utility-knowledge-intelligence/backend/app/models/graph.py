"""
Pydantic response and request models for Knowledge Graph Explorer API
"""

from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class GraphNode(BaseModel):
    """Knowledge graph node model"""
    id: str = Field(..., description="Stable Neo4j elementId")
    label: str = Field(..., description="Primary entity label (e.g. Asset, PowerPlant)")
    labels: List[str] = Field(default_factory=list, description="All labels assigned to node")
    name: str = Field(..., description="Readable display title or name")
    entity_id: str = Field("", description="Domain entity ID (e.g. AST-001, PLT-001)")
    properties: Dict[str, Any] = Field(default_factory=dict, description="Sanitized entity properties")


class GraphRelationship(BaseModel):
    """Knowledge graph relationship model"""
    id: str = Field(..., description="Stable Neo4j relationship elementId")
    source: str = Field(..., description="Source node elementId")
    target: str = Field(..., description="Target node elementId")
    type: str = Field(..., description="Relationship semantic type (e.g. HAS_PLANT)")
    properties: Dict[str, Any] = Field(default_factory=dict, description="Relationship properties")


class GraphOverviewResponse(BaseModel):
    """Overall schema and graph statistics"""
    total_nodes: int = Field(..., description="Total nodes in the graph")
    total_relationships: int = Field(..., description="Total relationships in the graph")
    node_counts_by_label: Dict[str, int] = Field(..., description="Count of nodes by primary label")
    relationship_counts_by_type: Dict[str, int] = Field(..., description="Count of relationships by type")
    available_labels: List[str] = Field(..., description="Whitelisted node labels")
    available_relationship_types: List[str] = Field(..., description="Whitelisted relationship types")


class GraphExploreResponse(BaseModel):
    """Filtered graph exploration payload for visualization"""
    nodes: List[GraphNode] = Field(default_factory=list)
    relationships: List[GraphRelationship] = Field(default_factory=list)
    total_nodes: int = Field(..., description="Number of nodes returned")
    total_relationships: int = Field(..., description="Number of relationships returned")
    is_truncated: bool = Field(False, description="Whether node result reached limit")
    filters_applied: Dict[str, Any] = Field(default_factory=dict)


class GraphNodeDetailResponse(BaseModel):
    """Detailed metadata and connection summary for a selected node"""
    node: GraphNode
    connected_count: int = Field(..., description="Total connected edges")
    connected_by_type: Dict[str, int] = Field(default_factory=dict, description="Counts by edge type")
    neighbors_preview: List[GraphNode] = Field(default_factory=list, description="Sample of immediate neighbors")
    document_links: List[Dict[str, Any]] = Field(default_factory=list, description="Linked documents/chunks if any")


class GraphNeighborsResponse(BaseModel):
    """Immediate neighbor expansion result"""
    center_node: GraphNode
    neighbor_nodes: List[GraphNode] = Field(default_factory=list)
    relationships: List[GraphRelationship] = Field(default_factory=list)
    total_neighbors: int = Field(..., description="Total count of connected neighbors")
