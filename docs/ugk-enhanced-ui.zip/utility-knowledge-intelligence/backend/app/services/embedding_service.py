"""
Embedding service using Sentence Transformers for local text embeddings
"""

import logging
from typing import List, Union, Optional
import numpy as np
from sentence_transformers import SentenceTransformer
import torch

from app.core.config import settings

logger = logging.getLogger(__name__)


class EmbeddingService:
    """Service for generating text embeddings using Sentence Transformers"""
    
    def __init__(self):
        self._model: Optional[SentenceTransformer] = None
        self._model_name = settings.embedding_model
        self._device = settings.embedding_device
        self._batch_size = settings.embedding_batch_size
        self._dimension = settings.embedding_dimension
    
    def _load_model(self) -> SentenceTransformer:
        """Load the embedding model lazily"""
        if self._model is None:
            try:
                logger.info(f"Loading embedding model: {self._model_name}")
                logger.info(f"Using device: {self._device}")
                
                # Load model with specified device
                self._model = SentenceTransformer(
                    self._model_name,
                    device=self._device
                )
                
                # Verify model dimension
                test_embedding = self._model.encode("test", convert_to_numpy=True)
                actual_dimension = len(test_embedding)
                
                if actual_dimension != self._dimension:
                    logger.warning(
                        f"Model dimension mismatch: expected {self._dimension}, "
                        f"got {actual_dimension}"
                    )
                    # Update dimension to match actual model
                    self._dimension = actual_dimension
                
                logger.info(f"Model loaded successfully with dimension: {actual_dimension}")
                
            except Exception as e:
                logger.error(f"Failed to load embedding model {self._model_name}: {e}")
                raise RuntimeError(
                    f"Cannot initialize embedding model {self._model_name}. "
                    f"Please check the model name and ensure sentence-transformers is installed."
                ) from e
        
        return self._model
    
    @property
    def model_name(self) -> str:
        """Get the model name"""
        return self._model_name
    
    @property
    def dimension(self) -> int:
        """Get the embedding dimension"""
        return self._dimension
    
    @property
    def device(self) -> str:
        """Get the device being used"""
        return self._device
    
    def embed_text(self, text: str, normalize: bool = True) -> List[float]:
        """
        Generate embedding for a single text
        
        Args:
            text: Input text to embed
            normalize: Whether to normalize the embedding for cosine similarity
            
        Returns:
            List of float values representing the embedding
        """
        if not text or text.strip() == "":
            logger.warning("Empty text provided for embedding")
            # Return a small random vector for empty text to ensure valid Neo4j vector
            # This creates a low-similarity embedding that won't match anything strongly
            import random
            random.seed(42)  # Consistent seed for reproducible results
            embedding = [random.uniform(-0.001, 0.001) for _ in range(self._dimension)]
            if normalize:
                # Normalize the small random vector
                norm = np.linalg.norm(embedding)
                if norm > 0:
                    embedding = (np.array(embedding) / norm).tolist()
            return embedding
        
        model = self._load_model()
        
        try:
            # Generate embedding
            embedding = model.encode(
                text,
                convert_to_numpy=True,
                normalize_embeddings=normalize
            )
            
            # Convert to list of floats
            return embedding.tolist()
            
        except Exception as e:
            logger.error(f"Error generating embedding for text: {e}")
            raise RuntimeError(f"Failed to generate embedding: {e}") from e
    
    def embed_texts(self, texts: List[str], normalize: bool = True) -> List[List[float]]:
        """
        Generate embeddings for multiple texts in batches
        
        Args:
            texts: List of input texts to embed
            normalize: Whether to normalize embeddings for cosine similarity
            
        Returns:
            List of embeddings, each as a list of float values
        """
        if not texts:
            return []
        
        # Handle empty texts
        processed_texts = []
        for text in texts:
            if not text or text.strip() == "":
                processed_texts.append("")  # Will be handled as zero vector
            else:
                processed_texts.append(text.strip())
        
        model = self._load_model()
        embeddings = []
        
        try:
            # Process in batches
            for i in range(0, len(processed_texts), self._batch_size):
                batch_texts = processed_texts[i:i + self._batch_size]
                
                # Generate embeddings for batch
                batch_embeddings = model.encode(
                    batch_texts,
                    convert_to_numpy=True,
                    normalize_embeddings=normalize,
                    batch_size=min(len(batch_texts), self._batch_size)
                )
                
                # Convert to list of lists
                for j, embedding in enumerate(batch_embeddings):
                    if not batch_texts[j]:  # Empty text
                        # Create small random vector for empty text
                        import random
                        random.seed(42 + j)  # Consistent but different seeds
                        empty_embedding = [random.uniform(-0.001, 0.001) for _ in range(self._dimension)]
                        if normalize:
                            norm = np.linalg.norm(empty_embedding)
                            if norm > 0:
                                empty_embedding = (np.array(empty_embedding) / norm).tolist()
                        embeddings.append(empty_embedding)
                    else:
                        embeddings.append(embedding.tolist())
            
            return embeddings
            
        except Exception as e:
            logger.error(f"Error generating batch embeddings: {e}")
            raise RuntimeError(f"Failed to generate batch embeddings: {e}") from e
    
    def compute_similarity(self, embedding1: List[float], embedding2: List[float]) -> float:
        """
        Compute cosine similarity between two embeddings
        
        Args:
            embedding1: First embedding vector
            embedding2: Second embedding vector
            
        Returns:
            Cosine similarity score between -1 and 1
        """
        try:
            # Convert to numpy arrays
            vec1 = np.array(embedding1)
            vec2 = np.array(embedding2)
            
            # Compute cosine similarity
            dot_product = np.dot(vec1, vec2)
            norm1 = np.linalg.norm(vec1)
            norm2 = np.linalg.norm(vec2)
            
            if norm1 == 0 or norm2 == 0:
                return 0.0
            
            similarity = dot_product / (norm1 * norm2)
            return float(similarity)
            
        except Exception as e:
            logger.error(f"Error computing similarity: {e}")
            return 0.0
    
    def is_valid_embedding(self, embedding: Optional[List[float]]) -> bool:
        """
        Check if an embedding is valid
        
        Args:
            embedding: Embedding to validate
            
        Returns:
            True if embedding is valid, False otherwise
        """
        if not embedding:
            return False
        
        if len(embedding) != self._dimension:
            return False
        
        # Check if all values are finite
        try:
            return all(np.isfinite(x) for x in embedding)
        except (TypeError, ValueError):
            return False


# Global embedding service instance
embedding_service = EmbeddingService()