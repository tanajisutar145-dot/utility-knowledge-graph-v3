"""
Service for Knowledge Graph operations, exploration, and neighbor traversal
"""

import logging
from datetime import datetime, date
from typing import List, Dict, Any, Optional, Tuple, Set
from fastapi import HTTPException

from app.graph.neo4j_client import neo4j_client
from app.models.graph import (
    GraphNode,
    GraphRelationship,
    GraphOverviewResponse,
    GraphExploreResponse,
    GraphNodeDetailResponse,
    GraphNeighborsResponse,
)

logger = logging.getLogger(__name__)


def serialize_property_value(val: Any) -> Any:
    """Safely convert Neo4j types and embeddings to JSON-serializable primitives"""
    if val is None:
        return None
    if isinstance(val, (datetime, date)):
        return val.isoformat()
    if hasattr(val, "isoformat"):
        return val.isoformat()
    if hasattr(val, "to_native"):
        native = val.to_native()
        if hasattr(native, "isoformat"):
            return native.isoformat()
        return str(native)
    if isinstance(val, (int, float, bool, str)):
        return val
    if isinstance(val, list):
        # Truncate high-dimensional vector embeddings to keep response lightweight
        if len(val) > 20 and all(isinstance(x, (int, float)) for x in val[:5]):
            return f"[{len(val)} dimensions vector]"
        return [serialize_property_value(x) for x in val]
    if isinstance(val, dict):
        return {k: serialize_property_value(v) for k, v in val.items()}
    return str(val)


def extract_node_display_info(labels: List[str], properties: Dict[str, Any]) -> Tuple[str, str, str]:
    """Extract standard primary label, domain entity ID, and display name"""
    primary_label = labels[0] if labels else "Entity"

    entity_id = (
        properties.get("asset_id") or
        properties.get("unit_id") or
        properties.get("plant_id") or
        properties.get("utility_id") or
        properties.get("component_id") or
        properties.get("work_order_id") or
        properties.get("inspection_id") or
        properties.get("failure_id") or
        properties.get("outage_id") or
        properties.get("test_id") or
        properties.get("maintenance_plan_id") or
        properties.get("document_id") or
        properties.get("chunk_id") or
        ""
    )

    name = (
        properties.get("name") or
        properties.get("unit_name") or
        properties.get("component_name") or
        properties.get("plan_name") or
        properties.get("title") or
        properties.get("failure_mode") or
        properties.get("asset_tag") or
        (f"Chunk {properties.get('chunk_id')}" if "Chunk" in labels else "") or
        (str(entity_id) if entity_id else "") or
        primary_label
    )

    return primary_label, str(entity_id), str(name)


class GraphService:
    """Service for managing knowledge graph exploration and traversal"""

    def __init__(self):
        self.client = neo4j_client

    def _ensure_connectivity(self):
        """Verify Neo4j connectivity before querying"""
        if not self.client.verify_connectivity():
            logger.error("Neo4j database connection unavailable for graph service")
            raise HTTPException(
                status_code=503,
                detail="Database service unavailable. Cannot connect to Neo4j."
            )

    def _get_whitelists(self) -> Tuple[Set[str], Set[str]]:
        """Retrieve valid schema labels and relationship types to prevent query injection"""
        try:
            label_res = self.client.execute_query("CALL db.labels() YIELD label RETURN label")
            labels = {r["label"] for r in label_res}
        except Exception:
            labels = {
                "Utility", "PowerPlant", "GeneratingUnit", "Asset", "Component",
                "Inspection", "FailureEvent", "WorkOrder", "MaintenancePlan",
                "OutageEvent", "HeatRateTest", "Document", "Chunk"
            }

        try:
            rel_res = self.client.execute_query("CALL db.relationshipTypes() YIELD relationshipType RETURN relationshipType")
            rel_types = {r["relationshipType"] for r in rel_res}
        except Exception:
            rel_types = {
                "HAS_PLANT", "HAS_UNIT", "HAS_ASSET", "HAS_COMPONENT", "HAS_INSPECTION",
                "HAS_FAILURE", "HAS_WORK_ORDER", "HAS_MAINTENANCE_PLAN", "HAS_OUTAGE",
                "HAS_HEAT_RATE_TEST", "TRIGGERED_WORK_ORDER", "HAS_CHUNK", "ABOUT_UNIT",
                "ABOUT_ASSET", "ABOUT_INSPECTION", "ABOUT_FAILURE", "ABOUT_WORK_ORDER"
            }

        return labels, rel_types

    def _build_graph_node(self, eid: str, labels: List[str], raw_props: Dict[str, Any]) -> GraphNode:
        """Construct GraphNode model with sanitized properties"""
        primary_label, entity_id, name = extract_node_display_info(labels, raw_props)
        clean_props = {k: serialize_property_value(v) for k, v in raw_props.items()}
        return GraphNode(
            id=eid,
            label=primary_label,
            labels=labels,
            name=name,
            entity_id=entity_id,
            properties=clean_props,
        )

    def _build_graph_rel(self, eid: str, rel_type: str, src: str, tgt: str, raw_props: Dict[str, Any]) -> GraphRelationship:
        """Construct GraphRelationship model with sanitized properties"""
        clean_props = {k: serialize_property_value(v) for k, v in raw_props.items()}
        return GraphRelationship(
            id=eid,
            source=src,
            target=tgt,
            type=rel_type,
            properties=clean_props,
        )

    def get_overview(self) -> GraphOverviewResponse:
        """Return graph-wide node and relationship counts grouped by label and type"""
        self._ensure_connectivity()
        valid_labels, valid_rels = self._get_whitelists()

        # Grouped node counts
        node_counts: Dict[str, int] = {}
        for lbl in sorted(valid_labels):
            cnt = self.client.get_node_count(lbl)
            if cnt > 0:
                node_counts[lbl] = cnt

        # Grouped relationship counts
        rel_counts: Dict[str, int] = {}
        for rt in sorted(valid_rels):
            cnt = self.client.get_relationship_count(rt)
            if cnt > 0:
                rel_counts[rt] = cnt

        total_nodes = self.client.get_node_count()
        total_rels = self.client.get_relationship_count()

        return GraphOverviewResponse(
            total_nodes=total_nodes,
            total_relationships=total_rels,
            node_counts_by_label=node_counts,
            relationship_counts_by_type=rel_counts,
            available_labels=sorted(valid_labels),
            available_relationship_types=sorted(valid_rels),
        )

    def explore_graph(
        self,
        node_label: Optional[str] = None,
        rel_type: Optional[str] = None,
        query: Optional[str] = None,
        limit: int = 100,
    ) -> GraphExploreResponse:
        """
        Retrieve filtered, strictly bounded nodes and their internal relationships.
        Validates labels/types against schema whitelist.
        """
        self._ensure_connectivity()
        valid_labels, valid_rels = self._get_whitelists()

        # Enforce strict bounds
        bounded_limit = max(1, min(limit, 250))

        # Validate filters
        cleaned_label = node_label if node_label and node_label in valid_labels else None
        cleaned_rel = rel_type if rel_type and rel_type in valid_rels else None
        search_query = query.strip() if query and query.strip() else None

        where_clauses: List[str] = []
        params: Dict[str, Any] = {"limit": bounded_limit}

        if cleaned_label:
            node_pattern = f"(n:{cleaned_label})"
        else:
            node_pattern = "(n)"

        if search_query:
            params["search_term"] = search_query
            where_clauses.append(
                "any(val in [n.name, n.asset_id, n.unit_name, n.unit_id, n.plant_id, n.utility_id, "
                "n.title, n.failure_mode, n.component_name, n.plan_name, n.description, n.asset_tag, "
                "n.work_order_id, n.inspection_id, n.failure_id, n.outage_id, n.test_id, n.chunk_id] "
                "WHERE val IS NOT NULL AND toLower(toString(val)) CONTAINS toLower($search_term))"
            )

        where_str = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""

        cypher_nodes = f"""
        MATCH {node_pattern}
        {where_str}
        RETURN elementId(n) as eid, labels(n) as lbls, properties(n) as props
        LIMIT $limit
        """

        node_records = self.client.execute_query(cypher_nodes, params)
        nodes: List[GraphNode] = []
        node_ids: List[str] = []

        for r in node_records:
            eid = r["eid"]
            node_ids.append(eid)
            nodes.append(self._build_graph_node(eid, r.get("lbls", []), r.get("props", {})))

        relationships: List[GraphRelationship] = []
        if node_ids:
            # Query relationships strictly between the retrieved nodes
            if cleaned_rel:
                rel_pattern = f"-[r:{cleaned_rel}]->"
            else:
                rel_pattern = "-[r]->"

            cypher_rels = f"""
            MATCH (n){rel_pattern}(m)
            WHERE elementId(n) IN $node_ids AND elementId(m) IN $node_ids
            RETURN elementId(r) as eid, type(r) as r_type,
                   elementId(n) as src, elementId(m) as tgt, properties(r) as props
            """
            rel_records = self.client.execute_query(cypher_rels, {"node_ids": node_ids})
            for r in rel_records:
                relationships.append(
                    self._build_graph_rel(
                        r["eid"],
                        r["r_type"],
                        r["src"],
                        r["tgt"],
                        r.get("props", {}),
                    )
                )

        is_truncated = len(nodes) >= bounded_limit

        return GraphExploreResponse(
            nodes=nodes,
            relationships=relationships,
            total_nodes=len(nodes),
            total_relationships=len(relationships),
            is_truncated=is_truncated,
            filters_applied={
                "node_label": cleaned_label,
                "rel_type": cleaned_rel,
                "query": search_query,
                "limit": bounded_limit,
            },
        )

    def get_node_detail(self, node_id: str) -> GraphNodeDetailResponse:
        """
        Retrieve detailed properties, edge summary, and neighbor sample for a node by elementId or domain ID
        """
        self._ensure_connectivity()

        # Try elementId first
        cypher_node = """
        MATCH (n)
        WHERE elementId(n) = $node_id
           OR n.asset_id = $node_id
           OR n.unit_id = $node_id
           OR n.plant_id = $node_id
           OR n.utility_id = $node_id
           OR n.failure_id = $node_id
           OR n.work_order_id = $node_id
           OR n.document_id = $node_id
           OR n.chunk_id = $node_id
        RETURN elementId(n) as eid, labels(n) as lbls, properties(n) as props
        LIMIT 1
        """
        node_records = self.client.execute_query(cypher_node, {"node_id": node_id})
        if not node_records:
            raise HTTPException(status_code=404, detail=f"Node '{node_id}' not found in knowledge graph")

        target_record = node_records[0]
        target_eid = target_record["eid"]
        target_node = self._build_graph_node(
            target_eid,
            target_record.get("lbls", []),
            target_record.get("props", {}),
        )

        # Edge counts by type
        cypher_edges = """
        MATCH (n) WHERE elementId(n) = $target_eid
        MATCH (n)-[r]-(neighbor)
        RETURN type(r) as r_type, count(r) as cnt
        """
        edge_records = self.client.execute_query(cypher_edges, {"target_eid": target_eid})
        connected_by_type = {r["r_type"]: r["cnt"] for r in edge_records if r.get("r_type")}
        total_connected = sum(connected_by_type.values())

        # Sample preview of neighbors
        cypher_neighbors = """
        MATCH (n) WHERE elementId(n) = $target_eid
        MATCH (n)-[r]-(neighbor)
        RETURN elementId(neighbor) as eid, labels(neighbor) as lbls, properties(neighbor) as props
        LIMIT 10
        """
        neighbor_records = self.client.execute_query(cypher_neighbors, {"target_eid": target_eid})
        neighbors_preview = [
            self._build_graph_node(r["eid"], r.get("lbls", []), r.get("props", {}))
            for r in neighbor_records
        ]

        # Check for linked documents/chunks
        cypher_docs = """
        MATCH (n) WHERE elementId(n) = $target_eid
        MATCH (n)<-[:ABOUT_ASSET|ABOUT_UNIT|ABOUT_FAILURE|ABOUT_WORK_ORDER|ABOUT_INSPECTION]-(c:Chunk)<-[:HAS_CHUNK]-(d:Document)
        RETURN d.document_id as doc_id, d.title as title, c.chunk_id as chunk_id, left(c.text, 150) as snippet
        LIMIT 5
        """
        doc_records = self.client.execute_query(cypher_docs, {"target_eid": target_eid})
        document_links = [
            {
                "document_id": r["doc_id"],
                "title": r.get("title") or r["doc_id"],
                "chunk_id": r["chunk_id"],
                "snippet": r.get("snippet", ""),
            }
            for r in doc_records
        ]

        return GraphNodeDetailResponse(
            node=target_node,
            connected_count=total_connected,
            connected_by_type=connected_by_type,
            neighbors_preview=neighbors_preview,
            document_links=document_links,
        )

    def get_node_neighbors(
        self,
        node_id: str,
        limit: int = 50,
        rel_type: Optional[str] = None,
        direction: str = "both",
    ) -> GraphNeighborsResponse:
        """
        Expand immediate neighbors of a node with strict limits
        """
        self._ensure_connectivity()
        valid_labels, valid_rels = self._get_whitelists()

        bounded_limit = max(1, min(limit, 100))
        cleaned_rel = rel_type if rel_type and rel_type in valid_rels else None

        # Resolve center node
        cypher_center = """
        MATCH (n)
        WHERE elementId(n) = $node_id
           OR n.asset_id = $node_id
           OR n.unit_id = $node_id
           OR n.plant_id = $node_id
           OR n.utility_id = $node_id
           OR n.failure_id = $node_id
           OR n.work_order_id = $node_id
        RETURN elementId(n) as eid, labels(n) as lbls, properties(n) as props
        LIMIT 1
        """
        center_records = self.client.execute_query(cypher_center, {"node_id": node_id})
        if not center_records:
            raise HTTPException(status_code=404, detail=f"Center node '{node_id}' not found")

        center_eid = center_records[0]["eid"]
        center_node = self._build_graph_node(
            center_eid,
            center_records[0].get("lbls", []),
            center_records[0].get("props", {}),
        )

        # Build direction pattern
        rel_token = f":{cleaned_rel}" if cleaned_rel else ""
        if direction == "out":
            pattern = f"-[r{rel_token}]->"
        elif direction == "in":
            pattern = f"<-[r{rel_token}]-"
        else:
            pattern = f"-[r{rel_token}]-"

        cypher_neighbors = f"""
        MATCH (n) WHERE elementId(n) = $center_eid
        MATCH (n){pattern}(neighbor)
        RETURN elementId(neighbor) as eid, labels(neighbor) as lbls, properties(neighbor) as props,
               elementId(r) as r_eid, type(r) as r_type,
               elementId(startNode(r)) as r_src, elementId(endNode(r)) as r_tgt,
               properties(r) as r_props
        LIMIT $limit
        """
        records = self.client.execute_query(cypher_neighbors, {"center_eid": center_eid, "limit": bounded_limit})

        seen_node_eids = set()
        seen_rel_eids = set()
        neighbor_nodes: List[GraphNode] = []
        relationships: List[GraphRelationship] = []

        for r in records:
            neigh_eid = r["eid"]
            if neigh_eid not in seen_node_eids and neigh_eid != center_eid:
                seen_node_eids.add(neigh_eid)
                neighbor_nodes.append(
                    self._build_graph_node(neigh_eid, r.get("lbls", []), r.get("props", {}))
                )

            rel_eid = r["r_eid"]
            if rel_eid not in seen_rel_eids:
                seen_rel_eids.add(rel_eid)
                relationships.append(
                    self._build_graph_rel(
                        rel_eid,
                        r["r_type"],
                        r["r_src"],
                        r["r_tgt"],
                        r.get("r_props", {}),
                    )
                )

        return GraphNeighborsResponse(
            center_node=center_node,
            neighbor_nodes=neighbor_nodes,
            relationships=relationships,
            total_neighbors=len(neighbor_nodes),
        )

    # Legacy methods for backward compatibility
    async def get_nodes(self, node_type: Optional[str] = None, limit: int = 100) -> List[dict]:
        res = self.explore_graph(node_label=node_type, limit=limit)
        return [{"id": n.id, "label": n.name, "type": n.label, "properties": n.properties} for n in res.nodes]

    async def get_relationships(self, relationship_type: Optional[str] = None, limit: int = 100) -> List[dict]:
        res = self.explore_graph(rel_type=relationship_type, limit=limit)
        return [{"id": r.id, "source": r.source, "target": r.target, "type": r.type, "properties": r.properties} for r in res.relationships]

    async def get_subgraph(self, node_id: str, depth: int = 2) -> dict:
        res = self.get_node_neighbors(node_id, limit=50)
        all_nodes = [res.center_node] + res.neighbor_nodes
        return {
            "nodes": [{"id": n.id, "label": n.name, "type": n.label, "properties": n.properties} for n in all_nodes],
            "relationships": [{"id": r.id, "source": r.source, "target": r.target, "type": r.type, "properties": r.properties} for r in res.relationships]
        }

    async def find_path(self, start_node: str, end_node: str, max_depth: int = 5) -> dict:
        return {"path": [start_node, end_node], "length": 1, "relationships": []}


# Global graph service instance
graph_service = GraphService()