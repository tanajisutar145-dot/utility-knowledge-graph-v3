"""
Asset management service with Neo4j knowledge graph integration
"""

import logging
from datetime import datetime, date
from typing import List, Optional, Dict, Any

from app.graph.neo4j_client import neo4j_client
from app.models.assets import (
    AssetOverviewResponse,
    AssetSummaryItem,
    AssetListResponse,
    AssetParentHierarchy,
    GeneratingUnitHierarchy,
    PowerPlantHierarchy,
    AssetComponent,
    AssetInspection,
    AssetWorkOrder,
    AssetMaintenancePlan,
    AssetFailureEvent,
    AssetOutageEvent,
    AssetDocument,
    AssetDetailResponse,
)

logger = logging.getLogger(__name__)


def serialize_val(val: Any) -> Any:
    """Safely convert Neo4j dates and structures to JSON-serializable primitives"""
    if val is None:
        return None
    if isinstance(val, (datetime, date)):
        return val.isoformat()
    if hasattr(val, "isoformat"):
        return val.isoformat()
    if hasattr(val, "to_native"):
        native = val.to_native()
        if hasattr(native, "isoformat"):
            return native.isoformat()
        return str(native)
    if isinstance(val, (int, float, bool, str)):
        return val
    if isinstance(val, list):
        if len(val) > 20 and all(isinstance(x, (int, float)) for x in val[:5]):
            return f"[{len(val)} dimensions vector]"
        return [serialize_val(x) for x in val]
    if isinstance(val, dict):
        return {k: serialize_val(v) for k, v in val.items()}
    return str(val)


class AssetService:
    """Service for querying asset inventory and detailed relational context"""

    def __init__(self):
        self.client = neo4j_client

    def get_overview(self) -> AssetOverviewResponse:
        """Get inventory summary statistics"""
        # Total and operational counts
        counts_q = """
        MATCH (a:Asset)
        RETURN count(a) as total,
               count(CASE WHEN a.operational_status = 'operational' THEN 1 END) as operational
        """
        counts_res = self.client.execute_query(counts_q)
        total_assets = counts_res[0]["total"] if counts_res else 0
        operational_assets = counts_res[0]["operational"] if counts_res else 0

        # Assets with failures
        fail_q = """
        MATCH (a:Asset)-[:HAS_FAILURE]->(f:FailureEvent)
        RETURN count(DISTINCT a) as with_failures
        """
        fail_res = self.client.execute_query(fail_q)
        assets_with_failures = fail_res[0]["with_failures"] if fail_res else 0

        # Criticality breakdown
        crit_q = """
        MATCH (a:Asset)
        RETURN a.criticality as crit, count(a) as count
        ORDER BY count DESC
        """
        crit_res = self.client.execute_query(crit_q)
        criticality_counts = {r["crit"]: r["count"] for r in crit_res if r.get("crit")}

        # Asset class breakdown
        class_q = """
        MATCH (a:Asset)
        RETURN a.asset_class as a_class, count(a) as count
        ORDER BY count DESC
        """
        class_res = self.client.execute_query(class_q)
        asset_class_counts = {r["a_class"]: r["count"] for r in class_res if r.get("a_class")}

        # Operational status breakdown
        status_q = """
        MATCH (a:Asset)
        RETURN a.operational_status as op_status, count(a) as count
        ORDER BY count DESC
        """
        status_res = self.client.execute_query(status_q)
        status_counts = {r["op_status"]: r["count"] for r in status_res if r.get("op_status")}

        return AssetOverviewResponse(
            total_assets=total_assets,
            operational_assets=operational_assets,
            assets_with_failures=assets_with_failures,
            criticality_counts=criticality_counts,
            asset_class_counts=asset_class_counts,
            status_counts=status_counts,
        )

    def list_assets(
        self,
        search: Optional[str] = None,
        asset_class: Optional[str] = None,
        criticality: Optional[str] = None,
        operational_status: Optional[str] = None,
        unit_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 50,
    ) -> AssetListResponse:
        """List assets with filtering, search, and related counts"""
        where_clauses = []
        params: Dict[str, Any] = {"skip": skip, "limit": limit}

        if asset_class:
            where_clauses.append("a.asset_class = $asset_class")
            params["asset_class"] = asset_class

        if criticality:
            where_clauses.append("a.criticality = $criticality")
            params["criticality"] = criticality

        if operational_status:
            where_clauses.append("a.operational_status = $operational_status")
            params["operational_status"] = operational_status

        if unit_id:
            where_clauses.append("a.unit_id = $unit_id")
            params["unit_id"] = unit_id

        if search and search.strip():
            where_clauses.append(
                "(toLower(a.name) CONTAINS toLower($search) "
                "OR toLower(a.asset_id) CONTAINS toLower($search) "
                "OR toLower(coalesce(a.asset_tag, '')) CONTAINS toLower($search) "
                "OR toLower(coalesce(a.model, '')) CONTAINS toLower($search) "
                "OR toLower(coalesce(a.manufacturer, '')) CONTAINS toLower($search))"
            )
            params["search"] = search.strip()

        where_stmt = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

        # Total count query
        count_q = f"MATCH (a:Asset) {where_stmt} RETURN count(a) as total"
        count_res = self.client.execute_query(count_q, params)
        total = count_res[0]["total"] if count_res else 0

        # Query items
        query = f"""
        MATCH (a:Asset)
        {where_stmt}
        OPTIONAL MATCH (u:GeneratingUnit)-[:HAS_ASSET]->(a)
        OPTIONAL MATCH (p:PowerPlant)-[:HAS_UNIT]->(u)
        OPTIONAL MATCH (a)-[:HAS_COMPONENT]->(c:Component)
        OPTIONAL MATCH (a)-[:HAS_INSPECTION]->(i:Inspection)
        OPTIONAL MATCH (a)-[:HAS_FAILURE]->(f:FailureEvent)
        OPTIONAL MATCH (a)-[:HAS_WORK_ORDER]->(w:WorkOrder)
        OPTIONAL MATCH (d:Document)-[:ABOUT_ASSET]->(a)
        WITH a, u, p,
             count(DISTINCT c) as components,
             count(DISTINCT i) as inspections,
             count(DISTINCT f) as failures,
             count(DISTINCT w) as work_orders,
             count(DISTINCT d) as docs
        RETURN a.asset_id as asset_id,
               a.name as name,
               coalesce(a.asset_class, 'unknown') as asset_class,
               coalesce(a.criticality, 'medium') as criticality,
               coalesce(a.operational_status, 'operational') as operational_status,
               a.manufacturer as manufacturer,
               a.model as model,
               a.installation_date as installation_date,
               a.asset_tag as asset_tag,
               a.unit_id as unit_id,
               u.unit_name as unit_name,
               p.plant_id as plant_id,
               p.name as plant_name,
               components,
               inspections,
               failures,
               work_orders,
               docs
        ORDER BY a.asset_id ASC
        SKIP $skip
        LIMIT $limit
        """
        rows = self.client.execute_query(query, params)

        items = []
        for r in rows:
            items.append(
                AssetSummaryItem(
                    asset_id=r["asset_id"],
                    name=r["name"] or r["asset_id"],
                    asset_class=r["asset_class"],
                    criticality=r["criticality"],
                    operational_status=r["operational_status"],
                    manufacturer=r.get("manufacturer"),
                    model=r.get("model"),
                    installation_date=serialize_val(r.get("installation_date")),
                    asset_tag=r.get("asset_tag"),
                    unit_id=r.get("unit_id"),
                    unit_name=r.get("unit_name"),
                    plant_id=r.get("plant_id"),
                    plant_name=r.get("plant_name"),
                    component_count=int(r.get("components", 0)),
                    inspection_count=int(r.get("inspections", 0)),
                    failure_count=int(r.get("failures", 0)),
                    work_order_count=int(r.get("work_orders", 0)),
                    document_count=int(r.get("docs", 0)),
                )
            )

        return AssetListResponse(
            assets=items,
            total=total,
            skip=skip,
            limit=limit,
        )

    def get_asset_detail(self, asset_id: str) -> Optional[AssetDetailResponse]:
        """Get full relational context for a specific asset"""
        # 1. Base asset node
        asset_q = """
        MATCH (a:Asset {asset_id: $asset_id})
        OPTIONAL MATCH (u:GeneratingUnit)-[:HAS_ASSET]->(a)
        OPTIONAL MATCH (p:PowerPlant)-[:HAS_UNIT]->(u)
        OPTIONAL MATCH (a)-[:HAS_COMPONENT]->(c:Component)
        OPTIONAL MATCH (a)-[:HAS_INSPECTION]->(i:Inspection)
        OPTIONAL MATCH (a)-[:HAS_FAILURE]->(f:FailureEvent)
        OPTIONAL MATCH (a)-[:HAS_WORK_ORDER]->(w:WorkOrder)
        OPTIONAL MATCH (d:Document)-[:ABOUT_ASSET]->(a)
        WITH a, u, p,
             count(DISTINCT c) as components,
             count(DISTINCT i) as inspections,
             count(DISTINCT f) as failures,
             count(DISTINCT w) as work_orders,
             count(DISTINCT d) as docs
        RETURN a.asset_id as asset_id,
               a.name as name,
               coalesce(a.asset_class, 'unknown') as asset_class,
               coalesce(a.criticality, 'medium') as criticality,
               coalesce(a.operational_status, 'operational') as operational_status,
               a.manufacturer as manufacturer,
               a.model as model,
               a.installation_date as installation_date,
               a.asset_tag as asset_tag,
               a.unit_id as unit_id,
               u.unit_name as unit_name,
               u.unit_type as unit_type,
               u.capacity_mw as unit_capacity,
               u.status as unit_status,
               p.plant_id as plant_id,
               p.name as plant_name,
               p.location as plant_location,
               p.plant_type as plant_type,
               p.capacity_mw as plant_capacity,
               components,
               inspections,
               failures,
               work_orders,
               docs
        """
        asset_res = self.client.execute_query(asset_q, {"asset_id": asset_id})
        if not asset_res:
            return None
        ar = asset_res[0]

        summary_item = AssetSummaryItem(
            asset_id=ar["asset_id"],
            name=ar["name"] or ar["asset_id"],
            asset_class=ar["asset_class"],
            criticality=ar["criticality"],
            operational_status=ar["operational_status"],
            manufacturer=ar.get("manufacturer"),
            model=ar.get("model"),
            installation_date=serialize_val(ar.get("installation_date")),
            asset_tag=ar.get("asset_tag"),
            unit_id=ar.get("unit_id"),
            unit_name=ar.get("unit_name"),
            plant_id=ar.get("plant_id"),
            plant_name=ar.get("plant_name"),
            component_count=int(ar.get("components", 0)),
            inspection_count=int(ar.get("inspections", 0)),
            failure_count=int(ar.get("failures", 0)),
            work_order_count=int(ar.get("work_orders", 0)),
            document_count=int(ar.get("docs", 0)),
        )

        # Hierarchy
        gen_unit = None
        if ar.get("unit_id"):
            gen_unit = GeneratingUnitHierarchy(
                unit_id=ar["unit_id"],
                unit_name=ar.get("unit_name") or ar["unit_id"],
                unit_type=ar.get("unit_type"),
                capacity_mw=float(ar["unit_capacity"]) if ar.get("unit_capacity") is not None else None,
                status=ar.get("unit_status"),
            )
        power_plant = None
        if ar.get("plant_id"):
            power_plant = PowerPlantHierarchy(
                plant_id=ar["plant_id"],
                name=ar.get("plant_name") or ar["plant_id"],
                location=ar.get("plant_location"),
                plant_type=ar.get("plant_type"),
                capacity_mw=float(ar["plant_capacity"]) if ar.get("plant_capacity") is not None else None,
            )
        hierarchy = AssetParentHierarchy(
            generating_unit=gen_unit,
            power_plant=power_plant,
        )

        # 2. Components
        comp_q = """
        MATCH (a:Asset {asset_id: $asset_id})-[:HAS_COMPONENT]->(c:Component)
        RETURN c.component_id as component_id,
               c.component_name as component_name,
               c.component_type as component_type,
               c.manufacturer as manufacturer,
               c.model as model,
               c.criticality as criticality,
               c.status as status
        ORDER BY c.component_name ASC
        """
        comp_res = self.client.execute_query(comp_q, {"asset_id": asset_id})
        components = [
            AssetComponent(
                component_id=c["component_id"],
                component_name=c["component_name"],
                component_type=c.get("component_type"),
                manufacturer=c.get("manufacturer"),
                model=c.get("model"),
                criticality=c.get("criticality"),
                status=c.get("status"),
            )
            for c in comp_res
        ]

        # 3. Inspections
        insp_q = """
        MATCH (a:Asset {asset_id: $asset_id})-[:HAS_INSPECTION]->(i:Inspection)
        RETURN i.inspection_id as inspection_id,
               i.inspection_date as inspection_date,
               i.inspection_type as inspection_type,
               i.inspector as inspector,
               i.condition as condition,
               i.findings as findings,
               i.severity as severity,
               i.recommended_action as recommended_action
        ORDER BY i.inspection_date DESC
        """
        insp_res = self.client.execute_query(insp_q, {"asset_id": asset_id})
        inspections = [
            AssetInspection(
                inspection_id=i["inspection_id"],
                inspection_date=serialize_val(i.get("inspection_date")),
                inspection_type=i.get("inspection_type"),
                inspector=i.get("inspector"),
                condition=i.get("condition"),
                findings=i.get("findings"),
                severity=i.get("severity"),
                recommended_action=i.get("recommended_action"),
            )
            for i in insp_res
        ]

        # 4. Work Orders
        wo_q = """
        MATCH (a:Asset {asset_id: $asset_id})-[:HAS_WORK_ORDER]->(w:WorkOrder)
        RETURN w.work_order_id as work_order_id,
               w.created_date as created_date,
               w.scheduled_date as scheduled_date,
               w.completion_date as completion_date,
               w.work_type as work_type,
               w.priority as priority,
               w.status as status,
               w.description as description,
               w.total_cost as total_cost
        ORDER BY w.created_date DESC
        """
        wo_res = self.client.execute_query(wo_q, {"asset_id": asset_id})
        work_orders = [
            AssetWorkOrder(
                work_order_id=w["work_order_id"],
                created_date=serialize_val(w.get("created_date")),
                scheduled_date=serialize_val(w.get("scheduled_date")),
                completion_date=serialize_val(w.get("completion_date")),
                work_type=w.get("work_type"),
                priority=w.get("priority"),
                status=w.get("status"),
                description=w.get("description"),
                total_cost=float(w["total_cost"]) if w.get("total_cost") is not None else None,
            )
            for w in wo_res
        ]

        # 5. Maintenance Plans
        mp_q = """
        MATCH (a:Asset {asset_id: $asset_id})-[:HAS_MAINTENANCE_PLAN]->(m:MaintenancePlan)
        RETURN m.maintenance_plan_id as maintenance_plan_id,
               m.plan_name as plan_name,
               m.maintenance_type as maintenance_type,
               m.frequency as frequency,
               m.last_execution_date as last_execution_date,
               m.next_due_date as next_due_date,
               m.status as status
        ORDER BY m.plan_name ASC
        """
        mp_res = self.client.execute_query(mp_q, {"asset_id": asset_id})
        maintenance_plans = [
            AssetMaintenancePlan(
                maintenance_plan_id=m["maintenance_plan_id"],
                plan_name=m["plan_name"],
                maintenance_type=m.get("maintenance_type"),
                frequency=m.get("frequency"),
                last_execution_date=serialize_val(m.get("last_execution_date")),
                next_due_date=serialize_val(m.get("next_due_date")),
                status=m.get("status"),
            )
            for m in mp_res
        ]

        # 6. Failure Events
        fail_q = """
        MATCH (a:Asset {asset_id: $asset_id})-[:HAS_FAILURE]->(f:FailureEvent)
        RETURN f.failure_id as failure_id,
               f.failure_date as failure_date,
               f.failure_mode as failure_mode,
               f.severity as severity,
               f.description as description,
               f.root_cause as root_cause,
               f.downtime_hours as downtime_hours,
               f.estimated_cost as estimated_cost,
               f.actual_cost as actual_cost,
               f.status as status
        ORDER BY f.failure_date DESC
        """
        fail_res = self.client.execute_query(fail_q, {"asset_id": asset_id})
        failures = [
            AssetFailureEvent(
                failure_id=f["failure_id"],
                failure_date=serialize_val(f.get("failure_date")),
                failure_mode=f.get("failure_mode"),
                severity=f.get("severity"),
                description=f.get("description"),
                root_cause=f.get("root_cause"),
                downtime_hours=float(f.get("downtime_hours", 0.0)),
                estimated_cost=float(f["estimated_cost"]) if f.get("estimated_cost") is not None else None,
                actual_cost=float(f["actual_cost"]) if f.get("actual_cost") is not None else None,
                status=f.get("status"),
            )
            for f in fail_res
        ]

        # 7. Outage Events from parent unit
        outages: List[AssetOutageEvent] = []
        if ar.get("unit_id"):
            outage_q = """
            MATCH (u:GeneratingUnit {unit_id: $unit_id})-[:HAS_OUTAGE]->(o:OutageEvent)
            RETURN o.outage_id as outage_id,
                   o.outage_type as outage_type,
                   o.start_date as start_date,
                   o.end_date as end_date,
                   o.duration_hours as duration_hours,
                   o.cause as cause,
                   o.status as status,
                   o.estimated_cost as estimated_cost
            ORDER BY o.start_date DESC
            """
            outage_res = self.client.execute_query(outage_q, {"unit_id": ar["unit_id"]})
            outages = [
                AssetOutageEvent(
                    outage_id=o["outage_id"],
                    outage_type=o.get("outage_type"),
                    start_date=serialize_val(o.get("start_date")),
                    end_date=serialize_val(o.get("end_date")),
                    duration_hours=float(o["duration_hours"]) if o.get("duration_hours") is not None else None,
                    cause=o.get("cause"),
                    status=o.get("status"),
                    estimated_cost=float(o["estimated_cost"]) if o.get("estimated_cost") is not None else None,
                )
                for o in outage_res
            ]

        # 8. Documents referencing this asset
        doc_q = """
        MATCH (d:Document)-[:ABOUT_ASSET]->(a:Asset {asset_id: $asset_id})
        RETURN d.document_id as document_id,
               d.title as title,
               d.document_type as document_type,
               d.source as source,
               d.created_date as created_date
        ORDER BY d.created_date DESC
        """
        doc_res = self.client.execute_query(doc_q, {"asset_id": asset_id})
        documents = [
            AssetDocument(
                document_id=d["document_id"],
                title=d["title"] or d["document_id"],
                document_type=d.get("document_type"),
                source=d.get("source"),
                created_date=serialize_val(d.get("created_date")),
            )
            for d in doc_res
        ]

        return AssetDetailResponse(
            asset=summary_item,
            hierarchy=hierarchy,
            components=components,
            inspections=inspections,
            work_orders=work_orders,
            maintenance_plans=maintenance_plans,
            failures=failures,
            outages=outages,
            documents=documents,
        )


asset_service = AssetService()
