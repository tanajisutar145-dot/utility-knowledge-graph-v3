"""
Service for retrieving real dashboard operational and intelligence metrics from Neo4j
"""

import logging
from datetime import datetime, timezone
from typing import Dict, Any, List
from fastapi import HTTPException

from app.graph.neo4j_client import neo4j_client
from app.core.config import settings
from app.models.dashboard import (
    DashboardSummaryResponse,
    DashboardKPIs,
    DashboardGraphStats,
    DashboardDocumentStats,
    AssetReliabilityStats,
    WorkOrderOverview,
    FailureItem,
    OutageTypeSummary,
    OutageOverview,
    InspectionOverview,
    OperationsStats,
    HeatRateObservation,
    HeatRateTrend,
    MaintenanceEffectiveness,
)

logger = logging.getLogger(__name__)


class DashboardService:
    """Service for computing dashboard intelligence metrics"""

    def __init__(self):
        self.client = neo4j_client

    def get_dashboard_summary(self) -> DashboardSummaryResponse:
        """
        Retrieve complete dashboard metrics from Neo4j.
        Read-only, parameterized Cypher queries.
        No LLM calls or data mutation.
        """
        # Verify Neo4j connectivity
        if not self.client.verify_connectivity():
            logger.error("Neo4j database connection unavailable for dashboard retrieval")
            raise HTTPException(
                status_code=503,
                detail="Database service unavailable. Cannot retrieve dashboard metrics."
            )

        try:
            # 1. Executive KPIs
            kpi_query = """
            MATCH (p:PowerPlant) WITH count(p) as plants
            MATCH (u:GeneratingUnit) WITH plants, count(u) as units
            MATCH (a:Asset) WITH plants, units, count(a) as assets
            MATCH (c:Component) WITH plants, units, assets, count(c) as components
            MATCH (w:WorkOrder) WITH plants, units, assets, components, count(w) as work_orders
            MATCH (i:Inspection) WITH plants, units, assets, components, work_orders, count(i) as inspections
            MATCH (f:FailureEvent) WITH plants, units, assets, components, work_orders, inspections, count(f) as failures
            MATCH (o:OutageEvent) WITH plants, units, assets, components, work_orders, inspections, failures, count(o) as outages
            MATCH (m:MaintenancePlan) WITH plants, units, assets, components, work_orders, inspections, failures, outages, count(m) as plans
            RETURN plants, units, assets, components, work_orders, inspections, failures, outages, plans
            """
            kpi_res = self.client.execute_query(kpi_query)
            kpi_row = kpi_res[0] if kpi_res else {}

            kpis = DashboardKPIs(
                power_plants=kpi_row.get("plants", 0),
                generating_units=kpi_row.get("units", 0),
                assets=kpi_row.get("assets", 0),
                components=kpi_row.get("components", 0),
                work_orders=kpi_row.get("work_orders", 0),
                inspections=kpi_row.get("inspections", 0),
                failure_events=kpi_row.get("failures", 0),
                outage_events=kpi_row.get("outages", 0),
                maintenance_plans=kpi_row.get("plans", 0),
            )

            # 2. Graph & Document counts
            graph_doc_query = """
            MATCH (d:Document) WITH count(d) as docs
            MATCH (c:Chunk) WITH docs, count(c) as chunks
            MATCH (ce:Chunk) 
                WHERE ce.embedding IS NOT NULL 
                AND size(ce.embedding) = $embedding_dim
                WITH docs, chunks, count(ce) as embedded
            MATCH (total_n) WITH docs, chunks, embedded, count(total_n) as total_nodes
            MATCH ()-[r]->() WITH docs, chunks, embedded, total_nodes, count(r) as total_rels
            RETURN docs, chunks, embedded, total_nodes, total_rels
            """
            gd_res = self.client.execute_query(
                graph_doc_query,
                {"embedding_dim": settings.embedding_dimension}
            )
            gd_row = gd_res[0] if gd_res else {}
            total_nodes = gd_row.get("total_nodes", 0)
            total_rels = gd_row.get("total_rels", 0)
            docs_count = gd_row.get("docs", 0)
            chunks_count = gd_row.get("chunks", 0)
            embedded_count = gd_row.get("embedded", 0)
            doc_nodes = docs_count + chunks_count
            structured_nodes = max(0, total_nodes - doc_nodes)

            graph_stats = DashboardGraphStats(
                total_nodes=total_nodes,
                total_relationships=total_rels,
                structured_nodes=structured_nodes,
                document_nodes=doc_nodes,
            )

            # Check Vector Index status
            index_status = "UNKNOWN"
            population_pct = 0.0
            try:
                idx_check = self.client.execute_query(
                    "SHOW INDEXES YIELD name, state, populationPercent WHERE name = 'chunk_embedding_index'"
                )
                if idx_check:
                    index_status = idx_check[0].get("state", "ONLINE")
                    population_pct = float(idx_check[0].get("populationPercent", 100.0))
            except Exception as e:
                logger.warning(f"Could not check vector index status: {e}")
                index_status = "ONLINE" if embedded_count > 0 else "ABSENT"
                population_pct = 100.0 if embedded_count > 0 else 0.0

            document_stats = DashboardDocumentStats(
                total_documents=docs_count,
                total_chunks=chunks_count,
                embedded_chunks=embedded_count,
                embedding_dimension=settings.embedding_dimension,
                embedding_model=settings.embedding_model,
                vector_index_name="chunk_embedding_index",
                vector_index_status=index_status,
                vector_index_population=population_pct,
            )

            # 3. Operational Intelligence - Asset Reliability
            asset_crit_res = self.client.execute_query(
                "MATCH (a:Asset) RETURN a.criticality as crit, count(a) as cnt"
            )
            criticality_counts = {row["crit"]: row["cnt"] for row in asset_crit_res if row.get("crit")}

            asset_status_res = self.client.execute_query(
                "MATCH (a:Asset) WHERE a.operational_status = 'operational' RETURN count(a) as cnt"
            )
            operational_assets = asset_status_res[0]["cnt"] if asset_status_res else kpis.assets

            asset_fail_res = self.client.execute_query(
                "MATCH (a:Asset)-[:HAS_FAILURE]->(f:FailureEvent) RETURN count(DISTINCT a) as cnt"
            )
            assets_with_failures = asset_fail_res[0]["cnt"] if asset_fail_res else 0

            asset_reliability = AssetReliabilityStats(
                total_assets=kpis.assets,
                operational_assets=operational_assets,
                assets_with_failures=assets_with_failures,
                criticality_counts=criticality_counts,
            )

            # 4. Operational Intelligence - Work Orders
            wo_status_res = self.client.execute_query(
                "MATCH (w:WorkOrder) RETURN w.status as status, count(w) as cnt"
            )
            status_counts = {row["status"]: row["cnt"] for row in wo_status_res if row.get("status")}

            wo_prio_res = self.client.execute_query(
                "MATCH (w:WorkOrder) RETURN w.priority as priority, count(w) as cnt"
            )
            priority_counts = {row["priority"]: row["cnt"] for row in wo_prio_res if row.get("priority")}

            wo_type_res = self.client.execute_query(
                "MATCH (w:WorkOrder) RETURN w.work_type as work_type, count(w) as cnt"
            )
            type_counts = {row["work_type"]: row["cnt"] for row in wo_type_res if row.get("work_type")}

            work_orders_overview = WorkOrderOverview(
                total_work_orders=kpis.work_orders,
                status_counts=status_counts,
                priority_counts=priority_counts,
                type_counts=type_counts,
            )

            # 5. Operational Intelligence - Failures
            failures_query = """
            MATCH (f:FailureEvent)
            OPTIONAL MATCH (a:Asset)-[:HAS_FAILURE]->(f)
            RETURN f.failure_id as failure_id, f.asset_id as asset_id, a.name as asset_name,
                   f.failure_mode as failure_mode, f.severity as severity,
                   f.downtime_hours as downtime_hours, f.actual_cost as actual_cost,
                   f.status as status, toString(f.failure_date) as failure_date
            ORDER BY f.failure_date DESC
            """
            fail_res = self.client.execute_query(failures_query)
            failure_items = [
                FailureItem(
                    failure_id=row["failure_id"],
                    asset_id=row["asset_id"] or "",
                    asset_name=row.get("asset_name") or f"Asset {row.get('asset_id')}",
                    failure_mode=row["failure_mode"] or "Unknown",
                    severity=row["severity"] or "medium",
                    downtime_hours=float(row.get("downtime_hours") or 0.0),
                    actual_cost=float(row.get("actual_cost")) if row.get("actual_cost") is not None else None,
                    status=row["status"] or "resolved",
                    failure_date=row.get("failure_date"),
                )
                for row in fail_res
            ]

            # 6. Operational Intelligence - Outages
            outage_query = """
            MATCH (o:OutageEvent)
            RETURN o.outage_type as outage_type, count(o) as cnt,
                   sum(o.duration_hours) as duration,
                   sum(o.estimated_cost) as cost,
                   sum(o.estimated_generation_loss_mwh) as loss_mwh
            """
            outage_res = self.client.execute_query(outage_query)
            by_type: Dict[str, OutageTypeSummary] = {}
            tot_duration = 0.0
            tot_cost = 0.0
            tot_loss = 0.0

            for row in outage_res:
                otype = row.get("outage_type") or "other"
                dur = float(row.get("duration") or 0.0)
                cost = float(row.get("cost") or 0.0)
                loss = float(row.get("loss_mwh") or 0.0)
                cnt = int(row.get("cnt") or 0)
                by_type[otype] = OutageTypeSummary(
                    count=cnt,
                    duration_hours=round(dur, 1),
                    estimated_cost=round(cost, 2),
                    loss_mwh=round(loss, 1),
                )
                tot_duration += dur
                tot_cost += cost
                tot_loss += loss

            outages_overview = OutageOverview(
                total_outages=kpis.outage_events,
                total_duration_hours=round(tot_duration, 1),
                total_estimated_cost=round(tot_cost, 2),
                total_loss_mwh=round(tot_loss, 1),
                by_type=by_type,
            )

            # 7. Operational Intelligence - Inspections
            insp_cond_res = self.client.execute_query(
                "MATCH (i:Inspection) RETURN i.condition as cond, count(i) as cnt"
            )
            insp_condition_counts = {row["cond"]: row["cnt"] for row in insp_cond_res if row.get("cond")}

            insp_sev_res = self.client.execute_query(
                "MATCH (i:Inspection) RETURN i.severity as sev, count(i) as cnt"
            )
            insp_severity_counts = {row["sev"]: row["cnt"] for row in insp_sev_res if row.get("sev")}

            inspection_overview = InspectionOverview(
                total_inspections=kpis.inspections,
                condition_counts=insp_condition_counts,
                severity_counts=insp_severity_counts,
            )

            operations = OperationsStats(
                asset_reliability=asset_reliability,
                work_orders=work_orders_overview,
                failures=failure_items,
                outages=outages_overview,
                inspections=inspection_overview,
            )

            # 8. Performance Intelligence - Heat Rate Trend
            hrt_query = """
            MATCH (h:HeatRateTest)<-[:HAS_HEAT_RATE_TEST]-(u:GeneratingUnit)
            RETURN h.test_id as test_id, h.unit_id as unit_id, u.unit_name as unit_name,
                   toString(h.test_date) as test_date, h.measured_heat_rate as measured_heat_rate,
                   h.baseline_heat_rate as baseline_heat_rate, h.deviation_percentage as deviation_percentage,
                   h.test_status as test_status, h.observations as observations
            ORDER BY h.test_date ASC, h.test_id ASC
            """
            hrt_res = self.client.execute_query(hrt_query)
            observations: List[HeatRateObservation] = [
                HeatRateObservation(
                    test_id=row["test_id"],
                    unit_id=row["unit_id"],
                    unit_name=row.get("unit_name") or row["unit_id"],
                    test_date=row.get("test_date"),
                    measured_heat_rate=float(row.get("measured_heat_rate") or 0.0),
                    baseline_heat_rate=float(row.get("baseline_heat_rate") or 7800.0),
                    deviation_percentage=float(row.get("deviation_percentage") or 0.0),
                    test_status=row.get("test_status") or "valid",
                    observations=row.get("observations"),
                )
                for row in hrt_res
            ]

            baseline = observations[0].baseline_heat_rate if observations else 7800.0
            initial_val = observations[0].measured_heat_rate if observations else baseline
            latest_val = observations[-1].measured_heat_rate if observations else initial_val
            delta = latest_val - initial_val
            delta_pct = round((delta / initial_val) * 100.0, 2) if initial_val > 0 else 0.0

            if delta > 0:
                interpretation = (
                    f"Measured heat rate increased by +{round(delta, 1)} BTU/kWh (+{delta_pct}%) "
                    f"from baseline {baseline:.0f} to {latest_val:.0f} BTU/kWh across {len(observations)} tests, "
                    f"indicating progressive thermal degradation."
                )
            elif delta < 0:
                interpretation = (
                    f"Measured heat rate improved by {round(delta, 1)} BTU/kWh ({delta_pct}%) "
                    f"over the testing period."
                )
            else:
                interpretation = "Measured heat rate remains stable and aligned with design baseline."

            performance = HeatRateTrend(
                observations=observations,
                baseline_heat_rate=baseline,
                unit="BTU/kWh",
                initial_rate=initial_val,
                latest_rate=latest_val,
                delta=round(delta, 1),
                delta_percentage=delta_pct,
                interpretation=interpretation,
            )

            # 9. Maintenance Effectiveness
            trig_res = self.client.execute_query(
                "MATCH ()-[r:TRIGGERED_WORK_ORDER]->() RETURN count(r) as cnt"
            )
            triggered_wo_count = trig_res[0]["cnt"] if trig_res else 0

            prev_count = type_counts.get("preventive", 0)
            corr_count = type_counts.get("corrective", 0)
            emerg_count = type_counts.get("emergency", 0)
            total_wo = kpis.work_orders or 1

            prev_pct = round((prev_count / total_wo) * 100.0, 1)
            corr_pct = round((corr_count / total_wo) * 100.0, 1)

            maintenance_note = (
                f"{prev_pct}% of work orders ({prev_count}/{total_wo}) represent scheduled preventive maintenance, "
                f"while {corr_pct}% ({corr_count}/{total_wo}) are corrective repairs. "
                f"Recorded failures directly triggered {triggered_wo_count} corrective work orders."
            )

            maintenance = MaintenanceEffectiveness(
                maintenance_plans_count=kpis.maintenance_plans,
                work_orders_count=kpis.work_orders,
                inspections_count=kpis.inspections,
                failures_count=kpis.failure_events,
                triggered_work_orders_count=triggered_wo_count,
                preventive_count=prev_count,
                corrective_count=corr_count,
                emergency_count=emerg_count,
                preventive_percentage=prev_pct,
                corrective_percentage=corr_pct,
                summary_note=maintenance_note,
            )

            return DashboardSummaryResponse(
                generated_at=datetime.now(timezone.utc).isoformat(),
                status="healthy",
                kpis=kpis,
                graph=graph_stats,
                documents=document_stats,
                operations=operations,
                performance=performance,
                maintenance=maintenance,
            )

        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Error computing dashboard summary: {e}", exc_info=True)
            raise HTTPException(
                status_code=500,
                detail=f"Internal error computing dashboard metrics: {str(e)}"
            )


# Global service instance
dashboard_service = DashboardService()
