"""
Document management service with Neo4j integration and ingestion pipeline
"""

import logging
import uuid
import json
from datetime import datetime, date
from pathlib import Path
from typing import List, Optional, Dict, Any
from fastapi import UploadFile, HTTPException

from app.graph.neo4j_client import neo4j_client
from app.core.config import settings
from app.documents.models import Document, DocumentType, ProcessingStatus
from app.documents.loader import DocumentLoader
from app.documents.parsers import get_parser_for_file
from app.graph.embeddings import EmbeddingManager
from app.models.documents import (
    DocumentOverviewResponse,
    DocumentSummaryItem,
    DocumentListResponse,
    DocumentChunkDetail,
    DocumentEntityLink,
    DocumentDetailResponse,
    DocumentUploadResult,
)

logger = logging.getLogger(__name__)


def serialize_val(val: Any) -> Any:
    """Safely convert Neo4j dates and structures to JSON-serializable primitives"""
    if val is None:
        return None
    if isinstance(val, (datetime, date)):
        return val.isoformat()
    if hasattr(val, "isoformat"):
        return val.isoformat()
    if hasattr(val, "to_native"):
        native = val.to_native()
        if hasattr(native, "isoformat"):
            return native.isoformat()
        return str(native)
    if isinstance(val, (int, float, bool, str)):
        return val
    if isinstance(val, list):
        if len(val) > 20 and all(isinstance(x, (int, float)) for x in val[:5]):
            return f"[{len(val)} dimensions vector]"
        return [serialize_val(x) for x in val]
    if isinstance(val, dict):
        return {k: serialize_val(v) for k, v in val.items()}
    return str(val)


class DocumentService:
    """Service for managing documents and chunks in Neo4j"""

    def __init__(self):
        self.client = neo4j_client
        self.upload_dir = Path("data/uploads")
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        self.loader = DocumentLoader(neo4j_client=self.client)
        self.embedding_mgr = EmbeddingManager()

    def get_overview(self) -> DocumentOverviewResponse:
        """Retrieve overview metrics for documents, chunks, and vector indexing"""
        # Document and chunk counts
        count_q = """
        MATCH (d:Document)
        OPTIONAL MATCH (c:Chunk)
        RETURN count(DISTINCT d) as total_docs, count(DISTINCT c) as total_chunks
        """
        counts = self.client.execute_query(count_q)
        total_docs = counts[0]["total_docs"] if counts else 0
        total_chunks = counts[0]["total_chunks"] if counts else 0

        # Embedded chunks count
        embedded_q = """
        MATCH (c:Chunk)
        WHERE c.embedding IS NOT NULL
        RETURN count(c) as embedded
        """
        embedded_res = self.client.execute_query(embedded_q)
        embedded_chunks = embedded_res[0]["embedded"] if embedded_res else 0

        # Document type breakdown
        type_q = """
        MATCH (d:Document)
        RETURN d.document_type as doc_type, count(d) as count
        ORDER BY count DESC
        """
        type_res = self.client.execute_query(type_q)
        doc_types = {r["doc_type"]: r["count"] for r in type_res if r.get("doc_type")}

        # Processing status breakdown
        status_q = """
        MATCH (d:Document)
        RETURN coalesce(d.processing_status, 'completed') as status, count(d) as count
        ORDER BY count DESC
        """
        status_res = self.client.execute_query(status_q)
        proc_statuses = {r["status"]: r["count"] for r in status_res}

        # Vector index status
        index_status = "ONLINE" if embedded_chunks > 0 else "ABSENT"
        population_pct = 100.0 if embedded_chunks > 0 else 0.0
        try:
            idx_check = self.client.execute_query(
                "SHOW INDEXES YIELD name, state, populationPercent WHERE name = 'chunk_embedding_index'"
            )
            if idx_check:
                index_status = idx_check[0].get("state", "ONLINE")
                population_pct = float(idx_check[0].get("populationPercent", 100.0))
        except Exception as e:
            logger.warning(f"Could not check vector index directly: {e}")

        return DocumentOverviewResponse(
            total_documents=total_docs,
            total_chunks=total_chunks,
            embedded_chunks=embedded_chunks,
            document_types=doc_types,
            processing_statuses=proc_statuses,
            vector_index_name="chunk_embedding_index",
            vector_index_status=index_status,
            vector_index_population=population_pct,
            embedding_model=settings.embedding_model,
            embedding_dimension=settings.embedding_dimension,
        )

    def list_documents(
        self,
        search: Optional[str] = None,
        document_type: Optional[str] = None,
        skip: int = 0,
        limit: int = 50,
    ) -> DocumentListResponse:
        """List documents matching search and type filters"""
        where_clauses = []
        params: Dict[str, Any] = {"skip": skip, "limit": limit}

        if document_type:
            where_clauses.append("d.document_type = $document_type")
            params["document_type"] = document_type

        if search and search.strip():
            where_clauses.append(
                "(toLower(d.title) CONTAINS toLower($search) "
                "OR toLower(d.document_id) CONTAINS toLower($search) "
                "OR toLower(d.source) CONTAINS toLower($search) "
                "OR toLower(coalesce(d.content, '')) CONTAINS toLower($search))"
            )
            params["search"] = search.strip()

        where_stmt = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

        # Total count query
        count_q = f"MATCH (d:Document) {where_stmt} RETURN count(d) as total"
        count_res = self.client.execute_query(count_q, params)
        total = count_res[0]["total"] if count_res else 0

        # Query items
        query = f"""
        MATCH (d:Document)
        {where_stmt}
        OPTIONAL MATCH (d)-[:HAS_CHUNK]->(c:Chunk)
        WITH d, count(DISTINCT c) as chunk_count, count(DISTINCT CASE WHEN c.embedding IS NOT NULL THEN c END) as embedded_chunks
        RETURN d.document_id as document_id,
               d.title as title,
               d.document_type as document_type,
               d.source as source,
               d.source_reference as source_reference,
               d.created_date as created_date,
               coalesce(d.processing_status, 'completed') as processing_status,
               d.content_hash as content_hash,
               size(coalesce(d.content, '')) as content_length,
               d.format as format,
               d.source_filename as source_filename,
               d.warnings as warnings,
               chunk_count,
               embedded_chunks
        ORDER BY d.created_date DESC, d.document_id ASC
        SKIP $skip
        LIMIT $limit
        """
        rows = self.client.execute_query(query, params)

        items = []
        for r in rows:
            raw_warn = r.get("warnings")
            if isinstance(raw_warn, list):
                warn_list = [str(w) for w in raw_warn]
            elif isinstance(raw_warn, str):
                warn_list = [raw_warn]
            else:
                warn_list = []

            items.append(
                DocumentSummaryItem(
                    document_id=r["document_id"],
                    title=r["title"] or "Untitled Document",
                    document_type=r["document_type"] or "unknown",
                    source=r["source"] or "Unknown",
                    source_reference=r.get("source_reference"),
                    created_date=serialize_val(r.get("created_date")),
                    processing_status=r.get("processing_status", "completed"),
                    content_hash=r.get("content_hash"),
                    content_length=int(r.get("content_length", 0)),
                    chunk_count=int(r.get("chunk_count", 0)),
                    embedded_chunks=int(r.get("embedded_chunks", 0)),
                    format=r.get("format"),
                    source_filename=r.get("source_filename"),
                    warnings=warn_list,
                )
            )

        return DocumentListResponse(
            documents=items,
            total=total,
            skip=skip,
            limit=limit,
        )

    def get_document_detail(self, document_id: str) -> Optional[DocumentDetailResponse]:
        """Get document details including content, chunks, and entity links"""
        # Fetch document node
        doc_q = """
        MATCH (d:Document {document_id: $document_id})
        RETURN d.document_id as document_id,
               d.title as title,
               d.document_type as document_type,
               d.source as source,
               d.source_reference as source_reference,
               d.created_date as created_date,
               coalesce(d.processing_status, 'completed') as processing_status,
               d.content_hash as content_hash,
               d.content as content,
               d.format as format,
               d.source_filename as source_filename,
               d.warnings as warnings
        """
        doc_res = self.client.execute_query(doc_q, {"document_id": document_id})
        if not doc_res:
            return None
        doc_row = doc_res[0]

        # Fetch chunks
        chunks_q = """
        MATCH (d:Document {document_id: $document_id})-[:HAS_CHUNK]->(c:Chunk)
        RETURN c.chunk_id as chunk_id,
               c.chunk_index as chunk_index,
               c.text as text,
               c.embedding IS NOT NULL as is_embedded,
               c.embedding_model as embedding_model,
               c.embedding_dimension as embedding_dimension,
               c.created_at as created_at,
               coalesce(c.page_number, c.meta_page_number) as page_number,
               coalesce(c.sheet_name, c.meta_sheet_name) as sheet_name,
               coalesce(c.row_range, c.meta_row_range) as row_range,
               coalesce(c.section_title, c.meta_section_title) as section_title,
               properties(c) as properties
        ORDER BY c.chunk_index ASC
        """
        chunk_rows = self.client.execute_query(chunks_q, {"document_id": document_id})
        chunks: List[DocumentChunkDetail] = []
        for c in chunk_rows:
            raw_props = c.get("properties") or {}
            # Filter out embedding vectors from metadata
            clean_meta = {
                k: serialize_val(v)
                for k, v in raw_props.items()
                if k != "embedding" and not k.startswith("_")
            }

            page_val = c.get("page_number")
            page_num: Optional[int] = None
            if page_val is not None:
                try:
                    page_num = int(page_val)
                except (ValueError, TypeError):
                    page_num = None

            chunks.append(
                DocumentChunkDetail(
                    chunk_id=c["chunk_id"],
                    chunk_index=int(c.get("chunk_index", 0)),
                    text=c.get("text", ""),
                    is_embedded=bool(c.get("is_embedded", False)),
                    embedding_model=c.get("embedding_model"),
                    embedding_dimension=c.get("embedding_dimension"),
                    created_at=serialize_val(c.get("created_at")),
                    page_number=page_num,
                    sheet_name=c.get("sheet_name"),
                    row_range=c.get("row_range"),
                    section_title=c.get("section_title"),
                    metadata=clean_meta,
                )
            )

        # Fetch linked entities
        entities_q = """
        MATCH (d:Document {document_id: $document_id})-[r]->(e)
        WHERE NOT e:Chunk
        RETURN type(r) as relationship,
               labels(e) as labels,
               coalesce(e.asset_id, e.unit_id, e.plant_id, e.inspection_id, e.failure_id, e.work_order_id, e.component_id, e.maintenance_plan_id, e.id) as entity_id,
               coalesce(e.name, e.unit_name, e.component_name, e.plan_name, e.description, e.failure_mode, e.title, '') as entity_name,
               properties(e) as properties
        ORDER BY type(r), entity_id
        """
        entity_rows = self.client.execute_query(entities_q, {"document_id": document_id})
        linked_entities: List[DocumentEntityLink] = []
        for e in entity_rows:
            raw_props = e.get("properties") or {}
            clean_props = {
                k: serialize_val(v)
                for k, v in raw_props.items()
                if not k.startswith("_")
            }
            linked_entities.append(
                DocumentEntityLink(
                    relationship=e["relationship"],
                    labels=e.get("labels", []),
                    entity_id=e["entity_id"] or "UNKNOWN",
                    entity_name=e.get("entity_name", ""),
                    properties=clean_props,
                )
            )

        doc_warnings = doc_row.get("warnings")
        if isinstance(doc_warnings, list):
            doc_warn_list = [str(w) for w in doc_warnings]
        elif isinstance(doc_warnings, str):
            doc_warn_list = [doc_warnings]
        else:
            doc_warn_list = []

        return DocumentDetailResponse(
            document_id=doc_row["document_id"],
            title=doc_row["title"] or "Untitled Document",
            document_type=doc_row["document_type"] or "unknown",
            source=doc_row["source"] or "Unknown",
            source_reference=doc_row.get("source_reference"),
            created_date=serialize_val(doc_row.get("created_date")),
            processing_status=doc_row.get("processing_status", "completed"),
            content_hash=doc_row.get("content_hash"),
            content=doc_row.get("content", ""),
            format=doc_row.get("format"),
            source_filename=doc_row.get("source_filename"),
            warnings=doc_warn_list,
            chunks=chunks,
            linked_entities=linked_entities,
        )

    async def upload_document(self, file: UploadFile) -> DocumentUploadResult:
        """Upload and process a document safely using modular format parsers, DocumentLoader, and EmbeddingManager"""
        # 1. Validate file format and obtain format parser
        filename = file.filename or "uploaded_document"
        try:
            parser = get_parser_for_file(filename)
        except ValueError as val_err:
            raise HTTPException(
                status_code=400,
                detail=str(val_err),
            )

        # 2. Enforce file size limit
        content_bytes = await file.read()
        max_size = getattr(settings, "max_upload_size_bytes", 5 * 1024 * 1024)
        if len(content_bytes) > max_size:
            max_mb = max_size // (1024 * 1024)
            raise HTTPException(
                status_code=400,
                detail=f"File exceeds maximum allowed size of {max_mb}MB ({len(content_bytes)} bytes).",
            )
        if len(content_bytes) == 0:
            raise HTTPException(
                status_code=400,
                detail="Uploaded file is empty (0 bytes).",
            )

        # 3. Safe server-side saving to avoid path traversal
        ext = Path(filename).suffix.lower()
        safe_stem = "".join(c for c in Path(filename).stem if c.isalnum() or c in ("-", "_"))
        safe_name = f"{uuid.uuid4().hex[:8]}_{safe_stem}{ext}"
        saved_path = self.upload_dir / safe_name
        try:
            with open(saved_path, "wb") as f:
                f.write(content_bytes)
        except Exception as e:
            logger.warning(f"Could not persist upload to cache directory: {e}")

        # 4. Parse content using format-specific parser
        try:
            extracted = parser.parse(content_bytes, filename)
        except ValueError as parse_err:
            raise HTTPException(
                status_code=400,
                detail=str(parse_err),
            )
        except Exception as e:
            logger.error(f"Unexpected error parsing {filename}: {e}", exc_info=True)
            raise HTTPException(
                status_code=400,
                detail=f"Error parsing document content: {e}",
            )

        if not extracted.content or not extracted.content.strip():
            raise HTTPException(
                status_code=400,
                detail="Document produced no readable text or content.",
            )

        # 5. Build Document domain model
        doc_meta = dict(extracted.metadata)
        doc_id = doc_meta.get("document_id") or f"DOC-{uuid.uuid4().hex[:6].upper()}"

        doc_type = DocumentType.OPERATIONAL_NOTE
        if doc_meta.get("document_type"):
            try:
                doc_type = DocumentType(doc_meta["document_type"])
            except Exception:
                doc_type = DocumentType.OPERATIONAL_NOTE

        # Consolidate metadata
        structured_meta = {
            "format": extracted.format,
            "source_filename": filename,
            "sections": [s.model_dump() for s in extracted.sections],
            "warnings": extracted.warnings,
            **doc_meta,
        }

        source = doc_meta.get("source") or f"Upload ({extracted.format.upper()})"
        source_ref = doc_meta.get("source_reference") or filename

        doc_obj = Document(
            document_id=doc_id,
            title=extracted.title,
            document_type=doc_type,
            source=source,
            source_reference=source_ref,
            created_date=datetime.utcnow(),
            content=extracted.content,
            metadata=structured_meta,
            asset_id=doc_meta.get("asset_id"),
            unit_id=doc_meta.get("unit_id"),
            inspection_id=doc_meta.get("inspection_id"),
            failure_id=doc_meta.get("failure_id"),
            work_order_id=doc_meta.get("work_order_id"),
        )

        # 6. Ingest into Neo4j via DocumentLoader
        load_result = self.loader.load_document(doc_obj)
        action = load_result.get("action", "created")
        chunks_created = load_result.get("chunks_created", 0)
        relationships_created = load_result.get("relationships_created", 0)
        entity_links = load_result.get("entity_links", 0)

        # 7. Generate vector embeddings for newly created chunks
        embeddings_generated = False
        if action in ["created", "updated"] and chunks_created > 0:
            try:
                chunks_needing = self.embedding_mgr.get_chunks_needing_embeddings(force=False)
                doc_chunks = [c for c in chunks_needing if c.get("chunk_id", "").startswith(doc_obj.document_id)]
                for c in doc_chunks:
                    emb = self.embedding_mgr.generate_chunk_embedding(c["chunk_id"], c["text"])
                    if emb:
                        self.embedding_mgr.store_chunk_embedding(c["chunk_id"], emb)
                embeddings_generated = True
            except Exception as emb_err:
                logger.warning(f"Embedding generation deferred: {emb_err}")

        message = (
            f"Document successfully {action}. "
            f"{chunks_created} chunks created, {relationships_created} relationships indexed."
        )
        if action == "skipped":
            message = "Document skipped: identical content hash already exists in Neo4j."

        if extracted.warnings:
            warning_text = " | ".join(extracted.warnings)
            message += f" Notice: {warning_text}"

        return DocumentUploadResult(
            document_id=doc_obj.document_id,
            title=doc_obj.title,
            action=action,
            chunks_created=chunks_created,
            relationships_created=relationships_created,
            entity_links=entity_links,
            embedded=embeddings_generated,
            format=extracted.format,
            warnings=extracted.warnings,
            message=message,
        )

    def delete_document(self, document_id: str) -> bool:
        """Safely delete document and its chunks from Neo4j"""
        del_q = """
        MATCH (d:Document {document_id: $document_id})
        OPTIONAL MATCH (d)-[:HAS_CHUNK]->(c:Chunk)
        DETACH DELETE c, d
        RETURN count(d) as deleted
        """
        res = self.client.execute_query(del_q, {"document_id": document_id})
        return bool(res and res[0].get("deleted", 0) > 0)


document_service = DocumentService()