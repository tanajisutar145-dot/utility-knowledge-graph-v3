"""
Neo4j schema initialization for utility knowledge graph
"""

import logging
from typing import List, Dict
from app.graph.neo4j_client import neo4j_client

logger = logging.getLogger(__name__)


class GraphSchema:
    """Manages Neo4j graph schema initialization"""
    
    def __init__(self):
        self.client = neo4j_client
    
    def initialize_schema(self) -> None:
        """Initialize complete graph schema"""
        print("Initializing Neo4j schema...")
        
        self.create_constraints()
        self.create_indexes()
        
        print("Schema initialization completed.")
    
    def create_constraints(self) -> None:
        """Create uniqueness constraints for all entity types"""
        print("Creating uniqueness constraints...")
        
        constraints = [
            "CREATE CONSTRAINT utility_id_unique IF NOT EXISTS FOR (u:Utility) REQUIRE u.utility_id IS UNIQUE",
            "CREATE CONSTRAINT plant_id_unique IF NOT EXISTS FOR (p:PowerPlant) REQUIRE p.plant_id IS UNIQUE", 
            "CREATE CONSTRAINT unit_id_unique IF NOT EXISTS FOR (u:GeneratingUnit) REQUIRE u.unit_id IS UNIQUE",
            "CREATE CONSTRAINT asset_id_unique IF NOT EXISTS FOR (a:Asset) REQUIRE a.asset_id IS UNIQUE",
            "CREATE CONSTRAINT component_id_unique IF NOT EXISTS FOR (c:Component) REQUIRE c.component_id IS UNIQUE",
            "CREATE CONSTRAINT inspection_id_unique IF NOT EXISTS FOR (i:Inspection) REQUIRE i.inspection_id IS UNIQUE",
            "CREATE CONSTRAINT failure_id_unique IF NOT EXISTS FOR (f:FailureEvent) REQUIRE f.failure_id IS UNIQUE",
            "CREATE CONSTRAINT work_order_id_unique IF NOT EXISTS FOR (w:WorkOrder) REQUIRE w.work_order_id IS UNIQUE",
            "CREATE CONSTRAINT maintenance_plan_id_unique IF NOT EXISTS FOR (m:MaintenancePlan) REQUIRE m.maintenance_plan_id IS UNIQUE",
            "CREATE CONSTRAINT outage_id_unique IF NOT EXISTS FOR (o:OutageEvent) REQUIRE o.outage_id IS UNIQUE",
            "CREATE CONSTRAINT test_id_unique IF NOT EXISTS FOR (h:HeatRateTest) REQUIRE h.test_id IS UNIQUE",
            # Document constraints (from Phase 4)
            "CREATE CONSTRAINT document_id_unique IF NOT EXISTS FOR (d:Document) REQUIRE d.document_id IS UNIQUE",
            "CREATE CONSTRAINT chunk_id_unique IF NOT EXISTS FOR (c:Chunk) REQUIRE c.chunk_id IS UNIQUE"
        ]
        
        for constraint in constraints:
            try:
                result = self.client.execute_write(constraint)
                if result["constraints_added"] > 0:
                    print(f"  ✓ Created constraint")
            except Exception as e:
                # Constraint may already exist, which is fine
                if "already exists" not in str(e).lower():
                    logger.error(f"Error creating constraint: {e}")
    
    def create_indexes(self) -> None:
        """Create useful indexes for query performance"""
        print("Creating indexes...")
        
        indexes = [
            # Asset indexes for common queries
            "CREATE INDEX asset_tag_index IF NOT EXISTS FOR (a:Asset) ON (a.asset_tag)",
            "CREATE INDEX asset_class_index IF NOT EXISTS FOR (a:Asset) ON (a.asset_class)",
            "CREATE INDEX asset_criticality_index IF NOT EXISTS FOR (a:Asset) ON (a.criticality)",
            
            # Failure event indexes
            "CREATE INDEX failure_mode_index IF NOT EXISTS FOR (f:FailureEvent) ON (f.failure_mode)",
            "CREATE INDEX failure_severity_index IF NOT EXISTS FOR (f:FailureEvent) ON (f.severity)",
            "CREATE INDEX failure_date_index IF NOT EXISTS FOR (f:FailureEvent) ON (f.failure_date)",
            
            # Work order indexes
            "CREATE INDEX work_order_status_index IF NOT EXISTS FOR (w:WorkOrder) ON (w.status)",
            "CREATE INDEX work_order_priority_index IF NOT EXISTS FOR (w:WorkOrder) ON (w.priority)",
            "CREATE INDEX work_order_type_index IF NOT EXISTS FOR (w:WorkOrder) ON (w.work_type)",
            
            # Inspection indexes
            "CREATE INDEX inspection_date_index IF NOT EXISTS FOR (i:Inspection) ON (i.inspection_date)",
            "CREATE INDEX inspection_condition_index IF NOT EXISTS FOR (i:Inspection) ON (i.condition)",
            
            # Outage indexes
            "CREATE INDEX outage_start_date_index IF NOT EXISTS FOR (o:OutageEvent) ON (o.start_date)",
            "CREATE INDEX outage_type_index IF NOT EXISTS FOR (o:OutageEvent) ON (o.outage_type)",
            
            # Heat rate test indexes
            "CREATE INDEX heat_rate_test_date_index IF NOT EXISTS FOR (h:HeatRateTest) ON (h.test_date)",
            
            # Document indexes (from Phase 4)
            "CREATE INDEX document_type_idx IF NOT EXISTS FOR (d:Document) ON (d.document_type)",
            "CREATE INDEX document_created_date_idx IF NOT EXISTS FOR (d:Document) ON (d.created_date)",
            "CREATE INDEX document_source_idx IF NOT EXISTS FOR (d:Document) ON (d.source)",
            "CREATE INDEX chunk_document_id_idx IF NOT EXISTS FOR (c:Chunk) ON (c.document_id)"
        ]
        
        for index in indexes:
            try:
                result = self.client.execute_write(index)
                if result["indexes_added"] > 0:
                    print(f"  ✓ Created index")
            except Exception as e:
                # Index may already exist, which is fine
                if "already exists" not in str(e).lower():
                    logger.error(f"Error creating index: {e}")
        
        # Create vector index separately
        self.create_vector_index()
    
    def create_vector_index(self) -> None:
        """Create Neo4j vector index for chunk embeddings"""
        from app.core.config import settings
        
        print("Creating vector index...")
        
        vector_index_query = f"""
        CREATE VECTOR INDEX chunk_embedding_index IF NOT EXISTS
        FOR (c:Chunk) ON (c.embedding)
        OPTIONS {{
            indexConfig: {{
                `vector.dimensions`: {settings.embedding_dimension},
                `vector.similarity_function`: 'cosine'
            }}
        }}
        """
        
        try:
            result = self.client.execute_write(vector_index_query)
            print(f"  ✓ Created vector index for chunk embeddings (dimension: {settings.embedding_dimension})")
        except Exception as e:
            # Vector index may already exist or Neo4j version may not support it
            if "already exists" in str(e).lower():
                print(f"  ✓ Vector index already exists")
            else:
                logger.error(f"Error creating vector index: {e}")
                print(f"  ⚠ Could not create vector index: {e}")
    
    def get_schema_info(self) -> Dict:
        """Get information about current schema"""
        from app.core.config import settings
        
        try:
            # Get constraints
            constraints = self.client.execute_query("SHOW CONSTRAINTS")
            
            # Get indexes  
            indexes = self.client.execute_query("SHOW INDEXES")
            
            # Check for vector index
            vector_index_exists = False
            try:
                vector_check = self.client.execute_query(
                    "SHOW INDEXES YIELD name, type, labelsOrTypes, properties "
                    "WHERE name = 'chunk_embedding_index'"
                )
                vector_index_exists = len(vector_check) > 0
            except Exception:
                pass
            
            schema_info = {
                "constraints": len(constraints),
                "indexes": len(indexes),
                "constraint_details": constraints,
                "index_details": indexes,
                "vector_index": {
                    "exists": vector_index_exists,
                    "name": "chunk_embedding_index",
                    "dimension": settings.embedding_dimension,
                    "similarity": "cosine",
                    "model": settings.embedding_model
                }
            }
            
            return schema_info
            
        except Exception as e:
            logger.error(f"Error getting schema info: {e}")
            return {"constraints": 0, "indexes": 0, "vector_index": {"exists": False}}


# Global schema manager
graph_schema = GraphSchema()