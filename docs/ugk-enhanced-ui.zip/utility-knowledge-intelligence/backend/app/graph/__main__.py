"""
Command-line interface for graph operations
"""

import sys
import argparse
import asyncio
from pathlib import Path

from .schema import graph_schema
from .loader import main as load_graph
from .embeddings import embedding_manager


def await_sync(coroutine):
    """Helper to run async functions in sync context"""
    try:
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(coroutine)
    except RuntimeError:
        # Create new event loop if none exists
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            return loop.run_until_complete(coroutine)
        finally:
            loop.close()


def main():
    """Main CLI entry point for graph operations"""
    parser = argparse.ArgumentParser(description='Neo4j graph operations')
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Initialize schema command
    schema_parser = subparsers.add_parser('init-schema', help='Initialize Neo4j schema')
    
    # Load graph command
    load_parser = subparsers.add_parser('load', help='Load graph data from CSV files')
    
    # Schema info command
    info_parser = subparsers.add_parser('schema-info', help='Display schema information')
    
    # Embedding commands
    embed_parser = subparsers.add_parser('embed', help='Generate embeddings for chunks')
    embed_parser.add_argument('--force', action='store_true', 
                             help='Regenerate all embeddings (even existing ones)')
    embed_parser.add_argument('--batch-size', type=int, 
                             help='Number of chunks to process in each batch')
    
    # Embedding stats command
    stats_parser = subparsers.add_parser('embed-stats', help='Show embedding statistics')
    
    # Vector search test command
    search_parser = subparsers.add_parser('vector-test', help='Test vector search')
    search_parser.add_argument('query', help='Search query text')
    search_parser.add_argument('--limit', type=int, default=5, 
                              help='Maximum number of results (default: 5)')
    search_parser.add_argument('--threshold', type=float, default=0.0,
                              help='Minimum similarity threshold (default: 0.0)')
    
    # Semantic retrieval command
    retrieve_parser = subparsers.add_parser('retrieve', help='Semantic retrieval with graph expansion')
    retrieve_parser.add_argument('query', help='Natural language query')
    retrieve_parser.add_argument('--limit', type=int, default=5,
                               help='Number of chunks to retrieve (default: 5)')
    retrieve_parser.add_argument('--graph-depth', type=int, default=1,
                               help='Graph expansion depth (default: 1)')
    retrieve_parser.add_argument('--threshold', type=float, default=0.0,
                               help='Minimum similarity threshold (default: 0.0)')
    
    # GraphRAG question answering command
    ask_parser = subparsers.add_parser('ask', help='GraphRAG question answering with grounded evidence')
    ask_parser.add_argument('question', help='Natural language question')
    ask_parser.add_argument('--limit', type=int, default=5,
                           help='Number of chunks to retrieve (default: 5)')
    ask_parser.add_argument('--graph-depth', type=int, default=1,
                           help='Graph expansion depth (default: 1)')
    ask_parser.add_argument('--threshold', type=float, default=0.0,
                           help='Minimum similarity threshold (default: 0.0)')
    ask_parser.add_argument('--no-verify', action='store_true',
                           help='Skip answer verification step')
    
    args = parser.parse_args()
    
    if args.command == 'init-schema':
        print("Initializing Neo4j schema...")
        graph_schema.initialize_schema()
        print("Schema initialization completed.")
        
    elif args.command == 'load':
        print("Loading graph data...")
        success = load_graph()
        sys.exit(0 if success else 1)
        
    elif args.command == 'schema-info':
        print("Getting schema information...")
        info = graph_schema.get_schema_info()
        print(f"Constraints: {info['constraints']}")
        print(f"Indexes: {info['indexes']}")
        
        # Display vector index info
        vector_info = info.get('vector_index', {})
        print(f"\nVector Index:")
        print(f"  Exists: {vector_info.get('exists', False)}")
        if vector_info.get('exists'):
            print(f"  Name: {vector_info.get('name', 'N/A')}")
            print(f"  Dimension: {vector_info.get('dimension', 'N/A')}")
            print(f"  Similarity: {vector_info.get('similarity', 'N/A')}")
            print(f"  Model: {vector_info.get('model', 'N/A')}")
        
    elif args.command == 'embed':
        print("Generating embeddings for chunks...")
        
        kwargs = {}
        if args.force:
            kwargs['force'] = True
        if args.batch_size:
            kwargs['batch_size'] = args.batch_size
        
        result = embedding_manager.generate_all_embeddings(**kwargs)
        
        print(f"\nEmbedding Generation Results:")
        print(f"Total chunks found: {result['total_chunks']}")
        print(f"Chunks processed: {result['chunks_processed']}")
        print(f"Successful: {result['successful']}")
        print(f"Failed: {result['failed']}")
        print(f"Skipped: {result['skipped']}")
        print(f"Execution time: {result['execution_time']:.2f} seconds")
        print(f"Model: {result['model']}")
        print(f"Dimension: {result['dimension']}")
        
        if result['failed'] > 0:
            sys.exit(1)
        
    elif args.command == 'embed-stats':
        print("Getting embedding statistics...")
        stats = embedding_manager.get_embedding_stats()
        
        print(f"\nEmbedding Statistics:")
        print(f"Total chunks: {stats['total_chunks']}")
        print(f"Chunks with embeddings: {stats['chunks_with_embeddings']}")
        print(f"Chunks without embeddings: {stats['chunks_without_embeddings']}")
        print(f"Embedding model: {stats['embedding_model']}")
        print(f"Embedding dimension: {stats['embedding_dimension']}")
        print(f"Device: {stats['embedding_device']}")
        
    elif args.command == 'vector-test':
        print(f"Testing vector search for: '{args.query}'")
        
        results = embedding_manager.vector_search(
            args.query, 
            limit=args.limit, 
            similarity_threshold=args.threshold
        )
        
        if not results:
            print("No results found.")
        else:
            print(f"\nFound {len(results)} results:")
            for i, result in enumerate(results, 1):
                print(f"\n{i}. Chunk: {result['chunk_id']}")
                print(f"   Document: {result['document_id']} - {result['document_title']}")
                print(f"   Similarity: {result['similarity_score']:.4f}")
                print(f"   Preview: {result['chunk_preview']}")
    
    elif args.command == 'retrieve':
        print(f"Semantic retrieval for: '{args.query}'")
        
        # Import here to avoid circular imports
        from app.retrieval import semantic_retriever, RetrievalRequest
        
        request = RetrievalRequest(
            query=args.query,
            top_k=args.limit,
            graph_depth=args.graph_depth,
            min_similarity=args.threshold
        )
        
        result = semantic_retriever.retrieve(request)
        
        # Display semantic results
        print(f"\n=== SEMANTIC RESULTS ===")
        if not result.semantic_results:
            print("No semantic results found.")
        else:
            for i, semantic_result in enumerate(result.semantic_results, 1):
                print(f"\n{i}. Chunk: {semantic_result.chunk_id}")
                print(f"   Document: {semantic_result.document_id} - {semantic_result.document_title}")
                print(f"   Similarity: {semantic_result.score:.4f}")
                print(f"   Source: {semantic_result.source or 'N/A'}")
                print(f"   Text: {semantic_result.text[:200]}{'...' if len(semantic_result.text) > 200 else ''}")
        
        # Display graph evidence
        print(f"\n=== GRAPH EVIDENCE ===")
        if not result.graph_evidence.entities:
            print("No graph entities found.")
        else:
            print(f"Entities ({len(result.graph_evidence.entities)}):")
            for entity in result.graph_evidence.entities:
                print(f"  • {entity.entity_type}: {entity.entity_id}")
                # Show key properties
                key_props = []
                for key, value in entity.properties.items():
                    if key in ['name', 'title', 'description', 'status', 'condition', 'severity']:
                        key_props.append(f"{key}={value}")
                if key_props:
                    print(f"    {', '.join(key_props)}")
        
        if result.graph_evidence.relationships:
            print(f"\nRelationships ({len(result.graph_evidence.relationships)}):")
            for rel in result.graph_evidence.relationships:
                print(f"  • {rel.source_id} --[{rel.relationship_type}]--> {rel.target_id}")
        
        # Display metadata
        print(f"\n=== METADATA ===")
        metadata = result.metadata
        print(f"Execution time: {metadata.get('execution_time', 0):.3f}s")
        print(f"Semantic results: {metadata.get('semantic_results_count', 0)}")
        print(f"Graph entities: {metadata.get('graph_entities_count', 0)}")
        print(f"Graph relationships: {metadata.get('graph_relationships_count', 0)}")
    
    elif args.command == 'ask':
        print(f"GraphRAG question answering for: '{args.question}'")
        
        # Import here to avoid circular imports
        from app.intelligence import graphrag_service, GraphRAGRequest
        
        request = GraphRAGRequest(
            question=args.question,
            top_k=args.limit,
            graph_depth=args.graph_depth,
            min_similarity=args.threshold,
            include_verification=not args.no_verify
        )
        
        try:
            response = graphrag_service.ask_question(request)
            
            print(f"\n{'='*60}")
            print("QUESTION")
            print("─" * 60)
            print(args.question)
            
            print(f"\n{'='*60}")
            print("ANSWER")
            print("─" * 60)
            print(response.answer)
            
            print(f"\n{'='*60}")
            print("CONFIDENCE")
            print("─" * 60)
            print(f"Level: {response.confidence.value.upper()}")
            
            if response.verification:
                print(f"\n{'='*60}")
                print("VERIFICATION")
                print("─" * 60)
                print(f"Verified: {'Yes' if response.verification.verified else 'No'}")
                print(f"Grounding Score: {response.verification.grounding_score:.3f}")
                
                if response.verification.supported_claims:
                    print(f"\nSupported Claims:")
                    for claim in response.verification.supported_claims:
                        print(f"  ✓ {claim}")
                
                if response.verification.unsupported_claims:
                    print(f"\nUnsupported Claims:")
                    for claim in response.verification.unsupported_claims:
                        print(f"  ✗ {claim}")
                
                if response.verification.warnings:
                    print(f"\nWarnings:")
                    for warning in response.verification.warnings:
                        print(f"  ⚠ {warning}")
            
            if response.sources['documents'] or response.sources['entities']:
                print(f"\n{'='*60}")
                print("SUPPORTING EVIDENCE")
                print("─" * 60)
                
                if response.sources['documents']:
                    print(f"Documents: {', '.join(response.sources['documents'])}")
                
                if response.sources['entities']:
                    print(f"Entities: {', '.join(response.sources['entities'][:10])}")  # Limit display
                    if len(response.sources['entities']) > 10:
                        print(f"  ... and {len(response.sources['entities']) - 10} more entities")
            
            print(f"\n{'='*60}")
            print("METADATA")
            print("─" * 60)
            metadata = response.metadata
            print(f"Execution time: {metadata.get('execution_time', 0):.3f}s")
            print(f"Groq model: {metadata.get('groq_model', 'unknown')}")
            print(f"Verification enabled: {metadata.get('verification_enabled', False)}")
            print("─" * 60)
            
        except Exception as e:
            print(f"\nERROR: GraphRAG question answering failed: {e}")
            sys.exit(1)
                
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()