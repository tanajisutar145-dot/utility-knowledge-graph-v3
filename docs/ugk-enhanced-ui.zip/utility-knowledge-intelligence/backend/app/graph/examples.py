"""
Example Cypher queries for the utility knowledge graph
"""

from app.graph.neo4j_client import neo4j_client


class GraphExamples:
    """Example queries for exploring the utility knowledge graph"""
    
    def __init__(self):
        self.client = neo4j_client
    
    def asset_hierarchy(self):
        """Show the complete asset hierarchy"""
        cypher = """
        MATCH (u:Utility)-[:HAS_PLANT]->(p:PowerPlant)
              -[:HAS_UNIT]->(unit:GeneratingUnit)
              -[:HAS_ASSET]->(a:Asset)
        RETURN u.name as utility, p.name as plant, 
               unit.unit_name as unit, a.name as asset,
               a.asset_class as asset_type
        ORDER BY u.name, p.name, unit.unit_name, a.name
        """
        return self.client.execute_query(cypher)
    
    def asset_failures(self):
        """Find all asset failures ordered by date"""
        cypher = """
        MATCH (a:Asset)-[:HAS_FAILURE]->(f:FailureEvent)
        RETURN a.asset_tag, a.name as asset_name, f.failure_mode, f.severity, 
               f.failure_date, f.actual_cost, f.downtime_hours
        ORDER BY f.failure_date DESC
        """
        return self.client.execute_query(cypher)
    
    def inspection_before_failure(self):
        """Find inspections that occurred before failures on the same asset"""
        cypher = """
        MATCH (a:Asset)-[:HAS_INSPECTION]->(i:Inspection),
              (a)-[:HAS_FAILURE]->(f:FailureEvent)
        WHERE i.inspection_date <= f.failure_date
        RETURN a.asset_tag, i.inspection_date, i.condition,
               i.findings, f.failure_date, f.failure_mode
        ORDER BY a.asset_tag, i.inspection_date
        """
        return self.client.execute_query(cypher)
    
    def failure_to_work_order(self):
        """Show failure events and their triggered work orders"""
        cypher = """
        MATCH (f:FailureEvent)-[:TRIGGERED_WORK_ORDER]->(w:WorkOrder)
        RETURN f.failure_mode, f.severity, f.actual_cost as failure_cost,
               w.work_order_id, w.status, w.total_cost as repair_cost,
               w.labor_hours
        ORDER BY f.actual_cost DESC
        """
        return self.client.execute_query(cypher)
    
    def heat_rate_trend(self):
        """Show heat rate test trends for all units"""
        cypher = """
        MATCH (u:GeneratingUnit)-[:HAS_HEAT_RATE_TEST]->(h:HeatRateTest)
        RETURN u.unit_name, h.test_date, h.measured_heat_rate,
               h.baseline_heat_rate, h.deviation_percentage
        ORDER BY u.unit_name, h.test_date
        """
        return self.client.execute_query(cypher)
    
    def critical_assets_with_failures(self):
        """Find critical assets that have experienced failures"""
        cypher = """
        MATCH (a:Asset)-[:HAS_FAILURE]->(f:FailureEvent)
        WHERE a.criticality = 'critical'
        RETURN a.asset_tag, a.name, a.asset_class,
               count(f) as failure_count,
               sum(f.downtime_hours) as total_downtime,
               sum(f.actual_cost) as total_repair_cost
        ORDER BY total_repair_cost DESC
        """
        return self.client.execute_query(cypher)
    
    def maintenance_effectiveness(self):
        """Analyze maintenance effectiveness by comparing planned vs corrective work"""
        cypher = """
        MATCH (a:Asset)-[:HAS_WORK_ORDER]->(w:WorkOrder)
        WITH a, w.work_type as work_type, count(w) as work_count,
             sum(w.total_cost) as total_cost
        RETURN a.asset_tag, a.name, work_type, work_count, total_cost
        ORDER BY a.asset_tag, work_type
        """
        return self.client.execute_query(cypher)
    
    def outage_analysis(self):
        """Analyze outage events by unit and cause"""
        cypher = """
        MATCH (u:GeneratingUnit)-[:HAS_OUTAGE]->(o:OutageEvent)
        RETURN u.unit_name, o.outage_type, o.cause,
               o.duration_hours, o.estimated_generation_loss_mwh,
               o.estimated_cost
        ORDER BY o.estimated_cost DESC
        """
        return self.client.execute_query(cypher)
    
    def repeated_failures_analysis(self):
        """Find assets with repeated failures"""
        cypher = """
        MATCH (a:Asset)-[:HAS_FAILURE]->(f:FailureEvent)
        WITH a, count(f) as failure_count, collect(f.failure_mode) as failure_modes
        WHERE failure_count > 1
        RETURN a.asset_tag, a.name, a.asset_class, failure_count,
               failure_modes
        ORDER BY failure_count DESC
        """
        return self.client.execute_query(cypher)
    
    def component_failure_correlation(self):
        """Show relationship between asset components and failures"""
        cypher = """
        MATCH (a:Asset)-[:HAS_COMPONENT]->(c:Component),
              (a)-[:HAS_FAILURE]->(f:FailureEvent)
        RETURN a.asset_tag, a.asset_class,
               collect(DISTINCT c.component_type) as components,
               collect(DISTINCT f.failure_mode) as failure_modes
        ORDER BY a.asset_tag
        """
        return self.client.execute_query(cypher)


def run_example_queries():
    """Run and display results of example queries"""
    examples = GraphExamples()
    
    print("=== ASSET HIERARCHY ===")
    results = examples.asset_hierarchy()
    for row in results[:5]:  # Show first 5 results
        print(f"{row['utility']} > {row['plant']} > {row['unit']} > {row['asset']} ({row['asset_type']})")
    
    print(f"\n=== ASSET FAILURES (Total: {len(examples.asset_failures())}) ===")
    results = examples.asset_failures()
    for row in results[:3]:  # Show first 3 failures
        print(f"{row['a.asset_tag']}: {row['f.failure_mode']} - ${row['f.actual_cost']:,.0f} ({row['f.downtime_hours']}h downtime)")
    
    print(f"\n=== HEAT RATE TRENDS ===")
    results = examples.heat_rate_trend()
    for row in results[:5]:
        print(f"{row['u.unit_name']}: {row['h.measured_heat_rate']} BTU/kWh ({row['h.deviation_percentage']:+.1f}%)")
    
    print(f"\n=== FAILURE → WORK ORDER CONNECTIONS ===")
    results = examples.failure_to_work_order()
    for row in results:
        print(f"{row['f.failure_mode']} → WO {row['w.work_order_id']}: ${row['repair_cost']:,.0f}")
    
    print(f"\n=== CRITICAL ASSETS WITH FAILURES ===")
    results = examples.critical_assets_with_failures()
    for row in results:
        print(f"{row['a.asset_tag']} ({row['a.asset_class']}): {row['failure_count']} failures, ${row['total_repair_cost']:,.0f} total cost")


if __name__ == "__main__":
    run_example_queries()