"""
Neo4j graph data loader for utility knowledge graph
"""

import csv
import logging
from pathlib import Path
from typing import Dict, List, Any
from datetime import datetime, date

from app.graph.neo4j_client import neo4j_client
from app.graph.schema import graph_schema

logger = logging.getLogger(__name__)


class GraphLoader:
    """Loads utility data into Neo4j graph"""
    
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.client = neo4j_client
        self.schema = graph_schema
        
        # Track loading statistics
        self.node_counts = {}
        self.relationship_counts = {}
    
    def load_complete_graph(self) -> None:
        """Load complete utility graph from CSV files"""
        print("Starting graph loading process...")
        
        # Validate source files exist
        self._validate_source_files()
        
        # Initialize schema
        self.schema.initialize_schema()
        
        # Load nodes in dependency order
        self._load_nodes()
        
        # Create relationships
        self._create_relationships()
        
        # Validate loaded graph
        self._validate_graph()
        
        print("Graph loading completed!")
    
    def _validate_source_files(self) -> None:
        """Validate that all required CSV files exist"""
        required_files = [
            "utilities.csv", "power_plants.csv", "generating_units.csv",
            "assets.csv", "components.csv", "inspections.csv",
            "failure_events.csv", "work_orders.csv", "maintenance_plans.csv", 
            "outage_events.csv", "heat_rate_tests.csv"
        ]
        
        missing_files = []
        for filename in required_files:
            if not (self.data_dir / filename).exists():
                missing_files.append(filename)
        
        if missing_files:
            raise FileNotFoundError(f"Missing CSV files: {missing_files}")
        
        print(f"✓ All {len(required_files)} CSV files found")
    
    def _load_nodes(self) -> None:
        """Load all node types in dependency order"""
        print("Loading nodes...")
        
        # Load in dependency order
        loading_order = [
            ("utilities.csv", "Utility", self._load_utilities),
            ("power_plants.csv", "PowerPlant", self._load_power_plants),
            ("generating_units.csv", "GeneratingUnit", self._load_generating_units),
            ("assets.csv", "Asset", self._load_assets),
            ("components.csv", "Component", self._load_components),
            ("inspections.csv", "Inspection", self._load_inspections),
            ("failure_events.csv", "FailureEvent", self._load_failure_events),
            ("work_orders.csv", "WorkOrder", self._load_work_orders),
            ("maintenance_plans.csv", "MaintenancePlan", self._load_maintenance_plans),
            ("outage_events.csv", "OutageEvent", self._load_outage_events),
            ("heat_rate_tests.csv", "HeatRateTest", self._load_heat_rate_tests)
        ]
        
        for filename, label, loader_func in loading_order:
            count = loader_func(filename, label)
            self.node_counts[label] = count
            print(f"  ✓ Loaded {count} {label} nodes")
    
    def _load_csv_file(self, filename: str, label: str, cypher_template: str) -> int:
        """Generic CSV file loader using MERGE for idempotency"""
        filepath = self.data_dir / filename
        count = 0
        
        with open(filepath, 'r', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            
            # Process in batches for efficiency
            batch = []
            batch_size = 100
            
            for row in reader:
                # Convert data types appropriately
                processed_row = self._process_row_data(row)
                batch.append(processed_row)
                
                if len(batch) >= batch_size:
                    self._execute_batch_merge(cypher_template, batch)
                    count += len(batch)
                    batch = []
            
            # Process remaining rows
            if batch:
                self._execute_batch_merge(cypher_template, batch)
                count += len(batch)
        
        return count
    
    def _process_row_data(self, row: Dict[str, str]) -> Dict[str, Any]:
        """Process row data with appropriate type conversions"""
        processed = {}
        
        for key, value in row.items():
            if not value or value.strip() == '':
                processed[key] = None
                continue
            
            # Convert dates and datetimes
            if key.endswith('_date') and value:
                try:
                    if 'T' in value or ' ' in value:
                        # DateTime
                        if 'T' in value:
                            dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
                        else:
                            dt = datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
                        processed[key] = dt
                    else:
                        # Date only
                        processed[key] = datetime.strptime(value, '%Y-%m-%d').date()
                except ValueError:
                    processed[key] = value  # Keep as string if parsing fails
                continue
            
            # Convert numeric fields
            if key in ['capacity_mw', 'downtime_hours', 'estimated_cost', 'actual_cost', 
                      'labor_hours', 'material_cost', 'total_cost', 'duration_hours',
                      'estimated_generation_loss_mwh', 'measured_heat_rate', 
                      'baseline_heat_rate', 'deviation_percentage']:
                try:
                    processed[key] = float(value)
                except ValueError:
                    processed[key] = value  # Keep as string if parsing fails
                continue
            
            # Keep as string
            processed[key] = value
        
        return processed
    
    def _execute_batch_merge(self, cypher_template: str, batch: List[Dict]) -> None:
        """Execute batch MERGE operation"""
        try:
            self.client.execute_write(cypher_template, {"batch": batch})
        except Exception as e:
            logger.error(f"Batch merge failed: {e}")
            raise
    
    def _load_utilities(self, filename: str, label: str) -> int:
        """Load utility nodes"""
        cypher = """
        UNWIND $batch AS row
        MERGE (u:Utility {utility_id: row.utility_id})
        SET u.name = row.name,
            u.region = row.region,
            u.country = row.country,
            u.description = row.description,
            u.status = row.status
        """
        return self._load_csv_file(filename, label, cypher)
    
    def _load_power_plants(self, filename: str, label: str) -> int:
        """Load power plant nodes"""
        cypher = """
        UNWIND $batch AS row
        MERGE (p:PowerPlant {plant_id: row.plant_id})
        SET p.utility_id = row.utility_id,
            p.name = row.name,
            p.location = row.location,
            p.plant_type = row.plant_type,
            p.capacity_mw = row.capacity_mw,
            p.commissioning_date = row.commissioning_date,
            p.status = row.status
        """
        return self._load_csv_file(filename, label, cypher)
    
    def _load_generating_units(self, filename: str, label: str) -> int:
        """Load generating unit nodes"""
        cypher = """
        UNWIND $batch AS row
        MERGE (u:GeneratingUnit {unit_id: row.unit_id})
        SET u.plant_id = row.plant_id,
            u.unit_name = row.unit_name,
            u.unit_type = row.unit_type,
            u.capacity_mw = row.capacity_mw,
            u.commissioning_date = row.commissioning_date,
            u.status = row.status
        """
        return self._load_csv_file(filename, label, cypher)
    
    def _load_assets(self, filename: str, label: str) -> int:
        """Load asset nodes"""
        cypher = """
        UNWIND $batch AS row
        MERGE (a:Asset {asset_id: row.asset_id})
        SET a.unit_id = row.unit_id,
            a.asset_tag = row.asset_tag,
            a.name = row.name,
            a.asset_class = row.asset_class,
            a.manufacturer = row.manufacturer,
            a.model = row.model,
            a.installation_date = row.installation_date,
            a.criticality = row.criticality,
            a.operational_status = row.operational_status
        """
        return self._load_csv_file(filename, label, cypher)
    
    def _load_components(self, filename: str, label: str) -> int:
        """Load component nodes"""
        cypher = """
        UNWIND $batch AS row
        MERGE (c:Component {component_id: row.component_id})
        SET c.asset_id = row.asset_id,
            c.component_name = row.component_name,
            c.component_type = row.component_type,
            c.manufacturer = row.manufacturer,
            c.model = row.model,
            c.criticality = row.criticality,
            c.installation_date = row.installation_date,
            c.status = row.status
        """
        return self._load_csv_file(filename, label, cypher)
    
    def _load_inspections(self, filename: str, label: str) -> int:
        """Load inspection nodes"""
        cypher = """
        UNWIND $batch AS row
        MERGE (i:Inspection {inspection_id: row.inspection_id})
        SET i.asset_id = row.asset_id,
            i.inspection_date = row.inspection_date,
            i.inspection_type = row.inspection_type,
            i.inspector = row.inspector,
            i.condition = row.condition,
            i.findings = row.findings,
            i.severity = row.severity,
            i.recommended_action = row.recommended_action
        """
        return self._load_csv_file(filename, label, cypher)
    
    def _load_failure_events(self, filename: str, label: str) -> int:
        """Load failure event nodes"""
        cypher = """
        UNWIND $batch AS row
        MERGE (f:FailureEvent {failure_id: row.failure_id})
        SET f.asset_id = row.asset_id,
            f.failure_date = row.failure_date,
            f.failure_mode = row.failure_mode,
            f.severity = row.severity,
            f.description = row.description,
            f.root_cause = row.root_cause,
            f.downtime_hours = row.downtime_hours,
            f.estimated_cost = row.estimated_cost,
            f.actual_cost = row.actual_cost,
            f.status = row.status
        """
        return self._load_csv_file(filename, label, cypher)
    
    def _load_work_orders(self, filename: str, label: str) -> int:
        """Load work order nodes"""
        cypher = """
        UNWIND $batch AS row
        MERGE (w:WorkOrder {work_order_id: row.work_order_id})
        SET w.asset_id = row.asset_id,
            w.failure_id = row.failure_id,
            w.created_date = row.created_date,
            w.scheduled_date = row.scheduled_date,
            w.completion_date = row.completion_date,
            w.work_type = row.work_type,
            w.priority = row.priority,
            w.status = row.status,
            w.description = row.description,
            w.labor_hours = row.labor_hours,
            w.material_cost = row.material_cost,
            w.total_cost = row.total_cost
        """
        return self._load_csv_file(filename, label, cypher)
    
    def _load_maintenance_plans(self, filename: str, label: str) -> int:
        """Load maintenance plan nodes"""
        cypher = """
        UNWIND $batch AS row
        MERGE (m:MaintenancePlan {maintenance_plan_id: row.maintenance_plan_id})
        SET m.asset_id = row.asset_id,
            m.plan_name = row.plan_name,
            m.maintenance_type = row.maintenance_type,
            m.frequency = row.frequency,
            m.last_execution_date = row.last_execution_date,
            m.next_due_date = row.next_due_date,
            m.status = row.status
        """
        return self._load_csv_file(filename, label, cypher)
    
    def _load_outage_events(self, filename: str, label: str) -> int:
        """Load outage event nodes"""
        cypher = """
        UNWIND $batch AS row
        MERGE (o:OutageEvent {outage_id: row.outage_id})
        SET o.unit_id = row.unit_id,
            o.outage_type = row.outage_type,
            o.start_date = row.start_date,
            o.end_date = row.end_date,
            o.duration_hours = row.duration_hours,
            o.cause = row.cause,
            o.status = row.status,
            o.estimated_generation_loss_mwh = row.estimated_generation_loss_mwh,
            o.estimated_cost = row.estimated_cost
        """
        return self._load_csv_file(filename, label, cypher)
    
    def _load_heat_rate_tests(self, filename: str, label: str) -> int:
        """Load heat rate test nodes"""
        cypher = """
        UNWIND $batch AS row
        MERGE (h:HeatRateTest {test_id: row.test_id})
        SET h.unit_id = row.unit_id,
            h.test_date = row.test_date,
            h.measured_heat_rate = row.measured_heat_rate,
            h.baseline_heat_rate = row.baseline_heat_rate,
            h.deviation_percentage = row.deviation_percentage,
            h.test_status = row.test_status,
            h.observations = row.observations
        """
        return self._load_csv_file(filename, label, cypher)
    
    def _create_relationships(self) -> None:
        """Create all graph relationships"""
        print("Creating relationships...")
        
        relationships = [
            ("HAS_PLANT", self._create_utility_plant_relationships),
            ("HAS_UNIT", self._create_plant_unit_relationships), 
            ("HAS_ASSET", self._create_unit_asset_relationships),
            ("HAS_COMPONENT", self._create_asset_component_relationships),
            ("HAS_INSPECTION", self._create_asset_inspection_relationships),
            ("HAS_FAILURE", self._create_asset_failure_relationships),
            ("HAS_WORK_ORDER", self._create_asset_work_order_relationships),
            ("HAS_MAINTENANCE_PLAN", self._create_asset_maintenance_relationships),
            ("HAS_OUTAGE", self._create_unit_outage_relationships),
            ("HAS_HEAT_RATE_TEST", self._create_unit_heat_rate_relationships),
            ("TRIGGERED_WORK_ORDER", self._create_failure_work_order_relationships)
        ]
        
        for rel_type, creator_func in relationships:
            count = creator_func()
            self.relationship_counts[rel_type] = count
            print(f"  ✓ Created {count} {rel_type} relationships")
    
    def _create_utility_plant_relationships(self) -> int:
        """Create Utility -> PowerPlant relationships"""
        cypher = """
        MATCH (u:Utility), (p:PowerPlant)
        WHERE u.utility_id = p.utility_id
        MERGE (u)-[:HAS_PLANT]->(p)
        """
        result = self.client.execute_write(cypher)
        return result["relationships_created"]
    
    def _create_plant_unit_relationships(self) -> int:
        """Create PowerPlant -> GeneratingUnit relationships"""
        cypher = """
        MATCH (p:PowerPlant), (u:GeneratingUnit)
        WHERE p.plant_id = u.plant_id
        MERGE (p)-[:HAS_UNIT]->(u)
        """
        result = self.client.execute_write(cypher)
        return result["relationships_created"]
    
    def _create_unit_asset_relationships(self) -> int:
        """Create GeneratingUnit -> Asset relationships"""
        cypher = """
        MATCH (u:GeneratingUnit), (a:Asset)
        WHERE u.unit_id = a.unit_id
        MERGE (u)-[:HAS_ASSET]->(a)
        """
        result = self.client.execute_write(cypher)
        return result["relationships_created"]
    
    def _create_asset_component_relationships(self) -> int:
        """Create Asset -> Component relationships"""
        cypher = """
        MATCH (a:Asset), (c:Component)
        WHERE a.asset_id = c.asset_id
        MERGE (a)-[:HAS_COMPONENT]->(c)
        """
        result = self.client.execute_write(cypher)
        return result["relationships_created"]
    
    def _create_asset_inspection_relationships(self) -> int:
        """Create Asset -> Inspection relationships"""
        cypher = """
        MATCH (a:Asset), (i:Inspection)
        WHERE a.asset_id = i.asset_id
        MERGE (a)-[:HAS_INSPECTION]->(i)
        """
        result = self.client.execute_write(cypher)
        return result["relationships_created"]
    
    def _create_asset_failure_relationships(self) -> int:
        """Create Asset -> FailureEvent relationships"""
        cypher = """
        MATCH (a:Asset), (f:FailureEvent)
        WHERE a.asset_id = f.asset_id
        MERGE (a)-[:HAS_FAILURE]->(f)
        """
        result = self.client.execute_write(cypher)
        return result["relationships_created"]
    
    def _create_asset_work_order_relationships(self) -> int:
        """Create Asset -> WorkOrder relationships"""
        cypher = """
        MATCH (a:Asset), (w:WorkOrder)
        WHERE a.asset_id = w.asset_id
        MERGE (a)-[:HAS_WORK_ORDER]->(w)
        """
        result = self.client.execute_write(cypher)
        return result["relationships_created"]
    
    def _create_asset_maintenance_relationships(self) -> int:
        """Create Asset -> MaintenancePlan relationships"""
        cypher = """
        MATCH (a:Asset), (m:MaintenancePlan)
        WHERE a.asset_id = m.asset_id
        MERGE (a)-[:HAS_MAINTENANCE_PLAN]->(m)
        """
        result = self.client.execute_write(cypher)
        return result["relationships_created"]
    
    def _create_unit_outage_relationships(self) -> int:
        """Create GeneratingUnit -> OutageEvent relationships"""
        cypher = """
        MATCH (u:GeneratingUnit), (o:OutageEvent)
        WHERE u.unit_id = o.unit_id
        MERGE (u)-[:HAS_OUTAGE]->(o)
        """
        result = self.client.execute_write(cypher)
        return result["relationships_created"]
    
    def _create_unit_heat_rate_relationships(self) -> int:
        """Create GeneratingUnit -> HeatRateTest relationships"""
        cypher = """
        MATCH (u:GeneratingUnit), (h:HeatRateTest)
        WHERE u.unit_id = h.unit_id
        MERGE (u)-[:HAS_HEAT_RATE_TEST]->(h)
        """
        result = self.client.execute_write(cypher)
        return result["relationships_created"]
    
    def _create_failure_work_order_relationships(self) -> int:
        """Create FailureEvent -> WorkOrder relationships"""
        cypher = """
        MATCH (f:FailureEvent), (w:WorkOrder)
        WHERE f.failure_id = w.failure_id
        AND w.failure_id IS NOT NULL
        MERGE (f)-[:TRIGGERED_WORK_ORDER]->(w)
        """
        result = self.client.execute_write(cypher)
        return result["relationships_created"]
    
    def _validate_graph(self) -> None:
        """Validate loaded graph structure and scenarios"""
        print("Validating loaded graph...")
        
        # Validate node counts
        self._validate_node_counts()
        
        # Validate relationship counts  
        self._validate_relationship_counts()
        
        # Validate scenarios
        self._validate_scenarios()
        
        print("Graph validation completed!")
    
    def _validate_node_counts(self) -> None:
        """Validate that expected nodes were loaded"""
        print("  Validating node counts...")
        
        for label in self.node_counts:
            actual_count = self.client.get_node_count(label)
            expected_count = self.node_counts[label]
            
            if actual_count != expected_count:
                raise ValueError(f"Node count mismatch for {label}: expected {expected_count}, got {actual_count}")
    
    def _validate_relationship_counts(self) -> None:
        """Validate that expected relationships exist in the graph"""
        print("  Validating relationship counts...")
        
        for rel_type in self.relationship_counts:
            actual_count = self.client.get_relationship_count(rel_type)
            # For idempotency, we check that the relationships exist, not that they were just created
            if actual_count == 0:
                raise ValueError(f"No relationships found for {rel_type}")
            # Store actual count for summary reporting
            self.relationship_counts[rel_type] = actual_count
    
    def _validate_scenarios(self) -> None:
        """Validate that the four key scenarios exist in the graph"""
        print("  Validating scenario data...")
        
        scenario_results = {
            "A": self._validate_scenario_a(),
            "B": self._validate_scenario_b(), 
            "C": self._validate_scenario_c(),
            "D": self._validate_scenario_d()
        }
        
        for scenario, passed in scenario_results.items():
            status = "PASS" if passed else "FAIL"
            print(f"    Scenario {scenario}: {status}")
            if not passed:
                logger.warning(f"Scenario {scenario} validation failed")
    
    def _validate_scenario_a(self) -> bool:
        """Validate Scenario A: Turbine Component Failure Chain"""
        try:
            # Find compressor blade failure with associated work order
            cypher = """
            MATCH (a:Asset)-[:HAS_FAILURE]->(f:FailureEvent)-[:TRIGGERED_WORK_ORDER]->(w:WorkOrder)
            WHERE f.failure_mode CONTAINS "Compressor Blade"
            AND f.downtime_hours > 100
            AND f.actual_cost > 800000
            RETURN a.asset_tag, f.failure_mode, f.downtime_hours, f.actual_cost, w.work_type
            """
            
            result = self.client.execute_query(cypher)
            return len(result) > 0
            
        except Exception as e:
            logger.error(f"Scenario A validation error: {e}")
            return False
    
    def _validate_scenario_b(self) -> bool:
        """Validate Scenario B: Heat Rate Degradation"""
        try:
            # Find heat rate test series showing degradation
            cypher = """
            MATCH (u:GeneratingUnit)-[:HAS_HEAT_RATE_TEST]->(h:HeatRateTest)
            WHERE h.baseline_heat_rate = 7800.0
            RETURN count(h) as test_count, 
                   min(h.measured_heat_rate) as min_hr,
                   max(h.measured_heat_rate) as max_hr
            """
            
            result = self.client.execute_query(cypher)
            if not result:
                return False
                
            data = result[0]
            return (data["test_count"] >= 5 and 
                   data["min_hr"] <= 7820 and 
                   data["max_hr"] >= 7950)
            
        except Exception as e:
            logger.error(f"Scenario B validation error: {e}")
            return False
    
    def _validate_scenario_c(self) -> bool:
        """Validate Scenario C: Repeated Asset Failures"""
        try:
            # Find asset with multiple failures (seal and bearing)
            cypher = """
            MATCH (a:Asset)-[:HAS_FAILURE]->(f:FailureEvent)
            WHERE f.failure_mode CONTAINS "Seal" OR f.failure_mode CONTAINS "Bearing"
            WITH a, count(f) as failure_count
            WHERE failure_count >= 2
            RETURN a.asset_tag, failure_count
            """
            
            result = self.client.execute_query(cypher)
            return len(result) > 0
            
        except Exception as e:
            logger.error(f"Scenario C validation error: {e}")
            return False
    
    def _validate_scenario_d(self) -> bool:
        """Validate Scenario D: Maintenance Effectiveness"""
        try:
            # Find assets with both maintenance plans and work orders
            cypher = """
            MATCH (a:Asset)-[:HAS_MAINTENANCE_PLAN]->(m:MaintenancePlan),
                  (a)-[:HAS_WORK_ORDER]->(w:WorkOrder)
            RETURN count(DISTINCT a) as assets_with_both
            """
            
            result = self.client.execute_query(cypher)
            if not result:
                return False
                
            return result[0]["assets_with_both"] > 0
            
        except Exception as e:
            logger.error(f"Scenario D validation error: {e}")
            return False
    
    def get_graph_summary(self) -> Dict[str, Any]:
        """Get comprehensive graph summary"""
        summary = {
            "total_nodes": self.client.get_node_count(),
            "total_relationships": self.client.get_relationship_count(),
            "nodes_by_label": {},
            "relationships_by_type": {}
        }
        
        # Get node counts by label
        for label in self.node_counts:
            summary["nodes_by_label"][label] = self.client.get_node_count(label)
        
        # Get relationship counts by type
        for rel_type in self.relationship_counts:
            summary["relationships_by_type"][rel_type] = self.client.get_relationship_count(rel_type)
        
        return summary


def main():
    """Main function to load graph data"""
    data_dir = Path(__file__).parent.parent.parent / "data" / "synthetic"
    
    if not data_dir.exists():
        print(f"Data directory not found: {data_dir}")
        print("Please run data generation first.")
        return False
    
    try:
        loader = GraphLoader(data_dir)
        loader.load_complete_graph()
        
        # Print summary
        summary = loader.get_graph_summary()
        print("\n" + "="*60)
        print("GRAPH LOADING SUMMARY")
        print("="*60)
        print(f"Total nodes: {summary['total_nodes']}")
        print(f"Total relationships: {summary['total_relationships']}")
        print("\nNodes by label:")
        for label, count in summary["nodes_by_label"].items():
            print(f"  {label}: {count}")
        print("\nRelationships by type:")
        for rel_type, count in summary["relationships_by_type"].items():
            print(f"  {rel_type}: {count}")
        
        return True
        
    except Exception as e:
        print(f"Graph loading failed: {e}")
        logger.error(f"Graph loading failed: {e}")
        return False


if __name__ == "__main__":
    main()