"""
Embedding generation and management for chunks
"""

import logging
from typing import List, Dict, Any, Optional, Tuple
import time
from app.graph.neo4j_client import neo4j_client
from app.services.embedding_service import embedding_service
from app.core.config import settings

logger = logging.getLogger(__name__)


class EmbeddingManager:
    """Manager for generating and storing chunk embeddings in Neo4j"""
    
    def __init__(self):
        self.client = neo4j_client
        self.embedding_service = embedding_service
    
    def get_chunks_needing_embeddings(self, force: bool = False) -> List[Dict[str, Any]]:
        """
        Get chunks that need embeddings generated
        
        Args:
            force: If True, include chunks that already have embeddings
            
        Returns:
            List of chunk data
        """
        if force:
            # Get all chunks when forcing regeneration
            query = """
            MATCH (c:Chunk)
            RETURN c.chunk_id as chunk_id, c.text as text, c.embedding as existing_embedding
            ORDER BY c.chunk_id
            """
        else:
            # Only get chunks without valid embeddings
            query = f"""
            MATCH (c:Chunk)
            WHERE c.embedding IS NULL 
               OR size(c.embedding) <> {settings.embedding_dimension}
            RETURN c.chunk_id as chunk_id, c.text as text, c.embedding as existing_embedding
            ORDER BY c.chunk_id
            """
        
        try:
            result = self.client.execute_query(query)
            logger.info(f"Found {len(result)} chunks needing embeddings")
            return result
        except Exception as e:
            logger.error(f"Error querying chunks for embeddings: {e}")
            return []
    
    def generate_chunk_embedding(self, chunk_id: str, text: str) -> Optional[List[float]]:
        """
        Generate embedding for a single chunk
        
        Args:
            chunk_id: Chunk identifier
            text: Chunk text content
            
        Returns:
            Generated embedding or None if failed
        """
        try:
            embedding = self.embedding_service.embed_text(text)
            
            # Validate embedding
            if not self.embedding_service.is_valid_embedding(embedding):
                logger.error(f"Invalid embedding generated for chunk {chunk_id}")
                return None
            
            return embedding
            
        except Exception as e:
            logger.error(f"Error generating embedding for chunk {chunk_id}: {e}")
            return None
    
    def store_chunk_embedding(self, chunk_id: str, embedding: List[float]) -> bool:
        """
        Store embedding in Neo4j for a chunk
        
        Args:
            chunk_id: Chunk identifier
            embedding: Embedding vector
            
        Returns:
            True if successful, False otherwise
        """
        query = """
        MATCH (c:Chunk {chunk_id: $chunk_id})
        SET c.embedding = $embedding,
            c.embedding_model = $model,
            c.embedding_dimension = $dimension,
            c.embedding_updated = datetime()
        RETURN c.chunk_id as updated_chunk
        """
        
        try:
            result = self.client.execute_query(query, {
                "chunk_id": chunk_id,
                "embedding": embedding,
                "model": self.embedding_service.model_name,
                "dimension": self.embedding_service.dimension
            })
            
            success = len(result) > 0
            if not success:
                logger.error(f"Chunk {chunk_id} not found for embedding update")
            
            return success
            
        except Exception as e:
            logger.error(f"Error storing embedding for chunk {chunk_id}: {e}")
            return False
    
    def generate_embeddings_batch(self, chunks: List[Dict[str, Any]]) -> Tuple[int, int, int]:
        """
        Generate embeddings for a batch of chunks
        
        Args:
            chunks: List of chunk data with chunk_id and text
            
        Returns:
            Tuple of (successful, failed, skipped) counts
        """
        if not chunks:
            return 0, 0, 0
        
        successful = 0
        failed = 0
        skipped = 0
        
        # Prepare texts for batch embedding
        texts = []
        chunk_ids = []
        
        for chunk in chunks:
            chunk_id = chunk['chunk_id']
            text = chunk['text']
            
            if not text or text.strip() == "":
                logger.warning(f"Skipping chunk {chunk_id} with empty text")
                skipped += 1
                continue
            
            texts.append(text)
            chunk_ids.append(chunk_id)
        
        if not texts:
            return successful, failed, skipped
        
        try:
            # Generate embeddings in batch
            logger.info(f"Generating embeddings for {len(texts)} chunks...")
            embeddings = self.embedding_service.embed_texts(texts)
            
            # Store embeddings
            for chunk_id, embedding in zip(chunk_ids, embeddings):
                if self.store_chunk_embedding(chunk_id, embedding):
                    successful += 1
                else:
                    failed += 1
            
        except Exception as e:
            logger.error(f"Error in batch embedding generation: {e}")
            failed += len(chunk_ids)
        
        return successful, failed, skipped
    
    def generate_all_embeddings(self, force: bool = False, batch_size: int = None) -> Dict[str, Any]:
        """
        Generate embeddings for all chunks that need them
        
        Args:
            force: If True, regenerate all embeddings
            batch_size: Number of chunks to process in each batch
            
        Returns:
            Statistics about the embedding generation process
        """
        start_time = time.time()
        
        if batch_size is None:
            batch_size = settings.embedding_batch_size
        
        logger.info("Starting embedding generation process...")
        logger.info(f"Model: {self.embedding_service.model_name}")
        logger.info(f"Dimension: {self.embedding_service.dimension}")
        logger.info(f"Force regeneration: {force}")
        
        # Get chunks needing embeddings
        chunks = self.get_chunks_needing_embeddings(force=force)
        
        if not chunks:
            logger.info("No chunks need embeddings")
            return {
                "total_chunks": 0,
                "chunks_processed": 0,
                "successful": 0,
                "failed": 0,
                "skipped": 0,
                "execution_time": 0,
                "model": self.embedding_service.model_name,
                "dimension": self.embedding_service.dimension
            }
        
        total_successful = 0
        total_failed = 0
        total_skipped = 0
        
        # Process chunks in batches
        for i in range(0, len(chunks), batch_size):
            batch = chunks[i:i + batch_size]
            batch_num = (i // batch_size) + 1
            total_batches = (len(chunks) + batch_size - 1) // batch_size
            
            logger.info(f"Processing batch {batch_num}/{total_batches} ({len(batch)} chunks)")
            
            successful, failed, skipped = self.generate_embeddings_batch(batch)
            
            total_successful += successful
            total_failed += failed
            total_skipped += skipped
            
            logger.info(f"Batch {batch_num} complete: {successful} successful, {failed} failed, {skipped} skipped")
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        logger.info("Embedding generation completed")
        logger.info(f"Total: {total_successful} successful, {total_failed} failed, {total_skipped} skipped")
        logger.info(f"Execution time: {execution_time:.2f} seconds")
        
        return {
            "total_chunks": len(chunks),
            "chunks_processed": total_successful + total_failed,
            "successful": total_successful,
            "failed": total_failed,
            "skipped": total_skipped,
            "execution_time": execution_time,
            "model": self.embedding_service.model_name,
            "dimension": self.embedding_service.dimension
        }
    
    def get_embedding_stats(self) -> Dict[str, Any]:
        """Get statistics about embeddings in the database"""
        queries = {
            "total_chunks": "MATCH (c:Chunk) RETURN count(c) as count",
            "chunks_with_embeddings": f"""
                MATCH (c:Chunk) 
                WHERE c.embedding IS NOT NULL 
                AND size(c.embedding) = {settings.embedding_dimension}
                RETURN count(c) as count
            """,
            "chunks_without_embeddings": f"""
                MATCH (c:Chunk) 
                WHERE c.embedding IS NULL 
                OR size(c.embedding) <> {settings.embedding_dimension}
                RETURN count(c) as count
            """
        }
        
        stats = {}
        
        for key, query in queries.items():
            try:
                result = self.client.execute_query(query)
                stats[key] = result[0]['count'] if result else 0
            except Exception as e:
                logger.error(f"Error getting {key}: {e}")
                stats[key] = 0
        
        # Add configuration info
        stats.update({
            "embedding_model": self.embedding_service.model_name,
            "embedding_dimension": self.embedding_service.dimension,
            "embedding_device": self.embedding_service.device
        })
        
        return stats
    
    def vector_search(self, query_text: str, limit: int = 5, similarity_threshold: float = 0.0) -> List[Dict[str, Any]]:
        """
        Perform vector similarity search on chunk embeddings
        
        Args:
            query_text: Text to search for
            limit: Maximum number of results to return
            similarity_threshold: Minimum similarity score
            
        Returns:
            List of matching chunks with similarity scores
        """
        try:
            # Generate embedding for query text
            query_embedding = self.embedding_service.embed_text(query_text)
            
            # Perform vector search
            search_query = f"""
            MATCH (node:Chunk)
              SEARCH node IN (
                VECTOR INDEX chunk_embedding_index
                FOR $query_embedding
                LIMIT $limit
              ) SCORE AS score
            WHERE score >= $similarity_threshold
            MATCH (d:Document)-[:HAS_CHUNK]->(node)
            RETURN 
                node.chunk_id as chunk_id,
                d.document_id as document_id,
                d.title as document_title,
                left(node.text, 200) + '...' as chunk_preview,
                node.text as full_text,
                score as similarity_score
            ORDER BY score DESC
            """
            
            result = self.client.execute_query(search_query, {
                "limit": limit,
                "query_embedding": query_embedding,
                "similarity_threshold": similarity_threshold
            })
            
            return result
            
        except Exception as e:
            logger.error(f"Error performing vector search: {e}")
            return []


# Global embedding manager instance
embedding_manager = EmbeddingManager()