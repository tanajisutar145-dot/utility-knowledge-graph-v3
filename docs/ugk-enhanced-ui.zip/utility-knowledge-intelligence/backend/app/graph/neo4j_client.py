"""
Neo4j database client
"""

from neo4j import GraphDatabase
from typing import List, Dict, Any, Optional
import logging

from app.core.config import settings

logger = logging.getLogger(__name__)


class Neo4jClient:
    """Neo4j database client for graph operations"""
    
    def __init__(self):
        self.uri = settings.neo4j_uri
        self.username = settings.neo4j_username
        self.password = settings.neo4j_password
        self._driver = None
    
    def _get_driver(self):
        """Get Neo4j driver instance, initialize if needed"""
        if self._driver is None:
            try:
                self._driver = GraphDatabase.driver(
                    self.uri,
                    auth=(self.username, self.password) if self.password else None
                )
            except Exception as e:
                logger.error(f"Failed to initialize Neo4j driver: {e}")
                return None
        return self._driver
    
    def verify_connectivity(self) -> bool:
        """Verify Neo4j database connectivity"""
        driver = self._get_driver()
        if not driver:
            return False
            
        try:
            with driver.session() as session:
                result = session.run("RETURN 1 AS health")
                record = result.single()
                return record is not None and record["health"] == 1
        except Exception as e:
            logger.error(f"Neo4j connectivity check failed: {e}")
            return False
    
    async def connect(self):
        """Initialize database connection"""
        driver = self._get_driver()
        return driver is not None
    
    async def close(self):
        """Close database connection"""
        if self._driver:
            self._driver.close()
            self._driver = None
    
    def execute_query(self, cypher: str, parameters: Dict[str, Any] = None) -> List[Dict]:
        """Execute Cypher query and return results"""
        driver = self._get_driver()
        if not driver:
            raise RuntimeError("Neo4j driver not available")
        
        try:
            with driver.session() as session:
                result = session.run(cypher, parameters or {})
                return [record.data() for record in result]
        except Exception as e:
            logger.error(f"Query execution failed: {e}")
            raise
    
    def execute_write(self, cypher: str, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """Execute write query and return summary"""
        driver = self._get_driver()
        if not driver:
            raise RuntimeError("Neo4j driver not available")
        
        try:
            with driver.session() as session:
                result = session.run(cypher, parameters or {})
                summary = result.consume()
                return {
                    "nodes_created": summary.counters.nodes_created,
                    "nodes_deleted": summary.counters.nodes_deleted,
                    "relationships_created": summary.counters.relationships_created,
                    "relationships_deleted": summary.counters.relationships_deleted,
                    "properties_set": summary.counters.properties_set,
                    "constraints_added": summary.counters.constraints_added,
                    "indexes_added": summary.counters.indexes_added
                }
        except Exception as e:
            logger.error(f"Write query execution failed: {e}")
            raise
    
    def get_node_count(self, label: str = None) -> int:
        """Get count of nodes with optional label filter"""
        if label:
            cypher = f"MATCH (n:{label}) RETURN count(n) as count"
        else:
            cypher = "MATCH (n) RETURN count(n) as count"
        
        result = self.execute_query(cypher)
        return result[0]["count"] if result else 0
    
    def get_relationship_count(self, rel_type: str = None) -> int:
        """Get count of relationships with optional type filter"""
        if rel_type:
            cypher = f"MATCH ()-[r:{rel_type}]->() RETURN count(r) as count"
        else:
            cypher = "MATCH ()-[r]->() RETURN count(r) as count"
        
        result = self.execute_query(cypher)
        return result[0]["count"] if result else 0


# Global Neo4j client instance
neo4j_client = Neo4jClient()