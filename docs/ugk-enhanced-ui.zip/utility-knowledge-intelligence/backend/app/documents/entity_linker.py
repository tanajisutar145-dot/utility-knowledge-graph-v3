"""
Entity linking service for connecting documents to graph entities
"""

import re
from typing import List, Dict, Set, Optional
from .models import Document, Chunk, EntityReference


class EntityLinker:
    """Service for linking documents to existing graph entities"""
    
    def __init__(self, neo4j_client=None):
        self.neo4j_client = neo4j_client
        
        # Known entity ID patterns
        self.entity_patterns = {
            'asset': re.compile(r'\bAST-\d{3}\b', re.IGNORECASE),
            'unit': re.compile(r'\bUNT-\d{3}\b', re.IGNORECASE),
            'inspection': re.compile(r'\bINS-\d{3}\b', re.IGNORECASE),
            'failure': re.compile(r'\bFAIL-\d{3}\b', re.IGNORECASE),
            'work_order': re.compile(r'\bWO-\d{3}\b', re.IGNORECASE),
            'maintenance_plan': re.compile(r'\bMP-\d{3}\b', re.IGNORECASE),
            'outage': re.compile(r'\bOUT-\d{3}\b', re.IGNORECASE)
        }
    
    def link_document_entities(self, document: Document) -> List[EntityReference]:
        """
        Find entity references in document content
        
        Args:
            document: Document to analyze
            
        Returns:
            List of entity references found
        """
        references = []
        text = document.content
        
        # Extract explicit entity IDs from metadata first
        metadata_refs = self._extract_metadata_entities(document)
        references.extend(metadata_refs)
        
        # Find entity IDs in text content
        text_refs = self._extract_text_entities(text)
        references.extend(text_refs)
        
        # Validate entities exist in Neo4j if client available
        if self.neo4j_client:
            references = self._validate_entities(references)
        
        return references
    
    def link_chunk_entities(self, chunk: Chunk) -> List[str]:
        """
        Find entity references in chunk text
        
        Args:
            chunk: Chunk to analyze
            
        Returns:
            List of entity IDs referenced in chunk
        """
        entity_ids = []
        text = chunk.text
        
        # Extract entity IDs from chunk metadata
        metadata_ids = self._extract_chunk_metadata_entities(chunk)
        entity_ids.extend(metadata_ids)
        
        # Find entity IDs in chunk text
        for entity_type, pattern in self.entity_patterns.items():
            matches = pattern.findall(text)
            for match in matches:
                if match not in entity_ids:
                    entity_ids.append(match.upper())
        
        return entity_ids
    
    def _extract_metadata_entities(self, document: Document) -> List[EntityReference]:
        """Extract entity references from document metadata"""
        references = []
        
        # Map document fields to entity types
        entity_mappings = [
            ('asset_id', 'Asset', document.asset_id),
            ('unit_id', 'GeneratingUnit', document.unit_id),
            ('inspection_id', 'Inspection', document.inspection_id),
            ('failure_id', 'FailureEvent', document.failure_id),
            ('work_order_id', 'WorkOrder', document.work_order_id)
        ]
        
        for field_name, entity_type, entity_id in entity_mappings:
            if entity_id:
                references.append(EntityReference(
                    entity_type=entity_type,
                    entity_id=entity_id,
                    confidence=1.0,  # High confidence for explicit metadata
                    context=f"Document metadata field: {field_name}"
                ))
        
        return references
    
    def _extract_text_entities(self, text: str) -> List[EntityReference]:
        """Extract entity references from text content"""
        references = []
        
        # Entity type mapping
        type_mapping = {
            'asset': 'Asset',
            'unit': 'GeneratingUnit', 
            'inspection': 'Inspection',
            'failure': 'FailureEvent',
            'work_order': 'WorkOrder',
            'maintenance_plan': 'MaintenancePlan',
            'outage': 'OutageEvent'
        }
        
        for pattern_name, pattern in self.entity_patterns.items():
            matches = pattern.finditer(text)
            for match in matches:
                entity_id = match.group().upper()
                start_pos = max(0, match.start() - 50)
                end_pos = min(len(text), match.end() + 50)
                context = text[start_pos:end_pos].strip()
                
                references.append(EntityReference(
                    entity_type=type_mapping[pattern_name],
                    entity_id=entity_id,
                    confidence=0.9,  # High confidence for ID patterns
                    context=context
                ))
        
        return references
    
    def _extract_chunk_metadata_entities(self, chunk: Chunk) -> List[str]:
        """Extract entity IDs from chunk metadata"""
        entity_ids = []
        
        # Check metadata for entity associations
        metadata_fields = ['asset_id', 'unit_id', 'inspection_id', 'failure_id', 'work_order_id']
        for field in metadata_fields:
            if field in chunk.metadata and chunk.metadata[field]:
                entity_ids.append(chunk.metadata[field])
        
        return entity_ids
    
    def _validate_entities(self, references: List[EntityReference]) -> List[EntityReference]:
        """
        Validate that referenced entities exist in Neo4j
        
        Args:
            references: List of entity references to validate
            
        Returns:
            Filtered list of valid entity references
        """
        if not self.neo4j_client:
            return references
        
        valid_references = []
        
        # Map entity types to their ID property names
        entity_id_properties = {
            'Asset': 'asset_id',
            'GeneratingUnit': 'unit_id', 
            'Inspection': 'inspection_id',
            'FailureEvent': 'failure_id',
            'WorkOrder': 'work_order_id',
            'MaintenancePlan': 'maintenance_plan_id',
            'OutageEvent': 'outage_id'
        }
        
        for ref in references:
            # Get the correct property name for this entity type
            id_property = entity_id_properties.get(ref.entity_type, 'id')
            
            # Query Neo4j to check if entity exists
            query = f"""
            MATCH (n:{ref.entity_type} {{{id_property}: $entity_id}})
            RETURN count(n) as count
            """
            
            try:
                result = self.neo4j_client.execute_query(query, {"entity_id": ref.entity_id})
                if result and len(result) > 0 and result[0]['count'] > 0:
                    valid_references.append(ref)
            except Exception as e:
                # Log error but continue processing
                print(f"Error validating entity {ref.entity_id}: {e}")
                # Keep reference with lower confidence
                ref.confidence *= 0.5
                valid_references.append(ref)
        
        return valid_references
    
    def get_document_entity_links(self, document: Document) -> Dict[str, List[str]]:
        """
        Get all entity links for a document organized by type
        
        Args:
            document: Document to analyze
            
        Returns:
            Dictionary mapping entity types to lists of entity IDs
        """
        references = self.link_document_entities(document)
        
        links = {}
        for ref in references:
            if ref.entity_type not in links:
                links[ref.entity_type] = []
            if ref.entity_id not in links[ref.entity_type]:
                links[ref.entity_type].append(ref.entity_id)
        
        return links