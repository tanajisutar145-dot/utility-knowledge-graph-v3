"""
Document loader for Neo4j integration
"""

from typing import List, Dict, Any, Optional
from datetime import datetime
from .models import Document, Chunk, EntityReference
from .processor import DocumentProcessor


class DocumentLoader:
    """Service for loading documents and chunks into Neo4j"""
    
    def __init__(self, neo4j_client):
        self.neo4j_client = neo4j_client
        self.processor = DocumentProcessor(neo4j_client=neo4j_client)
    
    def create_document_schema(self):
        """Create Neo4j schema for documents and chunks"""
        
        # Create constraints for unique identifiers
        constraints = [
            "CREATE CONSTRAINT document_id_unique IF NOT EXISTS FOR (d:Document) REQUIRE d.document_id IS UNIQUE",
            "CREATE CONSTRAINT chunk_id_unique IF NOT EXISTS FOR (c:Chunk) REQUIRE c.chunk_id IS UNIQUE"
        ]
        
        # Create indexes for performance
        indexes = [
            "CREATE INDEX document_type_idx IF NOT EXISTS FOR (d:Document) ON (d.document_type)",
            "CREATE INDEX document_created_date_idx IF NOT EXISTS FOR (d:Document) ON (d.created_date)",
            "CREATE INDEX document_source_idx IF NOT EXISTS FOR (d:Document) ON (d.source)",
            "CREATE INDEX chunk_document_id_idx IF NOT EXISTS FOR (c:Chunk) ON (c.document_id)"
        ]
        
        # Execute schema creation
        for constraint in constraints:
            try:
                self.neo4j_client.execute_query(constraint)
                print(f"Created constraint: {constraint}")
            except Exception as e:
                print(f"Error creating constraint: {e}")
        
        for index in indexes:
            try:
                self.neo4j_client.execute_query(index)
                print(f"Created index: {index}")
            except Exception as e:
                print(f"Error creating index: {e}")
    
    def load_document(self, document: Document) -> Dict[str, Any]:
        """
        Load a single document into Neo4j
        
        Args:
            document: Document to load
            
        Returns:
            Loading result with statistics
        """
        try:
            # Check if document already exists by ID or duplicate content hash
            existing = self._check_document_exists(document.document_id)
            if existing:
                # Check if content changed
                if existing.get('content_hash') == document.content_hash:
                    return {
                        "document_id": document.document_id,
                        "action": "skipped",
                        "reason": "unchanged_content",
                        "chunks_created": 0,
                        "relationships_created": 0
                    }
                else:
                    # Delete existing chunks before updating
                    self._delete_document_chunks(document.document_id)
            elif document.content_hash:
                existing_hash = self._check_content_hash_exists(document.content_hash)
                if existing_hash:
                    return {
                        "document_id": existing_hash.get("document_id", document.document_id),
                        "action": "skipped",
                        "reason": "duplicate_content_hash",
                        "chunks_created": 0,
                        "relationships_created": 0
                    }
            
            # Process document to get chunks and entity links
            result = self.processor.process_document(document)
            chunks = self.processor.chunker.chunk_document(document)
            entity_refs = self.processor.entity_linker.link_document_entities(document)
            
            # Create document node
            doc_result = self._create_document_node(document)
            
            # Create chunk nodes and relationships
            chunk_results = []
            for chunk in chunks:
                chunk_result = self._create_chunk_node(chunk)
                chunk_results.append(chunk_result)
            
            # Create document-to-entity relationships
            entity_rels = self._create_document_entity_relationships(document, entity_refs)
            
            # Create chunk-to-entity relationships
            chunk_entity_rels = []
            for chunk in chunks:
                chunk_rels = self._create_chunk_entity_relationships(chunk)
                chunk_entity_rels.extend(chunk_rels)
            
            total_relationships = len(entity_rels) + len(chunk_entity_rels) + len(chunks)  # +chunks for HAS_CHUNK rels
            
            return {
                "document_id": document.document_id,
                "action": "updated" if existing else "created",
                "chunks_created": len(chunks),
                "relationships_created": total_relationships,
                "entity_links": len(entity_refs)
            }
            
        except Exception as e:
            return {
                "document_id": document.document_id,
                "action": "failed",
                "error": str(e),
                "chunks_created": 0,
                "relationships_created": 0
            }
    
    def load_documents(self, documents: List[Document]) -> Dict[str, Any]:
        """
        Load multiple documents into Neo4j
        
        Args:
            documents: List of documents to load
            
        Returns:
            Loading statistics
        """
        results = []
        
        for document in documents:
            result = self.load_document(document)
            results.append(result)
        
        # Calculate statistics
        stats = self._calculate_loading_stats(results)
        return stats
    
    def _check_document_exists(self, document_id: str) -> Optional[Dict[str, Any]]:
        """Check if document already exists in Neo4j"""
        query = """
        MATCH (d:Document {document_id: $document_id})
        RETURN d.content_hash as content_hash, d.document_id as document_id
        """
        
        result = self.neo4j_client.execute_query(query, {"document_id": document_id})
        return result[0] if result else None

    def _check_content_hash_exists(self, content_hash: str) -> Optional[Dict[str, Any]]:
        """Check if a document with identical content hash already exists in Neo4j"""
        query = """
        MATCH (d:Document {content_hash: $content_hash})
        RETURN d.content_hash as content_hash, d.document_id as document_id
        LIMIT 1
        """
        result = self.neo4j_client.execute_query(query, {"content_hash": content_hash})
        return result[0] if result else None
    
    def _delete_document_chunks(self, document_id: str):
        """Delete existing chunks for a document"""
        query = """
        MATCH (d:Document {document_id: $document_id})-[:HAS_CHUNK]->(c:Chunk)
        DETACH DELETE c
        """
        
        self.neo4j_client.execute_query(query, {"document_id": document_id})
    
    def _create_document_node(self, document: Document) -> Dict[str, Any]:
        """Create document node in Neo4j"""
        query = """
        MERGE (d:Document {document_id: $document_id})
        SET d.document_type = $document_type,
            d.title = $title,
            d.source = $source,
            d.source_reference = $source_reference,
            d.created_date = datetime($created_date),
            d.content = $content,
            d.content_hash = $content_hash,
            d.processing_status = $processing_status,
            d.format = $format,
            d.source_filename = $source_filename,
            d.warnings = $warnings,
            d.updated_at = datetime()
        RETURN d.document_id as document_id
        """
        
        doc_format = None
        source_filename = None
        warnings = []
        if document.metadata:
            doc_format = document.metadata.get("format")
            source_filename = document.metadata.get("source_filename")
            warnings = document.metadata.get("warnings", [])

        params = {
            "document_id": document.document_id,
            "document_type": document.document_type if isinstance(document.document_type, str) else document.document_type.value,
            "title": document.title,
            "source": document.source,
            "source_reference": document.source_reference,
            "created_date": document.created_date.isoformat(),
            "content": document.content,
            "content_hash": document.content_hash,
            "processing_status": document.processing_status if isinstance(document.processing_status, str) else document.processing_status.value,
            "format": doc_format,
            "source_filename": source_filename,
            "warnings": warnings if isinstance(warnings, list) else [str(warnings)]
        }
        
        result = self.neo4j_client.execute_query(query, params)
        return result[0] if result else {}
    
    def _create_chunk_node(self, chunk: Chunk) -> Dict[str, Any]:
        """Create chunk node and link to document"""
        
        # Build dynamic SET clause for metadata properties
        set_clauses = [
            "c.document_id = $document_id",
            "c.chunk_index = $chunk_index", 
            "c.text = $text",
            "c.created_at = datetime($created_at)"
        ]
        
        params = {
            "document_id": chunk.document_id,
            "chunk_id": chunk.chunk_id,
            "chunk_index": chunk.chunk_index,
            "text": chunk.text,
            "created_at": datetime.now().isoformat()
        }
        
        # Add metadata as separate properties to avoid Neo4j complex object issues
        if chunk.metadata:
            for key, value in chunk.metadata.items():
                if isinstance(value, (str, int, float, bool)):
                    param_name = f"meta_{key}"
                    set_clauses.append(f"c.{param_name} = ${param_name}")
                    params[param_name] = value

                    # Direct properties for easy indexing & querying of source provenance
                    if key in ["page_number", "sheet_name", "row_range", "row_start", "row_end", "section_title", "format", "source_filename"]:
                        direct_param = f"direct_{key}"
                        set_clauses.append(f"c.{key} = ${direct_param}")
                        params[direct_param] = value
        
        set_clause = "SET " + ", ".join(set_clauses)
        
        query = f"""
        MATCH (d:Document {{document_id: $document_id}})
        MERGE (c:Chunk {{chunk_id: $chunk_id}})
        {set_clause}
        MERGE (d)-[:HAS_CHUNK]->(c)
        RETURN c.chunk_id as chunk_id
        """
        
        result = self.neo4j_client.execute_query(query, params)
        return result[0] if result else {}
    
    def _create_document_entity_relationships(self, document: Document, entity_refs: List[EntityReference]) -> List[Dict]:
        """Create relationships between document and entities"""
        relationships = []
        
        # Direct metadata relationships
        entity_mappings = [
            ('asset_id', 'Asset', 'ABOUT_ASSET', document.asset_id),
            ('unit_id', 'GeneratingUnit', 'ABOUT_UNIT', document.unit_id),
            ('inspection_id', 'Inspection', 'ABOUT_INSPECTION', document.inspection_id),
            ('failure_id', 'FailureEvent', 'ABOUT_FAILURE', document.failure_id),
            ('work_order_id', 'WorkOrder', 'ABOUT_WORK_ORDER', document.work_order_id)
        ]
        
        for field_name, entity_type, rel_type, entity_id in entity_mappings:
            if entity_id:
                rel = self._create_entity_relationship(
                    document.document_id, 'Document', 
                    entity_id, entity_type, 
                    rel_type
                )
                if rel:
                    relationships.append(rel)
        
        return relationships
    
    def _create_chunk_entity_relationships(self, chunk: Chunk) -> List[Dict]:
        """Create relationships between chunk and entities"""
        relationships = []
        
        for entity_id in chunk.referenced_entities:
            # Determine entity type from ID pattern
            entity_type = self._get_entity_type_from_id(entity_id)
            if entity_type:
                rel_type = f"MENTIONS_{entity_type.upper()}"
                rel = self._create_entity_relationship(
                    chunk.chunk_id, 'Chunk',
                    entity_id, entity_type,
                    rel_type
                )
                if rel:
                    relationships.append(rel)
        
        return relationships
    
    def _create_entity_relationship(self, from_id: str, from_type: str, to_id: str, to_type: str, rel_type: str) -> Optional[Dict]:
        """Create relationship between two nodes"""
        
        # Map entity types to their ID property names
        entity_id_properties = {
            'Asset': 'asset_id',
            'GeneratingUnit': 'unit_id', 
            'Inspection': 'inspection_id',
            'FailureEvent': 'failure_id',
            'WorkOrder': 'work_order_id',
            'MaintenancePlan': 'maintenance_plan_id',
            'OutageEvent': 'outage_id'
        }
        
        from_id_prop = 'document_id' if from_type == 'Document' else 'chunk_id'
        to_id_prop = entity_id_properties.get(to_type, 'id')
        
        query = f"""
        MATCH (from:{from_type} {{{from_id_prop}: $from_id}})
        MATCH (to:{to_type} {{{to_id_prop}: $to_id}})
        MERGE (from)-[r:{rel_type}]->(to)
        RETURN type(r) as relationship_type
        """
        
        try:
            result = self.neo4j_client.execute_query(query, {"from_id": from_id, "to_id": to_id})
            return result[0] if result else None
        except Exception as e:
            print(f"Error creating relationship {rel_type} from {from_id} to {to_id}: {e}")
            return None
    
    def _get_entity_type_from_id(self, entity_id: str) -> Optional[str]:
        """Determine entity type from ID pattern"""
        if entity_id.startswith('AST-'):
            return 'Asset'
        elif entity_id.startswith('UNT-'):
            return 'GeneratingUnit'
        elif entity_id.startswith('INS-'):
            return 'Inspection'
        elif entity_id.startswith('FAIL-'):
            return 'FailureEvent'
        elif entity_id.startswith('WO-'):
            return 'WorkOrder'
        elif entity_id.startswith('MP-'):
            return 'MaintenancePlan'
        elif entity_id.startswith('OUT-'):
            return 'OutageEvent'
        return None
    
    def _calculate_loading_stats(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate loading statistics"""
        total = len(results)
        created = sum(1 for r in results if r.get('action') == 'created')
        updated = sum(1 for r in results if r.get('action') == 'updated')
        skipped = sum(1 for r in results if r.get('action') == 'skipped')
        failed = sum(1 for r in results if r.get('action') == 'failed')
        
        total_chunks = sum(r.get('chunks_created', 0) for r in results)
        total_relationships = sum(r.get('relationships_created', 0) for r in results)
        
        return {
            "total_documents": total,
            "created": created,
            "updated": updated,
            "skipped": skipped,
            "failed": failed,
            "total_chunks": total_chunks,
            "total_relationships": total_relationships,
            "results": results
        }
    
    def verify_document_schema(self) -> Dict[str, Any]:
        """Verify document and chunk counts in Neo4j"""
        queries = {
            "documents": "MATCH (d:Document) RETURN count(d) as count",
            "chunks": "MATCH (c:Chunk) RETURN count(c) as count",
            "document_chunk_rels": "MATCH (d:Document)-[:HAS_CHUNK]->(c:Chunk) RETURN count(*) as count",
            "document_entity_rels": """
                MATCH (d:Document)-[r]->(e)
                WHERE type(r) STARTS WITH 'ABOUT_'
                RETURN count(*) as count
            """,
            "chunk_entity_rels": """
                MATCH (c:Chunk)-[r]->(e)
                WHERE type(r) STARTS WITH 'MENTIONS_'
                RETURN count(*) as count
            """
        }
        
        results = {}
        for key, query in queries.items():
            try:
                result = self.neo4j_client.execute_query(query)
                results[key] = result[0]['count'] if result else 0
            except Exception as e:
                results[key] = f"Error: {e}"
        
        return results