"""
Document domain models for unstructured content
"""

from pydantic import BaseModel, Field, validator
from typing import Optional, Dict, Any, List
from datetime import datetime
from enum import Enum
import hashlib


class DocumentType(str, Enum):
    INSPECTION_REPORT = "inspection_report"
    FAILURE_REPORT = "failure_report"
    WORK_ORDER_NOTE = "work_order_note"
    MAINTENANCE_REPORT = "maintenance_report"
    INCIDENT_REPORT = "incident_report"
    ENGINEERING_NOTE = "engineering_note"
    OPERATIONAL_NOTE = "operational_note"


class ProcessingStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class Document(BaseModel):
    """Document model for unstructured content"""
    
    document_id: str = Field(..., description="Unique document identifier")
    document_type: DocumentType = Field(..., description="Type of document")
    title: str = Field(..., description="Document title")
    source: str = Field(..., description="Source system or author")
    source_reference: Optional[str] = Field(None, description="External reference ID")
    created_date: datetime = Field(..., description="Document creation date")
    
    # Optional entity associations
    asset_id: Optional[str] = Field(None, description="Associated asset ID")
    unit_id: Optional[str] = Field(None, description="Associated generating unit ID")
    inspection_id: Optional[str] = Field(None, description="Associated inspection ID")
    failure_id: Optional[str] = Field(None, description="Associated failure event ID")
    work_order_id: Optional[str] = Field(None, description="Associated work order ID")
    
    content: str = Field(..., description="Document text content")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
    processing_status: ProcessingStatus = Field(ProcessingStatus.PENDING, description="Processing status")
    content_hash: str = Field("", description="Content hash for idempotency")
    
    @validator('content_hash', always=True)
    def generate_content_hash(cls, v, values):
        """Generate content hash from document content"""
        if 'content' in values and values['content']:
            content = values['content'].encode('utf-8')
            return hashlib.sha256(content).hexdigest()[:16]
        return v
    
    class Config:
        use_enum_values = True


class Chunk(BaseModel):
    """Text chunk model for document processing"""
    
    chunk_id: str = Field(..., description="Unique chunk identifier")
    document_id: str = Field(..., description="Parent document ID")
    chunk_index: int = Field(..., description="Chunk order within document")
    text: str = Field(..., description="Chunk text content")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Chunk metadata")
    
    # Optional entity references found in this chunk
    referenced_entities: List[str] = Field(default_factory=list, description="Entity IDs referenced in chunk")
    
    class Config:
        use_enum_values = True


class DocumentProcessingResult(BaseModel):
    """Result of document processing operation"""
    
    document_id: str
    chunks_created: int
    entity_links: int
    processing_status: ProcessingStatus
    error_message: Optional[str] = None
    
    class Config:
        use_enum_values = True


class EntityReference(BaseModel):
    """Entity reference found in document content"""
    
    entity_type: str = Field(..., description="Type of entity (Asset, WorkOrder, etc.)")
    entity_id: str = Field(..., description="Entity identifier")
    confidence: float = Field(..., description="Confidence score for the match")
    context: str = Field(..., description="Text context where reference was found")
    
    class Config:
        use_enum_values = True