"""
CLI for document processing operations
"""

import sys
import json
from pathlib import Path
from typing import List

# Add project root to path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

from app.documents.loader import DocumentLoader
from app.documents.processor import DocumentProcessor
from app.graph.neo4j_client import neo4j_client


def ingest_documents(documents_dir: str = None):
    """Ingest documents from directory into Neo4j"""
    
    if documents_dir is None:
        documents_dir = project_root / "data" / "documents"
    else:
        documents_dir = Path(documents_dir)
    
    if not documents_dir.exists():
        print(f"Documents directory not found: {documents_dir}")
        return
    
    print("=== Document Ingestion Process ===")
    print(f"Processing documents from: {documents_dir}")
    
    # Initialize services
    loader = DocumentLoader(neo4j_client)
    processor = DocumentProcessor(neo4j_client)
    
    # Verify Neo4j connectivity
    if not neo4j_client.verify_connectivity():
        print("ERROR: Cannot connect to Neo4j database")
        return
    
    print("✓ Neo4j connectivity verified")
    
    # Create document schema
    print("Creating document schema...")
    loader.create_document_schema()
    print("✓ Document schema created")
    
    # Discover documents
    print("Discovering documents...")
    documents = processor.discover_documents(documents_dir)
    print(f"✓ Found {len(documents)} documents")
    
    if not documents:
        print("No documents found to process")
        return
    
    # Validate documents
    print("Validating documents...")
    validation_results = []
    for doc in documents:
        validation = processor.validate_document(doc)
        validation_results.append(validation)
        if not validation["valid"]:
            print(f"  ⚠ {doc.document_id}: {', '.join(validation['issues'])}")
    
    valid_docs = [doc for doc, val in zip(documents, validation_results) if val["valid"]]
    print(f"✓ {len(valid_docs)} documents valid for processing")
    
    if not valid_docs:
        print("No valid documents to process")
        return
    
    # Process documents
    print("Processing documents...")
    loading_stats = loader.load_documents(valid_docs)
    
    print("\n=== Processing Results ===")
    print(f"Total documents: {loading_stats['total_documents']}")
    print(f"Created: {loading_stats['created']}")
    print(f"Updated: {loading_stats['updated']}")
    print(f"Skipped: {loading_stats['skipped']}")
    print(f"Failed: {loading_stats['failed']}")
    print(f"Total chunks: {loading_stats['total_chunks']}")
    print(f"Total relationships: {loading_stats['total_relationships']}")
    
    # Show failed documents
    failed_docs = [r for r in loading_stats['results'] if r.get('action') == 'failed']
    if failed_docs:
        print("\n=== Failed Documents ===")
        for doc in failed_docs:
            print(f"  {doc['document_id']}: {doc.get('error', 'Unknown error')}")
    
    # Verify schema
    print("\n=== Neo4j Verification ===")
    schema_stats = loader.verify_document_schema()
    for key, value in schema_stats.items():
        print(f"{key}: {value}")


def validate_documents(documents_dir: str = None):
    """Validate documents without ingesting"""
    
    if documents_dir is None:
        documents_dir = project_root / "data" / "documents"
    else:
        documents_dir = Path(documents_dir)
    
    if not documents_dir.exists():
        print(f"Documents directory not found: {documents_dir}")
        return
    
    print("=== Document Validation ===")
    print(f"Validating documents in: {documents_dir}")
    
    processor = DocumentProcessor()
    
    # Discover documents
    documents = processor.discover_documents(documents_dir)
    print(f"Found {len(documents)} documents")
    
    if not documents:
        print("No documents found")
        return
    
    # Validate each document
    all_valid = True
    for doc in documents:
        validation = processor.validate_document(doc)
        status = "✓" if validation["valid"] else "✗"
        print(f"{status} {doc.document_id} ({validation['content_length']} chars)")
        
        if not validation["valid"]:
            all_valid = False
            for issue in validation["issues"]:
                print(f"    - {issue}")
    
    print(f"\nValidation {'PASSED' if all_valid else 'FAILED'}")


def list_documents(documents_dir: str = None):
    """List discovered documents"""
    
    if documents_dir is None:
        documents_dir = project_root / "data" / "documents"
    else:
        documents_dir = Path(documents_dir)
    
    if not documents_dir.exists():
        print(f"Documents directory not found: {documents_dir}")
        return
    
    print("=== Document Discovery ===")
    
    processor = DocumentProcessor()
    documents = processor.discover_documents(documents_dir)
    
    if not documents:
        print("No documents found")
        return
    
    print(f"Found {len(documents)} documents:\n")
    
    for doc in documents:
        print(f"ID: {doc.document_id}")
        print(f"Type: {doc.document_type}")
        print(f"Title: {doc.title}")
        print(f"Source: {doc.source}")
        print(f"Content: {len(doc.content)} characters")
        
        # Show entity associations
        associations = []
        if doc.asset_id:
            associations.append(f"Asset: {doc.asset_id}")
        if doc.unit_id:
            associations.append(f"Unit: {doc.unit_id}")
        if doc.inspection_id:
            associations.append(f"Inspection: {doc.inspection_id}")
        if doc.failure_id:
            associations.append(f"Failure: {doc.failure_id}")
        if doc.work_order_id:
            associations.append(f"Work Order: {doc.work_order_id}")
        
        if associations:
            print(f"Links: {', '.join(associations)}")
        
        print("-" * 60)


def inspect_graph():
    """Inspect document nodes in Neo4j"""
    
    if not neo4j_client.verify_connectivity():
        print("ERROR: Cannot connect to Neo4j database")
        return
    
    print("=== Neo4j Document Graph Inspection ===")
    
    loader = DocumentLoader(neo4j_client)
    stats = loader.verify_document_schema()
    
    for key, value in stats.items():
        print(f"{key}: {value}")
    
    # Show sample documents
    print("\n=== Sample Documents ===")
    sample_query = """
    MATCH (d:Document)
    RETURN d.document_id, d.document_type, d.title, d.created_date
    ORDER BY d.created_date DESC
    LIMIT 5
    """
    
    try:
        results = neo4j_client.execute_query(sample_query)
        for doc in results:
            print(f"{doc['d.document_id']}: {doc['d.title']} ({doc['d.document_type']})")
    except Exception as e:
        print(f"Error querying documents: {e}")


def main():
    """Main CLI entry point"""
    
    if len(sys.argv) < 2:
        print("Usage: python -m app.documents <command> [options]")
        print("Commands:")
        print("  ingest [directory]    - Ingest documents into Neo4j")
        print("  validate [directory]  - Validate documents without ingesting")  
        print("  list [directory]      - List discovered documents")
        print("  inspect               - Inspect Neo4j document graph")
        return
    
    command = sys.argv[1]
    directory = sys.argv[2] if len(sys.argv) > 2 else None
    
    if command == "ingest":
        ingest_documents(directory)
    elif command == "validate":
        validate_documents(directory)
    elif command == "list":
        list_documents(directory)
    elif command == "inspect":
        inspect_graph()
    else:
        print(f"Unknown command: {command}")


if __name__ == "__main__":
    main()