"""
Factory and registry for format-specific document parsers
"""

from pathlib import Path
from typing import Dict, List, Type

from .base import BaseParser
from .pdf_parser import PDFParser
from .excel_parser import ExcelParser
from .csv_parser import CSVParser
from .docx_parser import WordParser
from .text_parser import TextParser
from .json_parser import JSONParser


SUPPORTED_EXTENSIONS = [".pdf", ".xlsx", ".csv", ".docx", ".txt", ".json"]
LEGACY_EXTENSIONS = [".xls"]

_PARSER_REGISTRY: Dict[str, Type[BaseParser]] = {
    ".pdf": PDFParser,
    ".xlsx": ExcelParser,
    ".csv": CSVParser,
    ".docx": WordParser,
    ".txt": TextParser,
    ".json": JSONParser,
}


def get_supported_extensions() -> List[str]:
    """Return list of officially supported file extensions"""
    return list(SUPPORTED_EXTENSIONS)


def get_parser_for_file(filename: str) -> BaseParser:
    """
    Resolve and instantiate the appropriate parser for a given filename.

    Raises:
        ValueError: If file extension is unsupported or a known legacy format like .xls
    """
    ext = Path(filename).suffix.lower()

    if ext in LEGACY_EXTENSIONS:
        raise ValueError(
            f"Legacy Excel (.xls) format is not supported due to security and compatibility constraints. "
            f"Please convert your document to .xlsx or .csv before uploading."
        )

    parser_cls = _PARSER_REGISTRY.get(ext)
    if not parser_cls:
        supported_list = ", ".join(sorted(SUPPORTED_EXTENSIONS))
        raise ValueError(
            f"Unsupported file format '{ext}'. Supported formats: {supported_list}."
        )

    return parser_cls()
