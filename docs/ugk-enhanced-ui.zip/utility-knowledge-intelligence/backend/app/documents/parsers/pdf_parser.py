"""
PDF Document Parser using PyMuPDF (fitz)
"""

import io
from pathlib import Path
from typing import List, Dict, Any
import fitz  # PyMuPDF

from .base import BaseParser, ExtractedDocument, ExtractedSection


class PDFParser(BaseParser):
    """Parser for PDF documents extracting text page-by-page with provenance"""

    @property
    def supported_extensions(self) -> List[str]:
        return [".pdf"]

    def parse(self, file_content: bytes, filename: str) -> ExtractedDocument:
        if not file_content:
            raise ValueError("PDF file is empty (0 bytes).")

        try:
            doc = fitz.open(stream=file_content, filetype="pdf")
        except Exception as e:
            raise ValueError(f"Failed to open PDF document. File may be corrupt or encrypted: {e}")

        try:
            page_count = doc.page_count
            if page_count == 0:
                raise ValueError("PDF document has 0 pages.")

            # Extract document metadata
            doc_meta: Dict[str, Any] = {}
            if doc.metadata:
                for k, v in doc.metadata.items():
                    if v and isinstance(v, (str, int, float, bool)):
                        doc_meta[k] = v

            title = doc_meta.get("title")
            if not title or not title.strip():
                # Derive title from filename
                clean_name = Path(filename).stem.replace("_", " ").replace("-", " ")
                title = clean_name.title() or "PDF Document"

            sections: List[ExtractedSection] = []
            full_text_parts: List[str] = []
            warnings: List[str] = []
            total_extracted_chars = 0
            has_images = False

            for page_idx in range(page_count):
                page = doc.load_page(page_idx)
                page_num = page_idx + 1

                # Check for images on page
                images = page.get_images(full=True)
                if images:
                    has_images = True

                # Extract text
                page_text = page.get_text("text").strip()
                char_count = len(page_text)
                total_extracted_chars += char_count

                if page_text:
                    full_text_parts.append(f"--- Page {page_num} ---\n{page_text}")
                    sections.append(
                        ExtractedSection(
                            title=f"Page {page_num}",
                            content=page_text,
                            page_number=page_num,
                            metadata={"char_count": char_count, "image_count": len(images)},
                        )
                    )

            # Detect scanned / image-only PDFs
            if total_extracted_chars < 50:
                if has_images or total_extracted_chars == 0:
                    warnings.append(
                        "Scanned or image-only PDF detected. OCR is required to extract full text."
                    )
                else:
                    warnings.append(
                        "PDF contains very little extractable text (<50 characters)."
                    )

            consolidated_text = "\n\n".join(full_text_parts)
            if not consolidated_text.strip():
                consolidated_text = f"[Document: {title} | {page_count} pages | No extractable text]"

            return ExtractedDocument(
                title=title,
                content=consolidated_text,
                format="pdf",
                source_filename=filename,
                sections=sections,
                metadata={
                    **doc_meta,
                    "total_pages": page_count,
                    "has_images": has_images,
                    "total_characters": total_extracted_chars,
                },
                warnings=warnings,
                page_count=page_count,
            )
        finally:
            doc.close()
