"""
Base interfaces and models for modular document extraction
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class ExtractedSection(BaseModel):
    """A granular, provenance-aware section within a parsed document"""
    title: Optional[str] = Field(None, description="Section or heading title")
    content: str = Field(..., description="Text content of the section")
    page_number: Optional[int] = Field(None, description="1-indexed page number for PDFs")
    sheet_name: Optional[str] = Field(None, description="Worksheet name for Excel files")
    row_start: Optional[int] = Field(None, description="Starting row index for spreadsheet data")
    row_end: Optional[int] = Field(None, description="Ending row index for spreadsheet data")
    section_title: Optional[str] = Field(None, description="Heading context for Word/Text docs")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Custom section metadata")


class ExtractedDocument(BaseModel):
    """Normalized document representation returned by format-specific parsers"""
    title: str = Field(..., description="Document title extracted from metadata or filename")
    content: str = Field(..., description="Full consolidated text content")
    format: str = Field(..., description="Detected format (pdf, xlsx, csv, docx, txt, json)")
    source_filename: str = Field(..., description="Original uploaded filename")
    sections: List[ExtractedSection] = Field(default_factory=list, description="Structured sections with provenance")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Document-level metadata")
    warnings: List[str] = Field(default_factory=list, description="Extraction warnings e.g. OCR required")
    page_count: Optional[int] = Field(None, description="Total pages if applicable")
    sheet_names: Optional[List[str]] = Field(None, description="Worksheet names if applicable")
    table_count: Optional[int] = Field(None, description="Number of tables identified")


class BaseParser(ABC):
    """Abstract interface that all document format parsers must implement"""

    @property
    @abstractmethod
    def supported_extensions(self) -> List[str]:
        """List of file extensions supported by this parser (lowercase, with dot)"""
        pass

    @abstractmethod
    def parse(self, file_content: bytes, filename: str) -> ExtractedDocument:
        """
        Parse raw bytes into a normalized ExtractedDocument.
        Must fail safely and raise ValueError with a clear user-facing message on malformed content.
        """
        pass
