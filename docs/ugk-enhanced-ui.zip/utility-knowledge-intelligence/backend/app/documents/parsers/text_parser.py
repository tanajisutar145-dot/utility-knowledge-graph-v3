"""
Plain Text (.txt) Document Parser preserving baseline behavior
"""

from pathlib import Path
from typing import List

from .base import BaseParser, ExtractedDocument, ExtractedSection


class TextParser(BaseParser):
    """Parser for plain text documents preserving existing working behavior"""

    @property
    def supported_extensions(self) -> List[str]:
        return [".txt"]

    def parse(self, file_content: bytes, filename: str) -> ExtractedDocument:
        if not file_content:
            raise ValueError("Text document is empty (0 bytes).")

        text = ""
        for encoding in ["utf-8", "utf-8-sig", "latin-1", "cp1252"]:
            try:
                text = file_content.decode(encoding)
                break
            except (UnicodeDecodeError, LookupError):
                continue

        if not text:
            raise ValueError("Unable to decode text document using supported encodings.")

        clean_name = Path(filename).stem.replace("_", " ").replace("-", " ")
        title = clean_name.title() or "Text Document"

        # Break into paragraph-based sections if double newlines exist
        raw_sections = [p.strip() for p in text.split("\n\n") if p.strip()]
        sections: List[ExtractedSection] = []

        if raw_sections:
            for idx, p_text in enumerate(raw_sections):
                sections.append(
                    ExtractedSection(
                        title=f"Section {idx + 1}",
                        content=p_text,
                        section_title=f"Section {idx + 1}",
                        metadata={"section_index": idx + 1},
                    )
                )
        else:
            sections.append(
                ExtractedSection(
                    title="Content",
                    content=text.strip(),
                    metadata={"section_index": 1},
                )
            )

        return ExtractedDocument(
            title=title,
            content=text,
            format="txt",
            source_filename=filename,
            sections=sections,
            metadata={"character_count": len(text), "section_count": len(sections)},
            warnings=[],
        )
