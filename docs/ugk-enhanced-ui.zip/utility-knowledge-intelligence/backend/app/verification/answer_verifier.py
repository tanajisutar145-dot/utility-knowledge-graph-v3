"""
Answer verification service for GraphRAG responses
"""

import logging
import re
from typing import List, Dict, Any, Set
from app.intelligence.models import VerificationResult
from app.retrieval.models import RetrievalResult

logger = logging.getLogger(__name__)


class AnswerVerifier:
    """Service for verifying GraphRAG answers against evidence"""
    
    def __init__(self):
        self.hallucination_patterns = [
            r"based on my knowledge",
            r"generally speaking",
            r"typically.*(?:happens|occurs|is)",
            r"in my experience",
            r"it is (?:common|usual|normal)",
            r"usually.*(?:happens|occurs|is)",
            r"from what I (?:know|understand)",
            r"as (?:far as|much as) I know"
        ]
        
        self.uncertainty_patterns = [
            r"insufficient evidence",
            r"not enough information",
            r"cannot determine",
            r"unclear from.*evidence",
            r"evidence does not support",
            r"I don't know",
            r"unable to (?:determine|find)"
        ]
        
        self.evidence_reference_patterns = [
            r"\[([A-Z]+-[0-9]+)\]",  # [DOC-001], [CHUNK-002]
            r"\b([A-Z]+-[0-9]+)\b",  # DOC-001, CHUNK-002 without brackets
        ]
    
    def verify_answer(self, answer: str, retrieval_result: RetrievalResult, question: str) -> VerificationResult:
        """
        Comprehensive verification of answer against evidence
        
        Args:
            answer: Generated answer text
            retrieval_result: Retrieved evidence from Phase 5B
            question: Original question
            
        Returns:
            Detailed verification result
        """
        logger.debug(f"Verifying answer of {len(answer)} characters against evidence")
        
        # Extract available evidence identifiers
        available_evidence = self._extract_available_evidence(retrieval_result)
        
        # Check evidence references in answer
        referenced_evidence = self._extract_referenced_evidence(answer)
        
        # Detect hallucination indicators
        hallucination_warnings = self._detect_hallucination_indicators(answer)
        
        # Check uncertainty acknowledgment
        acknowledges_uncertainty = self._check_uncertainty_acknowledgment(answer)
        
        # Verify numeric claims
        numeric_warnings = self._verify_numeric_claims(answer, retrieval_result)
        
        # Check for unsupported entity references
        entity_warnings = self._check_entity_references(answer, retrieval_result)
        
        # Calculate grounding score
        grounding_score = self._calculate_grounding_score(
            answer, referenced_evidence, available_evidence, 
            hallucination_warnings, acknowledges_uncertainty
        )
        
        # Compile supported and unsupported claims
        supported_claims = []
        unsupported_claims = []
        warnings = []
        
        # Evidence referencing
        if referenced_evidence:
            valid_refs = referenced_evidence.intersection(available_evidence['all_ids'])
            if valid_refs:
                supported_claims.append(f"References {len(valid_refs)} valid evidence items")
            
            invalid_refs = referenced_evidence - available_evidence['all_ids']
            if invalid_refs:
                unsupported_claims.append(f"References invalid evidence: {', '.join(list(invalid_refs)[:3])}")
                warnings.append("Answer contains references to unavailable evidence")
        
        # Uncertainty handling
        if acknowledges_uncertainty:
            supported_claims.append("Appropriately acknowledges evidence limitations")
        
        # Add warnings
        warnings.extend(hallucination_warnings)
        warnings.extend(numeric_warnings)
        warnings.extend(entity_warnings)
        
        # Evidence gaps
        evidence_gaps = self._identify_evidence_gaps(question, retrieval_result)
        
        # Final verification status
        verified = (
            grounding_score >= 0.6 and
            len(unsupported_claims) == 0 and
            len([w for w in warnings if 'hallucination' in w.lower()]) == 0
        )
        
        return VerificationResult(
            verified=verified,
            grounding_score=grounding_score,
            supported_claims=supported_claims,
            unsupported_claims=unsupported_claims,
            warnings=warnings,
            evidence_gaps=evidence_gaps
        )
    
    def _extract_available_evidence(self, retrieval_result: RetrievalResult) -> Dict[str, Set[str]]:
        """Extract all available evidence identifiers"""
        document_ids = {r.document_id for r in retrieval_result.semantic_results}
        chunk_ids = {r.chunk_id for r in retrieval_result.semantic_results}
        entity_ids = {e.entity_id for e in retrieval_result.graph_evidence.entities}
        
        all_ids = document_ids | chunk_ids | entity_ids
        
        return {
            'document_ids': document_ids,
            'chunk_ids': chunk_ids,
            'entity_ids': entity_ids,
            'all_ids': all_ids
        }
    
    def _extract_referenced_evidence(self, answer: str) -> Set[str]:
        """Extract evidence references from answer text"""
        referenced = set()
        
        for pattern in self.evidence_reference_patterns:
            matches = re.findall(pattern, answer, re.IGNORECASE)
            referenced.update(matches)
        
        return referenced
    
    def _detect_hallucination_indicators(self, answer: str) -> List[str]:
        """Detect patterns that suggest hallucination"""
        warnings = []
        
        for pattern in self.hallucination_patterns:
            matches = re.findall(pattern, answer, re.IGNORECASE)
            if matches:
                warnings.append(f"Potential hallucination indicator: '{matches[0]}'")
        
        return warnings
    
    def _check_uncertainty_acknowledgment(self, answer: str) -> bool:
        """Check if answer appropriately acknowledges uncertainty"""
        for pattern in self.uncertainty_patterns:
            if re.search(pattern, answer, re.IGNORECASE):
                return True
        return False
    
    def _verify_numeric_claims(self, answer: str, retrieval_result: RetrievalResult) -> List[str]:
        """Verify numeric claims against evidence"""
        warnings = []
        
        # Extract numbers from answer
        number_pattern = r'\b\d+(?:,\d{3})*(?:\.\d+)?\b'
        numbers_in_answer = re.findall(number_pattern, answer)
        
        if not numbers_in_answer:
            return warnings
        
        # Extract numbers from evidence
        evidence_text = ""
        for result in retrieval_result.semantic_results:
            evidence_text += " " + result.text
        
        for entity in retrieval_result.graph_evidence.entities:
            for value in entity.properties.values():
                evidence_text += " " + str(value)
        
        numbers_in_evidence = set(re.findall(number_pattern, evidence_text))
        
        # Check if answer numbers appear in evidence
        unsupported_numbers = []
        for num in numbers_in_answer:
            if num not in numbers_in_evidence:
                unsupported_numbers.append(num)
        
        if unsupported_numbers:
            warnings.append(f"Contains unsupported numeric claims: {', '.join(unsupported_numbers[:3])}")
        
        return warnings
    
    def _check_entity_references(self, answer: str, retrieval_result: RetrievalResult) -> List[str]:
        """Check entity references in the answer"""
        warnings = []
        
        # Get available entities
        available_entities = {e.entity_id for e in retrieval_result.graph_evidence.entities}
        
        # Look for entity-like patterns in answer
        entity_pattern = r'\b([A-Z]+-[0-9]+)\b'
        mentioned_entities = set(re.findall(entity_pattern, answer))
        
        # Check for references to non-existent entities
        invalid_entities = mentioned_entities - available_entities
        if invalid_entities:
            warnings.append(f"References non-existent entities: {', '.join(list(invalid_entities)[:3])}")
        
        return warnings
    
    def _calculate_grounding_score(self, answer: str, referenced_evidence: Set[str], 
                                  available_evidence: Dict[str, Set[str]], 
                                  hallucination_warnings: List[str], 
                                  acknowledges_uncertainty: bool) -> float:
        """Calculate overall grounding score"""
        score = 0.5  # Base score
        
        # Evidence referencing bonus
        if available_evidence['all_ids']:
            reference_ratio = len(referenced_evidence) / len(available_evidence['all_ids'])
            score += min(0.3, reference_ratio * 0.5)
        
        # Uncertainty acknowledgment bonus
        if acknowledges_uncertainty:
            score += 0.2
        
        # Hallucination penalty
        score -= len(hallucination_warnings) * 0.15
        
        # Answer length consideration (very short answers might be incomplete)
        if len(answer.strip()) < 50:
            score -= 0.1
        
        # Very long answers might contain hallucinations
        if len(answer) > 2000:
            score -= 0.05
        
        return max(0.0, min(1.0, score))
    
    def _identify_evidence_gaps(self, question: str, retrieval_result: RetrievalResult) -> List[str]:
        """Identify potential gaps in evidence for the question"""
        gaps = []
        
        # Check if we have minimal evidence
        if len(retrieval_result.semantic_results) == 0:
            gaps.append("No relevant document chunks found")
        
        if len(retrieval_result.graph_evidence.entities) == 0:
            gaps.append("No relevant graph entities found")
        
        # Question-specific gap detection
        question_lower = question.lower()
        
        if any(word in question_lower for word in ['cost', 'price', 'expense', 'budget']):
            # Check for cost-related evidence
            cost_evidence = False
            for result in retrieval_result.semantic_results:
                if any(word in result.text.lower() for word in ['cost', 'price', '$', 'expense', 'budget']):
                    cost_evidence = True
                    break
            
            if not cost_evidence:
                gaps.append("Question asks about costs but no cost information found in evidence")
        
        if any(word in question_lower for word in ['when', 'date', 'time']):
            # Check for temporal evidence
            temporal_evidence = False
            for result in retrieval_result.semantic_results:
                if any(word in result.text.lower() for word in ['date', 'time', 'when', 'during', 'at']):
                    temporal_evidence = True
                    break
            
            if not temporal_evidence:
                gaps.append("Question asks about timing but no temporal information found in evidence")
        
        return gaps


# Global answer verifier instance
answer_verifier = AnswerVerifier()