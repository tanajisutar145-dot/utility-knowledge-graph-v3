"""
Main FastAPI application entry point
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import yaml
from pathlib import Path

from app.core.config import settings
from app.api.routes import api_router
from app.api.middleware import setup_middleware
from app.llm.groq_client import groq_client
from app.graph.neo4j_client import neo4j_client

# Load configuration from YAML (for non-sensitive settings)
config_path = Path(__file__).parent.parent / "config.yaml"
with open(config_path, "r") as f:
    config = yaml.safe_load(f)

# Create FastAPI app
app = FastAPI(
    title=settings.app_name,
    description="Advanced Knowledge Graph Intelligence System",
    version="1.0.0",
    debug=settings.debug
)

# Setup middleware
setup_middleware(app, config)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_url],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routes
app.include_router(api_router, prefix="/api")

# Health check endpoint
@app.get("/health")
async def health_check():
    """Comprehensive health check endpoint"""
    
    # Check Groq configuration
    groq_status = "configured" if groq_client.is_configured() else "not_configured"
    
    # Check Neo4j connectivity
    neo4j_connected = neo4j_client.verify_connectivity()
    neo4j_status = "connected" if neo4j_connected else "disconnected"
    
    # Determine overall status
    overall_status = "healthy"
    if neo4j_status == "disconnected":
        overall_status = "degraded"
    
    return {
        "status": overall_status,
        "application": settings.app_name,
        "environment": settings.app_env,
        "services": {
            "backend": "healthy",
            "groq": groq_status,
            "neo4j": neo4j_status
        }
    }

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Welcome to Utility Knowledge Intelligence API",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.api_host,
        port=settings.api_port,
        reload=settings.debug
    )