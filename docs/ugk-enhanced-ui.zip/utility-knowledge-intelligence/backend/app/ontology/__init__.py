"""
Ontology management module
"""