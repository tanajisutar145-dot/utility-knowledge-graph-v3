"""
Context builder for GraphRAG pipeline
Transforms Phase 5B retrieval evidence into clean LLM context
"""

import logging
from typing import Dict, Any, List
from app.retrieval.models import RetrievalResult
from .models import ContextConfig

logger = logging.getLogger(__name__)


class ContextBuilder:
    """Builds structured context from retrieval evidence for LLM consumption"""
    
    def __init__(self, config: ContextConfig = None):
        self.config = config or ContextConfig()
    
    def build_context(self, question: str, retrieval_result: RetrievalResult) -> str:
        """
        Build formatted context string from retrieval results
        
        Args:
            question: Original user question
            retrieval_result: Phase 5B retrieval results
            
        Returns:
            Formatted context string for LLM
        """
        logger.debug(f"Building context for question: {question}")
        
        context_parts = []
        
        # Add question
        context_parts.append("=== USER QUESTION ===")
        context_parts.append(question)
        context_parts.append("")
        
        # Add semantic evidence
        semantic_results = retrieval_result.semantic_results[:self.config.max_chunks]
        if semantic_results:
            context_parts.append("=== SEMANTIC EVIDENCE ===")
            context_parts.append(f"Retrieved {len(semantic_results)} relevant document chunks:")
            context_parts.append("")
            
            for i, result in enumerate(semantic_results, 1):
                context_parts.append(f"CHUNK {i}: {result.chunk_id}")
                context_parts.append(f"Document: {result.document_id} - {result.document_title}")
                context_parts.append(f"Similarity Score: {result.score:.4f}")
                if result.source:
                    context_parts.append(f"Source: {result.source}")
                
                # Truncate text if needed
                text = result.text
                if self.config.truncate_long_text and len(text) > self.config.max_chunk_length:
                    text = text[:self.config.max_chunk_length] + "... [truncated]"
                
                context_parts.append(f"Content: {text}")
                context_parts.append("")
        
        # Add graph evidence
        graph_evidence = retrieval_result.graph_evidence
        if graph_evidence.entities or graph_evidence.relationships:
            context_parts.append("=== GRAPH EVIDENCE ===")
            
            # Add entities
            entities = graph_evidence.entities[:self.config.max_entities]
            if entities:
                context_parts.append(f"Related Entities ({len(entities)}):")
                for entity in entities:
                    entity_desc = f"- {entity.entity_type}: {entity.entity_id}"
                    
                    # Add key properties
                    key_props = self._extract_key_properties(entity.properties)
                    if key_props:
                        entity_desc += f" ({', '.join(key_props)})"
                    
                    context_parts.append(entity_desc)
                context_parts.append("")
            
            # Add relationships
            relationships = graph_evidence.relationships[:self.config.max_relationships]
            if relationships:
                context_parts.append(f"Entity Relationships ({len(relationships)}):")
                for rel in relationships:
                    rel_desc = f"- {rel.source_id} --[{rel.relationship_type}]--> {rel.target_id}"
                    context_parts.append(rel_desc)
                context_parts.append("")
        
        # Add retrieval metadata if requested
        if self.config.include_metadata:
            context_parts.append("=== RETRIEVAL METADATA ===")
            metadata = retrieval_result.metadata
            context_parts.append(f"Retrieval Method: {metadata.get('retrieval_method', 'unknown')}")
            context_parts.append(f"Top-K Setting: {metadata.get('top_k', 'unknown')}")
            context_parts.append(f"Graph Depth: {metadata.get('graph_depth', 'unknown')}")
            context_parts.append(f"Total Semantic Results: {metadata.get('semantic_results_count', 0)}")
            context_parts.append(f"Total Graph Entities: {metadata.get('graph_entities_count', 0)}")
            context_parts.append(f"Total Graph Relationships: {metadata.get('graph_relationships_count', 0)}")
            context_parts.append("")
        
        context_str = "\n".join(context_parts)
        logger.debug(f"Built context with {len(context_str)} characters")
        
        return context_str
    
    def _extract_key_properties(self, properties: Dict[str, Any]) -> List[str]:
        """Extract key properties for display"""
        key_fields = ['name', 'title', 'description', 'status', 'condition', 'severity', 'type', 'category']
        key_props = []
        
        for field in key_fields:
            if field in properties and properties[field] is not None:
                value = properties[field]
                # Convert to string and limit length
                value_str = str(value)
                if len(value_str) > 50:
                    value_str = value_str[:47] + "..."
                key_props.append(f"{field}={value_str}")
        
        return key_props
    
    def get_context_stats(self, context: str) -> Dict[str, Any]:
        """Get statistics about the built context"""
        return {
            "context_length": len(context),
            "context_lines": len(context.split('\n')),
            "has_semantic_evidence": "SEMANTIC EVIDENCE" in context,
            "has_graph_evidence": "GRAPH EVIDENCE" in context,
            "has_metadata": "RETRIEVAL METADATA" in context
        }