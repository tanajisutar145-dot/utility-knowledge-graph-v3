"""
Models for GraphRAG intelligence operations
"""

from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from enum import Enum


class ConfidenceLevel(str, Enum):
    """Confidence levels for GraphRAG answers"""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    VERY_LOW = "very_low"


class EvidenceReference(BaseModel):
    """Reference to supporting evidence"""
    evidence_id: str = Field(..., description="Evidence identifier (document_id, chunk_id, entity_id)")
    evidence_type: str = Field(..., description="Type of evidence (document, chunk, entity, relationship)")
    reason: str = Field(..., description="Why this evidence supports the claim")
    relevance_score: Optional[float] = Field(None, description="Relevance score if available")


class VerificationResult(BaseModel):
    """Result from answer verification process"""
    verified: bool = Field(..., description="Whether answer is verified against evidence")
    grounding_score: float = Field(..., description="Overall grounding score (0.0 to 1.0)")
    supported_claims: List[str] = Field(default_factory=list, description="Claims supported by evidence")
    unsupported_claims: List[str] = Field(default_factory=list, description="Claims not supported by evidence")
    warnings: List[str] = Field(default_factory=list, description="Verification warnings")
    evidence_gaps: List[str] = Field(default_factory=list, description="Areas where evidence is insufficient")


class GraphRAGAnswer(BaseModel):
    """Complete GraphRAG answer with verification"""
    question: str = Field(..., description="Original user question")
    answer: str = Field(..., description="Generated answer based on evidence")
    confidence: ConfidenceLevel = Field(..., description="Confidence level in the answer")
    supporting_evidence: List[EvidenceReference] = Field(default_factory=list, description="Evidence supporting the answer")
    supporting_documents: List[str] = Field(default_factory=list, description="Document IDs referenced")
    supporting_entities: List[str] = Field(default_factory=list, description="Entity IDs referenced")
    limitations: List[str] = Field(default_factory=list, description="Answer limitations and caveats")
    verification: VerificationResult = Field(..., description="Verification results")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Generation metadata")


class GraphRAGRequest(BaseModel):
    """Request for GraphRAG question answering"""
    question: str = Field(..., description="Natural language question", min_length=1)
    top_k: int = Field(5, description="Number of chunks to retrieve", ge=1, le=20)
    graph_depth: int = Field(1, description="Graph expansion depth", ge=0, le=3)
    min_similarity: float = Field(0.0, description="Minimum similarity threshold", ge=0.0, le=1.0)
    include_verification: bool = Field(True, description="Whether to include verification step")


class GraphRAGResponse(BaseModel):
    """Complete GraphRAG API response"""
    question: str = Field(..., description="Original question")
    answer: str = Field(..., description="Generated answer")
    confidence: ConfidenceLevel = Field(..., description="Answer confidence level")
    verification: VerificationResult = Field(..., description="Answer verification")
    evidence: Dict[str, Any] = Field(..., description="Retrieved evidence package")
    sources: Dict[str, List[str]] = Field(..., description="Source references")
    metadata: Dict[str, Any] = Field(..., description="Response metadata")


class ContextConfig(BaseModel):
    """Configuration for context building"""
    max_chunks: int = Field(10, description="Maximum chunks to include")
    max_chunk_length: int = Field(1000, description="Maximum length per chunk")
    max_entities: int = Field(20, description="Maximum entities to include")
    max_relationships: int = Field(30, description="Maximum relationships to include")
    include_metadata: bool = Field(True, description="Include retrieval metadata")
    truncate_long_text: bool = Field(True, description="Truncate overly long text")