"""
GraphRAG service for grounded question answering
"""

import logging
from typing import Optional, Dict, Any, List
import time

from app.retrieval import semantic_retriever, RetrievalRequest
from app.llm.groq_client import groq_client
from app.verification import answer_verifier
from .models import (
    GraphRAGRequest, GraphRAGAnswer, GraphRAGResponse, 
    ConfidenceLevel, EvidenceReference, VerificationResult, ContextConfig
)
from .context_builder import ContextBuilder
from .prompts import GRAPHRAG_SYSTEM_PROMPT, get_graphrag_user_prompt

logger = logging.getLogger(__name__)


class GraphRAGService:
    """Service for grounded GraphRAG question answering"""
    
    def __init__(self, context_config: ContextConfig = None):
        self.context_builder = ContextBuilder(context_config or ContextConfig())
        
        # Groq generation settings for enterprise QA
        self.groq_temperature = 0.1  # Low temperature for factual accuracy
        self.groq_max_tokens = 2048
        self.max_regeneration_attempts = 1
    
    def ask_question(self, request: GraphRAGRequest) -> GraphRAGResponse:
        """
        Complete GraphRAG pipeline for question answering
        
        Args:
            request: GraphRAG request with question and parameters
            
        Returns:
            Complete GraphRAG response with answer and verification
        """
        start_time = time.time()
        
        # Validate question
        if not request.question.strip():
            raise ValueError("Question cannot be empty")
        
        logger.info(f"Processing GraphRAG question: '{request.question}'")
        
        try:
            # Step 1: Phase 5B Retrieval
            retrieval_request = RetrievalRequest(
                query=request.question,
                top_k=request.top_k,
                graph_depth=request.graph_depth,
                min_similarity=request.min_similarity
            )
            
            retrieval_result = semantic_retriever.retrieve(retrieval_request)
            logger.info(f"Retrieved {len(retrieval_result.semantic_results)} semantic results, "
                       f"{len(retrieval_result.graph_evidence.entities)} entities")
            
            # Step 2: Build Context
            context = self.context_builder.build_context(request.question, retrieval_result)
            context_stats = self.context_builder.get_context_stats(context)
            logger.debug(f"Built context: {context_stats}")
            
            # Step 3: Generate Answer
            answer_text = self._generate_answer(request.question, context)
            if not answer_text:
                raise RuntimeError("Failed to generate answer from Groq")
            
            # Step 4: Verification (if requested)
            verification_result = None
            if request.include_verification:
                verification_result = self._verify_answer(
                    answer_text, retrieval_result, request.question
                )
            else:
                # Default verification for unverified answers
                verification_result = VerificationResult(
                    verified=False,
                    grounding_score=0.5,
                    warnings=["Answer was not verified against evidence"]
                )
            
            # Step 5: Determine confidence
            confidence = self._determine_confidence(verification_result, retrieval_result)
            
            # Step 6: Extract evidence references
            evidence_refs = self._extract_evidence_references(answer_text, retrieval_result)
            
            # Step 7: Build response
            execution_time = time.time() - start_time
            
            response = GraphRAGResponse(
                question=request.question,
                answer=answer_text,
                confidence=confidence,
                verification=verification_result,
                evidence={
                    "semantic_results": [result.dict() for result in retrieval_result.semantic_results],
                    "graph_evidence": retrieval_result.graph_evidence.dict()
                },
                sources={
                    "documents": list(set(r.document_id for r in retrieval_result.semantic_results)),
                    "entities": [e.entity_id for e in retrieval_result.graph_evidence.entities]
                },
                metadata={
                    "execution_time": execution_time,
                    "retrieval_method": retrieval_result.metadata.get("retrieval_method"),
                    "context_stats": context_stats,
                    "groq_model": "llama-3.3-70b-versatile",
                    "verification_enabled": request.include_verification
                }
            )
            
            logger.info(f"GraphRAG completed in {execution_time:.3f}s, confidence: {confidence}")
            return response
            
        except Exception as e:
            logger.error(f"GraphRAG pipeline failed: {e}")
            raise
    
    def _generate_answer(self, question: str, context: str) -> Optional[str]:
        """Generate answer using Groq LLM"""
        if not groq_client.is_configured():
            raise RuntimeError("Groq client is not configured")
        
        user_prompt = get_graphrag_user_prompt(question, context)
        
        logger.debug(f"Sending request to Groq (context length: {len(context)})")
        
        try:
            answer = groq_client.chat_completion(
                system_prompt=GRAPHRAG_SYSTEM_PROMPT,
                user_prompt=user_prompt,
                temperature=self.groq_temperature,
                max_tokens=self.groq_max_tokens
            )
            
            if answer:
                logger.debug(f"Received answer from Groq ({len(answer)} characters)")
                return answer.strip()
            else:
                logger.error("Groq returned empty response")
                return None
                
        except Exception as e:
            logger.error(f"Groq generation failed: {e}")
            raise RuntimeError(f"LLM generation failed: {e}")
    
    def _verify_answer(self, answer: str, retrieval_result, question: str) -> VerificationResult:
        """
        Verify answer against retrieved evidence using the answer verifier
        """
        logger.debug("Verifying answer against evidence")
        return answer_verifier.verify_answer(answer, retrieval_result, question)
    
    def _determine_confidence(self, verification_result: VerificationResult, retrieval_result) -> ConfidenceLevel:
        """Determine confidence level based on verification and evidence quality"""
        grounding_score = verification_result.grounding_score
        num_semantic_results = len(retrieval_result.semantic_results)
        num_entities = len(retrieval_result.graph_evidence.entities)
        
        # Calculate evidence strength
        evidence_strength = min(1.0, (num_semantic_results + num_entities) / 10)
        
        # Combined confidence score
        combined_score = (grounding_score + evidence_strength) / 2
        
        if combined_score >= 0.8 and verification_result.verified:
            return ConfidenceLevel.HIGH
        elif combined_score >= 0.6:
            return ConfidenceLevel.MEDIUM
        elif combined_score >= 0.4:
            return ConfidenceLevel.LOW
        else:
            return ConfidenceLevel.VERY_LOW
    
    def _extract_evidence_references(self, answer: str, retrieval_result) -> List[EvidenceReference]:
        """Extract evidence references from the generated answer"""
        references = []
        
        # Look for document references
        for result in retrieval_result.semantic_results:
            if result.document_id in answer or result.chunk_id in answer:
                references.append(EvidenceReference(
                    evidence_id=result.chunk_id,
                    evidence_type="chunk",
                    reason="Referenced in answer",
                    relevance_score=result.score
                ))
        
        # Look for entity references
        for entity in retrieval_result.graph_evidence.entities:
            if entity.entity_id in answer:
                references.append(EvidenceReference(
                    evidence_id=entity.entity_id,
                    evidence_type="entity",
                    reason="Referenced in answer"
                ))
        
        return references


# Global GraphRAG service instance
graphrag_service = GraphRAGService()