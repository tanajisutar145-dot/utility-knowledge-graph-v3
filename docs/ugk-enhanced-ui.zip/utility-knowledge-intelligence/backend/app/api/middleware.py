"""
API middleware setup
"""

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import time
import logging

logger = logging.getLogger(__name__)

def setup_middleware(app: FastAPI, config: dict):
    """Setup application middleware"""
    
    @app.middleware("http")
    async def add_process_time_header(request: Request, call_next):
        """Add processing time header"""
        start_time = time.time()
        response = await call_next(request)
        process_time = time.time() - start_time
        response.headers["X-Process-Time"] = str(process_time)
        return response
    
    @app.middleware("http")
    async def log_requests(request: Request, call_next):
        """Log all requests"""
        logger.info(f"{request.method} {request.url}")
        response = await call_next(request)
        logger.info(f"Response status: {response.status_code}")
        return response
    
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        """Global exception handler"""
        logger.error(f"Global exception: {exc}")
        return JSONResponse(
            status_code=500,
            content={"detail": "Internal server error"}
        )