"""
Intelligence API endpoints - GraphRAG question answering
"""

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field
from typing import List, Optional

from app.intelligence import graphrag_service, GraphRAGRequest, GraphRAGResponse
from app.services.intelligence_service import IntelligenceService

router = APIRouter()
intelligence_service = IntelligenceService()

# Legacy models for backward compatibility
class IntelligenceQuery(BaseModel):
    query: str
    context: Optional[List[str]] = None
    model: Optional[str] = None

class IntelligenceResponse(BaseModel):
    response: str
    confidence: float
    sources: List[str]
    reasoning: str

class FactCheckQuery(BaseModel):
    statement: str
    context: Optional[List[str]] = None

class FactCheckResponse(BaseModel):
    statement: str
    verdict: str  # "true", "false", "uncertain"
    confidence: float
    evidence: List[str]
    explanation: str

# New GraphRAG endpoint
@router.post("/ask", response_model=GraphRAGResponse)
async def graphrag_ask(request: GraphRAGRequest):
    """
    GraphRAG question answering with grounded evidence
    
    Processes natural language questions using semantic retrieval,
    graph expansion, and LLM generation with verification.
    """
    try:
        if not request.question.strip():
            raise HTTPException(status_code=400, detail="Question cannot be empty")
        
        response = graphrag_service.ask_question(request)
        return response
        
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        if "Groq" in str(e):
            raise HTTPException(status_code=503, detail="LLM service unavailable")
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

# Simplified ask endpoint for quick queries
class SimpleAskRequest(BaseModel):
    question: str = Field(..., description="Natural language question")
    top_k: int = Field(5, ge=1, le=20, description="Number of chunks to retrieve") 
    graph_depth: int = Field(1, ge=0, le=3, description="Graph expansion depth")

@router.post("/ask/simple")
async def simple_ask(request: SimpleAskRequest):
    """
    Simplified GraphRAG endpoint for quick questions
    
    Returns just the answer and confidence level.
    """
    try:
        if not request.question.strip():
            raise HTTPException(status_code=400, detail="Question cannot be empty")
        
        graphrag_request = GraphRAGRequest(
            question=request.question,
            top_k=request.top_k,
            graph_depth=request.graph_depth
        )
        
        response = graphrag_service.ask_question(graphrag_request)
        
        return {
            "question": response.question,
            "answer": response.answer,
            "confidence": response.confidence,
            "verified": response.verification.verified,
            "execution_time": response.metadata.get("execution_time")
        }
        
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        if "Groq" in str(e):
            raise HTTPException(status_code=503, detail="LLM service unavailable")
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

# Legacy endpoints for backward compatibility
@router.post("/query", response_model=IntelligenceResponse)
async def intelligent_query(query: IntelligenceQuery):
    """Process intelligent query (legacy endpoint)"""
    try:
        response = await intelligence_service.process_query(
            query.query,
            query.context,
            query.model
        )
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/fact-check", response_model=FactCheckResponse)
async def fact_check(query: FactCheckQuery):
    """Fact-check a statement (legacy endpoint)"""
    try:
        result = await intelligence_service.fact_check(
            query.statement,
            query.context
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/summarize")
async def summarize_content(content: str, max_length: int = 200):
    """Summarize content (legacy endpoint)"""
    try:
        summary = await intelligence_service.summarize(content, max_length)
        return {"summary": summary}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))