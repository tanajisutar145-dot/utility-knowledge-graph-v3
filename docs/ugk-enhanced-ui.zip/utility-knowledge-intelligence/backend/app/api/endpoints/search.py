"""
Search API endpoints
"""

from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from pydantic import BaseModel

from app.services.search_service import SearchService
from app.retrieval import semantic_retriever, RetrievalRequest

router = APIRouter()
search_service = SearchService()

class SearchQuery(BaseModel):
    query: str
    filters: Optional[dict] = None
    limit: int = 50

class SearchResult(BaseModel):
    id: str
    title: str
    content: str
    type: str
    score: float
    metadata: dict

class SearchResponse(BaseModel):
    results: List[SearchResult]
    total: int
    query_time: float

@router.post("/semantic", response_model=SearchResponse)
async def semantic_search(search_query: SearchQuery):
    """Perform semantic search with graph expansion"""
    try:
        # Use the new semantic retrieval system
        retrieval_request = RetrievalRequest(
            query=search_query.query,
            top_k=min(search_query.limit, 20),  # Limit to reasonable size
            graph_depth=1,  # Default graph expansion
            min_similarity=0.0
        )
        
        result = semantic_retriever.retrieve(retrieval_request)
        
        # Convert to legacy API format for compatibility
        search_results = []
        for semantic_result in result.semantic_results:
            search_result = SearchResult(
                id=semantic_result.chunk_id,
                title=semantic_result.document_title,
                content=semantic_result.text,
                type="chunk",
                score=semantic_result.score,
                metadata={
                    "document_id": semantic_result.document_id,
                    "source": semantic_result.source,
                    **semantic_result.metadata
                }
            )
            search_results.append(search_result)
        
        return SearchResponse(
            results=search_results,
            total=len(search_results),
            query_time=result.metadata.get("execution_time", 0.0)
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/retrieve")
async def semantic_retrieve(request: RetrievalRequest):
    """Perform semantic retrieval with graph expansion (full result)"""
    try:
        result = semantic_retriever.retrieve(request)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/keyword", response_model=SearchResponse)
async def keyword_search(search_query: SearchQuery):
    """Perform keyword search"""
    try:
        results = await search_service.keyword_search(
            search_query.query,
            search_query.filters,
            search_query.limit
        )
        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/similar/{item_id}", response_model=List[SearchResult])
async def find_similar(item_id: str, limit: int = Query(10, le=50)):
    """Find similar items"""
    try:
        similar = await search_service.find_similar(item_id, limit)
        return similar
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))