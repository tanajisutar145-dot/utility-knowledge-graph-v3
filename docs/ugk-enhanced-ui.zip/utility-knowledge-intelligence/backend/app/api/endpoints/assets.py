"""
Asset management API endpoints
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Optional

from app.services.asset_service import asset_service
from app.models.assets import (
    AssetOverviewResponse,
    AssetListResponse,
    AssetDetailResponse,
)

router = APIRouter()


@router.get("/overview", response_model=AssetOverviewResponse)
async def get_assets_overview():
    """Get overview statistics for assets"""
    try:
        return asset_service.get_overview()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/", response_model=AssetListResponse)
async def list_assets(
    search: Optional[str] = Query(None, description="Search query matching asset name, ID, model, or manufacturer"),
    asset_class: Optional[str] = Query(None, description="Filter by asset class/type"),
    criticality: Optional[str] = Query(None, description="Filter by criticality level"),
    operational_status: Optional[str] = Query(None, description="Filter by operational status"),
    unit_id: Optional[str] = Query(None, description="Filter by generating unit ID"),
    skip: int = Query(0, ge=0, description="Offset for pagination"),
    limit: int = Query(50, ge=1, le=100, description="Max assets to return"),
):
    """List assets with filtering, search, and related counts"""
    try:
        return asset_service.list_assets(
            search=search,
            asset_class=asset_class,
            criticality=criticality,
            operational_status=operational_status,
            unit_id=unit_id,
            skip=skip,
            limit=limit,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{asset_id}", response_model=AssetDetailResponse)
async def get_asset(asset_id: str):
    """Get comprehensive asset details with full relational context"""
    try:
        asset = asset_service.get_asset_detail(asset_id)
        if not asset:
            raise HTTPException(status_code=404, detail=f"Asset '{asset_id}' not found")
        return asset
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
