"""
Verification API endpoints
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from enum import Enum

from app.services.verification_service import VerificationService

router = APIRouter()
verification_service = VerificationService()

class VerificationStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"

class VerificationItem(BaseModel):
    id: str
    content: str
    type: str
    status: VerificationStatus
    confidence: float
    created_at: str
    reviewed_at: Optional[str] = None
    reviewer: Optional[str] = None

class VerificationDecision(BaseModel):
    decision: VerificationStatus
    comment: Optional[str] = None

@router.get("/pending", response_model=List[VerificationItem])
async def get_pending_verifications():
    """Get pending verification items"""
    try:
        items = await verification_service.get_pending_items()
        return items
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/review/{item_id}")
async def review_item(item_id: str, decision: VerificationDecision):
    """Review a verification item"""
    try:
        result = await verification_service.review_item(
            item_id,
            decision.decision,
            decision.comment
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/stats")
async def get_verification_stats():
    """Get verification statistics"""
    try:
        stats = await verification_service.get_stats()
        return stats
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))