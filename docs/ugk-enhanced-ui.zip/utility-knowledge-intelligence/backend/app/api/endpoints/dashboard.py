"""
Dashboard API endpoints - Executive intelligence summary
"""

from fastapi import APIRouter, HTTPException
from app.models.dashboard import DashboardSummaryResponse
from app.services.dashboard_service import dashboard_service

router = APIRouter()


@router.get("/summary", response_model=DashboardSummaryResponse)
async def get_dashboard_summary():
    """
    Get live executive dashboard summary.
    Retrieves real fleet KPIs, graph statistics, document counts,
    operational status, heat-rate performance trend, and maintenance indicators.
    Purely read-only query against Neo4j.
    """
    return dashboard_service.get_dashboard_summary()
