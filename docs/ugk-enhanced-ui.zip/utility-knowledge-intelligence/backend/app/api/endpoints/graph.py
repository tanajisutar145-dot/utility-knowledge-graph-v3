"""
Knowledge graph API endpoints - Interactive Graph Explorer
"""

from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional

from app.services.graph_service import graph_service
from app.models.graph import (
    GraphOverviewResponse,
    GraphExploreResponse,
    GraphNodeDetailResponse,
    GraphNeighborsResponse,
    GraphNode,
    GraphRelationship,
)

router = APIRouter()


@router.get("/overview", response_model=GraphOverviewResponse)
async def get_graph_overview():
    """
    Get Knowledge Graph overview statistics.
    Returns total nodes, total relationships, counts grouped by label and type,
    and schema whitelists.
    """
    try:
        return graph_service.get_overview()
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/explore", response_model=GraphExploreResponse)
async def explore_graph(
    node_label: Optional[str] = Query(None, description="Filter by node label"),
    rel_type: Optional[str] = Query(None, description="Filter by relationship type"),
    query: Optional[str] = Query(None, description="Search term matching node properties"),
    limit: int = Query(100, ge=1, le=250, description="Maximum nodes to return (1-250)"),
):
    """
    Explore knowledge graph nodes and internal relationships with filters.
    Strictly bounded, read-only Cypher query.
    """
    try:
        return graph_service.explore_graph(
            node_label=node_label,
            rel_type=rel_type,
            query=query,
            limit=limit,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/node/{node_id}", response_model=GraphNodeDetailResponse)
async def get_node_detail(node_id: str):
    """
    Get full properties, relationship counts, and neighbor summary for a specific node.
    Accepts elementId or domain entity ID.
    """
    try:
        return graph_service.get_node_detail(node_id)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/node/{node_id}/neighbors", response_model=GraphNeighborsResponse)
async def get_node_neighbors(
    node_id: str,
    limit: int = Query(50, ge=1, le=100, description="Max neighbor nodes to expand (1-100)"),
    rel_type: Optional[str] = Query(None, description="Filter edges by relationship type"),
    direction: str = Query("both", regex="^(in|out|both)$", description="Relationship direction"),
):
    """
    Expand immediate neighbors around a specific node.
    Bounded traversal returning real connected entities and relationships.
    """
    try:
        return graph_service.get_node_neighbors(
            node_id=node_id,
            limit=limit,
            rel_type=rel_type,
            direction=direction,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Backward-compatible legacy endpoints
@router.get("/nodes")
async def get_nodes(
    node_type: Optional[str] = None,
    limit: int = Query(100, le=1000)
):
    """Get graph nodes (legacy endpoint)"""
    try:
        return await graph_service.get_nodes(node_type, limit)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/relationships")
async def get_relationships(
    relationship_type: Optional[str] = None,
    limit: int = Query(100, le=1000)
):
    """Get graph relationships (legacy endpoint)"""
    try:
        return await graph_service.get_relationships(relationship_type, limit)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/subgraph")
async def get_subgraph(
    node_id: str,
    depth: int = Query(2, ge=1, le=5)
):
    """Get subgraph around a node (legacy endpoint)"""
    try:
        return await graph_service.get_subgraph(node_id, depth)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/path")
async def find_path(start_node: str, end_node: str, max_depth: int = 5):
    """Find path between two nodes (legacy endpoint)"""
    try:
        return await graph_service.find_path(start_node, end_node, max_depth)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))