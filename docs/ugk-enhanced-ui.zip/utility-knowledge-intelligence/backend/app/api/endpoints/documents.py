"""
Document management API endpoints
"""

from fastapi import APIRouter, UploadFile, File, HTTPException, Query
from typing import Optional

from app.services.document_service import document_service
from app.models.documents import (
    DocumentOverviewResponse,
    DocumentListResponse,
    DocumentDetailResponse,
    DocumentUploadResult,
)

router = APIRouter()


@router.get("/overview", response_model=DocumentOverviewResponse)
async def get_documents_overview():
    """Get overview statistics for documents and chunks"""
    try:
        return document_service.get_overview()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/", response_model=DocumentListResponse)
async def list_documents(
    search: Optional[str] = Query(None, description="Search query matching title, ID, or source"),
    document_type: Optional[str] = Query(None, description="Filter by document type"),
    skip: int = Query(0, ge=0, description="Offset for pagination"),
    limit: int = Query(50, ge=1, le=100, description="Max documents to return"),
):
    """List documents with optional filtering and search"""
    try:
        return document_service.list_documents(
            search=search,
            document_type=document_type,
            skip=skip,
            limit=limit,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{document_id}", response_model=DocumentDetailResponse)
async def get_document(document_id: str):
    """Get detailed document information including text, chunks, and linked entities"""
    try:
        doc = document_service.get_document_detail(document_id)
        if not doc:
            raise HTTPException(status_code=404, detail=f"Document '{document_id}' not found")
        return doc
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/upload", response_model=DocumentUploadResult)
async def upload_document(file: UploadFile = File(...)):
    """Upload and ingest a new document (.pdf, .xlsx, .csv, .docx, .txt, .json) into Neo4j and vector index"""
    try:
        return await document_service.upload_document(file)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{document_id}")
async def delete_document(document_id: str):
    """Delete document and associated chunks by ID"""
    try:
        success = document_service.delete_document(document_id)
        if not success:
            raise HTTPException(status_code=404, detail=f"Document '{document_id}' not found")
        return {"message": f"Document '{document_id}' deleted successfully", "document_id": document_id}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))