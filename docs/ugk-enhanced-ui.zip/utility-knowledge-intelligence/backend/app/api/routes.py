"""
Main API router that includes all endpoint routers
"""

from fastapi import APIRouter

from app.api.endpoints import documents, graph, search, intelligence, verification, dashboard, assets
from app.llm.groq_client import groq_client
from app.graph.neo4j_client import neo4j_client
from app.core.config import settings

api_router = APIRouter()

# Include all endpoint routers
api_router.include_router(dashboard.router, prefix="/dashboard", tags=["dashboard"])
api_router.include_router(documents.router, prefix="/documents", tags=["documents"])
api_router.include_router(assets.router, prefix="/assets", tags=["assets"])
api_router.include_router(graph.router, prefix="/graph", tags=["graph"])
api_router.include_router(search.router, prefix="/search", tags=["search"])
api_router.include_router(intelligence.router, prefix="/intelligence", tags=["intelligence"])
api_router.include_router(verification.router, prefix="/verification", tags=["verification"])

# Add health check under /api as well to avoid frontend route conflicts
@api_router.get("/health")
async def api_health_check():
    """Health check endpoint under /api prefix"""
    
    # Check Groq configuration
    groq_status = "configured" if groq_client.is_configured() else "not_configured"
    
    # Check Neo4j connectivity
    neo4j_connected = neo4j_client.verify_connectivity()
    neo4j_status = "connected" if neo4j_connected else "disconnected"
    
    # Determine overall status
    overall_status = "healthy"
    if neo4j_status == "disconnected":
        overall_status = "degraded"
    
    return {
        "status": overall_status,
        "application": settings.app_name,
        "environment": settings.app_env,
        "services": {
            "backend": "healthy",
            "groq": groq_status,
            "neo4j": neo4j_status
        }
    }