"""
Core application configuration module
"""