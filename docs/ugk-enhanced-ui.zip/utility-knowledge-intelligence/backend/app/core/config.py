"""
Application configuration using pydantic-settings
"""

from pydantic_settings import BaseSettings
from pathlib import Path
from typing import Optional


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""
    
    # Application
    app_name: str = "Utility Knowledge Intelligence"
    app_env: str = "development"
    debug: bool = True
    
    # Groq LLM
    groq_api_key: Optional[str] = None
    groq_model: str = "qwen/qwen3.8-27b"
    
    # Neo4j Database
    neo4j_uri: str = "bolt://localhost:7687"
    neo4j_username: str = "neo4j" 
    neo4j_password: Optional[str] = None
    
    # API
    api_host: str = "127.0.0.1"
    api_port: int = 8000
    frontend_url: str = "http://localhost:3000"
    
    # Directories and Uploads
    upload_dir: str = "./data/uploads"
    output_dir: str = "./outputs"
    max_upload_size_bytes: int = 5 * 1024 * 1024  # 5 MB configurable limit
    
    # Embeddings
    embedding_provider: str = "sentence_transformers"
    embedding_model: str = "BAAI/bge-small-en-v1.5"
    embedding_dimension: int = 384
    embedding_device: str = "cpu"
    embedding_batch_size: int = 32

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


# Global settings instance
settings = Settings()