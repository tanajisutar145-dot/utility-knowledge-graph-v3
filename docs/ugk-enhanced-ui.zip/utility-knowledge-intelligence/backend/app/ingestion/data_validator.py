"""
Data validation for synthetic utility data
"""

import csv
from pathlib import Path
from typing import Dict, List, Set, Any, Optional
from datetime import datetime, date
from collections import defaultdict

from app.models.utility_models import *


class DataValidator:
    """Validate utility data integrity and consistency"""
    
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.errors = []
        self.warnings = []
        self.entity_counts = {}
        
        # Store loaded data for cross-reference validation
        self.utilities = {}
        self.power_plants = {}
        self.generating_units = {}
        self.assets = {}
        self.components = {}
        self.inspections = {}
        self.failure_events = {}
        self.work_orders = {}
        self.maintenance_plans = {}
        self.outage_events = {}
        self.heat_rate_tests = {}
    
    def validate_all_data(self) -> bool:
        """Validate all utility data files"""
        print("Validating utility data...")
        
        # Load and validate each data file
        self._load_and_validate_file("utilities.csv", self.utilities, self._validate_utility)
        self._load_and_validate_file("power_plants.csv", self.power_plants, self._validate_power_plant)
        self._load_and_validate_file("generating_units.csv", self.generating_units, self._validate_generating_unit)
        self._load_and_validate_file("assets.csv", self.assets, self._validate_asset)
        self._load_and_validate_file("components.csv", self.components, self._validate_component)
        self._load_and_validate_file("inspections.csv", self.inspections, self._validate_inspection)
        self._load_and_validate_file("failure_events.csv", self.failure_events, self._validate_failure_event)
        self._load_and_validate_file("work_orders.csv", self.work_orders, self._validate_work_order)
        self._load_and_validate_file("maintenance_plans.csv", self.maintenance_plans, self._validate_maintenance_plan)
        self._load_and_validate_file("outage_events.csv", self.outage_events, self._validate_outage_event)
        self._load_and_validate_file("heat_rate_tests.csv", self.heat_rate_tests, self._validate_heat_rate_test)
        
        # Perform cross-reference validation
        self._validate_foreign_keys()
        self._validate_temporal_relationships()
        
        # Print results
        self._print_validation_results()
        
        return len(self.errors) == 0
    
    def _load_and_validate_file(self, filename: str, storage_dict: Dict, validator_func) -> None:
        """Load CSV file and validate individual records"""
        filepath = self.data_dir / filename
        
        if not filepath.exists():
            self.errors.append(f"File not found: {filename}")
            return
        
        count = 0
        ids_seen = set()
        
        try:
            with open(filepath, 'r', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                
                for row_num, row in enumerate(reader, start=2):  # Start at 2 (after header)
                    try:
                        # Check for duplicate IDs
                        id_field = self._get_id_field(filename)
                        record_id = row.get(id_field)
                        
                        if record_id in ids_seen:
                            self.errors.append(f"{filename}:{row_num} - Duplicate ID: {record_id}")
                        else:
                            ids_seen.add(record_id)
                        
                        # Store record for cross-reference validation
                        storage_dict[record_id] = row
                        
                        # Run entity-specific validation
                        validator_func(row, row_num, filename)
                        
                        count += 1
                        
                    except Exception as e:
                        self.errors.append(f"{filename}:{row_num} - Error processing record: {str(e)}")
        
        except Exception as e:
            self.errors.append(f"Error reading {filename}: {str(e)}")
        
        self.entity_counts[filename.replace('.csv', '')] = count
    
    def _get_id_field(self, filename: str) -> str:
        """Get the ID field name for each entity type"""
        id_mapping = {
            "utilities.csv": "utility_id",
            "power_plants.csv": "plant_id", 
            "generating_units.csv": "unit_id",
            "assets.csv": "asset_id",
            "components.csv": "component_id",
            "inspections.csv": "inspection_id",
            "failure_events.csv": "failure_id",
            "work_orders.csv": "work_order_id",
            "maintenance_plans.csv": "maintenance_plan_id",
            "outage_events.csv": "outage_id",
            "heat_rate_tests.csv": "test_id"
        }
        return id_mapping.get(filename, "id")
    
    def _validate_utility(self, row: Dict, row_num: int, filename: str) -> None:
        """Validate utility record"""
        required_fields = ["utility_id", "name", "region", "country"]
        self._check_required_fields(row, required_fields, row_num, filename)
    
    def _validate_power_plant(self, row: Dict, row_num: int, filename: str) -> None:
        """Validate power plant record"""
        required_fields = ["plant_id", "utility_id", "name", "location", "plant_type", "capacity_mw", "commissioning_date"]
        self._check_required_fields(row, required_fields, row_num, filename)
        
        # Validate capacity is numeric and positive
        try:
            capacity = float(row.get("capacity_mw", 0))
            if capacity <= 0:
                self.errors.append(f"{filename}:{row_num} - Invalid capacity_mw: {capacity}")
        except ValueError:
            self.errors.append(f"{filename}:{row_num} - capacity_mw must be numeric")
        
        # Validate date format
        self._validate_date_field(row, "commissioning_date", row_num, filename)
    
    def _validate_generating_unit(self, row: Dict, row_num: int, filename: str) -> None:
        """Validate generating unit record"""
        required_fields = ["unit_id", "plant_id", "unit_name", "unit_type", "capacity_mw", "commissioning_date"]
        self._check_required_fields(row, required_fields, row_num, filename)
        
        try:
            capacity = float(row.get("capacity_mw", 0))
            if capacity <= 0:
                self.errors.append(f"{filename}:{row_num} - Invalid capacity_mw: {capacity}")
        except ValueError:
            self.errors.append(f"{filename}:{row_num} - capacity_mw must be numeric")
        
        self._validate_date_field(row, "commissioning_date", row_num, filename)
    
    def _validate_asset(self, row: Dict, row_num: int, filename: str) -> None:
        """Validate asset record"""
        required_fields = ["asset_id", "unit_id", "asset_tag", "name", "asset_class"]
        self._check_required_fields(row, required_fields, row_num, filename)
        
        # Validate optional date field
        if row.get("installation_date"):
            self._validate_date_field(row, "installation_date", row_num, filename)
    
    def _validate_component(self, row: Dict, row_num: int, filename: str) -> None:
        """Validate component record"""
        required_fields = ["component_id", "asset_id", "component_name", "component_type"]
        self._check_required_fields(row, required_fields, row_num, filename)
        
        if row.get("installation_date"):
            self._validate_date_field(row, "installation_date", row_num, filename)
    
    def _validate_inspection(self, row: Dict, row_num: int, filename: str) -> None:
        """Validate inspection record"""
        required_fields = ["inspection_id", "asset_id", "inspection_date", "inspection_type", "inspector", "condition", "findings"]
        self._check_required_fields(row, required_fields, row_num, filename)
        
        self._validate_datetime_field(row, "inspection_date", row_num, filename)
    
    def _validate_failure_event(self, row: Dict, row_num: int, filename: str) -> None:
        """Validate failure event record"""
        required_fields = ["failure_id", "asset_id", "failure_date", "failure_mode", "severity", "description"]
        self._check_required_fields(row, required_fields, row_num, filename)
        
        self._validate_datetime_field(row, "failure_date", row_num, filename)
        
        # Validate numeric fields
        for field in ["downtime_hours", "estimated_cost", "actual_cost"]:
            if row.get(field):
                try:
                    value = float(row[field])
                    if value < 0:
                        self.errors.append(f"{filename}:{row_num} - {field} cannot be negative: {value}")
                except ValueError:
                    self.errors.append(f"{filename}:{row_num} - {field} must be numeric")
    
    def _validate_work_order(self, row: Dict, row_num: int, filename: str) -> None:
        """Validate work order record"""
        required_fields = ["work_order_id", "asset_id", "created_date", "work_type", "priority", "status", "description"]
        self._check_required_fields(row, required_fields, row_num, filename)
        
        self._validate_datetime_field(row, "created_date", row_num, filename)
        
        # Validate optional datetime fields
        for field in ["scheduled_date", "completion_date"]:
            if row.get(field):
                self._validate_datetime_field(row, field, row_num, filename)
        
        # Validate that completion_date is after created_date
        if row.get("completion_date") and row.get("created_date"):
            try:
                created = datetime.fromisoformat(row["created_date"].replace('Z', '+00:00'))
                completed = datetime.fromisoformat(row["completion_date"].replace('Z', '+00:00'))
                if completed < created:
                    self.errors.append(f"{filename}:{row_num} - completion_date cannot be before created_date")
            except ValueError:
                pass  # Date parsing errors already caught above
    
    def _validate_maintenance_plan(self, row: Dict, row_num: int, filename: str) -> None:
        """Validate maintenance plan record"""
        required_fields = ["maintenance_plan_id", "asset_id", "plan_name", "maintenance_type", "frequency"]
        self._check_required_fields(row, required_fields, row_num, filename)
        
        # Validate optional datetime fields
        for field in ["last_execution_date", "next_due_date"]:
            if row.get(field):
                self._validate_datetime_field(row, field, row_num, filename)
    
    def _validate_outage_event(self, row: Dict, row_num: int, filename: str) -> None:
        """Validate outage event record"""
        required_fields = ["outage_id", "unit_id", "outage_type", "start_date", "cause", "status"]
        self._check_required_fields(row, required_fields, row_num, filename)
        
        self._validate_datetime_field(row, "start_date", row_num, filename)
        
        if row.get("end_date"):
            self._validate_datetime_field(row, "end_date", row_num, filename)
            
            # Validate end_date is after start_date
            if row.get("start_date"):
                try:
                    start = datetime.fromisoformat(row["start_date"].replace('Z', '+00:00'))
                    end = datetime.fromisoformat(row["end_date"].replace('Z', '+00:00'))
                    if end < start:
                        self.errors.append(f"{filename}:{row_num} - end_date cannot be before start_date")
                except ValueError:
                    pass
    
    def _validate_heat_rate_test(self, row: Dict, row_num: int, filename: str) -> None:
        """Validate heat rate test record"""
        required_fields = ["test_id", "unit_id", "test_date", "measured_heat_rate", "baseline_heat_rate", "deviation_percentage"]
        self._check_required_fields(row, required_fields, row_num, filename)
        
        self._validate_datetime_field(row, "test_date", row_num, filename)
        
        # Validate numeric fields
        for field in ["measured_heat_rate", "baseline_heat_rate"]:
            try:
                value = float(row.get(field, 0))
                if value <= 0:
                    self.errors.append(f"{filename}:{row_num} - {field} must be positive: {value}")
            except ValueError:
                self.errors.append(f"{filename}:{row_num} - {field} must be numeric")
    
    def _check_required_fields(self, row: Dict, required_fields: List[str], row_num: int, filename: str) -> None:
        """Check that all required fields are present and not empty"""
        for field in required_fields:
            value = row.get(field, "").strip()
            if not value:
                self.errors.append(f"{filename}:{row_num} - Required field '{field}' is missing or empty")
    
    def _validate_date_field(self, row: Dict, field: str, row_num: int, filename: str) -> None:
        """Validate date field format"""
        value = row.get(field)
        if value:
            try:
                date.fromisoformat(value)
            except ValueError:
                self.errors.append(f"{filename}:{row_num} - Invalid date format for '{field}': {value}")
    
    def _validate_datetime_field(self, row: Dict, field: str, row_num: int, filename: str) -> None:
        """Validate datetime field format"""
        value = row.get(field)
        if value:
            try:
                # Handle both with and without timezone
                if 'T' in value:
                    datetime.fromisoformat(value.replace('Z', '+00:00'))
                else:
                    datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
            except ValueError:
                self.errors.append(f"{filename}:{row_num} - Invalid datetime format for '{field}': {value}")
    
    def _validate_foreign_keys(self) -> None:
        """Validate foreign key relationships"""
        print("Validating foreign key relationships...")
        
        # Power plants must reference valid utilities
        for plant_id, plant in self.power_plants.items():
            utility_id = plant.get("utility_id")
            if utility_id not in self.utilities:
                self.errors.append(f"power_plants.csv - Invalid utility_id: {utility_id} in plant {plant_id}")
        
        # Generating units must reference valid power plants
        for unit_id, unit in self.generating_units.items():
            plant_id = unit.get("plant_id")
            if plant_id not in self.power_plants:
                self.errors.append(f"generating_units.csv - Invalid plant_id: {plant_id} in unit {unit_id}")
        
        # Assets must reference valid generating units
        for asset_id, asset in self.assets.items():
            unit_id = asset.get("unit_id")
            if unit_id not in self.generating_units:
                self.errors.append(f"assets.csv - Invalid unit_id: {unit_id} in asset {asset_id}")
        
        # Components must reference valid assets
        for comp_id, comp in self.components.items():
            asset_id = comp.get("asset_id")
            if asset_id not in self.assets:
                self.errors.append(f"components.csv - Invalid asset_id: {asset_id} in component {comp_id}")
        
        # Inspections must reference valid assets
        for insp_id, insp in self.inspections.items():
            asset_id = insp.get("asset_id")
            if asset_id not in self.assets:
                self.errors.append(f"inspections.csv - Invalid asset_id: {asset_id} in inspection {insp_id}")
        
        # Failure events must reference valid assets
        for fail_id, fail in self.failure_events.items():
            asset_id = fail.get("asset_id")
            if asset_id not in self.assets:
                self.errors.append(f"failure_events.csv - Invalid asset_id: {asset_id} in failure {fail_id}")
        
        # Work orders must reference valid assets and optionally failures
        for wo_id, wo in self.work_orders.items():
            asset_id = wo.get("asset_id")
            if asset_id not in self.assets:
                self.errors.append(f"work_orders.csv - Invalid asset_id: {asset_id} in work order {wo_id}")
            
            failure_id = wo.get("failure_id")
            if failure_id and failure_id not in self.failure_events:
                self.errors.append(f"work_orders.csv - Invalid failure_id: {failure_id} in work order {wo_id}")
        
        # Maintenance plans must reference valid assets
        for mp_id, mp in self.maintenance_plans.items():
            asset_id = mp.get("asset_id")
            if asset_id not in self.assets:
                self.errors.append(f"maintenance_plans.csv - Invalid asset_id: {asset_id} in maintenance plan {mp_id}")
        
        # Outage events must reference valid units
        for out_id, out in self.outage_events.items():
            unit_id = out.get("unit_id")
            if unit_id not in self.generating_units:
                self.errors.append(f"outage_events.csv - Invalid unit_id: {unit_id} in outage {out_id}")
        
        # Heat rate tests must reference valid units
        for test_id, test in self.heat_rate_tests.items():
            unit_id = test.get("unit_id")
            if unit_id not in self.generating_units:
                self.errors.append(f"heat_rate_tests.csv - Invalid unit_id: {unit_id} in test {test_id}")
    
    def _validate_temporal_relationships(self) -> None:
        """Validate temporal relationships across entities"""
        print("Validating temporal relationships...")
        
        # Check that work orders addressing failures are created after the failure
        for wo_id, wo in self.work_orders.items():
            failure_id = wo.get("failure_id")
            if failure_id and failure_id in self.failure_events:
                failure = self.failure_events[failure_id]
                
                try:
                    failure_date = datetime.fromisoformat(failure["failure_date"].replace('Z', '+00:00'))
                    wo_created = datetime.fromisoformat(wo["created_date"].replace('Z', '+00:00'))
                    
                    if wo_created < failure_date:
                        self.errors.append(f"work_orders.csv - Work order {wo_id} created before associated failure {failure_id}")
                except (ValueError, KeyError):
                    # Date parsing errors already caught in individual validation
                    pass
    
    def _print_validation_results(self) -> None:
        """Print validation results summary"""
        print("\n" + "="*60)
        print("VALIDATION RESULTS")
        print("="*60)
        
        print("\nEntity Counts:")
        for entity, count in self.entity_counts.items():
            print(f"  {entity.replace('_', ' ').title()}: {count}")
        
        if self.warnings:
            print(f"\nWarnings ({len(self.warnings)}):")
            for warning in self.warnings:
                print(f"  ⚠️  {warning}")
        
        if self.errors:
            print(f"\nErrors ({len(self.errors)}):")
            for error in self.errors:
                print(f"  ❌ {error}")
            print(f"\nVALIDATION FAILED - {len(self.errors)} errors found")
        else:
            print(f"\n✅ VALIDATION PASSED - No errors found")
            if self.warnings:
                print(f"   ({len(self.warnings)} warnings)")


def main():
    """Main function to validate utility data"""
    data_dir = Path(__file__).parent.parent.parent / "data" / "synthetic"
    
    if not data_dir.exists():
        print(f"Data directory not found: {data_dir}")
        print("Please run data generation first.")
        return
    
    validator = DataValidator(data_dir)
    success = validator.validate_all_data()
    
    return success


if __name__ == "__main__":
    main()