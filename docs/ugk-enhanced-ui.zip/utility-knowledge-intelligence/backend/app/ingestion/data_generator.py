"""
Synthetic utility data generator
"""

import csv
import random
from datetime import datetime, date, timedelta
from pathlib import Path
from typing import List, Dict, Any
import uuid

from app.models.utility_models import *

# Set fixed seed for deterministic data generation
random.seed(42)

class UtilityDataGenerator:
    """Generate realistic synthetic utility data"""
    
    def __init__(self):
        self.utilities = []
        self.power_plants = []
        self.generating_units = []
        self.assets = []
        self.components = []
        self.inspections = []
        self.failure_events = []
        self.work_orders = []
        self.maintenance_plans = []
        self.outage_events = []
        self.heat_rate_tests = []
        
        # Asset manufacturers and models
        self.manufacturers = {
            AssetClass.GAS_TURBINE: ["General Electric", "Siemens", "Mitsubishi"],
            AssetClass.STEAM_TURBINE: ["General Electric", "Siemens", "Toshiba"],
            AssetClass.GENERATOR: ["General Electric", "ABB", "Siemens"],
            AssetClass.COMPRESSOR: ["Elliott", "Dresser-Rand", "Man Turbo"],
            AssetClass.BOILER: ["Babcock & Wilcox", "Foster Wheeler", "Alstom"],
            AssetClass.PUMP: ["Flowserve", "ITT Goulds", "Grundfos"],
            AssetClass.TRANSFORMER: ["ABB", "Siemens", "Schneider Electric"],
            AssetClass.COOLING_SYSTEM: ["SPX Cooling", "Hamon", "Johnson Controls"]
        }
        
        self.models = {
            "General Electric": ["7FA", "9E", "LM6000", "MS9001E"],
            "Siemens": ["SGT-800", "SGT-A65", "V94.2", "SST-900"],
            "Mitsubishi": ["M501F", "M701F", "MHI-501G", "M501J"]
        }
    
    def generate_utility_data(self) -> None:
        """Generate a single utility company"""
        utility = Utility(
            utility_id="UTL-001",
            name="Pacific Power Corporation",
            region="Western United States",
            country="United States",
            description="Major electric utility serving the Pacific Northwest region",
            status=UtilityStatus.ACTIVE
        )
        self.utilities.append(utility)
    
    def generate_power_plants(self) -> None:
        """Generate power plants for the utility"""
        plants = [
            {
                "plant_id": "PLT-001",
                "name": "Riverside Combined Cycle Plant",
                "location": "California",
                "plant_type": PlantType.COMBINED_CYCLE,
                "capacity_mw": 800.0,
                "commissioning_date": date(2010, 6, 15)
            },
            {
                "plant_id": "PLT-002", 
                "name": "Mountain View Natural Gas Plant",
                "location": "Nevada",
                "plant_type": PlantType.NATURAL_GAS,
                "capacity_mw": 450.0,
                "commissioning_date": date(2005, 3, 22)
            },
            {
                "plant_id": "PLT-003",
                "name": "Columbia River Hydro Station",
                "location": "Oregon",
                "plant_type": PlantType.HYDROELECTRIC,
                "capacity_mw": 320.0,
                "commissioning_date": date(1985, 9, 10)
            },
            {
                "plant_id": "PLT-004",
                "name": "Desert Wind Farm",
                "location": "Arizona",
                "plant_type": PlantType.WIND,
                "capacity_mw": 150.0,
                "commissioning_date": date(2018, 11, 5)
            }
        ]
        
        for plant_data in plants:
            plant = PowerPlant(
                utility_id="UTL-001",
                status=OperationalStatus.OPERATIONAL,
                **plant_data
            )
            self.power_plants.append(plant)
    
    def generate_generating_units(self) -> None:
        """Generate generating units for each plant"""
        unit_configs = [
            # Riverside Combined Cycle Plant
            ("PLT-001", [
                {"name": "Unit 1 GT", "type": UnitType.GAS_TURBINE, "capacity": 270.0, "date": date(2010, 6, 15)},
                {"name": "Unit 1 ST", "type": UnitType.STEAM_TURBINE, "capacity": 130.0, "date": date(2010, 8, 20)},
                {"name": "Unit 2 GT", "type": UnitType.GAS_TURBINE, "capacity": 270.0, "date": date(2010, 9, 10)},
                {"name": "Unit 2 ST", "type": UnitType.STEAM_TURBINE, "capacity": 130.0, "date": date(2010, 11, 15)}
            ]),
            # Mountain View Natural Gas Plant  
            ("PLT-002", [
                {"name": "Unit 1", "type": UnitType.GAS_TURBINE, "capacity": 150.0, "date": date(2005, 3, 22)},
                {"name": "Unit 2", "type": UnitType.GAS_TURBINE, "capacity": 150.0, "date": date(2005, 5, 18)},
                {"name": "Unit 3", "type": UnitType.GAS_TURBINE, "capacity": 150.0, "date": date(2005, 7, 25)}
            ]),
            # Columbia River Hydro Station
            ("PLT-003", [
                {"name": "Unit 1", "type": UnitType.HYDROELECTRIC, "capacity": 80.0, "date": date(1985, 9, 10)},
                {"name": "Unit 2", "type": UnitType.HYDROELECTRIC, "capacity": 80.0, "date": date(1985, 10, 15)},
                {"name": "Unit 3", "type": UnitType.HYDROELECTRIC, "capacity": 80.0, "date": date(1985, 11, 20)},
                {"name": "Unit 4", "type": UnitType.HYDROELECTRIC, "capacity": 80.0, "date": date(1985, 12, 18)}
            ]),
            # Desert Wind Farm
            ("PLT-004", [
                {"name": "Turbine Array A", "type": UnitType.WIND_TURBINE, "capacity": 75.0, "date": date(2018, 11, 5)},
                {"name": "Turbine Array B", "type": UnitType.WIND_TURBINE, "capacity": 75.0, "date": date(2018, 12, 1)}
            ])
        ]
        
        unit_counter = 1
        for plant_id, units in unit_configs:
            for unit_data in units:
                unit = GeneratingUnit(
                    unit_id=f"UNT-{unit_counter:03d}",
                    plant_id=plant_id,
                    unit_name=unit_data["name"],
                    unit_type=unit_data["type"],
                    capacity_mw=unit_data["capacity"],
                    commissioning_date=unit_data["date"],
                    status=OperationalStatus.OPERATIONAL
                )
                self.generating_units.append(unit)
                unit_counter += 1
    
    def generate_assets(self) -> None:
        """Generate assets for each generating unit"""
        asset_counter = 1
        
        for unit in self.generating_units:
            # Define asset classes based on unit type
            if unit.unit_type == UnitType.GAS_TURBINE:
                asset_classes = [AssetClass.GAS_TURBINE, AssetClass.GENERATOR, AssetClass.COMPRESSOR, 
                               AssetClass.COOLING_SYSTEM, AssetClass.CONTROL_SYSTEM]
            elif unit.unit_type == UnitType.STEAM_TURBINE:
                asset_classes = [AssetClass.STEAM_TURBINE, AssetClass.GENERATOR, AssetClass.BOILER,
                               AssetClass.PUMP, AssetClass.COOLING_SYSTEM]
            elif unit.unit_type == UnitType.HYDROELECTRIC:
                asset_classes = [AssetClass.GENERATOR, AssetClass.TRANSFORMER, AssetClass.PUMP,
                               AssetClass.CONTROL_SYSTEM]
            else:  # Wind turbine
                asset_classes = [AssetClass.GENERATOR, AssetClass.TRANSFORMER, AssetClass.CONTROL_SYSTEM]
            
            for asset_class in asset_classes:
                manufacturer = random.choice(self.manufacturers.get(asset_class, ["Generic Manufacturer"]))
                model = random.choice(self.models.get(manufacturer, ["Model-X"]))
                
                # Determine criticality based on asset type
                if asset_class in [AssetClass.GAS_TURBINE, AssetClass.STEAM_TURBINE, AssetClass.GENERATOR]:
                    criticality = CriticalityLevel.CRITICAL
                elif asset_class in [AssetClass.BOILER, AssetClass.TRANSFORMER]:
                    criticality = CriticalityLevel.HIGH
                else:
                    criticality = random.choice([CriticalityLevel.MEDIUM, CriticalityLevel.HIGH])
                
                asset = Asset(
                    asset_id=f"AST-{asset_counter:03d}",
                    unit_id=unit.unit_id,
                    asset_tag=f"{unit.unit_id}-{asset_class.value.upper()}-001",
                    name=f"{unit.unit_name} {asset_class.value.replace('_', ' ').title()}",
                    asset_class=asset_class,
                    manufacturer=manufacturer,
                    model=model,
                    installation_date=unit.commissioning_date,
                    criticality=criticality,
                    operational_status=OperationalStatus.OPERATIONAL
                )
                self.assets.append(asset)
                asset_counter += 1
    
    def generate_components(self) -> None:
        """Generate components for major assets"""
        component_counter = 1
        
        component_types = {
            AssetClass.GAS_TURBINE: ["Compressor Blades", "Combustor", "Turbine Blades", "Bearing Assembly"],
            AssetClass.STEAM_TURBINE: ["HP Turbine Section", "LP Turbine Section", "Governor Valve", "Bearing Assembly"],
            AssetClass.GENERATOR: ["Rotor", "Stator", "Exciter", "Cooling System"],
            AssetClass.BOILER: ["Economizer", "Superheater", "Reheater", "Steam Drum"],
            AssetClass.PUMP: ["Impeller", "Shaft", "Bearing Assembly", "Seal Assembly"]
        }
        
        for asset in self.assets:
            if asset.asset_class in component_types:
                types = component_types[asset.asset_class]
                num_components = random.randint(2, len(types))
                selected_types = random.sample(types, num_components)
                
                for comp_type in selected_types:
                    component = Component(
                        component_id=f"CMP-{component_counter:03d}",
                        asset_id=asset.asset_id,
                        component_name=f"{asset.name} - {comp_type}",
                        component_type=comp_type,
                        manufacturer=asset.manufacturer,
                        model=f"{asset.model}-{comp_type.replace(' ', '').upper()}",
                        criticality=random.choice([CriticalityLevel.MEDIUM, CriticalityLevel.HIGH]),
                        installation_date=asset.installation_date,
                        status=OperationalStatus.OPERATIONAL
                    )
                    self.components.append(component)
                    component_counter += 1
    
    def generate_maintenance_plans(self) -> None:
        """Generate maintenance plans for assets"""
        plan_counter = 1
        
        for asset in self.assets:
            # Critical assets get more maintenance plans
            num_plans = 2 if asset.criticality == CriticalityLevel.CRITICAL else 1
            
            for i in range(num_plans):
                plan_type = MaintenanceType.PREVENTIVE if i == 0 else random.choice(list(MaintenanceType))
                frequency = random.choice([MaintenanceFrequency.MONTHLY, MaintenanceFrequency.QUARTERLY, 
                                         MaintenanceFrequency.SEMI_ANNUALLY, MaintenanceFrequency.ANNUALLY])
                
                last_exec = datetime.now() - timedelta(days=random.randint(30, 365))
                
                # Calculate next due based on frequency
                if frequency == MaintenanceFrequency.MONTHLY:
                    next_due = last_exec + timedelta(days=30)
                elif frequency == MaintenanceFrequency.QUARTERLY:
                    next_due = last_exec + timedelta(days=90)
                elif frequency == MaintenanceFrequency.SEMI_ANNUALLY:
                    next_due = last_exec + timedelta(days=180)
                else:  # ANNUALLY
                    next_due = last_exec + timedelta(days=365)
                
                plan = MaintenancePlan(
                    maintenance_plan_id=f"MP-{plan_counter:03d}",
                    asset_id=asset.asset_id,
                    plan_name=f"{asset.name} {plan_type.value.title()} Maintenance",
                    maintenance_type=plan_type,
                    frequency=frequency,
                    last_execution_date=last_exec,
                    next_due_date=next_due,
                    status="active"
                )
                self.maintenance_plans.append(plan)
                plan_counter += 1
    
    def generate_scenario_data(self) -> None:
        """Generate connected scenario data with causal relationships"""
        
        # Scenario A: Turbine Component Failure Chain
        # Find a gas turbine asset
        gas_turbine = next((asset for asset in self.assets if asset.asset_class == AssetClass.GAS_TURBINE), None)
        if gas_turbine:
            self._create_turbine_failure_scenario(gas_turbine)
        
        # Scenario B: Heat Rate Degradation
        # Find a generating unit for heat rate tests  
        gas_turbine_unit = next((unit for unit in self.generating_units if unit.unit_type == UnitType.GAS_TURBINE), None)
        if gas_turbine_unit:
            self._create_heat_rate_scenario(gas_turbine_unit)
        
        # Scenario C: Repeated Asset Failures
        # Find a pump asset for repeated failures
        pump_asset = next((asset for asset in self.assets if asset.asset_class == AssetClass.PUMP), None)
        if pump_asset:
            self._create_repeated_failure_scenario(pump_asset)
        
        # Generate additional routine inspections and work orders
        self._generate_routine_inspections()
        self._generate_routine_work_orders()
        self._generate_outage_events()
    
    def _create_turbine_failure_scenario(self, turbine_asset: Asset) -> None:
        """Create a realistic turbine failure scenario"""
        base_time = datetime.now() - timedelta(days=60)
        
        # Step 1: Routine inspection finds abnormal vibration
        inspection = Inspection(
            inspection_id=f"INS-{len(self.inspections) + 1:03d}",
            asset_id=turbine_asset.asset_id,
            inspection_date=base_time,
            inspection_type=InspectionType.ROUTINE,
            inspector="John Smith",
            condition=ConditionRating.FAIR,
            findings="Elevated vibration levels detected at 2X running frequency. Recommend further investigation.",
            severity=SeverityLevel.MEDIUM,
            recommended_action="Schedule detailed vibration analysis and component inspection"
        )
        self.inspections.append(inspection)
        
        # Step 2: Component failure occurs 2 weeks later
        failure = FailureEvent(
            failure_id=f"FAIL-{len(self.failure_events) + 1:03d}",
            asset_id=turbine_asset.asset_id,
            failure_date=base_time + timedelta(days=14),
            failure_mode="Compressor Blade Liberation",
            severity=SeverityLevel.HIGH,
            description="Multiple compressor blades failed due to high cycle fatigue. Unit automatically tripped on high vibration.",
            root_cause="Blade fatigue failure due to high cycle stress and foreign object damage",
            downtime_hours=120.0,
            estimated_cost=850000.0,
            actual_cost=920000.0,
            status="resolved"
        )
        self.failure_events.append(failure)
        
        # Step 3: Emergency work order created
        work_order = WorkOrder(
            work_order_id=f"WO-{len(self.work_orders) + 1:03d}",
            asset_id=turbine_asset.asset_id,
            failure_id=failure.failure_id,
            created_date=base_time + timedelta(days=14, hours=2),
            scheduled_date=base_time + timedelta(days=15),
            completion_date=base_time + timedelta(days=19),
            work_type=WorkOrderType.EMERGENCY,
            priority=WorkOrderPriority.CRITICAL,
            status=WorkOrderStatus.COMPLETED,
            description="Replace damaged compressor blades and perform rotor balancing",
            labor_hours=96.0,
            material_cost=720000.0,
            total_cost=920000.0
        )
        self.work_orders.append(work_order)
    
    def _create_heat_rate_scenario(self, unit: GeneratingUnit) -> None:
        """Create heat rate degradation scenario"""
        base_time = datetime.now() - timedelta(days=180)
        baseline_hr = 7800.0  # BTU/kWh baseline
        
        # Generate series of heat rate tests showing degradation
        test_dates = [base_time + timedelta(days=i*30) for i in range(6)]
        heat_rates = [7800, 7820, 7850, 7890, 7935, 7980]  # Degrading performance
        
        for i, (test_date, hr) in enumerate(zip(test_dates, heat_rates)):
            deviation = ((hr - baseline_hr) / baseline_hr) * 100
            
            test = HeatRateTest(
                test_id=f"HRT-{len(self.heat_rate_tests) + 1:03d}",
                unit_id=unit.unit_id,
                test_date=test_date,
                measured_heat_rate=hr,
                baseline_heat_rate=baseline_hr,
                deviation_percentage=round(deviation, 2),
                test_status="valid",
                observations=f"Heat rate trending upward, {deviation:.1f}% above baseline" if i > 2 else "Within acceptable limits"
            )
            self.heat_rate_tests.append(test)
    
    def _create_repeated_failure_scenario(self, pump_asset: Asset) -> None:
        """Create repeated failure scenario for a pump"""
        base_time = datetime.now() - timedelta(days=200)
        
        # First failure - seal failure
        failure1 = FailureEvent(
            failure_id=f"FAIL-{len(self.failure_events) + 1:03d}",
            asset_id=pump_asset.asset_id,
            failure_date=base_time,
            failure_mode="Mechanical Seal Failure",
            severity=SeverityLevel.MEDIUM,
            description="Mechanical seal failed causing external leakage",
            root_cause="Normal wear and tear",
            downtime_hours=8.0,
            estimated_cost=5000.0,
            actual_cost=4800.0,
            status="resolved"
        )
        self.failure_events.append(failure1)
        
        # Work order for first failure
        wo1 = WorkOrder(
            work_order_id=f"WO-{len(self.work_orders) + 1:03d}",
            asset_id=pump_asset.asset_id,
            failure_id=failure1.failure_id,
            created_date=base_time + timedelta(hours=1),
            scheduled_date=base_time + timedelta(days=1),
            completion_date=base_time + timedelta(days=1, hours=8),
            work_type=WorkOrderType.CORRECTIVE,
            priority=WorkOrderPriority.HIGH,
            status=WorkOrderStatus.COMPLETED,
            description="Replace mechanical seal assembly",
            labor_hours=8.0,
            material_cost=3200.0,
            total_cost=4800.0
        )
        self.work_orders.append(wo1)
        
        # Second failure 90 days later - bearing failure
        failure2 = FailureEvent(
            failure_id=f"FAIL-{len(self.failure_events) + 1:03d}",
            asset_id=pump_asset.asset_id,
            failure_date=base_time + timedelta(days=90),
            failure_mode="Bearing Failure",
            severity=SeverityLevel.HIGH,
            description="Thrust bearing failure causing shaft misalignment and excessive vibration",
            root_cause="Inadequate lubrication and alignment issues",
            downtime_hours=24.0,
            estimated_cost=12000.0,
            actual_cost=13500.0,
            status="resolved"
        )
        self.failure_events.append(failure2)
    
    def _generate_routine_inspections(self) -> None:
        """Generate routine inspections for assets"""
        inspection_counter = len(self.inspections) + 1
        
        for asset in self.assets[:15]:  # Generate for first 15 assets
            # Generate 1-3 inspections per asset over the past year
            num_inspections = random.randint(1, 3)
            
            for _ in range(num_inspections):
                inspection_date = datetime.now() - timedelta(days=random.randint(30, 365))
                condition = random.choices(
                    [ConditionRating.EXCELLENT, ConditionRating.GOOD, ConditionRating.FAIR, ConditionRating.POOR],
                    weights=[0.2, 0.5, 0.25, 0.05]
                )[0]
                
                severity = SeverityLevel.LOW
                if condition == ConditionRating.POOR:
                    severity = SeverityLevel.HIGH
                elif condition == ConditionRating.FAIR:
                    severity = SeverityLevel.MEDIUM
                
                findings = self._generate_inspection_findings(asset.asset_class, condition)
                
                inspection = Inspection(
                    inspection_id=f"INS-{inspection_counter:03d}",
                    asset_id=asset.asset_id,
                    inspection_date=inspection_date,
                    inspection_type=random.choice(list(InspectionType)),
                    inspector=random.choice(["John Smith", "Sarah Johnson", "Mike Davis", "Lisa Wilson"]),
                    condition=condition,
                    findings=findings,
                    severity=severity,
                    recommended_action="Continue monitoring" if condition in [ConditionRating.EXCELLENT, ConditionRating.GOOD] else "Schedule maintenance"
                )
                self.inspections.append(inspection)
                inspection_counter += 1
    
    def _generate_inspection_findings(self, asset_class: AssetClass, condition: ConditionRating) -> str:
        """Generate realistic inspection findings based on asset type and condition"""
        findings_map = {
            AssetClass.GAS_TURBINE: {
                ConditionRating.EXCELLENT: "All parameters within normal operating ranges. No visible signs of wear.",
                ConditionRating.GOOD: "Minor surface oxidation on hot gas path components. Within acceptable limits.",
                ConditionRating.FAIR: "Moderate blade tip wear observed. Recommend monitoring vibration trends.",
                ConditionRating.POOR: "Significant blade damage and high vibration levels detected."
            },
            AssetClass.PUMP: {
                ConditionRating.EXCELLENT: "Pump operating smoothly with no leakage or unusual noise.",
                ConditionRating.GOOD: "Minor seal weepage observed. Flow and pressure normal.",
                ConditionRating.FAIR: "Increased bearing temperature and slight vibration noted.",
                ConditionRating.POOR: "Excessive vibration and bearing noise. Seal leakage present."
            }
        }
        
        default_findings = {
            ConditionRating.EXCELLENT: "Asset in excellent condition with no issues identified.",
            ConditionRating.GOOD: "Asset in good condition with minor maintenance items noted.",
            ConditionRating.FAIR: "Asset shows signs of wear requiring attention.",
            ConditionRating.POOR: "Asset requires immediate maintenance attention."
        }
        
        return findings_map.get(asset_class, default_findings).get(condition, "Inspection completed.")
    
    def _generate_routine_work_orders(self) -> None:
        """Generate routine maintenance work orders"""
        wo_counter = len(self.work_orders) + 1
        
        for asset in self.assets[:20]:  # Generate for first 20 assets
            # Generate 1-2 work orders per asset
            num_orders = random.randint(1, 2)
            
            for _ in range(num_orders):
                created_date = datetime.now() - timedelta(days=random.randint(10, 180))
                
                work_order = WorkOrder(
                    work_order_id=f"WO-{wo_counter:03d}",
                    asset_id=asset.asset_id,
                    failure_id=None,
                    created_date=created_date,
                    scheduled_date=created_date + timedelta(days=random.randint(1, 14)),
                    completion_date=created_date + timedelta(days=random.randint(1, 21)) if random.random() < 0.8 else None,
                    work_type=random.choice([WorkOrderType.PREVENTIVE, WorkOrderType.CORRECTIVE]),
                    priority=random.choices([WorkOrderPriority.LOW, WorkOrderPriority.MEDIUM, WorkOrderPriority.HIGH], 
                                          weights=[0.3, 0.5, 0.2])[0],
                    status=random.choices([WorkOrderStatus.COMPLETED, WorkOrderStatus.IN_PROGRESS, WorkOrderStatus.SCHEDULED], 
                                        weights=[0.7, 0.2, 0.1])[0],
                    description=f"Routine maintenance on {asset.name}",
                    labor_hours=random.uniform(4.0, 16.0),
                    material_cost=random.uniform(500.0, 5000.0),
                    total_cost=random.uniform(1000.0, 8000.0)
                )
                self.work_orders.append(work_order)
                wo_counter += 1
    
    def _generate_outage_events(self) -> None:
        """Generate outage events for generating units"""
        outage_counter = 1
        
        for unit in self.generating_units[:6]:  # Generate for first 6 units
            # Generate 1-2 outages per unit
            num_outages = random.randint(1, 2)
            
            for _ in range(num_outages):
                start_date = datetime.now() - timedelta(days=random.randint(30, 200))
                duration = random.uniform(8.0, 168.0)  # 8 hours to 1 week
                
                outage = OutageEvent(
                    outage_id=f"OUT-{outage_counter:03d}",
                    unit_id=unit.unit_id,
                    outage_type=random.choice(list(OutageType)),
                    start_date=start_date,
                    end_date=start_date + timedelta(hours=duration),
                    duration_hours=duration,
                    cause=random.choice([
                        "Planned maintenance", "Equipment failure", "Grid stability issue",
                        "Fuel supply interruption", "Environmental constraints"
                    ]),
                    status="completed",
                    estimated_generation_loss_mwh=unit.capacity_mw * duration,
                    estimated_cost=random.uniform(50000.0, 500000.0)
                )
                self.outage_events.append(outage)
                outage_counter += 1
    
    def generate_all_data(self) -> None:
        """Generate all synthetic utility data"""
        print("Generating synthetic utility data...")
        
        self.generate_utility_data()
        print(f"Generated {len(self.utilities)} utility")
        
        self.generate_power_plants()
        print(f"Generated {len(self.power_plants)} power plants")
        
        self.generate_generating_units()
        print(f"Generated {len(self.generating_units)} generating units")
        
        self.generate_assets()
        print(f"Generated {len(self.assets)} assets")
        
        self.generate_components()
        print(f"Generated {len(self.components)} components")
        
        self.generate_maintenance_plans()
        print(f"Generated {len(self.maintenance_plans)} maintenance plans")
        
        self.generate_scenario_data()
        print(f"Generated scenario data:")
        print(f"  - {len(self.inspections)} inspections")
        print(f"  - {len(self.failure_events)} failure events") 
        print(f"  - {len(self.work_orders)} work orders")
        print(f"  - {len(self.outage_events)} outage events")
        print(f"  - {len(self.heat_rate_tests)} heat rate tests")
    
    def write_csv_files(self, data_dir: Path) -> None:
        """Write all data to CSV files"""
        data_dir.mkdir(exist_ok=True)
        
        # Write each entity type to CSV
        datasets = [
            ("utilities.csv", self.utilities),
            ("power_plants.csv", self.power_plants),
            ("generating_units.csv", self.generating_units),
            ("assets.csv", self.assets),
            ("components.csv", self.components),
            ("inspections.csv", self.inspections),
            ("failure_events.csv", self.failure_events),
            ("work_orders.csv", self.work_orders),
            ("maintenance_plans.csv", self.maintenance_plans),
            ("outage_events.csv", self.outage_events),
            ("heat_rate_tests.csv", self.heat_rate_tests)
        ]
        
        for filename, data in datasets:
            if data:
                filepath = data_dir / filename
                self._write_csv(filepath, data)
                print(f"Written {len(data)} records to {filename}")
    
    def _write_csv(self, filepath: Path, data: List[BaseModel]) -> None:
        """Write pydantic models to CSV file"""
        if not data:
            return
            
        with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
            # Get field names from the first model
            fieldnames = list(data[0].dict().keys())
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            writer.writeheader()
            for item in data:
                row_dict = item.dict()
                # Convert datetime objects to ISO strings
                for key, value in row_dict.items():
                    if isinstance(value, (datetime, date)):
                        row_dict[key] = value.isoformat()
                writer.writerow(row_dict)


def main():
    """Main function to generate synthetic utility data"""
    generator = UtilityDataGenerator()
    generator.generate_all_data()
    
    # Write to data directory
    data_dir = Path(__file__).parent.parent.parent / "data" / "synthetic"
    generator.write_csv_files(data_dir)
    
    print("\nData generation completed!")
    print(f"Files written to: {data_dir}")


if __name__ == "__main__":
    main()