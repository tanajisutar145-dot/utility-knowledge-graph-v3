"""
Command-line interface for data ingestion operations
"""

import sys
import argparse
from pathlib import Path

from .data_generator import main as generate_data
from .data_validator import main as validate_data


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(description='Utility data ingestion tools')
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Generate data command
    generate_parser = subparsers.add_parser('generate', help='Generate synthetic utility data')
    
    # Validate data command  
    validate_parser = subparsers.add_parser('validate', help='Validate utility data')
    
    args = parser.parse_args()
    
    if args.command == 'generate':
        print("Generating synthetic utility data...")
        generate_data()
    elif args.command == 'validate':
        print("Validating utility data...")
        success = validate_data()
        sys.exit(0 if success else 1)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()