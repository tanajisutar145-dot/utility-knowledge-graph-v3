"""
Groq LLM client for AI model integration
"""

from groq import Groq
from typing import Optional
import logging

from app.core.config import settings

logger = logging.getLogger(__name__)


class GroqClient:
    """Client for Groq Large Language Model operations"""
    
    def __init__(self):
        self._client = None
        
    def _get_client(self) -> Optional[Groq]:
        """Get Groq client instance, initialize if needed"""
        if not settings.groq_api_key:
            logger.warning("Groq API key not configured")
            return None
            
        if self._client is None:
            try:
                self._client = Groq(api_key=settings.groq_api_key)
            except Exception as e:
                logger.error(f"Failed to initialize Groq client: {e}")
                return None
                
        return self._client
    
    def is_configured(self) -> bool:
        """Check if Groq is properly configured"""
        return bool(settings.groq_api_key)
    
    def chat_completion(
        self, 
        system_prompt: str, 
        user_prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 2000
    ) -> Optional[str]:
        """Perform a chat completion using Groq"""
        client = self._get_client()
        if not client:
            return None
            
        try:
            response = client.chat.completions.create(
                model=settings.groq_model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=temperature,
                max_tokens=max_tokens
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Groq chat completion failed: {e}")
            return None


# Global Groq client instance
groq_client = GroqClient()