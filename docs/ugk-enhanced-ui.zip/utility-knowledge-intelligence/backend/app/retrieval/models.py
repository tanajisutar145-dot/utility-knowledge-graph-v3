"""
Models for semantic retrieval and graph expansion
"""

from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime


class SemanticSearchResult(BaseModel):
    """Result from vector similarity search"""
    chunk_id: str = Field(..., description="Unique chunk identifier")
    document_id: str = Field(..., description="Parent document identifier")
    document_title: str = Field(..., description="Document title")
    text: str = Field(..., description="Chunk text content")
    score: float = Field(..., description="Similarity score (0.0 to 1.0)")
    source: Optional[str] = Field(None, description="Document source")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")


class GraphEntity(BaseModel):
    """Graph entity with properties and relationships"""
    entity_id: str = Field(..., description="Entity identifier")
    entity_type: str = Field(..., description="Entity type/label")
    properties: Dict[str, Any] = Field(default_factory=dict, description="Entity properties")


class GraphRelationship(BaseModel):
    """Graph relationship between entities"""
    source_id: str = Field(..., description="Source entity ID")
    target_id: str = Field(..., description="Target entity ID")
    relationship_type: str = Field(..., description="Relationship type")
    source_type: str = Field(..., description="Source entity type")
    target_type: str = Field(..., description="Target entity type")
    properties: Dict[str, Any] = Field(default_factory=dict, description="Relationship properties")


class GraphEvidence(BaseModel):
    """Structured graph evidence from expansion"""
    entities: List[GraphEntity] = Field(default_factory=list, description="Graph entities")
    relationships: List[GraphRelationship] = Field(default_factory=list, description="Graph relationships")


class RetrievalResult(BaseModel):
    """Complete retrieval result with semantic and graph evidence"""
    query: str = Field(..., description="Original user query")
    semantic_results: List[SemanticSearchResult] = Field(default_factory=list, description="Vector search results")
    graph_evidence: GraphEvidence = Field(default_factory=GraphEvidence, description="Graph expansion results")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Retrieval metadata")


class RetrievalRequest(BaseModel):
    """Request for semantic retrieval with graph expansion"""
    query: str = Field(..., description="Natural language query")
    top_k: int = Field(5, description="Number of top chunks to retrieve", ge=1, le=20)
    graph_depth: int = Field(1, description="Graph expansion depth", ge=0, le=3)
    min_similarity: float = Field(0.0, description="Minimum similarity threshold", ge=0.0, le=1.0)
    include_metadata: bool = Field(True, description="Include additional metadata in results")


class RetrievalConfig(BaseModel):
    """Configuration for retrieval operations"""
    default_top_k: int = 5
    max_top_k: int = 20
    default_graph_depth: int = 1
    max_graph_depth: int = 3
    default_similarity_threshold: float = 0.0
    max_expansion_entities: int = 100
    max_expansion_relationships: int = 200