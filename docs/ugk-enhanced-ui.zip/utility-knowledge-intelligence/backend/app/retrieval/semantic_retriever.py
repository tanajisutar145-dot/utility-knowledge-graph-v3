"""
Semantic retrieval service using vector search and graph expansion
"""

import logging
from typing import List, Dict, Any, Optional, Set, Tuple
import time

from app.graph.neo4j_client import neo4j_client
from app.services.embedding_service import embedding_service
from .models import (
    SemanticSearchResult, GraphEntity, GraphRelationship, 
    GraphEvidence, RetrievalResult, RetrievalRequest, RetrievalConfig
)

logger = logging.getLogger(__name__)


class SemanticRetriever:
    """Service for semantic retrieval with graph expansion"""
    
    def __init__(self):
        self.neo4j_client = neo4j_client
        self.embedding_service = embedding_service
        self.config = RetrievalConfig()
    
    def _convert_neo4j_types(self, obj):
        """Convert Neo4j types to JSON-serializable types"""
        if isinstance(obj, dict):
            return {key: self._convert_neo4j_types(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_neo4j_types(item) for item in obj]
        elif hasattr(obj, 'iso_format'):  # Neo4j DateTime
            return obj.iso_format()
        elif hasattr(obj, '__str__') and 'neo4j' in str(type(obj)):
            return str(obj)
        else:
            return obj
    
    def retrieve(self, request: RetrievalRequest) -> RetrievalResult:
        """
        Perform complete semantic retrieval with graph expansion
        
        Args:
            request: Retrieval request with query and parameters
            
        Returns:
            Complete retrieval result with semantic and graph evidence
        """
        start_time = time.time()
        
        logger.info(f"Starting semantic retrieval for query: '{request.query}'")
        
        # Step 1: Generate query embedding
        try:
            query_embedding = self.embedding_service.embed_text(request.query)
            logger.debug(f"Generated query embedding with dimension: {len(query_embedding)}")
        except Exception as e:
            logger.error(f"Failed to generate query embedding: {e}")
            return RetrievalResult(
                query=request.query,
                metadata={"error": f"Embedding generation failed: {e}"}
            )
        
        # Step 2: Perform vector search
        try:
            semantic_results = self._vector_search(
                query_embedding, 
                request.top_k, 
                request.min_similarity
            )
            logger.info(f"Vector search returned {len(semantic_results)} results")
        except Exception as e:
            logger.error(f"Vector search failed: {e}")
            return RetrievalResult(
                query=request.query,
                metadata={"error": f"Vector search failed: {e}"}
            )
        
        # Step 3: Graph expansion (if requested and results exist)
        graph_evidence = GraphEvidence()
        if request.graph_depth > 0 and semantic_results:
            try:
                graph_evidence = self._expand_graph(semantic_results, request.graph_depth)
                logger.info(f"Graph expansion found {len(graph_evidence.entities)} entities, {len(graph_evidence.relationships)} relationships")
            except Exception as e:
                logger.error(f"Graph expansion failed: {e}")
                # Continue with semantic results even if graph expansion fails
        
        # Step 4: Assemble final result
        execution_time = time.time() - start_time
        
        metadata = {
            "execution_time": execution_time,
            "top_k": request.top_k,
            "graph_depth": request.graph_depth,
            "min_similarity": request.min_similarity,
            "retrieval_method": "vector+graph",
            "semantic_results_count": len(semantic_results),
            "graph_entities_count": len(graph_evidence.entities),
            "graph_relationships_count": len(graph_evidence.relationships)
        }
        
        result = RetrievalResult(
            query=request.query,
            semantic_results=semantic_results,
            graph_evidence=graph_evidence,
            metadata=metadata
        )
        
        logger.info(f"Retrieval completed in {execution_time:.3f}s")
        return result
    
    def _vector_search(
        self, 
        query_embedding: List[float], 
        top_k: int, 
        min_similarity: float
    ) -> List[SemanticSearchResult]:
        """
        Perform vector similarity search against chunk embeddings
        
        Args:
            query_embedding: Query vector
            top_k: Number of results to return
            min_similarity: Minimum similarity threshold
            
        Returns:
            List of semantic search results
        """
        # Neo4j vector search using current SEARCH syntax
        search_query = """
        MATCH (node:Chunk)
          SEARCH node IN (
            VECTOR INDEX chunk_embedding_index
            FOR $query_embedding
            LIMIT $top_k
          ) SCORE AS score
        WHERE score >= $min_similarity
        MATCH (d:Document)-[:HAS_CHUNK]->(node)
        RETURN 
            node.chunk_id as chunk_id,
            d.document_id as document_id,
            d.title as document_title,
            d.source as source,
            node.text as text,
            score as similarity_score,
            {
                document_type: d.document_type,
                created_date: d.created_date,
                source_reference: d.source_reference
            } as metadata
        ORDER BY score DESC
        """
        
        try:
            results = self.neo4j_client.execute_query(search_query, {
                "top_k": top_k,
                "query_embedding": query_embedding,
                "min_similarity": min_similarity
            })
            
            # Convert to semantic search results
            semantic_results = []
            for result in results:
                # Convert Neo4j types to JSON-serializable types
                metadata = result.get('metadata', {})
                if metadata:
                    # Convert Neo4j DateTime objects to ISO strings
                    for key, value in metadata.items():
                        if hasattr(value, 'iso_format'):  # Neo4j DateTime
                            metadata[key] = value.iso_format()
                        elif hasattr(value, '__str__') and 'neo4j' in str(type(value)):
                            metadata[key] = str(value)
                
                semantic_result = SemanticSearchResult(
                    chunk_id=result['chunk_id'],
                    document_id=result['document_id'],
                    document_title=result['document_title'] or 'Untitled',
                    text=result['text'],
                    score=float(result['similarity_score']),
                    source=result.get('source'),
                    metadata=metadata
                )
                semantic_results.append(semantic_result)
            
            return semantic_results
            
        except Exception as e:
            logger.error(f"Vector search query failed: {e}")
            raise
    
    def _expand_graph(
        self, 
        semantic_results: List[SemanticSearchResult], 
        depth: int
    ) -> GraphEvidence:
        """
        Expand graph from retrieved chunks to find related entities
        
        Args:
            semantic_results: Results from vector search
            depth: Maximum expansion depth
            
        Returns:
            Graph evidence with entities and relationships
        """
        entities: Dict[str, GraphEntity] = {}
        relationships: List[GraphRelationship] = []
        
        # Get document IDs from semantic results
        document_ids = list(set(result.document_id for result in semantic_results))
        chunk_ids = list(set(result.chunk_id for result in semantic_results))
        
        logger.debug(f"Expanding graph from {len(document_ids)} documents and {len(chunk_ids)} chunks")
        
        # Step 1: Find entities directly linked to documents
        if document_ids:
            doc_entities = self._get_document_linked_entities(document_ids)
            entities.update(doc_entities)
            
            doc_relationships = self._get_document_relationships(document_ids)
            relationships.extend(doc_relationships)
        
        # Step 2: Expand from linked entities (if depth > 1)
        if depth > 1 and entities:
            entity_ids = list(entities.keys())
            expanded_entities, expanded_relationships = self._expand_from_entities(
                entity_ids, depth - 1
            )
            entities.update(expanded_entities)
            relationships.extend(expanded_relationships)
        
        # Limit results to prevent excessive data
        limited_entities = list(entities.values())[:self.config.max_expansion_entities]
        limited_relationships = relationships[:self.config.max_expansion_relationships]
        
        return GraphEvidence(
            entities=limited_entities,
            relationships=limited_relationships
        )
    
    def _get_document_linked_entities(self, document_ids: List[str]) -> Dict[str, GraphEntity]:
        """Get entities directly linked to documents"""
        query = """
        MATCH (d:Document)-[r]->(e)
        WHERE d.document_id IN $document_ids 
          AND type(r) STARTS WITH 'ABOUT_'
        RETURN 
            CASE 
                WHEN e.asset_id IS NOT NULL THEN e.asset_id
                WHEN e.failure_id IS NOT NULL THEN e.failure_id
                WHEN e.unit_id IS NOT NULL THEN e.unit_id
                WHEN e.inspection_id IS NOT NULL THEN e.inspection_id
                WHEN e.work_order_id IS NOT NULL THEN e.work_order_id
                ELSE elementId(e)
            END as entity_id,
            labels(e)[0] as entity_type,
            properties(e) as properties
        """
        
        try:
            results = self.neo4j_client.execute_query(query, {"document_ids": document_ids})
            
            entities = {}
            for result in results:
                entity_id = str(result['entity_id'])
                # Convert Neo4j types in properties
                properties = self._convert_neo4j_types(result['properties'])
                entity = GraphEntity(
                    entity_id=entity_id,
                    entity_type=result['entity_type'],
                    properties=properties
                )
                entities[entity_id] = entity
            
            return entities
            
        except Exception as e:
            logger.error(f"Failed to get document linked entities: {e}")
            return {}
    
    def _get_document_relationships(self, document_ids: List[str]) -> List[GraphRelationship]:
        """Get relationships from documents to entities"""
        query = """
        MATCH (d:Document)-[r]->(e)
        WHERE d.document_id IN $document_ids 
          AND type(r) STARTS WITH 'ABOUT_'
        RETURN 
            d.document_id as source_id,
            CASE 
                WHEN e.asset_id IS NOT NULL THEN e.asset_id
                WHEN e.failure_id IS NOT NULL THEN e.failure_id
                WHEN e.unit_id IS NOT NULL THEN e.unit_id
                WHEN e.inspection_id IS NOT NULL THEN e.inspection_id
                WHEN e.work_order_id IS NOT NULL THEN e.work_order_id
                ELSE elementId(e)
            END as target_id,
            type(r) as relationship_type,
            'Document' as source_type,
            labels(e)[0] as target_type,
            properties(r) as properties
        """
        
        try:
            results = self.neo4j_client.execute_query(query, {"document_ids": document_ids})
            
            relationships = []
            for result in results:
                # Convert Neo4j types in properties
                properties = self._convert_neo4j_types(result.get('properties', {}))
                relationship = GraphRelationship(
                    source_id=result['source_id'],
                    target_id=str(result['target_id']),
                    relationship_type=result['relationship_type'],
                    source_type=result['source_type'],
                    target_type=result['target_type'],
                    properties=properties
                )
                relationships.append(relationship)
            
            return relationships
            
        except Exception as e:
            logger.error(f"Failed to get document relationships: {e}")
            return []
    
    def _expand_from_entities(
        self, 
        entity_ids: List[str], 
        remaining_depth: int
    ) -> Tuple[Dict[str, GraphEntity], List[GraphRelationship]]:
        """
        Expand graph from existing entities to find neighbors
        
        Args:
            entity_ids: List of entity IDs to expand from
            remaining_depth: Remaining expansion depth
            
        Returns:
            Tuple of (new_entities, new_relationships)
        """
        if remaining_depth <= 0:
            return {}, []
        
        # Find entities connected to our current entities
        query = """
        MATCH (e1)-[r]->(e2)
        WHERE (
            e1.asset_id IN $entity_ids OR 
            e1.failure_id IN $entity_ids OR 
            e1.unit_id IN $entity_ids OR
            e1.inspection_id IN $entity_ids OR
            e1.work_order_id IN $entity_ids
        )
        AND NOT e2:Document AND NOT e2:Chunk
        RETURN 
            CASE 
                WHEN e1.asset_id IS NOT NULL THEN e1.asset_id
                WHEN e1.failure_id IS NOT NULL THEN e1.failure_id
                WHEN e1.unit_id IS NOT NULL THEN e1.unit_id
                WHEN e1.inspection_id IS NOT NULL THEN e1.inspection_id
                WHEN e1.work_order_id IS NOT NULL THEN e1.work_order_id
                ELSE elementId(e1)
            END as source_id,
            CASE 
                WHEN e2.asset_id IS NOT NULL THEN e2.asset_id
                WHEN e2.failure_id IS NOT NULL THEN e2.failure_id
                WHEN e2.unit_id IS NOT NULL THEN e2.unit_id
                WHEN e2.inspection_id IS NOT NULL THEN e2.inspection_id
                WHEN e2.work_order_id IS NOT NULL THEN e2.work_order_id
                ELSE elementId(e2)
            END as target_id,
            type(r) as relationship_type,
            labels(e1)[0] as source_type,
            labels(e2)[0] as target_type,
            properties(e1) as source_properties,
            properties(e2) as target_properties,
            properties(r) as rel_properties
        LIMIT 50
        """
        
        try:
            results = self.neo4j_client.execute_query(query, {"entity_ids": entity_ids})
            
            entities = {}
            relationships = []
            
            for result in results:
                source_id = str(result['source_id'])
                target_id = str(result['target_id'])
                
                # Add source entity if not already present
                if source_id not in entities:
                    source_properties = self._convert_neo4j_types(result['source_properties'])
                    entities[source_id] = GraphEntity(
                        entity_id=source_id,
                        entity_type=result['source_type'],
                        properties=source_properties
                    )
                
                # Add target entity
                if target_id not in entities:
                    target_properties = self._convert_neo4j_types(result['target_properties'])
                    entities[target_id] = GraphEntity(
                        entity_id=target_id,
                        entity_type=result['target_type'],
                        properties=target_properties
                    )
                
                # Add relationship
                rel_properties = self._convert_neo4j_types(result.get('rel_properties', {}))
                relationship = GraphRelationship(
                    source_id=source_id,
                    target_id=target_id,
                    relationship_type=result['relationship_type'],
                    source_type=result['source_type'],
                    target_type=result['target_type'],
                    properties=rel_properties
                )
                relationships.append(relationship)
            
            return entities, relationships
            
        except Exception as e:
            logger.error(f"Failed to expand from entities: {e}")
            return {}, []


# Global semantic retriever instance
semantic_retriever = SemanticRetriever()