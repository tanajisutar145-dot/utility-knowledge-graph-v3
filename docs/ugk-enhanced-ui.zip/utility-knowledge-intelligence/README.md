# Utility Knowledge Intelligence

A grounded enterprise knowledge graph and GraphRAG intelligence system combining domain ontology, document ingestion, vector embeddings, Neo4j graph storage, Groq LLM reasoning, and verified operational intelligence.

## 🚀 Key Features

1. **Executive Intelligence Dashboard**: Live fleet-wide operational telemetry, KPI metrics, maintenance audits, generating unit health, and vectorized document counts.
2. **Interactive Knowledge Graph Explorer**: Cytoscape.js-powered visual exploration of Neo4j entities, dynamic neighbor expansion, relationship inspection, and entity telemetry.
3. **Semantic Search & Evidence Exploration**: Vector similarity search using `BAAI/bge-small-en-v1.5` embeddings, cosine distance ranking, and multi-hop graph evidence expansion.
4. **GraphRAG Intelligence Chat**: Multi-turn utility reasoning combining vector-retrieved text chunks with Neo4j graph subgraphs, LLM synthesis via Groq, and fact verification.
5. **Document Intelligence & Upload Management**: Ingestion of operational documents, chunking, hash-based deduplication, embedding generation, linked entity extraction, and safe deletion.
6. **Asset Inventory & Relational Inspection**: Power plant, unit, asset, and component hierarchy tracking with inspection findings, failure histories, and maintenance records.
7. **System Health Monitoring**: Live status monitoring of FastAPI backend, Neo4j database, and Groq LLM connectivity with non-blocking manual and auto-refresh.

---

## 🏗️ Technology Stack

- **Frontend**:
  - React 18, TypeScript 4.9.4, Create React App (CRA)
  - Material UI (MUI v5)
  - React Router v6
  - Cytoscape.js (Interactive graph layout and rendering)
  - Axios (Centralized API client)
- **Backend**:
  - FastAPI (Python 3.10+)
  - Neo4j Graph Database 5.x (Bolt driver)
  - Sentence Transformers (`BAAI/bge-small-en-v1.5`, 384 dimensions)
  - Neo4j Vector Index (`chunk_embedding_index`)
  - Groq LLM API (`llama-3.3-70b-versatile` / `llama-3.1-8b-instant`)

---

## 🛠️ Prerequisites & Environment Variables

### Prerequisites
- Python 3.10+
- Node.js 18+ and npm
- Running Neo4j instance (version 5.x with APOC or vector index capability)
- Groq Cloud API Key (`GROQ_API_KEY`)

### Backend Environment Configuration
Configure `backend/.env`:

```env
# Neo4j Graph Database
NEO4J_URI=bolt://localhost:7687
NEO4J_USERNAME=neo4j
NEO4J_PASSWORD=your_secure_password
NEO4J_DATABASE=neo4j

# LLM Configuration
GROQ_API_KEY=your_groq_api_key
GROQ_MODEL=llama-3.3-70b-versatile

# Embedding Model
EMBEDDING_MODEL=BAAI/bge-small-en-v1.5
EMBEDDING_DIMENSION=384
```

---

## 🚀 Running the Application

### 1. Backend Service (Port 8000)

```bash
cd backend

# Create and activate virtual environment
python -m venv venv
# Windows:
.\venv\Scripts\activate
# Linux/macOS:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Start FastAPI development server
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

- Live API: `http://localhost:8000`
- Interactive Swagger UI: `http://localhost:8000/docs`

### 2. Frontend Application (Port 3000)

```bash
cd frontend

# Install dependencies
npm install

# Start Create React App dev server (proxies API requests to http://localhost:8000)
npm start
```

- Frontend Application: `http://localhost:3000`

---

## 📚 Centralized API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/health` | System health check (backend, Neo4j, Groq) |
| `GET` | `/api/dashboard/summary` | Live executive KPIs and operational summaries |
| `GET` | `/api/graph/overview` | Graph node and relationship counts by type |
| `GET` | `/api/graph/explore` | Filtered graph node and relationship retrieval |
| `GET` | `/api/graph/node/{node_id}` | Detailed node properties, connected counts, and grounding documents |
| `GET` | `/api/graph/node/{node_id}/neighbors` | Direct connected neighbors and relationship edges |
| `POST` | `/api/search/retrieve` | Semantic vector search with multi-hop graph expansion |
| `POST` | `/api/intelligence/ask` | GraphRAG question answering with verification |
| `GET` | `/api/documents/overview` | Document and chunk counts, vector indexing stats |
| `GET` | `/api/documents/` | Paginated document list with search and type filter |
| `GET` | `/api/documents/{document_id}` | Document content, chunks, and linked Neo4j entities |
| `POST` | `/api/documents/upload` | Multipart file upload (`.pdf`, `.xlsx`, `.csv`, `.docx`, `.txt`, `.json` up to 5 MB) |
| `DELETE`| `/api/documents/{document_id}` | Detach delete document and associated chunks from Neo4j |
| `GET` | `/api/assets/overview` | Asset fleet statistics (criticality, status, classes) |
| `GET` | `/api/assets/` | Filtered asset listing |
| `GET` | `/api/assets/{asset_id}` | Asset details, components, inspections, work orders, outages |

---

## 📄 Document Ingestion Rules & Multi-Format Architecture

- **Supported Formats**:
  - **PDF (`.pdf`)**: Page-by-page text extraction via PyMuPDF (`fitz`), preserving page numbers and document metadata. Scanned/image-only PDFs are automatically detected with clear OCR-required notices.
  - **Excel (`.xlsx`)**: Tabular extraction via `openpyxl` operating in `data_only=True` and `read_only=True` mode (reads cached formula values, strictly disables macro execution). Groups rows into record-aware batches with worksheet and row-range provenance.
  - **CSV (`.csv`)**: Multi-encoding fallback (UTF-8, UTF-8-sig, Latin-1, CP1252), dialect and delimiter detection via `csv.Sniffer`, and bounded row-range metadata.
  - **Word (`.docx`)**: Structure extraction via `python-docx` maintaining document ordering across paragraphs, heading hierarchies (`Heading 1`, `Heading 2`), and tabular data.
  - **Plain Text (`.txt`)**: Baseline sentence-aware extraction with multi-encoding fallback.
  - **JSON (`.json`)**: Schema-aware parsing preserving both standard Document objects and structured nested dictionaries/arrays.
- **Legacy Formats**: Legacy Excel (`.xls`) files are safely rejected with a clear instruction to convert to `.xlsx` or `.csv`.
- **Upload Size Limit**: Configurable via `MAX_UPLOAD_SIZE_BYTES` (defaults to 5 MB).
- **Structure-Aware Chunking**: Chunks preserve source-level provenance (`page_number`, `sheet_name`, `row_range`, `section_title`, `format`, `source_filename`) directly as properties on Neo4j `Chunk` nodes.
- **Embeddings**: Automatic 384-dimensional dense vectors generated via Sentence Transformers (`BAAI/bge-small-en-v1.5`) and indexed in `chunk_embedding_index`.
- **Deduplication**: SHA-256 content hashing guarantees idempotency and prevents duplicate ingestion.
- **Deletion Safety**: Documents and their associated chunks are safely detached and deleted from Neo4j upon user confirmation.

---

## 🧪 Testing and Production Build

### Frontend Tests & Build

```bash
cd frontend

# Run frontend test suite (12 suites, 152 tests)
npm test -- --watchAll=false

# Run production build
npm run build
```

### Backend Unit & Regression Tests

```bash
cd backend

# Run parser unit tests
python -m unittest tests/test_parsers.py

# Run API regression tests
python -m unittest tests/test_documents_and_assets.py
```

---

## ⚠️ Known Limitations & Compatibility Notes

1. **Scanned PDFs & OCR**: Scanned or image-only PDFs are accurately detected and flagged with an extraction warning that OCR is required. Mock or fake OCR is intentionally avoided to preserve evidence integrity.
2. **Spreadsheet Formulas**: Excel files are parsed using cached formula results (`data_only=True`). Formula evaluation and VBA macro execution are strictly disabled for security.
3. **Legacy Formats**: Binary Excel 97-2003 (`.xls`) is not supported due to format vulnerabilities and compatibility constraints.
4. **TypeScript 4.9.4 & `@types/d3-dispatch`**: `@types/d3-dispatch` contains syntax that may trigger warnings with TypeScript 4.9.4 standalone compiler checks, but does not prevent `npm run build` or Jest test suite execution. Dependencies have been intentionally preserved to avoid regression.